"""
Publication-quality plotting utilities for research papers.
Pre-configured for IEEE, ACL, NeurIPS and general academic venues.

SCAFFOLD — Use directly or customize via # TODO: FILL sections.
"""

import os
import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# ============================================================
# Try imports — graceful fallback
# ============================================================

try:
    import matplotlib
    matplotlib.use('Agg')  # Non-interactive backend for servers
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    HAS_MPL = True
except ImportError:
    HAS_MPL = False
    logger.warning("matplotlib not installed. Plotting disabled.")

try:
    import numpy as np
    HAS_NP = True
except ImportError:
    HAS_NP = False


# ============================================================
# Academic Style Configuration
# ============================================================

# Colorblind-safe palette (Tol's qualitative)
COLORS = [
    '#332288',  # indigo
    '#88CCEE',  # cyan
    '#44AA99',  # teal
    '#117733',  # green
    '#999933',  # olive
    '#DDCC77',  # sand
    '#CC6677',  # rose
    '#882255',  # wine
]

COLORS_TWO = ['#0077BB', '#EE7733']  # blue vs orange (proposed vs baseline)

HATCHES = ['///', '\\\\\\', '...', 'xxx', '+++', 'ooo', '---', '|||']

# Standard figure sizes
SIZES = {
    'ieee_col': (3.25, 2.5),
    'ieee_page': (6.875, 3.5),
    'ieee_square': (3.25, 3.25),
    'acl_col': (3.3, 2.5),
    'acl_page': (6.75, 3.5),
    'neurips_col': (5.5, 3.5),
    'neurips_page': (5.5, 4.0),
    'general_col': (3.5, 2.75),
    'general_page': (7.0, 3.5),
}


def apply_academic_style():
    """Apply publication-quality matplotlib style. Call once at start."""
    if not HAS_MPL:
        return

    matplotlib.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['Times New Roman', 'DejaVu Serif'],
        'font.size': 10,
        'axes.titlesize': 11,
        'axes.labelsize': 10,
        'xtick.labelsize': 9,
        'ytick.labelsize': 9,
        'legend.fontsize': 9,
        'text.usetex': False,
        'mathtext.fontset': 'stix',
        'lines.linewidth': 1.5,
        'lines.markersize': 5,
        'axes.linewidth': 0.8,
        'axes.grid': False,
        'axes.spines.top': False,
        'axes.spines.right': False,
        'grid.alpha': 0.3,
        'grid.linewidth': 0.5,
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'savefig.bbox': 'tight',
        'savefig.pad_inches': 0.05,
        'legend.frameon': False,
        'legend.borderpad': 0.3,
    })


# ============================================================
# Plot: Model Comparison Bar Chart
# ============================================================

def plot_model_comparison(models, scores, errors=None, metric_name="Score",
                          save_path="results/figures/model_comparison.pdf",
                          fig_size='ieee_col', highlight_best=True):
    """Bar chart comparing models with optional error bars.

    Args:
        models: List of model names.
        scores: List of scores.
        errors: List of std/CI values (optional).
        metric_name: Y-axis label.
        save_path: Output path (PDF recommended).
        fig_size: Key from SIZES dict or (w, h) tuple.
        highlight_best: Bold-outline the best bar.
    """
    if not HAS_MPL:
        return

    apply_academic_style()
    size = SIZES.get(fig_size, fig_size)
    fig, ax = plt.subplots(figsize=size)

    x = range(len(models))
    colors = COLORS[:len(models)]

    bars = ax.bar(x, scores, yerr=errors, capsize=3,
                  color=colors, edgecolor='black', linewidth=0.5,
                  error_kw={'linewidth': 0.8, 'capthick': 0.8})

    # Highlight best
    if highlight_best and scores:
        best_idx = scores.index(max(scores))
        bars[best_idx].set_edgecolor('#000000')
        bars[best_idx].set_linewidth(2.0)

    ax.set_xticks(x)
    ax.set_xticklabels(models, rotation=30, ha='right')
    ax.set_ylabel(metric_name)

    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    fig.savefig(save_path, format=save_path.split('.')[-1])
    plt.close()
    logger.info(f"Saved: {save_path}")


# ============================================================
# Plot: Training Curves
# ============================================================

def plot_training_curves(history, metrics=None,
                         save_path="results/figures/training_curves.pdf",
                         fig_size='ieee_page'):
    """Line plots for training and validation curves.

    Args:
        history: Dict with 'train' and 'val' lists of metric dicts.
        metrics: Which metrics to plot (default: all found in history).
        save_path: Output path.
        fig_size: Key from SIZES dict or (w, h) tuple.
    """
    if not HAS_MPL or not HAS_NP:
        return

    apply_academic_style()

    # Determine metrics to plot
    if metrics is None:
        metrics = list(history.get('train', [{}])[0].keys()) if history.get('train') else ['loss']

    n_metrics = len(metrics)
    size = SIZES.get(fig_size, fig_size)
    fig, axes = plt.subplots(1, n_metrics, figsize=(size[0], size[1]))
    if n_metrics == 1:
        axes = [axes]

    for ax, metric_name in zip(axes, metrics):
        # Training curve
        if history.get('train'):
            train_vals = [ep.get(metric_name) for ep in history['train'] if metric_name in ep]
            if train_vals:
                ax.plot(range(1, len(train_vals) + 1), train_vals,
                        color=COLORS_TWO[0], linewidth=1.5, label='Train')

        # Validation curve
        if history.get('val'):
            val_vals = [ep.get(metric_name) for ep in history['val'] if metric_name in ep]
            if val_vals:
                ax.plot(range(1, len(val_vals) + 1), val_vals,
                        color=COLORS_TWO[1], linewidth=1.5, label='Val')

        ax.set_xlabel('Epoch')
        ax.set_ylabel(metric_name.replace('_', ' ').title())
        ax.legend()

    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    fig.savefig(save_path, format=save_path.split('.')[-1])
    plt.close()
    logger.info(f"Saved: {save_path}")


# ============================================================
# Plot: Multi-Seed Confidence Band
# ============================================================

def plot_multi_seed_curves(all_histories, metric_name='loss', split='val',
                           save_path="results/figures/multi_seed.pdf",
                           fig_size='ieee_col', label="Model"):
    """Line plot with shaded std band across multiple seeds.

    Args:
        all_histories: List of history dicts (one per seed).
        metric_name: Which metric to plot.
        split: 'train' or 'val'.
        save_path: Output path.
        fig_size: Key from SIZES dict.
        label: Legend label.
    """
    if not HAS_MPL or not HAS_NP:
        return

    apply_academic_style()

    # Collect values per epoch
    all_vals = []
    for hist in all_histories:
        vals = [ep.get(metric_name) for ep in hist.get(split, []) if metric_name in ep]
        all_vals.append(vals)

    # Truncate to shortest
    min_len = min(len(v) for v in all_vals)
    all_vals = np.array([v[:min_len] for v in all_vals])

    means = np.mean(all_vals, axis=0)
    stds = np.std(all_vals, axis=0)
    epochs = np.arange(1, min_len + 1)

    size = SIZES.get(fig_size, fig_size)
    fig, ax = plt.subplots(figsize=size)

    ax.plot(epochs, means, color=COLORS_TWO[0], linewidth=1.5, label=label)
    ax.fill_between(epochs, means - stds, means + stds, alpha=0.2, color=COLORS_TWO[0])

    ax.set_xlabel('Epoch')
    ax.set_ylabel(metric_name.replace('_', ' ').title())
    ax.legend()

    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    fig.savefig(save_path, format=save_path.split('.')[-1])
    plt.close()
    logger.info(f"Saved: {save_path}")


# ============================================================
# Plot: Ablation Grouped Bar Chart
# ============================================================

def plot_ablation(configs, metrics_dict,
                  save_path="results/figures/ablation.pdf",
                  fig_size='ieee_page'):
    """Grouped bar chart for ablation study.

    Args:
        configs: List of config/ablation names.
        metrics_dict: {'Metric1': [values_per_config], 'Metric2': [...]}
        save_path: Output path.
        fig_size: Key from SIZES dict.
    """
    if not HAS_MPL or not HAS_NP:
        return

    apply_academic_style()
    size = SIZES.get(fig_size, fig_size)
    fig, ax = plt.subplots(figsize=size)

    n_groups = len(configs)
    n_metrics = len(metrics_dict)
    bar_width = 0.8 / n_metrics

    for i, (metric_name, values) in enumerate(metrics_dict.items()):
        x = [j + i * bar_width for j in range(n_groups)]
        ax.bar(x, values, width=bar_width, label=metric_name,
               color=COLORS[i % len(COLORS)], edgecolor='black', linewidth=0.4)

    ax.set_xticks([j + bar_width * (n_metrics - 1) / 2 for j in range(n_groups)])
    ax.set_xticklabels(configs, rotation=30, ha='right')
    ax.legend()

    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    fig.savefig(save_path, format=save_path.split('.')[-1])
    plt.close()
    logger.info(f"Saved: {save_path}")


# ============================================================
# Plot: Confusion Matrix
# ============================================================

def plot_confusion_matrix(cm, class_names,
                          save_path="results/figures/confusion_matrix.pdf",
                          fig_size='ieee_square', normalize=True):
    """Confusion matrix heatmap.

    Args:
        cm: 2D array (num_classes x num_classes).
        class_names: List of class names.
        save_path: Output path.
        fig_size: Key from SIZES dict.
        normalize: Whether to normalize rows to percentages.
    """
    if not HAS_MPL or not HAS_NP:
        return

    apply_academic_style()
    cm = np.array(cm)

    if normalize:
        row_sums = cm.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1  # avoid division by zero
        cm_plot = cm.astype('float') / row_sums
    else:
        cm_plot = cm

    size = SIZES.get(fig_size, fig_size)
    fig, ax = plt.subplots(figsize=size)

    im = ax.imshow(cm_plot, cmap='Blues', vmin=0, vmax=1 if normalize else None)

    ax.set_xticks(range(len(class_names)))
    ax.set_yticks(range(len(class_names)))
    ax.set_xticklabels(class_names, rotation=45, ha='right', fontsize=8)
    ax.set_yticklabels(class_names, fontsize=8)

    # Annotations
    for i in range(len(class_names)):
        for j in range(len(class_names)):
            val = cm_plot[i, j]
            color = 'white' if val > 0.5 else 'black'
            text = f'{val:.1%}' if normalize else f'{int(cm[i, j])}'
            ax.text(j, i, text, ha='center', va='center', fontsize=7, color=color)

    ax.set_xlabel('Predicted')
    ax.set_ylabel('True')
    fig.colorbar(im, ax=ax, shrink=0.8)

    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    fig.savefig(save_path, format=save_path.split('.')[-1])
    plt.close()
    logger.info(f"Saved: {save_path}")


# ============================================================
# Table: LaTeX Result Table
# ============================================================

def generate_latex_table(results_data, metric_names, model_names=None,
                         caption="", label="tab:results",
                         save_path="results/tables/main_results.tex",
                         bold_best=True, higher_is_better=None):
    """Generate a LaTeX table from results.

    Args:
        results_data: Dict of {model_name: {metric: "mean±std" or float}}.
        metric_names: List of metric column names.
        model_names: Ordered list of model names (optional, defaults to dict keys).
        caption: Table caption.
        label: LaTeX label.
        save_path: Output path.
        bold_best: Bold the best value in each column.
        higher_is_better: Dict {metric: bool} or single bool for all.
    """
    if model_names is None:
        model_names = list(results_data.keys())

    if isinstance(higher_is_better, bool):
        higher_is_better = {m: higher_is_better for m in metric_names}
    elif higher_is_better is None:
        higher_is_better = {m: True for m in metric_names}

    # Parse mean values for comparison
    def parse_mean(val):
        if isinstance(val, (int, float)):
            return float(val)
        if isinstance(val, str) and '±' in val:
            return float(val.split('±')[0].strip())
        return float(val)

    # Find best per metric
    best_vals = {}
    for metric in metric_names:
        values = []
        for model in model_names:
            v = results_data.get(model, {}).get(metric)
            if v is not None:
                values.append((model, parse_mean(v)))
        if values:
            if higher_is_better.get(metric, True):
                best_vals[metric] = max(values, key=lambda x: x[1])[0]
            else:
                best_vals[metric] = min(values, key=lambda x: x[1])[0]

    # Build LaTeX
    col_align = 'l' + 'c' * len(metric_names)
    lines = [
        f"\\begin{{table}}[t]",
        f"\\centering",
        f"\\caption{{{caption}}}",
        f"\\label{{{label}}}",
        f"\\begin{{tabular}}{{{col_align}}}",
        f"\\toprule",
        "Model & " + " & ".join(metric_names) + " \\\\",
        "\\midrule",
    ]

    for model in model_names:
        row = [model]
        for metric in metric_names:
            val = results_data.get(model, {}).get(metric, "—")
            val_str = str(val)
            if bold_best and best_vals.get(metric) == model:
                val_str = f"\\textbf{{{val_str}}}"
            row.append(val_str)
        lines.append(" & ".join(row) + " \\\\")

    lines.extend([
        "\\bottomrule",
        "\\end{tabular}",
        "\\end{table}",
    ])

    latex = "\n".join(lines)

    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, 'w') as f:
        f.write(latex)

    logger.info(f"Saved LaTeX table: {save_path}")
    return latex


# ============================================================
# Batch Figure Generator
# ============================================================

def generate_all_figures(config, results_dir="results/raw"):
    """Generate all standard figures from saved results.

    Reads result JSON files and produces publication-ready figures.

    Args:
        config: Full experiment config.
        results_dir: Directory containing result JSON files.

    # TODO: FILL — customize which figures to generate for your project.
    """
    apply_academic_style()
    figures_dir = os.path.join(config.get("output_dir", "results"), "figures")
    os.makedirs(figures_dir, exist_ok=True)

    # 1. Training curves (if history exists)
    history_path = os.path.join(config.get("run_output_dir", "."), "training_history.json")
    if os.path.exists(history_path):
        with open(history_path, 'r') as f:
            history = json.load(f)
        plot_training_curves(
            history,
            save_path=os.path.join(figures_dir, "training_curves.pdf")
        )

    # TODO: FILL — add more figure generation calls
    # Example:
    # plot_model_comparison(
    #     models=['Baseline', 'Ours', 'Ours+Aug'],
    #     scores=[0.82, 0.89, 0.91],
    #     errors=[0.02, 0.01, 0.015],
    #     metric_name='F1 Score',
    #     save_path=os.path.join(figures_dir, 'model_comparison.pdf')
    # )

    logger.info(f"All figures saved to {figures_dir}")


# ============================================================
# Entry Point
# ============================================================

if __name__ == "__main__":
    from src.config import load_config
    config = load_config()
    generate_all_figures(config)
