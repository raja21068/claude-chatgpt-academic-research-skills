"""
Training loop scaffold for research experiments.
Handles epoch loop, logging, checkpointing, early stopping, and multi-seed runs.

SCAFFOLD — Claude fills # TODO: FILL sections only.
"""

import os
import sys
import time
import json
import logging
from pathlib import Path

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.config import load_config, save_config
from src.utils import set_seed, setup_logging, log_environment, timer, EarlyStopping, get_device
from src.data_loader import create_dataloaders, verify_data_integrity

logger = logging.getLogger(__name__)


# ============================================================
# Model Factory
# ============================================================

def create_model(config):
    """Instantiate the model/method from config.

    Args:
        config: Full experiment config dict.

    Returns:
        model: The model instance.

    # TODO: FILL — import and instantiate your model
    # Example:
    #   from src.model import MyModel
    #   model = MyModel(**config['model'])
    #   return model.to(get_device(config['device']))
    """
    raise NotImplementedError("Implement create_model() for your method.")


def create_optimizer(model, config):
    """Create optimizer from config.

    Args:
        model: The model instance.
        config: Full experiment config dict.

    Returns:
        optimizer: The optimizer instance.
    """
    import torch.optim as optim

    train_cfg = config["training"]
    lr = train_cfg["learning_rate"]
    wd = train_cfg["weight_decay"]

    optimizers = {
        "adam": lambda: optim.Adam(model.parameters(), lr=lr, weight_decay=wd),
        "adamw": lambda: optim.AdamW(model.parameters(), lr=lr, weight_decay=wd),
        "sgd": lambda: optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=wd),
    }

    optimizer_name = train_cfg.get("optimizer", "adam").lower()
    assert optimizer_name in optimizers, \
        f"Unknown optimizer '{optimizer_name}'. Choose from: {list(optimizers.keys())}"

    return optimizers[optimizer_name]()


def create_scheduler(optimizer, config, num_training_steps=None):
    """Create learning rate scheduler from config.

    Args:
        optimizer: The optimizer.
        config: Full experiment config dict.
        num_training_steps: Total training steps (for warmup schedulers).

    Returns:
        scheduler: The scheduler instance or None.
    """
    import torch.optim.lr_scheduler as lr_scheduler

    train_cfg = config["training"]
    sched_name = train_cfg.get("scheduler", "none").lower()
    epochs = train_cfg["epochs"]

    if sched_name == "none":
        return None
    elif sched_name == "cosine":
        return lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    elif sched_name == "step":
        return lr_scheduler.StepLR(optimizer, step_size=max(epochs // 3, 1), gamma=0.1)
    elif sched_name == "plateau":
        return lr_scheduler.ReduceLROnPlateau(
            optimizer, mode='max' if config["evaluation"]["higher_is_better"] else 'min',
            patience=5, factor=0.5
        )
    else:
        logger.warning(f"Unknown scheduler '{sched_name}', skipping.")
        return None


# ============================================================
# Train One Epoch
# ============================================================

def train_one_epoch(model, train_loader, optimizer, config, epoch):
    """Train for one epoch.

    Args:
        model: The model instance.
        train_loader: Training data loader.
        optimizer: The optimizer.
        config: Full config dict.
        epoch: Current epoch number.

    Returns:
        dict: Training metrics for this epoch (e.g., {'loss': 0.5}).

    # TODO: FILL — implement the training step for your method.
    # Template:
    #   model.train()
    #   total_loss = 0
    #   for batch in train_loader:
    #       optimizer.zero_grad()
    #       inputs, targets = batch['input'].to(device), batch['target'].to(device)
    #       outputs = model(inputs)
    #       loss = criterion(outputs, targets)
    #       loss.backward()
    #       if config['training']['grad_clip'] > 0:
    #           torch.nn.utils.clip_grad_norm_(model.parameters(), config['training']['grad_clip'])
    #       optimizer.step()
    #       total_loss += loss.item()
    #   return {'loss': total_loss / len(train_loader)}
    """
    raise NotImplementedError("Implement train_one_epoch() for your method.")


# ============================================================
# Validate
# ============================================================

def validate(model, val_loader, config):
    """Run validation and compute metrics.

    Args:
        model: The model instance.
        val_loader: Validation data loader.
        config: Full config dict.

    Returns:
        dict: Validation metrics (e.g., {'loss': 0.3, 'accuracy': 0.85}).

    # TODO: FILL — implement validation for your method.
    # Template:
    #   model.eval()
    #   all_preds, all_targets = [], []
    #   total_loss = 0
    #   with torch.no_grad():
    #       for batch in val_loader:
    #           inputs, targets = batch['input'].to(device), batch['target'].to(device)
    #           outputs = model(inputs)
    #           loss = criterion(outputs, targets)
    #           total_loss += loss.item()
    #           all_preds.append(outputs)
    #           all_targets.append(targets)
    #   metrics = compute_metrics(all_preds, all_targets, config)
    #   metrics['loss'] = total_loss / len(val_loader)
    #   return metrics
    """
    raise NotImplementedError("Implement validate() for your method.")


# ============================================================
# Checkpointing
# ============================================================

def save_checkpoint(model, optimizer, scheduler, epoch, metrics, config, is_best=False):
    """Save a training checkpoint.

    Args:
        model: Model instance.
        optimizer: Optimizer instance.
        scheduler: Scheduler instance (or None).
        epoch: Current epoch.
        metrics: Current metrics dict.
        config: Full config dict.
        is_best: Whether this is the best model so far.
    """
    import torch

    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict() if scheduler else None,
        'metrics': metrics,
        'config': config,
    }

    # Save latest
    path = os.path.join(config["checkpoint_dir"], f"{config['experiment_name']}_latest.pt")
    torch.save(checkpoint, path)

    # Save best
    if is_best:
        best_path = os.path.join(config["checkpoint_dir"], f"{config['experiment_name']}_best.pt")
        torch.save(checkpoint, best_path)
        logger.info(f"New best model saved (epoch {epoch})")


def load_checkpoint(model, optimizer, scheduler, config):
    """Load a training checkpoint if it exists.

    Returns:
        int: Epoch to resume from (0 if no checkpoint).
    """
    import torch

    path = os.path.join(config["checkpoint_dir"], f"{config['experiment_name']}_latest.pt")
    if not os.path.exists(path):
        return 0

    checkpoint = torch.load(path, map_location=config["device"])
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    if scheduler and checkpoint['scheduler_state_dict']:
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])

    logger.info(f"Resumed from checkpoint (epoch {checkpoint['epoch']})")
    return checkpoint['epoch']


# ============================================================
# Main Training Loop
# ============================================================

def train(config):
    """Full training pipeline for a single seed.

    Args:
        config: Full experiment config dict.

    Returns:
        dict: Final results including best metrics and training history.
    """
    import torch

    # Setup
    set_seed(config["seed"])
    exp_logger = setup_logging(config["log_dir"], config["experiment_name"])
    exp_logger.info(f"Starting experiment: {config['experiment_name']} (seed={config['seed']})")

    # Log environment
    log_environment(config, exp_logger)
    save_config(config, os.path.join(config["run_output_dir"], "config.yaml"))

    # Data integrity check
    integrity = verify_data_integrity(config)
    if integrity["issues"]:
        exp_logger.warning(f"Data integrity issues: {integrity['issues']}")

    # Create components
    loaders = create_dataloaders(config)
    model = create_model(config)
    optimizer = create_optimizer(model, config)
    scheduler = create_scheduler(optimizer, config)

    # Param count
    num_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    exp_logger.info(f"Model parameters: {num_params:,}")

    # Early stopping
    eval_cfg = config["evaluation"]
    early_stopping = None
    patience = config["training"].get("early_stopping_patience", 0)
    if patience > 0:
        early_stopping = EarlyStopping(
            patience=patience,
            higher_is_better=eval_cfg["higher_is_better"]
        )

    # Resume from checkpoint if exists
    start_epoch = load_checkpoint(model, optimizer, scheduler, config)

    # Training loop
    history = {"train": [], "val": []}
    best_metric = None
    primary_metric = eval_cfg.get("primary_metric", "loss")

    for epoch in range(start_epoch, config["training"]["epochs"]):
        epoch_start = time.time()

        # Train
        train_metrics = train_one_epoch(model, loaders['train'], optimizer, config, epoch)
        history["train"].append(train_metrics)

        # Validate
        val_metrics = {}
        if loaders.get('val') and (epoch + 1) % eval_cfg.get("eval_every", 1) == 0:
            val_metrics = validate(model, loaders['val'], config)
            history["val"].append(val_metrics)

            # Check best
            current_metric = val_metrics.get(primary_metric, val_metrics.get("loss", 0))
            is_best = False
            if best_metric is None:
                is_best = True
            elif eval_cfg["higher_is_better"]:
                is_best = current_metric > best_metric
            else:
                is_best = current_metric < best_metric

            if is_best:
                best_metric = current_metric

            # Checkpoint
            save_checkpoint(model, optimizer, scheduler, epoch, val_metrics, config, is_best)

            # Early stopping
            if early_stopping and early_stopping(current_metric):
                exp_logger.info(f"Early stopping at epoch {epoch}")
                break

        # Scheduler step
        if scheduler:
            if isinstance(scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                if val_metrics:
                    scheduler.step(val_metrics.get(primary_metric, val_metrics.get("loss")))
            else:
                scheduler.step()

        # Log
        elapsed = time.time() - epoch_start
        lr = optimizer.param_groups[0]['lr']
        exp_logger.info(
            f"Epoch {epoch+1}/{config['training']['epochs']} | "
            f"Train Loss: {train_metrics.get('loss', 'N/A'):.4f} | "
            f"Val {primary_metric}: {val_metrics.get(primary_metric, 'N/A')} | "
            f"LR: {lr:.2e} | {elapsed:.1f}s"
        )

    # Save training history
    history_path = os.path.join(config["run_output_dir"], "training_history.json")
    with open(history_path, 'w') as f:
        json.dump(history, f, indent=2, default=str)

    results = {
        "experiment_name": config["experiment_name"],
        "seed": config["seed"],
        "best_metric": best_metric,
        "primary_metric": primary_metric,
        "total_epochs": epoch + 1,
        "num_params": num_params,
    }

    results_path = os.path.join(config["run_output_dir"], "results.json")
    with open(results_path, 'w') as f:
        json.dump(results, f, indent=2, default=str)

    exp_logger.info(f"Training complete. Best {primary_metric}: {best_metric}")
    return results


# ============================================================
# Multi-Seed Runner
# ============================================================

def run_multi_seed(config):
    """Run the experiment across multiple seeds and aggregate results.

    Args:
        config: Full experiment config dict.

    Returns:
        dict: Aggregated results with mean and std.
    """
    seeds = config.get("seeds", [config["seed"]])
    all_results = []

    for seed in seeds:
        seed_config = {**config, "seed": seed}
        seed_config["experiment_name"] = f"{config['experiment_name']}_seed{seed}"
        result = train(seed_config)
        all_results.append(result)

    # Aggregate
    if all_results:
        import numpy as np
        best_metrics = [r["best_metric"] for r in all_results if r["best_metric"] is not None]
        if best_metrics:
            aggregated = {
                "experiment_name": config["experiment_name"],
                "seeds": seeds,
                "primary_metric": config["evaluation"]["primary_metric"],
                "mean": float(np.mean(best_metrics)),
                "std": float(np.std(best_metrics)),
                "min": float(np.min(best_metrics)),
                "max": float(np.max(best_metrics)),
                "per_seed": all_results,
            }

            agg_path = os.path.join(config["output_dir"], f"{config['experiment_name']}_aggregated.json")
            with open(agg_path, 'w') as f:
                json.dump(aggregated, f, indent=2, default=str)

            logger.info(
                f"Multi-seed results: {aggregated['mean']:.4f} ± {aggregated['std']:.4f} "
                f"(seeds: {seeds})"
            )
            return aggregated

    return {"error": "No valid results collected."}


# ============================================================
# Entry Point
# ============================================================

if __name__ == "__main__":
    config = load_config()

    if len(config.get("seeds", [])) > 1:
        results = run_multi_seed(config)
    else:
        results = train(config)

    print(json.dumps(results, indent=2, default=str))
