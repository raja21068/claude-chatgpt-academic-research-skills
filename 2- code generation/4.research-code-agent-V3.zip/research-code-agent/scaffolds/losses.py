"""
Loss Function Library for Research Code.
Tested implementations with explicit shape contracts and validation.

SCAFFOLD — Claude selects the relevant loss and fills # TODO: FILL sections.
Each loss includes a toy test to verify correctness before use.

Usage:
    1. Identify which loss the paper uses.
    2. Copy the relevant class into src/losses.py.
    3. Fill any # TODO: FILL markers.
    4. Run the built-in test to verify.
"""

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


# ============================================================
# 1. LABEL SMOOTHING CROSS ENTROPY
# ============================================================
# Use for: classification with regularization
# Papers: any paper mentioning "label smoothing"

class LabelSmoothingCrossEntropy(nn.Module):
    """Cross-entropy with label smoothing.

    Shape contract:
        logits:  (batch, num_classes) — raw logits, NOT softmax
        targets: (batch,) — integer class indices

    Args:
        smoothing: Label smoothing factor (0.0 = no smoothing, 0.1 = common).
    """

    def __init__(self, smoothing=0.1, reduction='mean'):
        super().__init__()
        assert 0.0 <= smoothing < 1.0, f"Smoothing must be in [0, 1), got {smoothing}"
        self.smoothing = smoothing
        self.reduction = reduction

    def forward(self, logits, targets):
        assert logits.dim() == 2, f"Expected logits shape (B, C), got {logits.shape}"
        assert targets.dim() == 1, f"Expected targets shape (B,), got {targets.shape}"

        num_classes = logits.size(1)
        log_probs = F.log_softmax(logits, dim=-1)

        # Smooth labels
        smooth_targets = torch.full_like(log_probs, self.smoothing / (num_classes - 1))
        smooth_targets.scatter_(1, targets.unsqueeze(1), 1.0 - self.smoothing)

        loss = -(smooth_targets * log_probs).sum(dim=-1)

        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        return loss


# ============================================================
# 2. FOCAL LOSS
# ============================================================
# Use for: imbalanced classification
# Papers: RetinaNet, any class-imbalanced detection/classification

class FocalLoss(nn.Module):
    """Focal loss for addressing class imbalance.

    Shape contract:
        logits:  (batch, num_classes) — raw logits
        targets: (batch,) — integer class indices

    Args:
        alpha: Weighting factor per class or scalar (None = no weighting).
        gamma: Focusing parameter (0 = CE, 2 = common for imbalanced).
    """

    def __init__(self, alpha=None, gamma=2.0, reduction='mean'):
        super().__init__()
        self.gamma = gamma
        self.reduction = reduction
        if alpha is not None:
            if isinstance(alpha, (list, tuple)):
                self.alpha = torch.tensor(alpha, dtype=torch.float32)
            else:
                self.alpha = alpha
        else:
            self.alpha = None

    def forward(self, logits, targets):
        assert logits.dim() == 2, f"Expected logits shape (B, C), got {logits.shape}"

        ce_loss = F.cross_entropy(logits, targets, reduction='none')
        pt = torch.exp(-ce_loss)  # probability of correct class
        focal_weight = (1 - pt) ** self.gamma

        loss = focal_weight * ce_loss

        if self.alpha is not None:
            if isinstance(self.alpha, torch.Tensor):
                alpha = self.alpha.to(logits.device)
                at = alpha[targets]
            else:
                at = self.alpha
            loss = at * loss

        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        return loss


# ============================================================
# 3. CONTRASTIVE LOSS (InfoNCE / NT-Xent)
# ============================================================
# Use for: SimCLR, MoCo, CLIP, contrastive learning
# Papers: any "contrastive loss", "InfoNCE", "NT-Xent"

class InfoNCELoss(nn.Module):
    """InfoNCE / NT-Xent contrastive loss.

    Shape contract:
        z1: (batch, embed_dim) — L2-normalized embeddings of view 1
        z2: (batch, embed_dim) — L2-normalized embeddings of view 2
        Positive pairs: z1[i] and z2[i]

    Args:
        temperature: Scaling temperature (0.07-0.5 common).
    """

    def __init__(self, temperature=0.07):
        super().__init__()
        assert temperature > 0, f"Temperature must be positive, got {temperature}"
        self.temperature = temperature

    def forward(self, z1, z2):
        assert z1.shape == z2.shape, f"Shape mismatch: z1 {z1.shape} vs z2 {z2.shape}"
        assert z1.dim() == 2, f"Expected shape (B, D), got {z1.shape}"

        B = z1.size(0)

        # Normalize (should already be normalized, but safety check)
        z1 = F.normalize(z1, dim=-1)
        z2 = F.normalize(z2, dim=-1)

        # Concatenate both views
        z = torch.cat([z1, z2], dim=0)  # (2B, D)

        # Similarity matrix
        sim = torch.matmul(z, z.T) / self.temperature  # (2B, 2B)

        # Mask out self-similarity
        mask = ~torch.eye(2 * B, dtype=torch.bool, device=z.device)
        sim = sim.masked_fill(~mask, float('-inf'))

        # Positive pairs: (i, i+B) and (i+B, i)
        labels = torch.cat([torch.arange(B, 2 * B), torch.arange(0, B)]).to(z.device)

        loss = F.cross_entropy(sim, labels)
        return loss


# ============================================================
# 4. TRIPLET LOSS
# ============================================================
# Use for: metric learning, face recognition, retrieval
# Papers: FaceNet, any "triplet loss" or "embedding learning"

class TripletLoss(nn.Module):
    """Triplet loss with margin.

    Shape contract:
        anchor:   (batch, embed_dim)
        positive: (batch, embed_dim)
        negative: (batch, embed_dim)

    Args:
        margin: Distance margin (0.2-1.0 common).
    """

    def __init__(self, margin=0.5, reduction='mean'):
        super().__init__()
        self.margin = margin
        self.reduction = reduction

    def forward(self, anchor, positive, negative):
        assert anchor.shape == positive.shape == negative.shape, \
            f"Shape mismatch: {anchor.shape}, {positive.shape}, {negative.shape}"

        pos_dist = F.pairwise_distance(anchor, positive, p=2)
        neg_dist = F.pairwise_distance(anchor, negative, p=2)

        loss = F.relu(pos_dist - neg_dist + self.margin)

        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        return loss


# ============================================================
# 5. DICE LOSS (for segmentation)
# ============================================================
# Use for: medical image segmentation, semantic segmentation
# Papers: V-Net, any segmentation paper

class DiceLoss(nn.Module):
    """Soft Dice loss for segmentation.

    Shape contract:
        logits:  (batch, num_classes, H, W) — raw logits
        targets: (batch, H, W) — integer class indices
                 OR (batch, num_classes, H, W) — one-hot

    Args:
        smooth: Smoothing factor to prevent division by zero.
    """

    def __init__(self, smooth=1.0, reduction='mean'):
        super().__init__()
        self.smooth = smooth
        self.reduction = reduction

    def forward(self, logits, targets):
        num_classes = logits.size(1)
        probs = F.softmax(logits, dim=1)

        # Convert targets to one-hot if needed
        if targets.dim() == logits.dim() - 1:
            targets_onehot = F.one_hot(targets.long(), num_classes).permute(0, 3, 1, 2).float()
        else:
            targets_onehot = targets.float()

        # Compute Dice per class
        dims = (0, 2, 3)  # reduce over batch, H, W
        intersection = (probs * targets_onehot).sum(dim=dims)
        cardinality = probs.sum(dim=dims) + targets_onehot.sum(dim=dims)

        dice = (2.0 * intersection + self.smooth) / (cardinality + self.smooth)
        loss = 1.0 - dice

        if self.reduction == 'mean':
            return loss.mean()
        return loss


# ============================================================
# 6. KL DIVERGENCE (for VAE, knowledge distillation)
# ============================================================
# Use for: VAE latent regularization, distillation

class KLDivergenceLoss(nn.Module):
    """KL divergence for VAE (assumes diagonal Gaussian).

    Shape contract:
        mu:     (batch, latent_dim)
        logvar: (batch, latent_dim)

    Returns:
        KL(q(z|x) || N(0,1))
    """

    def __init__(self, reduction='mean'):
        super().__init__()
        self.reduction = reduction

    def forward(self, mu, logvar):
        assert mu.shape == logvar.shape, f"Shape mismatch: mu {mu.shape} vs logvar {logvar.shape}"

        kl = -0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=-1)

        if self.reduction == 'mean':
            return kl.mean()
        elif self.reduction == 'sum':
            return kl.sum()
        return kl


# ============================================================
# 7. COMBINED / MULTI-TASK LOSS
# ============================================================
# Use for: any paper with multiple loss terms weighted by lambdas

class CombinedLoss(nn.Module):
    """Weighted combination of multiple loss functions.

    Shape contract:
        Depends on component losses. Each component receives its own inputs.

    Args:
        losses: Dict of {name: loss_module}.
        weights: Dict of {name: weight}. Missing names default to 1.0.

    Usage:
        combined = CombinedLoss(
            losses={'ce': nn.CrossEntropyLoss(), 'dice': DiceLoss()},
            weights={'ce': 1.0, 'dice': 0.5}
        )
        total = combined({'ce': (logits, targets), 'dice': (logits, targets)})
    """

    def __init__(self, losses, weights=None):
        super().__init__()
        self.losses = nn.ModuleDict(losses)
        self.weights = weights or {name: 1.0 for name in losses}

    def forward(self, inputs_dict):
        """
        Args:
            inputs_dict: Dict of {loss_name: (arg1, arg2, ...)} or {loss_name: args_tuple}
        """
        total = 0.0
        breakdown = {}

        for name, loss_fn in self.losses.items():
            if name not in inputs_dict:
                continue
            args = inputs_dict[name]
            if isinstance(args, (tuple, list)):
                value = loss_fn(*args)
            else:
                value = loss_fn(args)

            weight = self.weights.get(name, 1.0)
            weighted = weight * value
            total = total + weighted
            breakdown[name] = value.item()

        breakdown['total'] = total.item() if isinstance(total, torch.Tensor) else total
        return total, breakdown


# ============================================================
# SANITY TESTS — Run these before using any loss
# ============================================================

def run_loss_sanity_tests():
    """Verify all loss functions with toy examples."""
    if not HAS_TORCH:
        print("PyTorch not available. Skipping loss tests.")
        return

    print("Running loss sanity tests...\n")
    torch.manual_seed(42)
    B, C, D, H, W = 4, 5, 128, 16, 16  # batch, classes, embed_dim, height, width

    # 1. Label Smoothing CE
    logits = torch.randn(B, C)
    targets = torch.randint(0, C, (B,))
    loss_val = LabelSmoothingCrossEntropy(smoothing=0.1)(logits, targets)
    assert loss_val.dim() == 0 and loss_val > 0, "LabelSmoothingCE failed"
    print(f"  LabelSmoothingCE:  {loss_val.item():.4f} PASSED")

    # 2. Focal Loss
    loss_val = FocalLoss(gamma=2.0)(logits, targets)
    assert loss_val.dim() == 0 and loss_val > 0, "FocalLoss failed"
    print(f"  FocalLoss:         {loss_val.item():.4f} PASSED")

    # 3. InfoNCE
    z1 = F.normalize(torch.randn(B, D), dim=-1)
    z2 = F.normalize(torch.randn(B, D), dim=-1)
    loss_val = InfoNCELoss(temperature=0.07)(z1, z2)
    assert loss_val.dim() == 0 and loss_val > 0, "InfoNCE failed"
    print(f"  InfoNCE:           {loss_val.item():.4f} PASSED")

    # 4. Triplet Loss
    anchor = torch.randn(B, D)
    positive = anchor + torch.randn(B, D) * 0.1  # close to anchor
    negative = torch.randn(B, D)  # far from anchor
    loss_val = TripletLoss(margin=0.5)(anchor, positive, negative)
    assert loss_val.dim() == 0 and loss_val >= 0, "TripletLoss failed"
    print(f"  TripletLoss:       {loss_val.item():.4f} PASSED")

    # 5. Dice Loss
    seg_logits = torch.randn(B, C, H, W)
    seg_targets = torch.randint(0, C, (B, H, W))
    loss_val = DiceLoss()(seg_logits, seg_targets)
    assert loss_val.dim() == 0 and 0 <= loss_val <= 1, "DiceLoss failed"
    print(f"  DiceLoss:          {loss_val.item():.4f} PASSED")

    # 6. KL Divergence
    mu = torch.randn(B, D)
    logvar = torch.randn(B, D)
    loss_val = KLDivergenceLoss()(mu, logvar)
    assert loss_val.dim() == 0 and loss_val > 0, "KLDivergence failed"
    print(f"  KLDivergence:      {loss_val.item():.4f} PASSED")

    # 7. Combined Loss
    combined = CombinedLoss(
        losses={'ce': nn.CrossEntropyLoss(), 'focal': FocalLoss()},
        weights={'ce': 1.0, 'focal': 0.5}
    )
    total, breakdown = combined({'ce': (logits, targets), 'focal': (logits, targets)})
    assert total > 0, "CombinedLoss failed"
    print(f"  CombinedLoss:      {total.item():.4f} (breakdown: {breakdown}) PASSED")

    print("\nAll loss sanity tests PASSED.")


if __name__ == "__main__":
    run_loss_sanity_tests()
