"""
Architecture Pattern Library for Research Code.
Pre-built building blocks with explicit shape contracts.

SCAFFOLD — Claude selects the relevant block and fills # TODO: FILL sections.
Do NOT generate these architectures from scratch. Use these validated patterns.

Usage:
    1. Identify which pattern matches the paper's architecture.
    2. Copy the relevant class(es) into src/model.py.
    3. Fill the # TODO: FILL markers with paper-specific details.
    4. Compose blocks into the full model.
"""

import math

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


# ============================================================
# 1. RESIDUAL BLOCK (ResNet-style)
# ============================================================
# Use for: CNNs with skip connections, feature extractors
# Papers: ResNet, ResNeXt, WideResNet, any "residual" mention

class ResidualBlock(nn.Module):
    """Standard residual block with optional downsampling.

    Shape contract:
        Input:  (batch, in_channels, H, W)
        Output: (batch, out_channels, H', W')
        H' = H // stride, W' = W // stride
    """

    def __init__(self, in_channels, out_channels, stride=1, dropout=0.0):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.dropout = nn.Dropout2d(dropout) if dropout > 0 else nn.Identity()

        # Skip connection
        self.shortcut = nn.Identity()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels),
            )

    def forward(self, x):
        identity = self.shortcut(x)
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.dropout(out)
        out = self.bn2(self.conv2(out))
        out = F.relu(out + identity)
        return out


# ============================================================
# 2. MULTI-HEAD SELF-ATTENTION
# ============================================================
# Use for: Transformers, attention mechanisms, self-attention layers
# Papers: BERT, GPT, ViT, any "attention" mention

class MultiHeadSelfAttention(nn.Module):
    """Multi-head self-attention with optional masking.

    Shape contract:
        Input:  (batch, seq_len, d_model)
        Output: (batch, seq_len, d_model)
    """

    def __init__(self, d_model, num_heads, dropout=0.1):
        super().__init__()
        assert d_model % num_heads == 0, f"d_model ({d_model}) must be divisible by num_heads ({num_heads})"

        self.d_model = d_model
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads

        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.out_proj = nn.Linear(d_model, d_model)
        self.dropout = nn.Dropout(dropout)
        self.scale = math.sqrt(self.head_dim)

    def forward(self, x, mask=None):
        B, L, D = x.shape

        Q = self.q_proj(x).view(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        K = self.k_proj(x).view(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        V = self.v_proj(x).view(B, L, self.num_heads, self.head_dim).transpose(1, 2)

        # Attention scores: (B, heads, L, L)
        attn = torch.matmul(Q, K.transpose(-2, -1)) / self.scale

        if mask is not None:
            attn = attn.masked_fill(mask == 0, float('-inf'))

        attn = F.softmax(attn, dim=-1)
        attn = self.dropout(attn)

        # Apply attention to values
        out = torch.matmul(attn, V)  # (B, heads, L, head_dim)
        out = out.transpose(1, 2).contiguous().view(B, L, D)
        out = self.out_proj(out)
        return out


# ============================================================
# 3. TRANSFORMER ENCODER BLOCK
# ============================================================
# Use for: BERT-style encoders, ViT, classification transformers

class TransformerEncoderBlock(nn.Module):
    """Standard Transformer encoder block: MHSA + FFN with pre-norm.

    Shape contract:
        Input:  (batch, seq_len, d_model)
        Output: (batch, seq_len, d_model)
    """

    def __init__(self, d_model, num_heads, d_ff=None, dropout=0.1):
        super().__init__()
        d_ff = d_ff or 4 * d_model

        self.norm1 = nn.LayerNorm(d_model)
        self.attn = MultiHeadSelfAttention(d_model, num_heads, dropout)
        self.norm2 = nn.LayerNorm(d_model)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model),
            nn.Dropout(dropout),
        )

    def forward(self, x, mask=None):
        x = x + self.attn(self.norm1(x), mask)
        x = x + self.ffn(self.norm2(x))
        return x


# ============================================================
# 4. TRANSFORMER DECODER BLOCK (with cross-attention)
# ============================================================
# Use for: GPT-style decoders, seq2seq, machine translation

class TransformerDecoderBlock(nn.Module):
    """Transformer decoder block: masked self-attn + cross-attn + FFN.

    Shape contract:
        Input:  target (batch, tgt_len, d_model), memory (batch, src_len, d_model)
        Output: (batch, tgt_len, d_model)
    """

    def __init__(self, d_model, num_heads, d_ff=None, dropout=0.1):
        super().__init__()
        d_ff = d_ff or 4 * d_model

        self.norm1 = nn.LayerNorm(d_model)
        self.self_attn = MultiHeadSelfAttention(d_model, num_heads, dropout)
        self.norm2 = nn.LayerNorm(d_model)
        self.cross_attn_q = nn.Linear(d_model, d_model)
        self.cross_attn_k = nn.Linear(d_model, d_model)
        self.cross_attn_v = nn.Linear(d_model, d_model)
        self.cross_attn_out = nn.Linear(d_model, d_model)
        self.cross_attn_dropout = nn.Dropout(dropout)
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads
        self.scale = math.sqrt(self.head_dim)
        self.norm3 = nn.LayerNorm(d_model)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model),
            nn.Dropout(dropout),
        )

    def forward(self, x, memory, tgt_mask=None):
        # Masked self-attention
        x = x + self.self_attn(self.norm1(x), tgt_mask)

        # Cross-attention with encoder memory
        h = self.norm2(x)
        B, TL, D = h.shape
        _, SL, _ = memory.shape
        Q = self.cross_attn_q(h).view(B, TL, self.num_heads, self.head_dim).transpose(1, 2)
        K = self.cross_attn_k(memory).view(B, SL, self.num_heads, self.head_dim).transpose(1, 2)
        V = self.cross_attn_v(memory).view(B, SL, self.num_heads, self.head_dim).transpose(1, 2)
        attn = F.softmax(torch.matmul(Q, K.transpose(-2, -1)) / self.scale, dim=-1)
        attn = self.cross_attn_dropout(attn)
        cross_out = torch.matmul(attn, V).transpose(1, 2).contiguous().view(B, TL, D)
        x = x + self.cross_attn_out(cross_out)

        # FFN
        x = x + self.ffn(self.norm3(x))
        return x


# ============================================================
# 5. U-NET ENCODER/DECODER BLOCK
# ============================================================
# Use for: segmentation, image-to-image, denoising, diffusion

class UNetEncoderBlock(nn.Module):
    """U-Net encoder block: double conv + downsample.

    Shape contract:
        Input:  (batch, in_ch, H, W)
        Output: (batch, out_ch, H//2, W//2), skip: (batch, out_ch, H, W)
    """

    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )
        self.pool = nn.MaxPool2d(2)

    def forward(self, x):
        skip = self.conv(x)
        down = self.pool(skip)
        return down, skip


class UNetDecoderBlock(nn.Module):
    """U-Net decoder block: upsample + concat skip + double conv.

    Shape contract:
        Input:  x (batch, in_ch, H, W), skip (batch, skip_ch, 2H, 2W)
        Output: (batch, out_ch, 2H, 2W)
    """

    def __init__(self, in_channels, skip_channels, out_channels):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_channels, in_channels // 2, 2, stride=2)
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels // 2 + skip_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x, skip):
        x = self.up(x)
        # Handle size mismatch
        if x.shape != skip.shape:
            x = F.interpolate(x, size=skip.shape[2:], mode='bilinear', align_corners=False)
        x = torch.cat([x, skip], dim=1)
        return self.conv(x)


# ============================================================
# 6. GNN MESSAGE PASSING LAYER
# ============================================================
# Use for: graph neural networks, node classification, link prediction

class GraphConvLayer(nn.Module):
    """Simple GCN-style message passing layer.

    Shape contract:
        Input:  x (num_nodes, in_features), edge_index (2, num_edges)
        Output: (num_nodes, out_features)
    """

    def __init__(self, in_features, out_features, dropout=0.1):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, edge_index):
        # Simple adjacency-based aggregation
        src, dst = edge_index[0], edge_index[1]
        num_nodes = x.size(0)

        # Message: transform source features
        messages = self.linear(x[src])  # (num_edges, out_features)

        # Aggregate: sum messages to target nodes
        out = torch.zeros(num_nodes, messages.size(1), device=x.device)
        out.scatter_add_(0, dst.unsqueeze(1).expand_as(messages), messages)

        # Degree normalization
        deg = torch.zeros(num_nodes, device=x.device)
        deg.scatter_add_(0, dst, torch.ones(dst.size(0), device=x.device))
        deg = deg.clamp(min=1).unsqueeze(1)
        out = out / deg

        return self.dropout(F.relu(out))


# ============================================================
# 7. PROJECTION HEAD (for contrastive learning)
# ============================================================
# Use for: SimCLR, MoCo, BYOL, contrastive methods

class ProjectionHead(nn.Module):
    """MLP projection head for contrastive learning.

    Shape contract:
        Input:  (batch, in_dim)
        Output: (batch, out_dim) — L2 normalized
    """

    def __init__(self, in_dim, hidden_dim=None, out_dim=128):
        super().__init__()
        hidden_dim = hidden_dim or in_dim
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, out_dim),
        )

    def forward(self, x):
        x = self.net(x)
        return F.normalize(x, dim=-1)


# ============================================================
# 8. CLASSIFIER HEAD
# ============================================================
# Use for: any classification task on top of a feature extractor

class ClassifierHead(nn.Module):
    """Classification head with optional hidden layer.

    Shape contract:
        Input:  (batch, in_dim)
        Output: (batch, num_classes) — logits, NOT softmax
    """

    def __init__(self, in_dim, num_classes, hidden_dim=None, dropout=0.1):
        super().__init__()
        if hidden_dim:
            self.net = nn.Sequential(
                nn.Linear(in_dim, hidden_dim),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, num_classes),
            )
        else:
            self.net = nn.Sequential(
                nn.Dropout(dropout),
                nn.Linear(in_dim, num_classes),
            )

    def forward(self, x):
        return self.net(x)


# ============================================================
# 9. POSITIONAL ENCODING
# ============================================================
# Use for: Transformers, ViT, any sequence model needing position info

class SinusoidalPositionalEncoding(nn.Module):
    """Sinusoidal positional encoding (non-learnable).

    Shape contract:
        Input:  (batch, seq_len, d_model)
        Output: (batch, seq_len, d_model)
    """

    def __init__(self, d_model, max_len=5000, dropout=0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)

        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)  # (1, max_len, d_model)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)


class LearnablePositionalEncoding(nn.Module):
    """Learnable positional encoding (ViT-style).

    Shape contract:
        Input:  (batch, seq_len, d_model)
        Output: (batch, seq_len, d_model)
    """

    def __init__(self, d_model, max_len=5000, dropout=0.1):
        super().__init__()
        self.pos_embedding = nn.Parameter(torch.randn(1, max_len, d_model) * 0.02)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = x + self.pos_embedding[:, :x.size(1)]
        return self.dropout(x)


# ============================================================
# 10. PATCH EMBEDDING (for Vision Transformers)
# ============================================================
# Use for: ViT, DeiT, Swin-style models

class PatchEmbedding(nn.Module):
    """Convert image into patch tokens.

    Shape contract:
        Input:  (batch, channels, H, W)
        Output: (batch, num_patches, d_model)
        num_patches = (H // patch_size) * (W // patch_size)
    """

    def __init__(self, img_size=224, patch_size=16, in_channels=3, d_model=768):
        super().__init__()
        self.num_patches = (img_size // patch_size) ** 2
        self.proj = nn.Conv2d(in_channels, d_model, kernel_size=patch_size, stride=patch_size)
        self.cls_token = nn.Parameter(torch.randn(1, 1, d_model) * 0.02)

    def forward(self, x):
        B = x.shape[0]
        x = self.proj(x)                # (B, d_model, H/P, W/P)
        x = x.flatten(2).transpose(1, 2)  # (B, num_patches, d_model)
        cls = self.cls_token.expand(B, -1, -1)
        x = torch.cat([cls, x], dim=1)  # (B, 1 + num_patches, d_model)
        return x


# ============================================================
# ASSEMBLY GUIDE
# ============================================================
#
# To build a complete model, compose these blocks:
#
# CNN Classifier:
#   ResidualBlock(3, 64) → ResidualBlock(64, 128, stride=2) → ... → AdaptiveAvgPool2d → ClassifierHead
#
# Vision Transformer:
#   PatchEmbedding → LearnablePositionalEncoding → N × TransformerEncoderBlock → ClassifierHead (on CLS token)
#
# U-Net Segmentation:
#   N × UNetEncoderBlock → Bottleneck → N × UNetDecoderBlock → 1×1 Conv output
#
# BERT-style Encoder:
#   nn.Embedding → SinusoidalPositionalEncoding → N × TransformerEncoderBlock → task head
#
# Contrastive Learning:
#   Backbone (ResNet/ViT) → ProjectionHead → contrastive loss
#
# GNN:
#   N × GraphConvLayer → Readout (mean/sum) → ClassifierHead
#
# Seq2Seq:
#   Encoder: Embedding → N × TransformerEncoderBlock
#   Decoder: Embedding → N × TransformerDecoderBlock → Linear output
