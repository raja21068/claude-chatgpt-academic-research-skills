@echo off
REM ============================================================
REM One-Click Research Experiment Runner (Windows)
REM ============================================================
REM Usage:
REM   1. Place your dataset in the .\data\ folder
REM   2. Edit configs\default.yaml with your settings
REM   3. Double-click this file or run: run.bat
REM
REM This script will:
REM   - Create a conda environment (if not exists)
REM   - Install all dependencies
REM   - Verify data integrity
REM   - Train the model (multi-seed if configured)
REM   - Evaluate on test set
REM   - Generate publication-quality figures and tables
REM   - Save everything to .\results\
REM ============================================================

setlocal enabledelayedexpansion

REM --- Configuration ---
set PROJECT_NAME=experiment
REM TODO: FILL — your project name
set ENV_NAME=%PROJECT_NAME%_env
set PYTHON_VERSION=3.10
set CONFIG_FILE=configs\default.yaml
set SEEDS=42 123 456
REM TODO: FILL — your seeds

echo ============================================================
echo   Research Experiment Runner
echo   Project: %PROJECT_NAME%
echo   Config:  %CONFIG_FILE%
echo ============================================================
echo.

REM ============================================================
REM Step 1: Environment Setup
REM ============================================================
echo [INFO] Step 1/6: Setting up environment...

where conda >nul 2>nul
if %errorlevel% equ 0 (
    REM Check if env exists
    conda env list | findstr /C:"%ENV_NAME%" >nul 2>nul
    if %errorlevel% equ 0 (
        echo [OK] Conda environment '%ENV_NAME%' already exists.
    ) else (
        echo [INFO] Creating conda environment '%ENV_NAME%'...
        conda create -n %ENV_NAME% python=%PYTHON_VERSION% -y
        echo [OK] Conda environment created.
    )

    REM Activate environment
    call conda activate %ENV_NAME%
    echo [OK] Activated conda environment: %ENV_NAME%
) else (
    echo [WARN] Conda not found. Using system Python.
    if not exist ".venv" (
        echo [INFO] Creating virtual environment...
        python -m venv .venv
    )
    call .venv\Scripts\activate.bat
    echo [OK] Activated virtual environment.
)

REM ============================================================
REM Step 2: Install Dependencies
REM ============================================================
echo [INFO] Step 2/6: Installing dependencies...

pip install --upgrade pip -q
pip install -r requirements.txt -q

echo [OK] Dependencies installed.

REM Check GPU
python -c "import sys; exec(\"try:\n import torch\n if torch.cuda.is_available():\n  gpu=torch.cuda.get_device_name(0);mem=torch.cuda.get_device_properties(0).total_mem/1e9;print(f'GPU: {gpu} ({mem:.1f}GB)')\n else: print('No GPU. Using CPU.')\nexcept ImportError: print('PyTorch not installed.')\")" 2>nul

REM ============================================================
REM Step 3: Verify Data
REM ============================================================
echo.
echo [INFO] Step 3/6: Verifying data...

if exist "data\*" (
    echo [OK] Data directory found with contents.
    dir /B data\ 2>nul | findstr /R "." >nul
    if %errorlevel% neq 0 (
        echo [ERROR] Data directory is empty!
        echo [ERROR] Place your dataset in .\data\ and run again.
        pause
        exit /b 1
    )
) else (
    echo [ERROR] Data directory is empty or missing!
    echo [ERROR] Place your dataset in .\data\ and run again.
    pause
    exit /b 1
)

echo.

REM ============================================================
REM Step 4: Train
REM ============================================================
echo [INFO] Step 4/6: Training...

for %%S in (%SEEDS%) do (
    echo [INFO] Training with seed %%S...
    python -m src.train --config %CONFIG_FILE% --seed %%S --experiment_name %PROJECT_NAME%_seed%%S
    if %errorlevel% neq 0 (
        echo [ERROR] Training failed for seed %%S
        pause
        exit /b 1
    )
    echo [OK] Seed %%S training complete.
)

echo.

REM ============================================================
REM Step 5: Evaluate
REM ============================================================
echo [INFO] Step 5/6: Evaluating...

for %%S in (%SEEDS%) do (
    echo [INFO] Evaluating seed %%S...
    python -m src.evaluate --config %CONFIG_FILE% --seed %%S --experiment_name %PROJECT_NAME%_seed%%S
    if %errorlevel% neq 0 (
        echo [ERROR] Evaluation failed for seed %%S
        pause
        exit /b 1
    )
    echo [OK] Seed %%S evaluation complete.
)

echo.

REM ============================================================
REM Step 6: Generate Figures and Tables
REM ============================================================
echo [INFO] Step 6/6: Generating figures and tables...

python -c "from src.config import load_config; from utils.plotting import generate_all_figures; config=load_config('%CONFIG_FILE%', []); generate_all_figures(config)" 2>nul
if %errorlevel% equ 0 (
    echo [OK] Figures generated.
) else (
    echo [WARN] Figure generation skipped.
)

if exist "scripts\generate_tables.py" (
    python scripts\generate_tables.py --config %CONFIG_FILE%
    echo [OK] Tables generated.
) else (
    echo [WARN] Table generation script not found.
)

echo.
echo ============================================================
echo [OK] ALL DONE!
echo ============================================================
echo.
echo Results:      .\results\
echo Checkpoints:  .\checkpoints\
echo Figures:      .\results\figures\
echo Tables:       .\results\tables\
echo Logs:         .\logs\
echo.
echo To reproduce: run.bat
echo ============================================================
echo.
pause
