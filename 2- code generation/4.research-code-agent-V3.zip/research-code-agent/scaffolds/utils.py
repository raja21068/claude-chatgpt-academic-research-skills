"""
Common utilities for research experiments.
Seed management, logging, device setup, and timing.

SCAFFOLD — Claude fills # TODO: FILL sections only.
"""

import os
import sys
import time
import json
import random
import logging
import platform
from pathlib import Path
from datetime import datetime
from contextlib import contextmanager


# ============================================================
# Seed Management
# ============================================================

def set_seed(seed):
    """Set all random seeds for reproducibility.

    Args:
        seed: Integer seed value.
    """
    random.seed(seed)

    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass

    try:
        import torch
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except ImportError:
        pass

    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
    except ImportError:
        pass

    os.environ['PYTHONHASHSEED'] = str(seed)


# ============================================================
# Logging
# ============================================================

def setup_logging(log_dir, experiment_name, level=logging.INFO):
    """Configure logging to both file and console.

    Args:
        log_dir: Directory for log files.
        experiment_name: Name for the log file.
        level: Logging level.

    Returns:
        logging.Logger: Configured logger.
    """
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = os.path.join(log_dir, f"{experiment_name}_{timestamp}.log")

    # Create logger
    logger = logging.getLogger(experiment_name)
    logger.setLevel(level)
    logger.handlers = []  # Clear existing handlers

    # File handler
    fh = logging.FileHandler(log_file)
    fh.setLevel(level)

    # Console handler
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(level)

    # Format
    fmt = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    fh.setFormatter(fmt)
    ch.setFormatter(fmt)

    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger


# ============================================================
# Environment Logging
# ============================================================

def log_environment(config, logger=None):
    """Log the full experiment environment for reproducibility.

    Args:
        config: Experiment config dict.
        logger: Logger instance (prints if None).
    """
    env_info = {
        "timestamp": datetime.now().isoformat(),
        "python_version": sys.version,
        "platform": platform.platform(),
        "hostname": platform.node(),
        "config": config,
    }

    # Check for GPU
    try:
        import torch
        env_info["torch_version"] = torch.__version__
        env_info["cuda_available"] = torch.cuda.is_available()
        if torch.cuda.is_available():
            env_info["cuda_version"] = torch.version.cuda
            env_info["gpu_name"] = torch.cuda.get_device_name(0)
            env_info["gpu_count"] = torch.cuda.device_count()
            env_info["gpu_memory_gb"] = round(
                torch.cuda.get_device_properties(0).total_mem / 1e9, 2
            )
    except ImportError:
        env_info["torch_version"] = "not installed"

    try:
        import numpy as np
        env_info["numpy_version"] = np.__version__
    except ImportError:
        pass

    # Save to file
    env_path = os.path.join(config.get("run_output_dir", "."), "environment.json")
    with open(env_path, 'w') as f:
        json.dump(env_info, f, indent=2, default=str)

    msg = f"Environment logged to {env_path}"
    if logger:
        logger.info(msg)
    else:
        print(msg)

    return env_info


# ============================================================
# Results Management
# ============================================================

def save_results(results, path):
    """Save experiment results to JSON.

    Args:
        results: Dict of results (metrics, predictions, etc.).
        path: Output file path.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        json.dump(results, f, indent=2, default=str)


def load_results(path):
    """Load experiment results from JSON."""
    with open(path, 'r') as f:
        return json.load(f)


def append_to_results_log(results_log_path, entry):
    """Append a result entry to a JSONL results log.

    Args:
        results_log_path: Path to the JSONL file.
        entry: Dict with keys like experiment_name, seed, metrics, etc.
    """
    os.makedirs(os.path.dirname(results_log_path), exist_ok=True)
    entry["timestamp"] = datetime.now().isoformat()
    with open(results_log_path, 'a') as f:
        f.write(json.dumps(entry, default=str) + '\n')


# ============================================================
# Timing
# ============================================================

@contextmanager
def timer(name="Block", logger=None):
    """Context manager for timing code blocks.

    Usage:
        with timer("Training"):
            train_model(...)
    """
    start = time.time()
    yield
    elapsed = time.time() - start
    msg = f"{name} completed in {elapsed:.2f}s ({elapsed/60:.1f}min)"
    if logger:
        logger.info(msg)
    else:
        print(msg)


class EarlyStopping:
    """Early stopping to terminate training when validation metric stops improving.

    Args:
        patience: How many epochs to wait after last improvement.
        min_delta: Minimum change to qualify as an improvement.
        higher_is_better: Whether higher metric values are better.
    """
    def __init__(self, patience=10, min_delta=0.0, higher_is_better=True):
        self.patience = patience
        self.min_delta = min_delta
        self.higher_is_better = higher_is_better
        self.counter = 0
        self.best_score = None
        self.should_stop = False

    def __call__(self, score):
        if self.best_score is None:
            self.best_score = score
            return False

        if self.higher_is_better:
            improved = score > self.best_score + self.min_delta
        else:
            improved = score < self.best_score - self.min_delta

        if improved:
            self.best_score = score
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.should_stop = True

        return self.should_stop


# ============================================================
# Device Utilities
# ============================================================

def get_device(config_device="auto"):
    """Get the best available compute device.

    Args:
        config_device: 'auto', 'cuda', 'cpu', 'mps', or 'cuda:N'.

    Returns:
        torch.device or string for non-torch frameworks.
    """
    try:
        import torch
        if config_device == "auto":
            if torch.cuda.is_available():
                return torch.device("cuda")
            elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
                return torch.device("mps")
            return torch.device("cpu")
        return torch.device(config_device)
    except ImportError:
        return config_device


# ============================================================
# Quick Test
# ============================================================

if __name__ == "__main__":
    set_seed(42)
    logger = setup_logging("./logs", "test")
    logger.info("Utils module loaded successfully.")

    with timer("Test block", logger):
        time.sleep(0.1)

    es = EarlyStopping(patience=3, higher_is_better=True)
    for score in [0.5, 0.6, 0.55, 0.54, 0.53]:
        stop = es(score)
        logger.info(f"Score: {score}, Stop: {stop}")
