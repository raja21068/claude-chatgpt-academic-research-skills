"""
Evaluation pipeline scaffold for research experiments.
Loads a trained model, runs inference on test set, computes metrics, saves results.

SCAFFOLD — Claude fills # TODO: FILL sections only.
"""

import os
import sys
import json
import logging
from pathlib import Path
from collections import defaultdict

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.config import load_config
from src.utils import set_seed, setup_logging, timer, save_results
from src.data_loader import create_dataloaders

logger = logging.getLogger(__name__)


# ============================================================
# Metric Functions
# ============================================================

# TODO: FILL — implement your domain-specific metrics.
# Each metric function should follow this contract:
#
# def metric_name(predictions, targets, **kwargs):
#     """
#     Args:
#         predictions: Model predictions (list, array, or tensor).
#         targets: Ground truth labels (list, array, or tensor).
#     Returns:
#         float: The computed metric value.
#     """
#     pass
#
# Example:
# def accuracy(predictions, targets):
#     correct = sum(p == t for p, t in zip(predictions, targets))
#     return correct / len(targets)


METRIC_REGISTRY = {
    # TODO: FILL — register your metrics here
    # "accuracy": accuracy,
    # "f1_macro": lambda p, t: f1_score(t, p, average='macro'),
    # "rmse": lambda p, t: np.sqrt(np.mean((np.array(p) - np.array(t))**2)),
}


def compute_metrics(predictions, targets, metric_names):
    """Compute all requested metrics.

    Args:
        predictions: Model predictions.
        targets: Ground truth.
        metric_names: List of metric names from METRIC_REGISTRY.

    Returns:
        dict: {metric_name: value}
    """
    results = {}
    for name in metric_names:
        if name in METRIC_REGISTRY:
            try:
                results[name] = float(METRIC_REGISTRY[name](predictions, targets))
            except Exception as e:
                logger.error(f"Error computing metric '{name}': {e}")
                results[name] = None
        else:
            logger.warning(f"Unknown metric '{name}'. Available: {list(METRIC_REGISTRY.keys())}")
    return results


# ============================================================
# Metric Sanity Tests
# ============================================================

def run_metric_sanity_checks():
    """Run toy test cases to verify metric implementations.

    # TODO: FILL — add toy examples with known expected outputs.
    # Example:
    #   assert abs(accuracy([1,1,0], [1,0,0]) - 0.6667) < 0.01, "Accuracy toy test failed"
    #   assert abs(rmse([1,2,3], [1,2,4]) - 0.5774) < 0.01, "RMSE toy test failed"
    """
    logger.info("Running metric sanity checks...")

    # TODO: FILL — add your toy tests
    test_cases = [
        # ("metric_name", predictions, targets, expected_value, tolerance),
    ]

    for name, preds, targets, expected, tol in test_cases:
        if name in METRIC_REGISTRY:
            result = METRIC_REGISTRY[name](preds, targets)
            assert abs(result - expected) < tol, \
                f"Metric '{name}' sanity check FAILED: got {result}, expected {expected}"
            logger.info(f"  {name}: PASSED (got {result:.4f}, expected {expected:.4f})")

    logger.info("All metric sanity checks passed.")


# ============================================================
# Inference
# ============================================================

def run_inference(model, test_loader, config):
    """Run inference on test data and collect predictions.

    Args:
        model: Trained model instance.
        test_loader: Test data loader.
        config: Full config dict.

    Returns:
        tuple: (all_predictions, all_targets, all_metadata)

    # TODO: FILL — implement inference for your method.
    # Template:
    #   import torch
    #   model.eval()
    #   all_preds, all_targets = [], []
    #   with torch.no_grad():
    #       for batch in test_loader:
    #           inputs = batch['input'].to(config['device'])
    #           targets = batch['target']
    #           outputs = model(inputs)
    #           preds = outputs.argmax(dim=-1).cpu().tolist()  # adjust for your task
    #           all_preds.extend(preds)
    #           all_targets.extend(targets.tolist())
    #   return all_preds, all_targets, {}
    """
    raise NotImplementedError("Implement run_inference() for your method.")


# ============================================================
# Load Trained Model
# ============================================================

def load_trained_model(config, checkpoint_type="best"):
    """Load a trained model from checkpoint.

    Args:
        config: Full config dict.
        checkpoint_type: 'best' or 'latest'.

    Returns:
        model: Loaded model in eval mode.
    """
    import torch
    from src.train import create_model

    model = create_model(config)
    checkpoint_path = os.path.join(
        config["checkpoint_dir"],
        f"{config['experiment_name']}_{checkpoint_type}.pt"
    )

    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    checkpoint = torch.load(checkpoint_path, map_location=config["device"])
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()

    logger.info(f"Loaded {checkpoint_type} checkpoint from epoch {checkpoint['epoch']}")
    return model


# ============================================================
# Full Evaluation Pipeline
# ============================================================

def evaluate(config, checkpoint_type="best"):
    """Run full evaluation pipeline: load model → inference → metrics → save.

    Args:
        config: Full experiment config dict.
        checkpoint_type: 'best' or 'latest'.

    Returns:
        dict: Evaluation results.
    """
    set_seed(config["seed"])
    eval_logger = setup_logging(config["log_dir"], f"eval_{config['experiment_name']}")

    # Sanity check metrics first
    run_metric_sanity_checks()

    # Load model and data
    model = load_trained_model(config, checkpoint_type)
    loaders = create_dataloaders(config)

    if loaders.get('test') is None:
        eval_logger.error("No test data available.")
        return {"error": "No test data."}

    # Run inference
    eval_logger.info("Running inference on test set...")
    with timer("Inference", eval_logger):
        predictions, targets, metadata = run_inference(model, loaders['test'], config)

    # Compute metrics
    metric_names = config["evaluation"].get("metrics", list(METRIC_REGISTRY.keys()))
    metrics = compute_metrics(predictions, targets, metric_names)
    eval_logger.info(f"Test metrics: {metrics}")

    # Build results
    results = {
        "experiment_name": config["experiment_name"],
        "seed": config["seed"],
        "checkpoint": checkpoint_type,
        "split": "test",
        "num_samples": len(predictions),
        "metrics": metrics,
    }

    # Save results
    results_dir = os.path.join(config["output_dir"], "raw")
    os.makedirs(results_dir, exist_ok=True)

    results_path = os.path.join(results_dir, f"{config['experiment_name']}_test_results.json")
    save_results(results, results_path)
    eval_logger.info(f"Results saved to {results_path}")

    # Save raw predictions (for detailed analysis)
    preds_path = os.path.join(results_dir, f"{config['experiment_name']}_predictions.json")
    save_results({
        "predictions": predictions,
        "targets": targets,
        "metadata": metadata,
    }, preds_path)

    return results


# ============================================================
# Multi-Seed Evaluation Aggregator
# ============================================================

def aggregate_multi_seed_results(config):
    """Aggregate test results across multiple seeds.

    Reads per-seed result files and computes mean ± std for each metric.

    Args:
        config: Full config dict.

    Returns:
        dict: Aggregated results.
    """
    import numpy as np

    seeds = config.get("seeds", [config["seed"]])
    results_dir = os.path.join(config["output_dir"], "raw")
    all_metrics = defaultdict(list)

    for seed in seeds:
        result_path = os.path.join(
            results_dir,
            f"{config['experiment_name']}_seed{seed}_test_results.json"
        )
        if os.path.exists(result_path):
            with open(result_path, 'r') as f:
                result = json.load(f)
            for metric_name, value in result.get("metrics", {}).items():
                if value is not None:
                    all_metrics[metric_name].append(value)
        else:
            logger.warning(f"Result file not found for seed {seed}: {result_path}")

    # Aggregate
    aggregated = {}
    for metric_name, values in all_metrics.items():
        aggregated[metric_name] = {
            "mean": float(np.mean(values)),
            "std": float(np.std(values)),
            "min": float(np.min(values)),
            "max": float(np.max(values)),
            "values": values,
            "num_seeds": len(values),
        }

    # Save
    agg_path = os.path.join(config["output_dir"], f"{config['experiment_name']}_aggregated_test.json")
    save_results(aggregated, agg_path)

    # Print table
    print(f"\n{'Metric':<20} {'Mean':>10} {'± Std':>10} {'Min':>10} {'Max':>10} {'Seeds':>6}")
    print("-" * 70)
    for name, stats in aggregated.items():
        print(f"{name:<20} {stats['mean']:>10.4f} {stats['std']:>10.4f} "
              f"{stats['min']:>10.4f} {stats['max']:>10.4f} {stats['num_seeds']:>6}")

    return aggregated


# ============================================================
# Entry Point
# ============================================================

if __name__ == "__main__":
    config = load_config()

    # Single evaluation
    results = evaluate(config)

    # Multi-seed aggregation if multiple seeds
    if len(config.get("seeds", [])) > 1:
        aggregated = aggregate_multi_seed_results(config)
