"""
Configuration management for research experiments.
Loads YAML configs with CLI argument overrides and ensures reproducibility.

SCAFFOLD — Claude fills # TODO: FILL sections only.
"""

import argparse
import yaml
import os
import sys
import json
from pathlib import Path
from datetime import datetime
from copy import deepcopy


# ============================================================
# Default Configuration
# ============================================================

DEFAULT_CONFIG = {
    # --- Project ---
    "project_name": "experiment",  # TODO: FILL — project identifier
    "experiment_name": "default",

    # --- Data ---
    "data": {
        "dataset_name": "",        # TODO: FILL — dataset identifier
        "data_dir": "./data",
        "train_split": "train",
        "val_split": "val",
        "test_split": "test",
        "num_workers": 4,
        "batch_size": 32,
        # TODO: FILL — add dataset-specific fields (e.g., max_length, image_size)
    },

    # --- Model ---
    "model": {
        "name": "",                # TODO: FILL — model/method name
        # TODO: FILL — add model-specific hyperparameters
    },

    # --- Training ---
    "training": {
        "epochs": 100,
        "learning_rate": 1e-3,
        "weight_decay": 1e-4,
        "optimizer": "adam",       # adam / sgd / adamw
        "scheduler": "cosine",    # cosine / step / plateau / none
        "warmup_epochs": 5,
        "grad_clip": 1.0,         # 0 to disable
        "early_stopping_patience": 10,  # 0 to disable
    },

    # --- Evaluation ---
    "evaluation": {
        "eval_every": 1,          # evaluate every N epochs
        "metrics": [],             # TODO: FILL — e.g., ["accuracy", "f1_macro"]
        "primary_metric": "",      # TODO: FILL — metric for model selection
        "higher_is_better": True,  # TODO: FILL
    },

    # --- Reproducibility ---
    "seed": 42,
    "seeds": [42, 123, 456],      # for multi-seed experiments
    "deterministic": True,

    # --- Paths ---
    "output_dir": "./results",
    "checkpoint_dir": "./checkpoints",
    "log_dir": "./logs",

    # --- Hardware ---
    "device": "auto",             # auto / cuda / cpu / mps
    "mixed_precision": False,
}


# ============================================================
# Config Loader
# ============================================================

def load_config(config_path=None, cli_args=None):
    """Load config from YAML file with CLI overrides.

    Priority: CLI args > YAML file > DEFAULT_CONFIG

    Args:
        config_path: Path to YAML config file (optional).
        cli_args: List of CLI arguments (optional, defaults to sys.argv).

    Returns:
        dict: Merged configuration.
    """
    config = deepcopy(DEFAULT_CONFIG)

    # Load YAML if provided
    if config_path and Path(config_path).exists():
        with open(config_path, 'r') as f:
            yaml_config = yaml.safe_load(f) or {}
        config = _deep_merge(config, yaml_config)

    # Parse CLI overrides
    parser = argparse.ArgumentParser(description="Experiment Configuration")
    parser.add_argument("--config", type=str, default=config_path, help="Path to YAML config")
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--device", type=str, default=None)
    parser.add_argument("--experiment_name", type=str, default=None)
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--batch_size", type=int, default=None)
    parser.add_argument("--lr", type=float, default=None)
    # TODO: FILL — add project-specific CLI arguments

    args = parser.parse_args(cli_args)

    # Apply CLI overrides (only non-None values)
    if args.config and args.config != config_path:
        with open(args.config, 'r') as f:
            yaml_config = yaml.safe_load(f) or {}
        config = _deep_merge(config, yaml_config)
    if args.seed is not None:
        config["seed"] = args.seed
    if args.device is not None:
        config["device"] = args.device
    if args.experiment_name is not None:
        config["experiment_name"] = args.experiment_name
    if args.epochs is not None:
        config["training"]["epochs"] = args.epochs
    if args.batch_size is not None:
        config["data"]["batch_size"] = args.batch_size
    if args.lr is not None:
        config["training"]["learning_rate"] = args.lr

    # Resolve device
    config["device"] = _resolve_device(config["device"])

    # Create output directories
    _setup_directories(config)

    return config


def save_config(config, path):
    """Save config to YAML for reproducibility."""
    with open(path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)


def save_config_json(config, path):
    """Save config to JSON (useful for logging)."""
    with open(path, 'w') as f:
        json.dump(config, f, indent=2)


# ============================================================
# Helpers
# ============================================================

def _deep_merge(base, override):
    """Recursively merge override dict into base dict."""
    result = deepcopy(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = deepcopy(value)
    return result


def _resolve_device(device_str):
    """Resolve 'auto' to the best available device."""
    if device_str == "auto":
        try:
            import torch
            if torch.cuda.is_available():
                return "cuda"
            elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
                return "mps"
        except ImportError:
            pass
        return "cpu"
    return device_str


def _setup_directories(config):
    """Create output directories if they don't exist."""
    run_name = f"{config['experiment_name']}_{config['seed']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    config["run_name"] = run_name
    config["run_output_dir"] = os.path.join(config["output_dir"], run_name)

    for dir_key in ["run_output_dir", "checkpoint_dir", "log_dir"]:
        os.makedirs(config[dir_key], exist_ok=True)


# ============================================================
# Quick Test
# ============================================================

if __name__ == "__main__":
    cfg = load_config()
    print("Loaded config:")
    print(yaml.dump(cfg, default_flow_style=False))
    print(f"Device: {cfg['device']}")
    print(f"Run output: {cfg['run_output_dir']}")
