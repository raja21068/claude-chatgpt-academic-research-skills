"""
Dataset loading and preprocessing scaffold.
Handles train/val/test splits, transforms, and data integrity checks.

SCAFFOLD — Claude fills # TODO: FILL sections only.
"""

import os
import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


# ============================================================
# Dataset Class
# ============================================================

class ResearchDataset:
    """Base dataset class for research experiments.

    Subclass this and implement _load_data() and __getitem__()
    for your specific dataset.

    Args:
        data_dir: Root directory containing the dataset.
        split: One of 'train', 'val', 'test'.
        config: Data configuration dict.
        transform: Optional transform/preprocessing function.
    """

    def __init__(self, data_dir, split, config=None, transform=None):
        self.data_dir = Path(data_dir)
        self.split = split
        self.config = config or {}
        self.transform = transform

        # Validate split
        assert split in ('train', 'val', 'test'), \
            f"Invalid split '{split}'. Must be 'train', 'val', or 'test'."

        # Validate data directory exists
        assert self.data_dir.exists(), \
            f"Data directory not found: {self.data_dir}"

        # Load data
        self.samples = self._load_data()
        logger.info(f"Loaded {len(self.samples)} samples for split '{split}'")

    def _load_data(self):
        """Load and return list of samples for the current split.

        Returns:
            list: Each element is a sample (dict, tuple, or custom format).

        # TODO: FILL — implement dataset-specific loading logic.
        # Examples:
        #   - Read CSV: pd.read_csv(self.data_dir / f'{self.split}.csv')
        #   - Read images: glob(self.data_dir / self.split / '*.png')
        #   - Read JSON: json.load(open(self.data_dir / f'{self.split}.json'))
        #   - Read HuggingFace: datasets.load_dataset('name', split=self.split)
        """
        raise NotImplementedError("Implement _load_data() for your dataset.")

    def __getitem__(self, idx):
        """Return a single preprocessed sample.

        Args:
            idx: Sample index.

        Returns:
            dict: With keys like 'input', 'target', 'metadata', etc.

        # TODO: FILL — implement sample retrieval and preprocessing.
        """
        sample = self.samples[idx]

        if self.transform:
            sample = self.transform(sample)

        return sample

    def __len__(self):
        return len(self.samples)


# ============================================================
# Data Loaders (PyTorch)
# ============================================================

def create_dataloaders(config):
    """Create train, val, and test data loaders.

    Args:
        config: Full experiment config dict.

    Returns:
        dict: {'train': loader, 'val': loader, 'test': loader}
    """
    data_config = config.get("data", {})
    data_dir = data_config.get("data_dir", "./data")
    batch_size = data_config.get("batch_size", 32)
    num_workers = data_config.get("num_workers", 4)

    # TODO: FILL — define transforms for each split
    train_transform = None  # TODO: FILL — e.g., augmentation for training
    eval_transform = None   # TODO: FILL — e.g., normalize only for eval

    # Create datasets
    datasets = {}
    for split in ['train', 'val', 'test']:
        transform = train_transform if split == 'train' else eval_transform
        try:
            datasets[split] = ResearchDataset(
                data_dir=data_dir,
                split=split,
                config=data_config,
                transform=transform
            )
        except (FileNotFoundError, AssertionError) as e:
            logger.warning(f"Could not load split '{split}': {e}")
            datasets[split] = None

    # Create loaders
    try:
        from torch.utils.data import DataLoader

        loaders = {}
        for split, dataset in datasets.items():
            if dataset is None:
                loaders[split] = None
                continue
            loaders[split] = DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=(split == 'train'),
                num_workers=num_workers,
                pin_memory=True,
                drop_last=(split == 'train'),
            )
        return loaders

    except ImportError:
        logger.info("PyTorch not available. Returning raw datasets.")
        return datasets


# ============================================================
# Data Integrity Checks
# ============================================================

def verify_data_integrity(config):
    """Run data sanity checks before training.

    Checks:
        - Data directory exists
        - All required splits exist
        - No empty splits
        - No data leakage between splits (sample ID overlap)
        - Basic statistics (sample counts, label distribution)

    Args:
        config: Full experiment config dict.

    Returns:
        dict: Integrity report.
    """
    data_dir = Path(config.get("data", {}).get("data_dir", "./data"))
    report = {
        "data_dir": str(data_dir),
        "exists": data_dir.exists(),
        "splits": {},
        "leakage_check": "not_implemented",  # TODO: FILL if sample IDs available
        "issues": [],
    }

    if not data_dir.exists():
        report["issues"].append(f"Data directory not found: {data_dir}")
        return report

    for split in ['train', 'val', 'test']:
        split_info = {"exists": False, "count": 0}

        # TODO: FILL — check split existence based on your data format
        # Example for file-based splits:
        # split_path = data_dir / f'{split}.csv'
        # split_info["exists"] = split_path.exists()

        report["splits"][split] = split_info

    # TODO: FILL — add leakage check if sample IDs are available
    # Example:
    # train_ids = set(train_df['id'])
    # test_ids = set(test_df['id'])
    # overlap = train_ids & test_ids
    # if overlap:
    #     report["issues"].append(f"LEAKAGE: {len(overlap)} IDs in both train and test")
    #     report["leakage_check"] = "FAILED"

    if not report["issues"]:
        logger.info("Data integrity check passed.")
    else:
        for issue in report["issues"]:
            logger.warning(f"Data issue: {issue}")

    return report


# ============================================================
# Quick Test
# ============================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("Data loader scaffold loaded.")
    print("Implement ResearchDataset._load_data() and __getitem__() for your dataset.")
