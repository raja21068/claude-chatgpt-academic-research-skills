#!/usr/bin/env bash
# ============================================================
# One-Click Research Experiment Runner (Linux/Mac)
# ============================================================
# Usage:
#   1. Place your dataset in the ./data/ folder
#   2. Edit configs/default.yaml with your settings
#   3. Run: bash run.sh
#
# This script will:
#   - Create a conda environment (if not exists)
#   - Install all dependencies
#   - Verify data integrity
#   - Train the model (multi-seed if configured)
#   - Evaluate on test set
#   - Generate publication-quality figures and tables
#   - Save everything to ./results/
# ============================================================

set -e  # Exit on error

# --- Configuration ---
PROJECT_NAME="experiment"           # TODO: FILL — your project name
ENV_NAME="${PROJECT_NAME}_env"
PYTHON_VERSION="3.10"
CONFIG_FILE="configs/default.yaml"
SEEDS="42 123 456"                  # TODO: FILL — your seeds

# --- Colors for output ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info()  { echo -e "${BLUE}[INFO]${NC} $1"; }
log_ok()    { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

echo "============================================================"
echo "  Research Experiment Runner"
echo "  Project: ${PROJECT_NAME}"
echo "  Config:  ${CONFIG_FILE}"
echo "============================================================"
echo ""

# ============================================================
# Step 1: Environment Setup
# ============================================================
log_info "Step 1/6: Setting up environment..."

# Check if conda is available
if command -v conda &> /dev/null; then
    # Check if env exists
    if conda env list | grep -q "^${ENV_NAME} "; then
        log_ok "Conda environment '${ENV_NAME}' already exists."
    else
        log_info "Creating conda environment '${ENV_NAME}' with Python ${PYTHON_VERSION}..."
        conda create -n "${ENV_NAME}" python="${PYTHON_VERSION}" -y
        log_ok "Conda environment created."
    fi

    # Activate environment
    eval "$(conda shell.bash hook)"
    conda activate "${ENV_NAME}"
    log_ok "Activated conda environment: ${ENV_NAME}"
else
    log_warn "Conda not found. Using system Python."
    # Fallback: create venv
    if [ ! -d ".venv" ]; then
        log_info "Creating virtual environment..."
        python3 -m venv .venv
    fi
    source .venv/bin/activate
    log_ok "Activated virtual environment."
fi

# ============================================================
# Step 2: Install Dependencies
# ============================================================
log_info "Step 2/6: Installing dependencies..."

pip install --upgrade pip -q
pip install -r requirements.txt -q

log_ok "Dependencies installed."

# Check GPU availability
python3 -c "
import sys
try:
    import torch
    if torch.cuda.is_available():
        gpu = torch.cuda.get_device_name(0)
        mem = torch.cuda.get_device_properties(0).total_mem / 1e9
        print(f'GPU detected: {gpu} ({mem:.1f} GB)')
    elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
        print('Apple MPS detected.')
    else:
        print('No GPU detected. Using CPU.')
except ImportError:
    print('PyTorch not installed. Framework-specific GPU check skipped.')
"

# ============================================================
# Step 3: Verify Data
# ============================================================
log_info "Step 3/6: Verifying data..."

if [ -d "data" ] && [ "$(ls -A data 2>/dev/null)" ]; then
    log_ok "Data directory found with contents."
    ls -la data/ | head -10
else
    log_error "Data directory is empty or missing!"
    log_error "Please place your dataset in the ./data/ folder and run again."
    exit 1
fi

# Run data integrity check
python3 -c "
from src.config import load_config
from src.data_loader import verify_data_integrity
config = load_config('${CONFIG_FILE}', [])
report = verify_data_integrity(config)
if report['issues']:
    print('Data issues found:')
    for issue in report['issues']:
        print(f'  - {issue}')
else:
    print('Data integrity check passed.')
" 2>/dev/null || log_warn "Data integrity check skipped (not implemented yet)."

echo ""

# ============================================================
# Step 4: Train
# ============================================================
log_info "Step 4/6: Training..."

for SEED in ${SEEDS}; do
    log_info "Training with seed ${SEED}..."
    python3 -m src.train \
        --config "${CONFIG_FILE}" \
        --seed "${SEED}" \
        --experiment_name "${PROJECT_NAME}_seed${SEED}"

    log_ok "Seed ${SEED} training complete."
done

echo ""

# ============================================================
# Step 5: Evaluate
# ============================================================
log_info "Step 5/6: Evaluating..."

for SEED in ${SEEDS}; do
    log_info "Evaluating seed ${SEED}..."
    python3 -m src.evaluate \
        --config "${CONFIG_FILE}" \
        --seed "${SEED}" \
        --experiment_name "${PROJECT_NAME}_seed${SEED}"

    log_ok "Seed ${SEED} evaluation complete."
done

echo ""

# ============================================================
# Step 6: Generate Figures and Tables
# ============================================================
log_info "Step 6/6: Generating figures and tables..."

# Generate figures
python3 -c "
from src.config import load_config
from utils.plotting import generate_all_figures
config = load_config('${CONFIG_FILE}', [])
generate_all_figures(config)
" 2>/dev/null || log_warn "Figure generation skipped (customize plotting.py first)."

# Generate result tables
if [ -f "scripts/generate_tables.py" ]; then
    python3 scripts/generate_tables.py --config "${CONFIG_FILE}"
    log_ok "Tables generated."
else
    log_warn "scripts/generate_tables.py not found. Skipping table generation."
fi

echo ""
echo "============================================================"
log_ok "ALL DONE!"
echo "============================================================"
echo ""
echo "Results:      ./results/"
echo "Checkpoints:  ./checkpoints/"
echo "Figures:      ./results/figures/"
echo "Tables:       ./results/tables/"
echo "Logs:         ./logs/"
echo ""
echo "To reproduce: bash run.sh"
echo "============================================================"
