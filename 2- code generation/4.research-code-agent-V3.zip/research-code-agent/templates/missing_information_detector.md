# Missing Information Detector

Run this before Claude Code implementation, full training, queue execution, and paper claims.

## Summary

| Category | Status | Count | Action |
|---|---:|---:|---|
| Hidden hyperparameters |  |  |  |
| Unspecified preprocessing |  |  |  |
| Ambiguous equations |  |  |  |
| Missing optimizer settings |  |  |  |
| Missing seeds |  |  |  |
| Missing data filtering |  |  |  |

## Classification Labels

- **BLOCKER**: cannot implement or evaluate correctly without this information.
- **RISKY ASSUMPTION**: can proceed only if assumption is explicitly stated and later verified.
- **SAFE DEFAULT**: standard default is acceptable but must be logged in config and README.
- **NOT NEEDED**: irrelevant for this project; explain why.

## A. Hidden Hyperparameters

Check batch size, learning rate, dropout, weight decay, warmup, scheduler, gradient clipping, augmentation probability, thresholds, early stopping patience, number of layers, hidden dimensions, temperature, margin, loss weights, negative sampling, and inference thresholds.

| Item | Evidence found | Status | Proposed action/default | Risk if wrong |
|---|---|---|---|---|
|  |  |  |  |  |

## B. Unspecified Preprocessing

Check normalization, scaling, tokenization, image resizing/cropping, sequence truncation, missing-value imputation, deduplication, outlier handling, train-only fitting of scalers, leakage-safe transforms, and augmentation rules.

| Item | Evidence found | Status | Proposed action/default | Risk if wrong |
|---|---|---|---|---|
|  |  |  |  |  |

## C. Ambiguous Equations

Check undefined symbols, tensor dimensions, reduction operations, masks, indexing, normalization constants, log base, epsilon/stability terms, objective sign, summation range, and whether loss is averaged per sample, per token, per class, or per dataset.

| Equation / symbol | Ambiguity | Status | Proposed resolution | Risk if wrong |
|---|---|---|---|---|
|  |  |  |  |  |

## D. Missing Optimizer Settings

Check optimizer family, lr, betas/momentum, epsilon, weight decay, decoupled vs coupled weight decay, scheduler, warmup, decay schedule, gradient accumulation, clipping, mixed precision, and EMA.

| Setting | Evidence found | Status | Proposed action/default | Risk if wrong |
|---|---|---|---|---|
|  |  |  |  |  |

## E. Missing Seeds

Check random seed values, number of runs, split seed, data loader worker seed, deterministic flags, CUDA determinism, and whether reported results are single-run or mean±std.

| Seed item | Evidence found | Status | Proposed action/default | Risk if wrong |
|---|---|---|---|---|
|  |  |  |  |  |

## F. Missing Data Filtering

Check inclusion/exclusion criteria, class filtering, minimum sample length, quality thresholds, duplicate removal, temporal filtering, language/domain filters, train/test contamination, label cleaning, and outlier rules.

| Filter item | Evidence found | Status | Proposed action/default | Risk if wrong |
|---|---|---|---|---|
|  |  |  |  |  |

## Blocker List

| Blocker | Why it blocks implementation/evaluation | Required user/source input |
|---|---|---|
|  |  |  |

## Risky Assumptions Allowed for Sanity Run Only

| Assumption | Why acceptable for sanity only | Must be confirmed before full queue? |
|---|---|---|
|  |  |  |

## Safe Defaults to Log

| Default | Value | Where to log in config/code |
|---|---|---|
|  |  |  |

## Decision

- [ ] Safe to generate scaffold code only.
- [ ] Safe to run sanity test.
- [ ] Safe to run full queue.
- [ ] Safe to write paper claim.

Full queue is allowed only when all BLOCKER items are resolved.
