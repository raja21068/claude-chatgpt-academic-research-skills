# Reproducibility Checklist

- [ ] Environment documented
- [ ] Dependencies documented
- [ ] Hardware documented
- [ ] Dataset source documented
- [ ] Split policy documented
- [ ] Preprocessing documented
- [ ] Seeds set and recorded
- [ ] Commands provided
- [ ] Metrics defined
- [ ] Baselines documented
- [ ] Ablations documented
- [ ] Raw results saved
- [ ] Tables/figures reproducible
- [ ] Known nondeterminism disclosed
- [ ] No private paths or secrets
- [ ] License/citation placeholders included
