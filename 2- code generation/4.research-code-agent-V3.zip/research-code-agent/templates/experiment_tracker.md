# Experiment Tracker

| Run ID | Stage | Claim Tested | System / Variant | Dataset / Split | Metrics | Seeds | Priority | Status | Result Path | Notes |
|---|---|---|---|---|---|---:|---|---|---|---|
| R001 | Sanity | Pipeline works | Toy/overfit check | small split | loss/target metric | 1 | MUST | TODO | results/R001.json | |
| R002 | Baseline | Baseline is reproducible | strongest baseline | official split | official metric | 3 | MUST | TODO | results/R002.json | |
| R003 | Main | Primary claim | proposed method | official split | official metric | 3 | MUST | TODO | results/R003.json | |
| R004 | Ablation | Contribution isolation | proposed - component | official split | official metric | 3 | MUST | TODO | results/R004.json | |

Status values: TODO, RUNNING, DONE, FAILED_OOM, FAILED_OTHER, BLOCKED, CUT.
