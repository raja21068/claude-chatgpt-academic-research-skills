# Results Summary

## Main Result
| Method | Dataset/Split | Metric | Mean | Std | Seeds | Result File |
|---|---|---|---:|---:|---:|---|

## Baseline Comparison
| Baseline | Proposed | Metric | Difference | Supports Claim? |
|---|---|---|---:|---|

## Ablation Results
| Variant | Removed/Changed Component | Metric | Delta vs Full | Interpretation |
|---|---|---|---:|---|

## Robustness / Sensitivity
| Test | Setting | Metric | Interpretation |
|---|---|---|---|

## Claims Supported
- Supported:
- Partially supported:
- Not supported:

## Paper-ready but honest interpretation
Write only claims supported by audited result files.
