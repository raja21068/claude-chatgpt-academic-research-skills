# Previous Paper Evaluation Extraction Matrix

| Paper | Domain/task | Dataset/split | Metrics | Baselines | Main result table format | Ablations | Statistical reporting | Useful convention | Do not copy |
|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | |
