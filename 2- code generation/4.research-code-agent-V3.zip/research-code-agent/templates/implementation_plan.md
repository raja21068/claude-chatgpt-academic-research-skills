# Implementation Plan

## Goal

## Inputs

## Assumptions

## Proposed file tree

```text
src/
configs/
scripts/
results/
tests/
```

## Modules

| Module | Responsibility | Inputs | Outputs | Verification |
|---|---|---|---|---|
| | | | | |

## Experiment flow

1.
2.
3.

## Metrics

## Baselines

## Ablations

## Run commands

## Risks / missing details
