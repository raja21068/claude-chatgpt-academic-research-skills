# Claim-Evidence-Code Map

| Paper claim | Code artifact | Dataset/split | Metric | Result file | Paper table/figure | Verification | Caveat |
|---|---|---|---|---|---|---|---|
| | | | | | | | |
