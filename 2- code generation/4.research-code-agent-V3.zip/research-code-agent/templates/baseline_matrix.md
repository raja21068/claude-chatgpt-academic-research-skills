# Baseline Matrix

| Baseline | Source | Same data split? | Same preprocessing? | Hyperparameters documented? | Fairness risk | Paper table |
|---|---|---:|---:|---:|---|---|
| | | | | | | |
