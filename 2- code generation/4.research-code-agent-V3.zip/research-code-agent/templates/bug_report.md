# Research Code Bug Report

## Symptom

## Command

## Error / suspicious result

## Expected behavior

## Likely root cause

## Minimal fix

## Robust fix

## Validation check

## Does this affect reported paper results?
