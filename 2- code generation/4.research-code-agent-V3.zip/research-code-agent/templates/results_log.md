# Results Log

## Experiment

## Date / run ID

## Command

## Config

## Dataset split

## Seed(s)

## Metrics

| Metric | Value | Notes |
|---|---:|---|
| | | |

## Output files

## Observations

## Validity concerns

## Paper claim supported
