# Ablation Plan

| Ablation | Component changed | Hypothesis | Config diff | Metric | Expected table row | Caveat |
|---|---|---|---|---|---|---|
| | | | | | | |
