# Claim Gate

Before implementation, freeze the paper claims.

## Primary Claim

## Supporting Claims

## Anti-Claims to Rule Out
Examples:
- The improvement comes only from more parameters.
- The improvement comes only from more data.
- The improvement is caused by leakage or split mismatch.
- The proposed module is decorative and not necessary.

## Minimum Evidence Required
| Claim | Required Experiment | Metric | Success Criterion | Table/Figure Target |
|---|---|---|---|---|

## Claims Not Allowed Yet
List any claims that cannot be made until more evidence exists.
