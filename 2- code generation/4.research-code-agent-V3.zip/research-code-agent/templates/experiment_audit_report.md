# Experiment Audit Report

## Verdict
- PASS / PASS WITH WARNINGS / FAIL

## Artifact Inventory
- Evaluation scripts:
- Metric scripts:
- Result files:
- Configs:
- Tracker:
- Paper claims:

## A. Ground Truth Provenance
| Script | Target Source | Dataset-derived? | Risk | Fix |
|---|---|---|---|---|

## B. Score Normalization
| Metric | Formula Source | Suspicious Normalization? | Risk | Fix |
|---|---|---|---|---|

## C. Result File Existence and Number Matching
| Claim | Result File | Metric Key | Claimed Number | Actual Number | Match? |
|---|---|---|---:|---:|---|

## D. Dead Code / Unused Metrics
| Function | File | Called? | Appears in Results? | Action |
|---|---|---|---|---|

## E. Scope vs Claim Strength
| Claim | Evidence Scope | Claim Strength | Overclaim Risk | Suggested Wording |
|---|---|---|---|---|

## Required Fixes Before Paper Writing
1.
2.
3.
