# Code Prompt Brief

## Task

## Inputs available

## Missing information

## Assumptions

## Target output

## Constraints

## Quality bar

## Verification plan
