# Input Specification for ResearchCode Agent

Use this file to prepare inputs before asking the agent to write code. Better inputs produce better code.

---

## Minimum Input

The agent can start with only:

```yaml
project_title: ""
research_goal: ""
method_summary: ""
expected_code_output: ""
programming_language: "Python or other"
```

## Recommended Full Input Packet

```yaml
project:
  title: ""
  paper_type: "empirical / theory / system / benchmark / survey / other"
  target_venue: ""
  contribution_claims:
    - ""

method:
  problem_statement: ""
  core_algorithm: ""
  equations_or_pseudocode: ""
  inputs: []
  outputs: []
  assumptions: []

implementation:
  preferred_language: "Python"
  preferred_framework: "PyTorch / TensorFlow / JAX / sklearn / R / MATLAB / other"
  target_environment: "local / Colab / cluster / Docker / unknown"
  hardware: "CPU / GPU / TPU / unknown"
  existing_code: "none / uploaded / link / pasted"

experiments:
  datasets:
    - name: ""
      source: ""
      split_policy: ""
      preprocessing: ""
  baselines:
    - ""
  metrics:
    - ""
  ablations:
    - ""
  expected_tables:
    - ""
  expected_figures:
    - ""

reproducibility:
  random_seeds: []
  logging_requirements: []
  checkpointing: ""
  config_format: "YAML / JSON / CLI args / other"

constraints:
  page_claims_to_support: []
  runtime_limit: ""
  memory_limit: ""
  license_or_release_requirements: ""
```

---

## Required Clarification Checks

Before writing major code, identify:

- What is the exact research claim the code must support?
- What datasets are available and how are they split?
- Which metrics decide success?
- Which baselines are mandatory?
- What environment should the code run in?
- What outputs are needed for the paper?
- What cannot be assumed?

---

## If the User Gives Only a Paper PDF or Draft

First extract:

1. Method components and algorithm steps.
2. Data requirements and preprocessing.
3. Baselines and metrics.
4. Tables and figures needing code support.
5. Missing implementation details.
6. A code plan before writing code.

---

## Domain Evaluation Packet

Because evaluation metrics vary by research domain, upload a small domain packet whenever possible:

```yaml
domain_evaluation_packet:
  target_domain: "computer vision / NLP / recommender systems / medicine / robotics / education / other"
  task_name: ""
  primary_benchmark_or_dataset: ""
  official_metric_source: "paper / README / evaluation script / competition page / venue checklist"
  metrics:
    - name: ""
      definition: ""
      higher_is_better: true
      aggregation: "micro / macro / per-class / per-dataset / per-seed / other"
      edge_cases: []
  previous_papers_to_upload:
    minimum: 1
    recommended: 2-5
    purpose: "learn domain metrics, result table format, baseline set, and reporting conventions"
  baseline_result_tables: []
  statistical_reporting: "mean+/-std / confidence interval / significance test / human eval / not applicable"
  known_validity_risks: []
```

### What to Upload

Best packet:

1. One strong previous paper closest to your task.
2. One benchmark or dataset paper.
3. Official evaluation script or README, when available.
4. Your own experimental log or draft result table.
5. Target venue checklist or artifact instructions.

One previous paper is enough to start, but it should not be treated as law. The agent must extract conventions and then verify them against the official benchmark/metric source whenever possible.
