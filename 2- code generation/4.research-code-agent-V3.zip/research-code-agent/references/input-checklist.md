# Input Checklist for ResearchCode Agent

Use this as a quick checklist before starting a new research code project. Better inputs produce dramatically better code.

---

## Minimum Input (start here)

Upload or provide these materials:

1. **Research idea or paper draft** - method description, model architecture, algorithm or pseudocode, objective/loss function, expected contribution.

2. **One close previous paper** - similar task or domain, similar dataset or benchmark, similar evaluation style, similar result-table format.

3. **Dataset information** - dataset name, train/validation/test split, input format, label or target format, preprocessing rules.

4. **Evaluation information** - metric name, metric formula or official definition, whether higher or lower is better, aggregation method (mean, macro, micro, per-class, per-dataset, per-seed), official evaluation script if available.

5. **Expected code output** - full repository or selected files, preferred framework (PyTorch, TensorFlow, JAX, scikit-learn, plain Python), training/evaluation/plotting script requirements, reproducibility requirements.

---

## Best Input Package

For highest quality, upload:

```text
1. my_method.md          (method description, algorithm, equations)
2. previous_paper.pdf    (closest related work)
3. dataset_readme.md     (dataset details, splits, preprocessing)
4. eval_script.py        (official evaluation script, if available)
5. experiment_log.md     (any existing experiment notes)
6. results_table.md      (expected or draft result table)
7. coding_preferences.yaml  (framework, style, environment preferences)
```

---

## Starter Prompt

```text
Use the uploaded ResearchCode Agent guidelines.

My task is [your task].
My domain is [NLP / computer vision / medical AI / education / robotics / etc.].
Use the uploaded previous paper and dataset documentation to identify the correct metrics, baselines, and result-table format.

First create:
1. Code Prompt Contract
2. Implementation plan
3. Domain Evaluation Contract
4. Repo structure

Do not write final code until the evaluation metric and dataset split are clear.
```

---

## Rule to Remember

Do not let the agent guess evaluation metrics. Metrics, baselines, dataset splits, and result-table formats should come from the previous paper, benchmark documentation, official evaluation script, or your explicit instruction.
