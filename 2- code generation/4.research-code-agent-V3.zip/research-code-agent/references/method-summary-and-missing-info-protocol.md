# Method Summary and Missing Information Protocol

This protocol makes the research-code-agent strict enough for top journal and A-class conference workflows. It prevents Claude Code from filling scientific gaps silently.

## Mandatory Rule

Before implementation, produce both:

1. `METHOD_SUMMARY_CONTRACT.yaml`
2. `MISSING_INFORMATION_DETECTOR.md`

These files must be created even when the user asks for a one-shot pipeline.

## Method Summary Required Fields

The method summary must include:

- input
- output
- architecture
- training process
- losses
- datasets
- evaluation

Each field must be supported by the user material, paper, code, previous experiments, or clearly marked as `NOT STATED / NEEDS USER CONFIRMATION`.

## Missing Information Detector Required Checks

The detector must scan for:

- hidden hyperparameters
- unspecified preprocessing
- ambiguous equations
- missing optimizer settings
- missing seeds
- missing data filtering

Every issue must be classified as BLOCKER, RISKY ASSUMPTION, SAFE DEFAULT, or NOT NEEDED.

## Execution Gate

- Scaffold generation can proceed with placeholders if gaps are labeled.
- Sanity run can proceed with risky assumptions if they are logged.
- Full queue cannot proceed with unresolved blockers.
- Paper claims cannot be made from results that did not pass the detector and audit.
