# Domain Evaluation Guide

Research metrics and result tables depend on the domain, task, dataset, and venue. Do not use generic metrics by default. This guide covers how to build a Domain Evaluation Contract and safely implement evaluation code.

---

## Building a Domain Evaluation Contract

Use this prompt pattern before writing any evaluation code:

```text
Use the uploaded domain materials to build a Domain Evaluation Contract before writing evaluation code.

Inputs:
- paper draft or method summary
- uploaded previous paper(s)
- dataset or benchmark description
- official metric script/README if available
- current experimental log or planned result table

Return:
1. Domain and task definition.
2. Dataset split policy.
3. Primary and secondary metrics.
4. Exact metric formulas or source references from uploaded files.
5. Higher/lower-is-better direction.
6. Aggregation method.
7. Baselines required for fair comparison.
8. Result table format.
9. Statistical reporting convention.
10. Leakage, fairness, and validity risks.
11. Missing information.

Do not write evaluation code until this contract is clear.
```

---

## Source Priority for Metrics

Use this order when determining the correct metric:

1. Official benchmark evaluation script or README.
2. Dataset or benchmark paper.
3. Closest previous paper in the same task.
4. Target venue requirements.
5. General domain knowledge only as a fallback.

---

## Extracting Conventions from Prior Papers

A previous paper is useful for:

- Discovering common metrics.
- Copying table structure style (not numbers).
- Identifying standard baselines.
- Understanding reporting conventions.
- Checking what ablations reviewers expect.

Never copy claims, code, text, or results from a previous paper unless the user explicitly provides permission and proper citation context.

Use this prompt to extract evaluation conventions:

```text
Read the uploaded previous paper(s) only to extract evaluation conventions.
Do not copy text, claims, or results.

Extract:
- metrics used
- datasets and splits
- baselines
- result table columns
- ablations
- significance/variance reporting
- failure-case reporting
- limitations in evaluation

Then propose the correct evaluation plan for my project.
```

Use `./templates/previous_paper_extraction_matrix.md` to organize extracted information.

---

## Generating Evaluation Code Safely

Write evaluation code only after summarizing the metric definition and edge cases.

Required components:

- Metric function with documented inputs and outputs.
- Toy examples with expected outputs for verification.
- Aggregation function.
- Result serialization schema.
- Warnings for invalid inputs.
- Paper-table formatting from saved raw results.

Never invent metric values or result numbers.

Use this prompt:

```text
Write evaluation code for this domain only after summarizing the metric definition and edge cases.

Required:
- metric function with documented inputs/outputs
- toy examples with expected outputs
- aggregation function
- result serialization schema
- warnings for invalid inputs
- paper-table formatting from saved raw results

Never invent metric values or result numbers.
```

---

## Metric Implementation Rules

- Implement the metric exactly as defined by the official source.
- Add toy test cases with known expected outputs.
- Separate per-example, per-class, per-dataset, and aggregate scores.
- Log all inputs used for metric calculation.
- Mark uncertain metric choices before producing paper-facing results.
