# Paper Parsing Protocol

Before writing ANY code from a paper, complete this mandatory extraction checklist. Every field must be filled or explicitly marked as "NOT STATED IN PAPER" — that distinction is critical, because "not stated" means I must ask the user or flag an assumption.

This protocol prevents my worst failure mode: confidently filling gaps with guesses from similar papers.

---

## Why This Exists

When I read a paper and jump to code, I silently fill in missing details from pattern matching. This causes:

- Wrong tensor dimensions (paper says "feature vector", I guess 512 when it should be 768)
- Wrong initialization (paper doesn't specify, I use Xavier when they used Kaiming)
- Wrong normalization (I add BatchNorm where they used LayerNorm)
- Wrong training tricks (I miss the label smoothing buried in Appendix B)
- Wrong data augmentation (I guess "standard augmentation" incorrectly)

This checklist forces explicit extraction before any generation.

---

## Extraction Checklist

Complete this for every paper before writing code. Read the ENTIRE paper including appendix, supplementary material, and footnotes.

### Section 1: Problem and Task

```yaml
problem_definition: ""           # What exactly is being solved
task_type: ""                    # classification / detection / generation / etc.
input_format: ""                 # What goes into the model (image, text, graph, etc.)
output_format: ""                # What comes out (class label, bounding box, text, etc.)
input_dimensions: ""             # Exact tensor shape if stated, "NOT STATED" if not
output_dimensions: ""            # Exact tensor shape if stated, "NOT STATED" if not
```

### Section 2: Architecture

```yaml
architecture_type: ""            # Transformer / CNN / RNN / GNN / hybrid / other
backbone: ""                     # ResNet-50 / ViT-B / BERT-base / etc.
pretrained: ""                   # yes/no, which checkpoint, from where
num_layers: ""                   # or "NOT STATED"
hidden_dimensions: ""            # list all stated dimensions
attention_heads: ""              # if applicable
dropout_rate: ""                 # or "NOT STATED"
activation_function: ""          # ReLU / GELU / SiLU / etc. or "NOT STATED"
normalization: ""                # BatchNorm / LayerNorm / GroupNorm / none / "NOT STATED"
initialization: ""               # Xavier / Kaiming / normal / "NOT STATED"
special_components:              # list any novel blocks
  - name: ""
    description: ""
    equations: []                # transcribe exactly from paper
    dimensions: ""               # every stated dimension
```

### Section 3: Loss Function

```yaml
loss_function: ""                # exact name
loss_formula: ""                 # transcribe the equation
loss_components: []              # if multi-term, list each term with weight
loss_weights: ""                 # lambda values for each component
temperature: ""                  # if contrastive/distillation, or "NOT STATED"
label_smoothing: ""              # value or "NOT STATED"
gradient_clipping: ""            # value or "NOT STATED"
```

### Section 4: Training Configuration

```yaml
optimizer: ""                    # Adam / SGD / AdamW / etc.
learning_rate: ""                # exact value
lr_schedule: ""                  # cosine / step / warmup+decay / etc.
warmup_steps_or_epochs: ""       # exact value or "NOT STATED"
weight_decay: ""                 # exact value or "NOT STATED"
batch_size: ""                   # per-GPU and total if stated
gradient_accumulation: ""        # steps or "NOT STATED"
epochs: ""                       # or total steps
mixed_precision: ""              # yes/no/"NOT STATED"
ema: ""                          # exponential moving average decay or "NOT STATED"
```

### Section 5: Data

```yaml
dataset_names: []                # all datasets used
dataset_sizes: ""                # train/val/test counts
split_policy: ""                 # random / temporal / predefined / k-fold
split_ratio: ""                  # 80/10/10 or specific numbers
preprocessing:
  - step: ""                     # resize, normalize, tokenize, etc.
    details: ""                  # exact parameters
augmentations: []                # list every augmentation with parameters
data_format: ""                  # image size, sequence length, etc.
class_distribution: ""           # balanced or imbalanced
special_handling: ""             # any custom data processing tricks
```

### Section 6: Evaluation

```yaml
metrics:
  - name: ""
    formula: ""                  # exact definition or "official script"
    higher_is_better: true
    aggregation: ""              # micro/macro/weighted
evaluation_protocol: ""          # single-run / k-fold / multi-seed / etc.
seeds: []                        # exact seeds if stated
statistical_reporting: ""        # mean±std / CI / significance test
baselines_compared: []           # every baseline name and source
```

### Section 7: Hidden Tricks (Check Appendix!)

```yaml
tricks_from_appendix:
  - trick: ""
    location: ""                 # "Appendix B, paragraph 2"
    impact: ""                   # how important is this for reproduction

tricks_from_footnotes:
  - trick: ""
    location: ""

tricks_from_supplementary:
  - trick: ""
    location: ""

implementation_details_url: ""   # GitHub repo if available
```

### Section 8: Ambiguity Register

List EVERY detail that is ambiguous, missing, or could be interpreted multiple ways:

```yaml
ambiguities:
  - item: ""                     # what is unclear
    location_in_paper: ""        # where the ambiguity occurs
    my_best_guess: ""            # what I would assume
    confidence: "low/medium/high"
    needs_user_input: true/false
    risk_if_wrong: "low/medium/high/critical"
```

---

## Post-Extraction Validation

After completing the checklist, run these checks:

### Check 1: Dimension Chain

Trace the data dimensions through the entire pipeline:

```text
Input [shape] → Preprocessing [shape] → Encoder [shape] → ... → Output [shape]
```

Every dimension transition must be accounted for. If a transition is unclear, flag it.

### Check 2: Information Flow

Can I draw the complete computational graph from input to loss? If any edge is unclear, flag it.

### Check 3: "NOT STATED" Audit

Count the number of "NOT STATED" fields. Classify each:

- **Safe to assume** (e.g., Adam optimizer beta values are almost always default)
- **Risky to assume** (e.g., hidden dimension, learning rate schedule)
- **Critical to ask** (e.g., loss weights, data split, evaluation protocol)

Present all "risky" and "critical" items to the user before writing code.

### Check 4: Reproducibility Likelihood

Rate the paper's reproducibility:

| Rating | Criteria |
|---|---|
| A — Fully specified | All fields filled, code available, clear protocol |
| B — Mostly specified | 1-3 minor gaps, can assume safely |
| C — Partially specified | 5+ gaps, several risky assumptions needed |
| D — Underspecified | Major architecture or training details missing |
| F — Not reproducible | Cannot implement without contacting authors |

Report this rating to the user.

---

## Output Format

After completing extraction, present to the user:

```text
## Paper Extraction Report

### Reproducibility Rating: [A/B/C/D/F]

### Fully Extracted (N fields)
[Summary of what was clearly stated]

### Assumptions Required (N fields)
[Each assumption with confidence level]
- [item]: assuming [value] (confidence: [low/med/high], risk: [low/med/high])

### Must Ask User (N fields)
[Critical ambiguities that need user input]
1. [question about ambiguity]
2. [question about ambiguity]

### Dimension Chain
Input [shape] → ... → Output [shape]
[Flag any unclear transitions]

### Ready to proceed?
```

Wait for user confirmation on all assumptions before writing code.
