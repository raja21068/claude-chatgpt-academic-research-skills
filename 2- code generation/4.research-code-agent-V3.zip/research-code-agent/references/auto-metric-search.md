# Auto-Search Evaluation Metrics

When the user does not provide evaluation metrics, baselines, or benchmark details, do not guess and do not halt. Instead, search the internet to discover the correct domain-standard evaluation protocol, then present findings for user confirmation before proceeding.

---

## When to Trigger

Activate this search protocol when any of these are true:

- User provides a task name but no metrics (e.g., "text summarization" without mentioning ROUGE).
- User provides a dataset name but no evaluation details.
- User says "use standard metrics" or "whatever is normal for this task."
- The Domain Evaluation Contract has empty metric fields after intake.
- User uploads a paper draft that lacks an evaluation section.

---

## Search Strategy

### Step 1: Identify the Search Query

Build queries from three components:

```text
[task name] + [domain] + evaluation metrics benchmark
[dataset name] + leaderboard benchmark metrics
[task name] + [venue: NeurIPS/ICML/CVPR/ACL/EMNLP] + 2024 2025 evaluation
```

Examples:

- "text summarization NLP evaluation metrics benchmark 2024"
- "ImageNet image classification leaderboard metrics"
- "medical image segmentation evaluation metrics MICCAI 2024 2025"
- "recommender systems evaluation metrics RecSys 2024"

### Step 2: Priority Sources

Search in this order and stop once you have enough information:

1. **PapersWithCode** (`paperswithcode.com/task/[task-name]`)
   - Provides: standard metrics, leaderboard, benchmark datasets, SOTA results.
   - Extract: metric names, dataset names, top model scores for baseline reference.

2. **Recent survey papers** (search: "[task] survey evaluation 2024 2025")
   - Provides: comprehensive metric comparison, pros/cons of each metric, domain conventions.
   - Extract: recommended metrics, known pitfalls, aggregation methods.

3. **Benchmark dataset papers or READMEs** (search: "[dataset name] paper evaluation protocol")
   - Provides: official metrics, split policy, evaluation script.
   - Extract: exact metric definitions, data split ratios, evaluation constraints.

4. **Top venue proceedings** (search: "[task] [venue] 2024 best paper")
   - Provides: what top 10% papers in this area actually report.
   - Extract: which metrics, how many baselines, what ablations, statistical reporting style.

5. **Competition pages** (Kaggle, DCASE, SemEval, BioASQ, etc.)
   - Provides: official evaluation metric, submission format, scoring code.
   - Extract: exact metric, aggregation, edge cases.

### Step 3: Extract and Structure

For each discovered metric, record:

```yaml
metric:
  name: ""
  definition: ""
  higher_is_better: true/false
  aggregation: "micro / macro / per-class / per-sample / per-seed"
  source: "PapersWithCode / survey paper / dataset README / competition"
  source_url: ""
  edge_cases: []
  commonly_paired_with: []  # e.g., Precision usually reported with Recall and F1
```

For baselines, record:

```yaml
baseline:
  name: ""
  source: "paper title or repo URL"
  reported_score: ""
  dataset_and_split: ""
  year: ""
  notes: ""
```

### Step 4: Present for Confirmation

Never silently adopt searched metrics. Present findings to the user in this format:

```text
Based on searching recent papers and benchmarks for [task/domain], here are the standard evaluation conventions:

Primary metrics: [list with definitions]
Secondary metrics: [list]
Standard baselines: [list with scores]
Standard dataset splits: [description]
Statistical reporting: [mean±std / CI / significance test]
Source: [URLs]

Should I use these for your project, or do you want to modify anything?
```

Wait for user confirmation before writing the Domain Evaluation Contract.

---

## Fallback Rules

- If no PapersWithCode page exists for the task, rely on the most recent survey paper.
- If no survey exists, find the 3 most-cited papers in the last 2 years for that task and extract their common metrics.
- If the domain is very niche and no standards exist, clearly state this and ask the user to define metrics. Do not invent a protocol.
- Always prefer official evaluation scripts over metric descriptions in paper text.
- When multiple metrics conflict between sources, present all and let the user choose.

---

## Common Domain Quick Reference

Use this as a starting point for searches, not as a final answer:

| Domain | Common Tasks | Likely Metrics | Where to Verify |
|---|---|---|---|
| NLP | classification, NER, summarization, translation, QA | Accuracy, F1, ROUGE, BLEU, BERTScore, EM | PapersWithCode, ACL Anthology |
| Computer Vision | classification, detection, segmentation | Accuracy, mAP, IoU, mIoU, FID, SSIM | PapersWithCode, COCO eval |
| Speech | ASR, TTS, speaker ID | WER, CER, MOS, PESQ | PapersWithCode, ESPnet |
| Recommender | rating, ranking, click | RMSE, MAE, NDCG, HR, MRR | RecSys proceedings |
| Medical AI | diagnosis, segmentation | AUROC, Dice, Sensitivity, Specificity | MICCAI proceedings |
| Reinforcement Learning | control, games | Return, success rate, sample efficiency | Gymnasium benchmarks |
| Graph ML | node/link/graph | Accuracy, F1, AUC, Hits@K, MRR | OGB leaderboards |

This table is a search hint only. Always verify with actual search results.
