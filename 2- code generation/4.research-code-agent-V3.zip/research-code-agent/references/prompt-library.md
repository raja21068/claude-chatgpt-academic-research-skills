# Prompt Library

Ready-to-use prompts for every stage of the research code workflow. Read this reference when you need a structured prompt for a specific task.

---

## Table of Contents

1. [Master Research Code Prompt](#master-research-code-prompt)
2. [Paper-to-Code Prompts](#paper-to-code-prompts)
3. [Code Generation Prompts](#code-generation-prompts)
4. [Debugging and Repair Prompts](#debugging-and-repair-prompts)
5. [Reproducibility Prompts](#reproducibility-prompts)
6. [Results-to-Paper Prompts](#results-to-paper-prompts)

---

## Master Research Code Prompt

Use this prompt when starting a new research-code task:

```text
You are my research-code assistant. Help me convert my research paper idea, method, or draft into clean, reproducible code.

First produce a Code Prompt Contract with:
- Task
- Inputs available
- Missing information
- Assumptions
- Target output
- Constraints
- Quality bar
- Verification plan

Then produce an implementation plan before writing code.

Follow these rules:
- Do not fabricate results.
- Do not claim the code has run unless I provide logs or tool output.
- Keep data loading, model/method, training, evaluation, plotting, and configuration separate.
- Include sanity checks and reproducibility notes.
- Map every experiment output to a paper table, figure, or claim.

My materials are:
[paste or upload paper draft, method, pseudocode, data notes, metrics, baselines, environment]
```

---

## Paper-to-Code Prompts

### Extract Implementation Requirements from a Paper Draft

```text
Read my paper draft and extract only the implementation-relevant details.
Return:
1. Core algorithm in steps.
2. Required inputs and outputs.
3. Data preprocessing requirements.
4. Model components or method modules.
5. Training/inference procedure.
6. Metrics.
7. Baselines.
8. Ablations.
9. Tables/figures that need code support.
10. Missing details I must provide before code can be reliable.
Do not write code yet.
```

### Turn Method into Implementation Plan

```text
Using the method description, create an implementation plan.
Return:
- proposed file tree
- module responsibilities
- key functions/classes with input/output signatures
- config fields
- experiment commands
- tests and sanity checks
- risks or ambiguities
Do not invent dataset-specific details.
```

### Convert Algorithm to Code

```text
Implement the algorithm from the plan.
Write code in small files. For each file, provide:
- filename
- purpose
- code
- assumptions
- how to test it
Use clear names and comments only where helpful.
```

---

## Code Generation Prompts

### Generate a Clean Module

```text
Write a clean, testable module for [module name].
Inputs:
[inputs]
Outputs:
[outputs]
Constraints:
[framework, environment, runtime, memory]
Quality bar:
- explicit types or docstrings
- validation for shapes and empty inputs
- deterministic behavior where possible
- no hidden global state
- clear errors
Also provide a minimal usage example and sanity test.
```

### Generate a Research Experiment Script

```text
Write an experiment script for [experiment].
It should:
- load config
- set seeds
- load data
- run method/baseline
- compute metrics
- save raw predictions if appropriate
- save metrics as a structured result file
- log environment and parameters
- avoid test-set tuning
Return the file tree and code blocks.
```

### Generate Configs

```text
Create a YAML config schema for this experiment.
Include fields for data, method, baselines, metrics, seeds, logging, output paths, hardware, and ablations.
Explain which fields must never be changed after seeing test results.
```

---

## Debugging and Repair Prompts

### Debug from Error Message

```text
Debug this research-code error.
Inputs:
- code snippet
- full error/stack trace
- command used
- expected behavior
- actual behavior
Return:
1. likely root cause
2. minimal fix
3. robust fix
4. tests to confirm
5. any risk to experiment validity
```

### Debug from Suspicious Results

```text
These results look suspicious. Audit the experiment for possible bugs.
Check:
- data leakage
- split mistakes
- metric implementation
- baseline unfairness
- seed instability
- preprocessing mismatch
- train/eval mode mistakes
- shape broadcasting bugs
- accidental test tuning
Return likely causes and validation checks.
```

### Code Repair Without Changing Science

```text
Fix the code while preserving the scientific method.
Do not silently change the algorithm, metric, data split, or baseline.
If a scientific change is needed, label it as a proposed method change, not a bug fix.
```

---

## Reproducibility Prompts

### Reproducibility Checklist

```text
Create a reproducibility checklist for this research code.
Cover:
- environment
- dependencies
- hardware
- datasets
- preprocessing
- random seeds
- training/inference commands
- expected runtime
- saved outputs
- result tables and figures
- known nondeterminism
- limitations
```

### Code-Release README

```text
Write a README for releasing this research code.
Include:
- project overview
- installation
- data setup
- quick start
- reproduce main result
- reproduce ablations
- generate paper tables/figures
- config explanation
- troubleshooting
- citation placeholder
- license placeholder
```

### Artifact Audit

```text
Audit whether this code package is ready for artifact review.
Score it on:
- installability
- reproducibility
- documentation
- dataset clarity
- command clarity
- result traceability
- license/compliance
Return blocking issues first.
```

---

## Results-to-Paper Prompts

### Map Code Outputs to Paper Claims

```text
Create a claim-evidence-code map.
For each paper claim, list:
- code file or function that produces the evidence
- dataset and split
- metric
- result artifact path
- table/figure in paper
- verification check
- risk of overclaiming
```

### Generate Table/Figure Plan from Results

```text
Given these result logs, plan paper-ready tables and figures.
Return:
- table/figure title
- required columns/axes
- source result files
- aggregation method
- caption claim
- caveats
Do not invent missing numbers.
```

### Results Integrity Check

```text
Check these results for integrity before I put them in the paper.
Look for:
- impossible values
- inconsistent metrics
- missing baselines
- cherry-picked seeds
- unclear statistical significance
- mismatched table claims
- overclaiming in captions
```
