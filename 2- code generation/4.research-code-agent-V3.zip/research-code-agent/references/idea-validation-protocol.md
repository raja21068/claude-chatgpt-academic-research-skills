# Idea Validation and Brainstorming Protocol

Before writing a single line of code or even an implementation plan, validate the research idea. This step prevents wasting weeks of compute and effort on an idea that cannot become a publishable paper.

This protocol is MANDATORY. Do not skip it. Do not let the user rush past it. A 15-minute brainstorm here saves months of dead-end work.

---

## When to Trigger

Run this protocol when:

- User presents a new research idea (not a pre-accepted paper).
- User says "I want to work on X" or "I have this idea."
- User uploads a very early draft without a clear related work or contribution statement.
- User asks "is this worth pursuing?" or "can this be a paper?"

Skip only when:

- User has an already-accepted paper and just needs code implementation.
- User explicitly says "skip validation, just code it."
- User is implementing someone else's published method for reproduction.

---

## Phase 1: Understand the Idea (Ask These Questions)

Before giving any opinion, fully understand what the user is proposing. Ask these questions one group at a time — do not dump all questions at once.

### Group A: Core Idea

1. What problem are you trying to solve? (one sentence)
2. What is your proposed approach? (one paragraph max)
3. Why do you think this approach will work better than existing methods?
4. What is the key insight or hypothesis behind your idea?

### Group B: Context and Motivation

5. What domain is this in? (NLP, CV, medical AI, robotics, etc.)
6. Who would care about this result? (which community, which application?)
7. What existing methods are you trying to improve upon?
8. What are the known limitations of current approaches that your idea addresses?

### Group C: Practical Feasibility

9. What datasets would you use to evaluate this?
10. Do you have access to the required compute? (GPU hours estimate)
11. What is your timeline? (conference deadline, thesis milestone)
12. Do you have any preliminary results or intuition that this works?

Wait for user answers before proceeding to Phase 2.

---

## Phase 2: Novelty and Trend Analysis

After understanding the idea, evaluate it across these dimensions. Use WebSearch to verify claims and find related work.

### 2A: Recency Check

Search for:
```text
[core technique] + [domain] + 2024 2025 recent
[problem name] + latest approaches + survey
```

Questions to answer:
- Has this exact idea been published already? (If yes, stop and tell the user.)
- Has a very similar idea been published? (If yes, what makes the user's version different?)
- Is the problem still considered open, or has it been largely solved?
- When was the last significant paper on this topic? (If 5+ years ago with no follow-up, ask why.)

### 2B: Trend Alignment

Search for:
```text
[domain] + research trends + 2025
[domain] + workshop topics + NeurIPS ICML CVPR ACL 2025
```

Questions to answer:
- Does this idea align with current research interests?
- Is the community moving toward or away from this type of approach?
- Are there recent workshops, challenges, or shared tasks related to this?
- Could this idea be reframed to fit a trending direction without losing its core contribution?

### 2C: Novelty Assessment

Rate the idea on this novelty scale:

| Level | Description | Publication Potential |
|---|---|---|
| 1 — Incremental | Small tweak to existing method | Workshop paper, maybe |
| 2 — Solid contribution | New combination, clear improvement | Good venue paper |
| 3 — Novel method | New approach with clear advantages | Top venue paper |
| 4 — Paradigm shift | Fundamentally new way of thinking | Best paper candidate |
| 5 — New problem | Defines a problem nobody studied | High-impact if validated |

Most good papers are Level 2-3. Level 1 needs very strong empirical results to compensate. Level 4-5 needs very strong validation to be believed.

### 2D: Contribution Clarity

A publishable paper needs at least one clear contribution. Classify the user's idea:

- **Methodological**: new algorithm, architecture, loss function, training procedure
- **Empirical**: new benchmark, large-scale study, surprising finding
- **Theoretical**: new proof, bound, analysis, understanding
- **Systems**: new tool, framework, pipeline that enables new research
- **Dataset/Benchmark**: new dataset, evaluation protocol, or challenge
- **Application**: applying existing methods to a new important domain

If the contribution is unclear, help the user sharpen it.

---

## Phase 3: Critical Brainstorming

Now stress-test the idea honestly. Present these as constructive challenges, not attacks.

### 3A: Reviewer Simulation

Think like a skeptical reviewer. Identify the top 3-5 weaknesses a reviewer would flag:

```text
"A reviewer would likely ask:"
1. Why not just use [simpler baseline] instead?
2. How do you know the improvement comes from [your contribution] and not [confound]?
3. Does this generalize beyond [specific dataset]?
4. What is the computational cost compared to baselines?
5. [Domain-specific concern]
```

### 3B: Ablation Feasibility

Can the user design ablations that isolate the contribution?
- If the method has 3 novel components, can each be tested independently?
- If not, the contribution is entangled and harder to publish.

### 3C: Baseline Strength

Are there strong baselines the user must beat?
- Search PapersWithCode or recent papers for SOTA on the target task.
- If SOTA is very strong (e.g., GPT-4 level), the user needs a different angle (efficiency, domain-specific, interpretability).
- If SOTA is weak or old, the idea has more room.

### 3D: Scope Check

Is the scope right for a single paper?
- Too narrow: "We change one hyperparameter and get 0.3% improvement" → not publishable.
- Too broad: "We solve all of NLP" → not feasible.
- Right: "We propose method X for problem Y, evaluate on Z, show improvement on metrics M1/M2 with ablations."

---

## Phase 4: Present the Assessment

After the analysis, present a structured assessment to the user:

```text
## Research Idea Assessment

### Idea Summary
[One paragraph restating the idea]

### Novelty Rating: [1-5] — [description]

### Strengths
- [strength 1]
- [strength 2]

### Risks / Weaknesses
- [risk 1 — with suggestion to address]
- [risk 2 — with suggestion to address]

### Closest Related Work
- [paper 1 — how it differs]
- [paper 2 — how it differs]

### Trend Fit
[Does it align with current research interests?]

### Suggested Contribution Statement
"We propose [X] which [addresses Y] by [doing Z]. Unlike prior work [A, B], our approach [key difference]. We demonstrate [expected results] on [datasets]."

### Recommended Next Steps
1. [first thing to do]
2. [second thing to do]
3. [third thing to do]

### Verdict
[GO / GO WITH CHANGES / PIVOT / STOP]
```

### Verdict Definitions

- **GO**: Idea is novel, feasible, and aligned with trends. Proceed to implementation plan.
- **GO WITH CHANGES**: Core idea is good but needs refinement. Specify what to change before coding.
- **PIVOT**: The idea has potential but the current framing won't work. Suggest a better angle.
- **STOP**: The idea has been done, is not feasible, or lacks a clear contribution. Suggest alternatives.

---

## Phase 5: Strengthen the Idea (if GO WITH CHANGES or PIVOT)

If the idea needs work, brainstorm improvements:

1. **Combination strategy**: Can you combine two existing ideas in a novel way?
2. **New angle**: Can you apply this to an underserved domain or task?
3. **Efficiency argument**: Can you match SOTA with significantly less compute/data?
4. **Interpretability**: Can you explain why the method works, not just that it works?
5. **Practical impact**: Can you show real-world deployment value?
6. **Negative result framing**: If the idea might not beat SOTA, can the negative result teach something valuable?

After refinement, re-run the novelty and reviewer simulation checks on the improved version.

---

## Anti-Patterns to Avoid

- **Cheerleading**: Never say "great idea!" without verifying. Honest assessment prevents wasted effort.
- **Killing good ideas**: Some unconventional ideas are exactly what gets published. Don't be too conservative.
- **Scope creep during brainstorming**: The goal is to validate and sharpen, not to redesign the entire project.
- **Skipping related work search**: The #1 reason papers get rejected is "this has been done before." Always search.
- **Assuming trends are mandatory**: Important problems that are unfashionable can still produce great papers.
