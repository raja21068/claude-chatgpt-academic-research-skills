# Output Language Protocol

Skills write output files in the language configured for the project. Check in this order:

1. `CLAUDE.md` — look for `language:` field
2. The user's prompt language (if Chinese → write in Chinese; if English → write in English)
3. Default: English

This applies to all markdown output files. Code files are always in English regardless.

Do not mix languages within a single output file.
