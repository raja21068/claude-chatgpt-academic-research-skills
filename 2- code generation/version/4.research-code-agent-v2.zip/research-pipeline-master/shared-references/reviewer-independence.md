# Reviewer Independence Protocol

## Principle

The **executor** (Claude) and the **reviewer** (GPT-5.4 via Codex MCP) must stay independent.

- The executor collects file paths and structures the prompt.
- The reviewer reads files and judges integrity.
- The executor does NOT pre-interpret, summarize, or editorialize content before passing it to the reviewer.
- The executor does NOT filter which files the reviewer sees (unless the skill explicitly scopes the audit).

## Why

If the executor summarizes results before review, it can unconsciously (or deliberately) omit unfavorable evidence. Cross-model integrity requires that the reviewer forms its own judgment from primary sources.

## Enforcement

- Pass file paths to the reviewer, not file contents.
- The reviewer reads files directly via its sandbox.
- After the review, the executor may parse and format the reviewer's output — but must preserve the full raw response verbatim in the review log.
