# Reviewer Routing Reference

## Default: Codex MCP

```
REVIEWER_BACKEND = codex
model: gpt-5.4
config: {"model_reasoning_effort": "xhigh"}
```

Use via `mcp__codex__codex` for the first call, `mcp__codex__codex-reply` for subsequent rounds in the same thread.

## Override: Oracle MCP (GPT-5.4 Pro)

```
--- reviewer: oracle-pro
```

Use when you need GPT-5.4 Pro's extended context window or higher rate limits.

## Choosing a Backend

| Situation | Backend |
|-----------|---------|
| Standard review round | codex (default) |
| Very long paper + full repo | oracle-pro |
| Nightmare difficulty mode | codex exec (direct repo access) |
| Codex unavailable | Skip gracefully, document in review log |

## Graceful Degradation

If the configured backend is unavailable:
1. Log: "Reviewer backend [name] unavailable — skipping cross-model review"
2. Continue pipeline without blocking
3. Tag affected outputs as "reviewer unavailable — not cross-model verified"
