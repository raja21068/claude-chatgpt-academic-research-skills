# Experiment Integrity Reference

## Common Fraud Patterns in LLM-Generated Research

These are NOT intentional deception. They are failure modes of optimizing agents.

### 1. Fake Ground Truth
Model generates synthetic "reference" from its own output, then reports high agreement as performance.
**Detection**: Check where GT is loaded from. Must be the dataset split, not a model's output.

### 2. Score Normalization Fraud
Metric divided by the model's own max/mean, producing scores near 1.0.
**Detection**: Check the denominator of any normalized metric. Must come from dataset statistics, not prediction statistics.

### 3. Phantom Results
Numbers claimed from files that don't exist or functions never called.
**Detection**: Verify every claimed result file exists and contains the claimed key and value.

### 4. Insufficient Scope
2-scene pilots reported as "comprehensive evaluation."
**Detection**: Count actual scenes/datasets/seeds tested vs language used in claims.

### 5. Dead Code Metrics
Metric function defined but never called. Its output never appears in any result file.
**Detection**: Trace every metric function to its call site and output file.

## Integrity Status Levels

- **PASS**: No issues found.
- **WARN**: Minor issues; results can be reported with caveats.
- **FAIL**: Structural integrity issue; claims should not be made without fixing.

Integrity status never blocks the pipeline — but it tags all downstream claims.
