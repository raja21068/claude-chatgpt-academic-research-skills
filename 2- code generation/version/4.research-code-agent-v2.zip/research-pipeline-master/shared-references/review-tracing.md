# Review Tracing Protocol

After every `mcp__codex__codex` or `mcp__codex__codex-reply` call, save a trace.

## Default Trace Location

```
.aris/traces/<skill-name>/<date>_run<NN>/
```

Example: `.aris/traces/auto-review-loop/20260516_run01/`

## Trace Files

```
trace_request.json    # The prompt and config sent to the reviewer
trace_response.json   # The full raw response received
trace_meta.json       # Timestamp, model, threadId, round number
```

## Using save_trace.sh

```bash
tools/save_trace.sh \
  --skill auto-review-loop \
  --round 2 \
  --request-file /tmp/review_request.json \
  --response-file /tmp/review_response.json
```

## Trace Parameter

Skills accept a `--- trace:` parameter:
- `full` (default): save all three files
- `meta-only`: save only trace_meta.json
- `off`: skip tracing entirely

Never delete traces from a completed run. They are the audit trail.
