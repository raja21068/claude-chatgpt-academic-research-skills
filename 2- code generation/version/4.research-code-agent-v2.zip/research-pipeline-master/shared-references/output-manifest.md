# Output Manifest Protocol

Every skill that writes an output file must append an entry to `MANIFEST.md` in the project root.

```markdown
## [TIMESTAMP] [skill-name]
| File | Description | Size |
|------|-------------|------|
| refine-logs/EXPERIMENT_PLAN_20260516T120000Z.md | Versioned experiment plan | ~4KB |
| refine-logs/EXPERIMENT_PLAN.md | Fixed canonical name (copy) | ~4KB |
```

**Format**: ISO timestamp, skill name as heading. Table with path, description, approximate size.

If MANIFEST.md does not exist, create it with a header:
```markdown
# Project Output Manifest
Auto-generated. One entry per skill invocation that produces files.
```
