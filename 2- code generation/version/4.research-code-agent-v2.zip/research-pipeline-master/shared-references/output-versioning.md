# Output Versioning Protocol

When writing any output file, always write a timestamped version first, then copy to the fixed canonical name.

```bash
TIMESTAMP=$(date -u +%Y%m%dT%H%M%SZ)
# Write timestamped version first
write_file "output-dir/EXPERIMENT_PLAN_${TIMESTAMP}.md" [content]
# Copy to fixed name (overwrite)
cp "output-dir/EXPERIMENT_PLAN_${TIMESTAMP}.md" "output-dir/EXPERIMENT_PLAN.md"
```

**Why**: The timestamped version preserves history; the fixed name is what downstream skills read. Never write only the fixed name — you lose history on every overwrite.

Log both filenames to MANIFEST.md (see output-manifest.md).
