# Code Release README Template

## Overview

## Installation

## Data setup

## Quick start

## Reproduce main result

## Reproduce ablations

## Generate paper tables and figures

## Configuration

## Repository structure

```text
src/          production-ready modules
configs/      experiment configs
scripts/      entry-point scripts
experiments/  per-run experiment folders
data/         raw and processed datasets
results/      figures and tables
tests/        unit and integration tests
notebooks/    exploratory analysis
demos/        interactive demos
papers/       related PDFs and BibTeX
```

## Known constraints and scope

## Troubleshooting

## Citation

## License
