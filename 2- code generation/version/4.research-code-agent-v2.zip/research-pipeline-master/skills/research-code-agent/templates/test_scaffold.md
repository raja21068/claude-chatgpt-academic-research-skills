# Test Scaffold

Use this template for every new module. Research code must be verifiable before results are reported.

---

## Module under test

**File:** `src/<module>.py`
**Function / class:**

---

## Toy test (deterministic, tiny input)

```python
# Always include at least one test with a known expected output.
# Do not use random data for toy tests.

def test_<function>_toy():
    input_data = ...      # minimal, hand-constructed
    expected   = ...      # computed by hand or from paper formula
    result     = <function>(input_data)
    assert result == expected, f"Expected {expected}, got {result}"
```

---

## Shape / type check

```python
def test_<function>_output_shape():
    # Verify tensor/array shapes and types match the contract.
    output = <function>(...)
    assert output.shape == (expected_shape,)
    assert output.dtype == expected_dtype
```

---

## Edge case checks

| Edge case | Input | Expected behavior |
|---|---|---|
| Empty input | `[]` / `None` | Raises `ValueError` |
| Single element | `[x]` | Returns scalar without crash |
| All-zero input | `zeros(...)` | Defined behavior (document it) |

```python
import pytest

def test_<function>_empty_raises():
    with pytest.raises(ValueError):
        <function>([])
```

---

## Reproducibility check

```python
def test_<function>_deterministic():
    import torch; torch.manual_seed(42)
    out1 = <function>(input_data)
    torch.manual_seed(42)
    out2 = <function>(input_data)
    assert torch.allclose(out1, out2), "Output is not deterministic"
```

---

## Metric sanity check (for evaluation code only)

```python
def test_metric_perfect_score():
    preds  = [0, 1, 2]
    labels = [0, 1, 2]
    assert compute_metric(preds, labels) == PERFECT_SCORE

def test_metric_chance_level():
    # Confirm chance-level behavior is as expected by the domain contract.
    ...
```

---

## Run command

```bash
pytest tests/test_<module>.py -v
```

---

## Notes

- All tests must pass before results from this module are reported in a paper table or figure.
- If a test fails after a code change, re-run the relevant experiment before updating any numbers.
- Mark skipped tests with `@pytest.mark.skip(reason="...")` — never silently delete them.
