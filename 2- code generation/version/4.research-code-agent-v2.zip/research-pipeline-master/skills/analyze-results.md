---
name: analyze-results
description: "Analyze ML experiment results: compute statistics, build comparison tables, detect patterns, and generate paper-ready insights. Use when user says: analyze results, compare experiments, interpret results, 分析结果, or after experiment-queue or experiment-bridge completes."
argument-hint: [results-path-or-description]
allowed-tools: Bash(*), Read, Grep, Glob, Write, Edit, Agent
---

# Analyze Experiment Results

Analyze: **$ARGUMENTS**

## Overview

This skill turns raw experiment output (JSON, CSV, logs) into structured findings, comparison tables, and paper-ready insights. It connects directly to `/experiment-bridge`, `/experiment-queue`, and `/auto-review-loop`.

## Constants

- **OUTPUT_DIR = `results/`** — Where analysis outputs go. Fall back to `figures/` or project root.
- **MIN_SEEDS_FOR_STD = 2** — Report mean ± std only when at least 2 seeds exist; otherwise report single value and flag it.
- **SIGNIFICANCE_ALPHA = 0.05** — Threshold for flagging statistical significance.
- **SUSPICIOUS_THRESHOLD = 0.99** — Flag any normalized metric above this as potentially fraudulent (see experiment-audit integration).

## Workflow

### Step 1: Locate Results

Scan for output files — do not assume a fixed path:

```bash
find . -name "*.json" -path "*/results/*" -o \
       -name "*.json" -path "*/figures/*" -o \
       -name "*.json" -path "*/outputs/*" -o \
       -name "*.csv"  -path "*/results/*" | sort
```

Also check:
- `refine-logs/EXPERIMENT_TRACKER.md` — for run status and expected outputs
- `experiment_queue/<run-ts>/queue_state.json` — for queue completion status
- `EXPERIMENT_AUDIT.json` — if it exists, read `integrity_status` before reporting

If `EXPERIMENT_AUDIT.json` exists and `integrity_status == "fail"`, tag all reported numbers with **[INTEGRITY CONCERN]** and note it prominently in the summary.

### Step 2: Parse and Structure Results

For each JSON result file:

```python
import json, glob, pandas as pd

records = []
for path in glob.glob("results/**/*.json", recursive=True):
    with open(path) as f:
        data = json.load(f)
    records.append(data)

df = pd.DataFrame(records)
print(df.dtypes)
print(df.describe())
```

For CSV files:

```python
df = pd.read_csv("results/results.csv")
print(df.head())
```

Identify:
- **Independent variables**: model type, hyperparameters, data config, seed
- **Dependent variables**: primary metric, secondary metrics
- **Run metadata**: timestamp, GPU, duration

### Step 3: Build Comparison Table

For each experimental condition:

1. Group by independent variables
2. Compute mean ± std across seeds (when `n_seeds >= MIN_SEEDS_FOR_STD`)
3. Compute delta vs baseline (absolute and relative)
4. Flag best result per column

```python
summary = df.groupby(["method", "dataset"])["primary_metric"].agg(["mean", "std", "count"])
summary["delta_vs_baseline"] = summary["mean"] - baseline_mean
summary["relative_improvement"] = summary["delta_vs_baseline"] / abs(baseline_mean) * 100
```

Output format:

| Method | Dataset | Primary Metric | Δ vs Baseline | Seeds |
|--------|---------|---------------|---------------|-------|
| Baseline | ... | X.XX ± Y.YY | — | 3 |
| Ours | ... | **X.XX ± Y.YY** | +Z.ZZ (+P%) | 3 |

### Step 4: Statistical Analysis

Depending on what's present:

**Multiple seeds** — report mean ± std; run paired t-test vs baseline:

```python
from scipy import stats
t_stat, p_val = stats.ttest_rel(ours_scores, baseline_scores)
significant = p_val < SIGNIFICANCE_ALPHA
```

**Hyperparameter sweep** — identify trend type:

```python
# Plot metric vs hyperparameter value
# Classify: monotonic increasing / decreasing / U-shaped / plateau
```

**Suspicious results** — flag any metric above `SUSPICIOUS_THRESHOLD` when normalized:

```
⚠️ WARNING: metric 'boundary_iou' = 0.997 is suspiciously high.
   Check: is the denominator derived from model output? → run /experiment-audit
```

**Missing seeds** — flag runs with only 1 seed:

```
⚠️ Run R003 has only 1 seed. Results may not be reproducible.
   Consider adding seeds [200, 201] before reporting.
```

### Step 5: Generate Structured Findings

For each finding, use this structure:

```markdown
### Finding N: [Short title]
- **Observation**: [what the data shows — always include numbers]
- **Interpretation**: [why this is likely happening]
- **Implication**: [what this means for the paper claim]
- **Confidence**: [high / medium / low] — based on number of seeds and effect size
- **Next step**: [what experiment would test this interpretation further]
- **Paper target**: [which table / figure / claim this supports]
```

### Step 6: Connect to Paper Claims

For each experiment block in `refine-logs/EXPERIMENT_PLAN.md`:

1. Find the corresponding result
2. Evaluate against the **success criterion** stated in the plan
3. Mark: ✅ criterion met / ⚠️ partial / ❌ criterion not met / ⏳ still running

```markdown
## Claim Coverage

| Block | Claim | Criterion | Result | Status |
|-------|-------|-----------|--------|--------|
| B1    | C1    | Δ > 2pp   | +3.1pp | ✅      |
| B2    | C1    | p < 0.05  | p=0.03 | ✅      |
| B3    | C2    | ablation shows component matters | Δ=+1.2pp | ✅ |
```

### Step 7: Write Output Files

#### `results/ANALYSIS_REPORT.md`

```markdown
# Experiment Analysis Report

**Date**: [today]
**Project**: [project name]
**Integrity status**: [from EXPERIMENT_AUDIT.json, or "not audited"]

## Summary

[2-3 sentence executive summary of the main finding]

## Comparison Table

[full table from Step 3]

## Statistical Summary

[significance tests, seed counts, effect sizes]

## Findings

[numbered findings from Step 5]

## Claim Coverage

[table from Step 6]

## Concerns

[any suspicious results, missing seeds, failed runs]

## Suggested Next Steps

[ranked list of follow-up experiments or analyses]
```

#### `results/ANALYSIS_REPORT.json` (for machine consumption)

```json
{
  "date": "2026-05-16",
  "integrity_status": "pass",
  "primary_metric": "accuracy",
  "conditions": [
    {"method": "baseline", "mean": 0.823, "std": 0.012, "seeds": 3},
    {"method": "ours", "mean": 0.871, "std": 0.008, "seeds": 3, "delta": 0.048, "p_value": 0.02}
  ],
  "findings": [
    {"id": "F1", "title": "...", "confidence": "high", "claim": "C1", "status": "supported"}
  ],
  "concerns": [],
  "suggested_next": ["run ablation B3 with seed 201"]
}
```

### Step 8: Print Summary

```
📊 Analysis Complete

  Conditions analyzed: [N]
  Seeds per condition: [mean]
  Primary metric: [name]

  Best result: [method] — [metric] = X.XX ± Y.YY (+Z.ZZ vs baseline, p=0.0X)
  Claim C1: ✅ supported
  Claim C2: ⚠️ partial (only 1 seed)

  Concerns:
  - [if any]

  Next step: → /auto-review-loop "[topic]"
  Report: results/ANALYSIS_REPORT.md
```

## Integration with Other Skills

### Reads from:
- `/experiment-bridge` — `refine-logs/EXPERIMENT_RESULTS.md`, result JSON/CSV files
- `/experiment-queue` — `experiment_queue/<run-ts>/queue_state.json`, result JSON files
- `/experiment-audit` — `EXPERIMENT_AUDIT.json` (integrity status)
- `/experiment-plan` — `refine-logs/EXPERIMENT_PLAN.md` (success criteria and claim map)

### Feeds into:
- `/auto-review-loop` — `results/ANALYSIS_REPORT.md` is the primary evidence document for review rounds
- Paper writing skills — `results/ANALYSIS_REPORT.json` provides structured claim-support data

## Key Rules

- **Never invent numbers.** Every value in the report must appear in an actual output file.
- **Always compute delta vs baseline.** Absolute numbers alone are insufficient.
- **Flag missing seeds.** Single-seed results must be labeled as provisional.
- **Read EXPERIMENT_AUDIT.json first.** If integrity is flagged, tag all results accordingly.
- **Match claims to plan.** Every finding should link to a block in EXPERIMENT_PLAN.md.
- **Separate observation from interpretation.** Do not conflate what the data shows with why.
