# Research Pipeline Master

A modular skill system for turning research ideas into paper-ready results. Each skill is one stage of the pipeline; they compose cleanly and can be used independently or end-to-end.

---

## Pipeline Overview

```
Idea / Proposal
      │
      ▼
┌─────────────────────────┐
│   experiment-plan       │  Turn a refined proposal into a claim-driven
│                         │  experiment roadmap with run order + budget
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│   research-code-agent   │  Implement the method: Code Prompt Contract →
│                         │  implementation plan → modular, testable code
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│   experiment-bridge     │  Deploy the plan: implement scripts, cross-model
│                         │  code review (GPT-5.4), run on GPU, collect results
└────────────┬────────────┘
             │        ├─── small batches (≤5 jobs): run-experiment
             │        └─── large batches (≥10 jobs, multi-phase):
             ▼                    experiment-queue
┌─────────────────────────┐
│   experiment-audit      │  Integrity check: cross-model (GPT-5.4) audit of
│                         │  GT provenance, normalization, result existence,
│                         │  dead code, scope. Advisory — never blocks.
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│   analyze-results       │  Statistics, comparison tables, structured findings,
│                         │  claim coverage, paper-ready ANALYSIS_REPORT.md
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│   auto-review-loop      │  Autonomous multi-round review: GPT-5.4 reviews →
│                         │  Claude fixes → re-review (up to 4 rounds)
└────────────┬────────────┘
             │
             ▼
        Paper writing
```

---

## Skills

| Skill | File | Purpose |
|-------|------|---------|
| `experiment-plan` | `skills/experiment-plan.md` | Claim-driven experiment roadmap |
| `research-code-agent` | `skills/research-code-agent/SKILL.md` | Paper-to-code implementation |
| `experiment-bridge` | `skills/experiment-bridge.md` | Implement + deploy + collect results |
| `experiment-queue` | `skills/experiment-queue.md` | Orchestrate large batches (≥10 jobs) |
| `experiment-audit` | `skills/experiment-audit.md` | Cross-model integrity verification |
| `analyze-results` | `skills/analyze-results.md` | Stats, tables, findings, claim coverage |
| `auto-review-loop` | `skills/auto-review-loop.md` | Autonomous iterative review loop |

---

## Shared References

All skills share these protocol documents:

| Reference | File | Used by |
|-----------|------|---------|
| Output Versioning | `shared-references/output-versioning.md` | All output-writing skills |
| Output Manifest | `shared-references/output-manifest.md` | All output-writing skills |
| Output Language | `shared-references/output-language.md` | All output-writing skills |
| Reviewer Independence | `shared-references/reviewer-independence.md` | experiment-audit, auto-review-loop |
| Experiment Integrity | `shared-references/experiment-integrity.md` | experiment-audit |
| Review Tracing | `shared-references/review-tracing.md` | experiment-audit, auto-review-loop |
| Reviewer Routing | `shared-references/reviewer-routing.md` | experiment-audit, auto-review-loop |

---

## Key Design Principles

**Every experiment must defend a claim.** The experiment-plan skill enforces this — every block links to a claim in the claim map. Experiments without a linked claim are cut.

**Cross-model integrity.** Executor (Claude) and reviewer (GPT-5.4) are always different model families. Claude collects paths; GPT reads files and judges. This follows the reviewer-independence protocol.

**Never block the pipeline.** The experiment-audit skill is advisory. Even a FAIL verdict lets the pipeline continue — it tags claims with `[INTEGRITY CONCERN]`, visible to the reviewer in the next round.

**State survives crashes.** The experiment-queue persists `queue_state.json` after every state change. The auto-review-loop persists `REVIEW_STATE.json` after every round. Both are resumable after a crash or context compaction.

**No fabricated results.** Every number in an output file must come from an actual experiment run. The experiment-audit checks this. The analyze-results skill reads audit status before reporting.

---

## Typical Session

```bash
# 1. Plan
/experiment-plan "FINAL_PROPOSAL.md"

# 2. Implement
/research-code-agent "implement the method from FINAL_PROPOSAL.md"

# 3. Deploy (small batch)
/experiment-bridge "refine-logs/EXPERIMENT_PLAN.md"

# 3. Deploy (large batch with phases)
/experiment-queue "manifest.yaml"

# 4. Audit
/experiment-audit "results/"

# 5. Analyze
/analyze-results "results/"

# 6. Review loop
/auto-review-loop "my topic"
```

---

## Reviewer Difficulty Levels (auto-review-loop)

| Level | Description |
|-------|-------------|
| `medium` | MCP-based review; Claude controls what GPT sees |
| `hard` | + Reviewer Memory (GPT tracks suspicions) + Debate Protocol |
| `nightmare` | + GPT reads repo directly via `codex exec`; Claude cannot filter |

Default: `medium`. Override: `/auto-review-loop "topic" — difficulty: hard`

---

## File Outputs (typical project)

```
refine-logs/
  EXPERIMENT_PLAN.md          ← experiment-plan
  EXPERIMENT_TRACKER.md       ← experiment-plan, updated by experiment-bridge
  EXPERIMENT_RESULTS.md       ← experiment-bridge
  FINAL_PROPOSAL.md           ← upstream (research-refine)

results/
  ANALYSIS_REPORT.md          ← analyze-results
  ANALYSIS_REPORT.json        ← analyze-results

EXPERIMENT_AUDIT.md           ← experiment-audit
EXPERIMENT_AUDIT.json         ← experiment-audit

review-stage/
  AUTO_REVIEW.md              ← auto-review-loop
  REVIEW_STATE.json           ← auto-review-loop (crash recovery)

MANIFEST.md                   ← all skills (output manifest)
REVIEWER_MEMORY.md            ← auto-review-loop (hard/nightmare only)
```
