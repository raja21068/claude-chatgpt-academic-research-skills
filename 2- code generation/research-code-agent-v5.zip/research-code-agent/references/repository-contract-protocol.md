# Repository contract protocol

Use this protocol for substantial paper-to-code work and implementations spanning several files. Keep small fixes and isolated modules on the existing focused workflow.

1. Write a method summary and inventory missing information. Resolve decisions that change method behavior before full implementation. Use the Code Readiness Gate to record the decision.
2. Start `REPOSITORY_CONTRACT.yaml` from `templates/repository_contract.yaml`. Give each behavior an ID, a source locator, one owning file, an explicit forbidden substitution, and a check with an expected outcome. Capture split isolation, preprocessing, equation reductions, scoring, and baselines when they affect fidelity.
3. Record provenance as `paper_stated`, `author_specified`, `inferred`, `external`, or `unresolved`. Give an exact section, table, equation, repository path/version, or project decision in `source`. For an unresolved item, identify the source area examined. Add `rationale` for inferred, external, and unresolved items. Unresolved items have `verification: null`. Set `blocking: true` when the unknown could change results or undermine the intended claim.
4. List implementation files, responsibilities, and dependencies. Record each shared API or artifact with one producer, its consumers, and the expected signature or schema. Include shapes, dtypes, units, serialization keys, and checkpoint fields where applicable. Declare the producer in each consumer's `depends_on` list.
5. Run the validator in plan mode for a draft. Run it in full mode before full code generation or full experiment execution. Use the printed dependency order when implementing files. Resolve blocking issues or explicitly revise the project scope. Review the evidence behind any inference and record the rationale.
6. After implementing, run full validation with the project root and run the verification checks themselves. Include at least one consumer test for critical shared interfaces, plus a real-data smoke run when data is available. Record which tests actually ran and where outputs were saved. Update the contract and affected tests together if a requirement or shared interface changes.

Run from this package directory with Python 3.10+ and PyYAML installed.

```bash
python scripts/validate_repository_contract.py /path/to/REPOSITORY_CONTRACT.yaml
python scripts/validate_repository_contract.py /path/to/REPOSITORY_CONTRACT.yaml --mode full
python scripts/validate_repository_contract.py /path/to/REPOSITORY_CONTRACT.yaml --mode full --repo-root /path/to/project
```

The validator checks document structure, references, dependency order, blockers, and optionally file existence and Python syntax. Review source grounding and run the listed checks to establish behavior.

Design reference [PaperCompiler by Liu, Pham, and Yoon (2026)](https://arxiv.org/abs/2609.02272). V5 implements a local contract and validator for use in coding-agent sessions.
