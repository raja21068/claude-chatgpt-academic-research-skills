"""Validate a research repository contract without importing project code."""

import argparse
from graphlib import CycleError, TopologicalSorter
from pathlib import Path, PurePosixPath
import sys

import yaml


PROVENANCE = {"paper_stated", "author_specified", "inferred", "external", "unresolved"}


class UniqueKeyLoader(yaml.SafeLoader):
    """Reject duplicate YAML keys instead of silently overwriting evidence."""

    def construct_mapping(self, node, deep=False):
        self.flatten_mapping(node)
        result = {}
        for key_node, value_node in node.value:
            key = self.construct_object(key_node, deep=deep)
            if key in result:
                raise ValueError(f"Duplicate YAML key: {key!r}")
            result[key] = self.construct_object(value_node, deep=deep)
        return result


def require(condition, message):
    if not condition:
        raise ValueError(message)


def field_text(record, field, context):
    value = record.get(field)
    require(isinstance(value, str) and value.strip(), f"{context}.{field} must be nonempty text")
    return value.strip()


def relative_path(value, context):
    require(isinstance(value, str) and value.strip() == value, f"{context} must be a repository-relative path")
    path = PurePosixPath(value)
    require(
        bool(path.parts) and str(path) == value and not path.is_absolute()
        and ".." not in path.parts and "\\" not in value and ":" not in value,
        f"{context} must be a canonical repository-relative path: {value!r}",
    )
    return value


def index_records(contract, section, key, *, required=True):
    records = contract.get(section)
    require(isinstance(records, list) and (records or not required), f"{section} must be a {'nonempty ' if required else ''}list")
    indexed = {}
    for position, record in enumerate(records, start=1):
        context = f"{section}[{position}]"
        require(isinstance(record, dict), f"{context} must be a mapping")
        identifier = field_text(record, key, context)
        require(identifier not in indexed, f"Duplicate {section} {key}: {identifier}")
        indexed[identifier] = record
    return indexed


def file_references(record, key, context, files):
    values = record.get(key)
    require(isinstance(values, list), f"{context}.{key} must be a list")
    references = [relative_path(value, f"{context}.{key}") for value in values]
    require(len(set(references)) == len(references), f"Duplicate entries in {context}.{key}")
    missing = sorted(set(references) - files.keys())
    require(not missing, f"{context}.{key} refers to undeclared files: {', '.join(missing)}")
    return references


def validate_contract(contract, mode="plan"):
    require(isinstance(contract, dict), "Contract must be a YAML mapping")
    require(type(contract.get("schema_version")) is int and contract["schema_version"] == 1, "Expected schema_version: 1")
    files = index_records(contract, "files", "path")
    requirements = index_records(contract, "requirements", "id")
    interfaces = index_records(contract, "interfaces", "id", required=False)

    dependencies = {}
    for path, record in files.items():
        relative_path(record["path"], "files.path")
        field_text(record, "responsibility", path)
        dependencies[path] = file_references(record, "depends_on", path, files)

    try:
        order = list(TopologicalSorter(dependencies).static_order())
    except CycleError as exc:
        raise ValueError(f"File dependencies contain a cycle: {' -> '.join(exc.args[1])}") from exc

    blockers = []
    verification_paths = set()
    for identifier, record in requirements.items():
        context = f"Requirement {identifier}"
        field_text(record, "behavior", context)
        field_text(record, "forbidden_substitution", context)
        owner = relative_path(record.get("owner"), f"{context}.owner")
        require(owner in files, f"{context} has an undeclared owner: {owner}")
        provenance = field_text(record, "provenance", context)
        require(provenance in PROVENANCE, f"{context} has unknown provenance: {provenance}")
        field_text(record, "source", context)
        if provenance in {"inferred", "external", "unresolved"}:
            field_text(record, "rationale", context)
        blocking = record.get("blocking")
        require(type(blocking) is bool, f"{context}.blocking must be true or false")
        verification = record.get("verification")
        if provenance == "unresolved":
            if blocking:
                blockers.append(identifier)
            require(verification is None, f"{context}.verification must be null while unresolved")
            continue
        require(isinstance(verification, dict), f"{context}.verification must describe a check")
        verification_paths.add(relative_path(verification.get("path"), f"{context}.verification.path"))
        field_text(verification, "expected", f"{context}.verification")

    for identifier, record in interfaces.items():
        context = f"Interface {identifier}"
        require(field_text(record, "kind", context) in {"api", "artifact"}, f"{context}.kind must be api or artifact")
        field_text(record, "signature_or_schema", context)
        producer = relative_path(record.get("producer"), f"{context}.producer")
        require(producer in files, f"{context} has an undeclared producer: {producer}")
        consumers = file_references(record, "consumers", context, files)
        require(consumers, f"{context} must have at least one consumer")
        for consumer in consumers:
            require(producer in dependencies[consumer], f"{context} requires {consumer} to depend on {producer}")

    require(mode != "full" or not blockers, f"Unresolved blocking requirements: {', '.join(blockers)}")
    return order, blockers, verification_paths


def check_repository(root, paths):
    root = root.resolve(strict=True)
    require(root.is_dir(), f"Repository root is not a directory: {root}")
    for relative in sorted(paths):
        path = (root / relative).resolve()
        require(path.is_relative_to(root), f"Contract file resolves outside the repository: {relative}")
        require(path.is_file(), f"Contract file missing: {relative}")
        if path.suffix == ".py":
            compile(path.read_bytes(), relative, "exec")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("contract", type=Path)
    parser.add_argument("--mode", choices=("plan", "full"), default="plan")
    parser.add_argument("--repo-root", type=Path, help="Check declared files and verification files against this repository.")
    args = parser.parse_args(argv)

    try:
        contract = yaml.load(args.contract.read_text(encoding="utf-8"), Loader=UniqueKeyLoader)
        order, blockers, verification_paths = validate_contract(contract, args.mode)
        if args.repo_root is not None:
            check_repository(args.repo_root, set(order) | verification_paths)
    except (OSError, SyntaxError, ValueError, TypeError, RuntimeError, yaml.YAMLError) as exc:
        print(f"Contract invalid: {exc}", file=sys.stderr)
        return 1

    print("Repository contract structure verified.")
    print("Implementation order: " + " -> ".join(order))
    if blockers:
        print("Unresolved blocking requirements: " + ", ".join(blockers))
    if args.repo_root is not None:
        print("Declared files exist and Python sources parse. Run the verification checks to confirm behavior.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
