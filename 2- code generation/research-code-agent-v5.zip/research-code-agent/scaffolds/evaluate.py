"""
Evaluation pipeline scaffold for research experiments.
Loads a trained model, runs inference on test set, computes metrics, saves results.

SCAFFOLD — Claude fills # TODO: FILL sections only.
"""

import os
import sys
import json
import logging
import math
from pathlib import Path
from collections import defaultdict

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.config import load_config
from src.utils import set_seed, setup_logging, timer, save_results
from src.data_loader import create_dataloaders, require_data_integrity

logger = logging.getLogger(__name__)


# ============================================================
# Metric Functions
# ============================================================

# TODO: FILL — implement your domain-specific metrics.
# Each metric function should follow this contract:
#
# def metric_name(predictions, targets, **kwargs):
#     """
#     Args:
#         predictions: Model predictions (list, array, or tensor).
#         targets: Ground truth labels (list, array, or tensor).
#     Returns:
#         float: The computed metric value.
#     """
#     pass
#
# Example:
# def accuracy(predictions, targets):
#     correct = sum(p == t for p, t in zip(predictions, targets))
#     return correct / len(targets)


METRIC_REGISTRY = {
    # TODO: FILL — register your metrics here
    # "accuracy": accuracy,
    # "f1_macro": lambda p, t: f1_score(t, p, average='macro'),
    # "rmse": lambda p, t: np.sqrt(np.mean((np.array(p) - np.array(t))**2)),
}


# TODO: FILL — add an expected-value case for each configured metric.
METRIC_SANITY_CASES = [
    # ("metric_name", predictions, targets, expected_value, absolute_tolerance),
]


def validate_metric_names(metric_names):
    if not isinstance(metric_names, (list, tuple)) or not metric_names:
        raise ValueError("Configure at least one evaluation metric.")
    if any(not isinstance(name, str) or not name.strip() for name in metric_names):
        raise ValueError("Metric names must be nonempty strings.")
    if len(set(metric_names)) != len(metric_names):
        raise ValueError("Evaluation metric names must be unique.")
    unknown = [name for name in metric_names if not callable(METRIC_REGISTRY.get(name))]
    if unknown:
        raise ValueError("Unknown evaluation metrics: " + ", ".join(unknown))


def compute_metrics(predictions, targets, metric_names):
    """Compute requested finite scalar metrics and surface metric errors."""
    validate_metric_names(metric_names)
    results = {}
    for name in metric_names:
        try:
            value = float(METRIC_REGISTRY[name](predictions, targets))
        except (TypeError, ValueError, ArithmeticError) as exc:
            raise ValueError(f"Metric {name} failed: {exc}") from exc
        if not math.isfinite(value):
            raise ValueError(f"Metric {name} returned a non-finite value.")
        results[name] = value
    return results


def run_metric_sanity_checks(metric_names=None):
    """Check every selected metric against at least one known expected value."""
    if metric_names is None:
        metric_names = list(METRIC_REGISTRY)
    validate_metric_names(metric_names)
    covered = set()
    for name, predictions, targets, expected, tolerance in METRIC_SANITY_CASES:
        if name not in metric_names:
            continue
        actual = compute_metrics(predictions, targets, [name])[name]
        if (
            not math.isfinite(expected) or not math.isfinite(tolerance) or tolerance < 0
            or not math.isclose(actual, expected, rel_tol=0, abs_tol=tolerance)
        ):
            raise ValueError(f"Metric {name} failed its sanity check: expected {expected}, got {actual}.")
        covered.add(name)
    missing = [name for name in metric_names if name not in covered]
    if missing:
        raise ValueError("Missing metric sanity cases for: " + ", ".join(missing))
    logger.info("Metric sanity checks passed for %s.", ", ".join(metric_names))


# ============================================================
# Inference
# ============================================================

def run_inference(model, test_loader, config):
    """Run inference on test data and collect predictions.

    Args:
        model: Trained model instance.
        test_loader: Test data loader.
        config: Full config dict.

    Returns:
        tuple: (all_predictions, all_targets, all_metadata)

    # TODO: FILL — implement inference for your method.
    # Template:
    #   import torch
    #   model.eval()
    #   all_preds, all_targets = [], []
    #   with torch.no_grad():
    #       for batch in test_loader:
    #           inputs = batch['input'].to(config['device'])
    #           targets = batch['target']
    #           outputs = model(inputs)
    #           preds = outputs.argmax(dim=-1).cpu().tolist()  # adjust for your task
    #           all_preds.extend(preds)
    #           all_targets.extend(targets.tolist())
    #   return all_preds, all_targets, {}
    """
    raise NotImplementedError("Implement run_inference() for your method.")


# ============================================================
# Load Trained Model
# ============================================================

def load_trained_model(config, checkpoint_type="best"):
    """Load a trained model from checkpoint.

    Args:
        config: Full config dict.
        checkpoint_type: 'best' or 'latest'.

    Returns:
        model: Loaded model in eval mode.
    """
    import torch
    from src.train import create_model

    model = create_model(config)
    checkpoint_path = os.path.join(
        config["checkpoint_dir"],
        f"{config['experiment_name']}_{checkpoint_type}.pt"
    )

    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    checkpoint = torch.load(checkpoint_path, map_location=config["device"])
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()

    logger.info(f"Loaded {checkpoint_type} checkpoint from epoch {checkpoint['epoch']}")
    return model


# ============================================================
# Full Evaluation Pipeline
# ============================================================

def evaluate(config, checkpoint_type="best"):
    """Run full evaluation pipeline: load model → inference → metrics → save.

    Args:
        config: Full experiment config dict.
        checkpoint_type: 'best' or 'latest'.

    Returns:
        dict: Evaluation results.
    """
    set_seed(config["seed"])
    eval_logger = setup_logging(config["log_dir"], f"eval_{config['experiment_name']}")

    metric_names = config["evaluation"]["metrics"]
    run_metric_sanity_checks(metric_names)
    require_data_integrity(config)

    # Load model and data
    model = load_trained_model(config, checkpoint_type)
    loaders = create_dataloaders(config)

    if loaders.get('test') is None:
        raise ValueError("No test data available.")

    # Run inference
    eval_logger.info("Running inference on test set...")
    with timer("Inference", eval_logger):
        predictions, targets, metadata = run_inference(model, loaders['test'], config)

    # Compute metrics
    if len(predictions) == 0 or len(predictions) != len(targets):
        raise ValueError("Inference must return nonempty predictions and targets with matching counts.")
    metrics = compute_metrics(predictions, targets, metric_names)
    eval_logger.info(f"Test metrics: {metrics}")

    # Build results
    results = {
        "experiment_name": config["experiment_name"],
        "seed": config["seed"],
        "checkpoint": checkpoint_type,
        "split": "test",
        "num_samples": len(predictions),
        "metrics": metrics,
    }

    # Save results
    results_dir = os.path.join(config["output_dir"], "raw")
    os.makedirs(results_dir, exist_ok=True)

    # Save raw predictions (for detailed analysis)
    preds_path = os.path.join(results_dir, f"{config['experiment_name']}_predictions.json")
    save_results({
        "predictions": predictions,
        "targets": targets,
        "metadata": metadata,
    }, preds_path)

    results_path = os.path.join(results_dir, f"{config['experiment_name']}_test_results.json")
    save_results(results, results_path)
    eval_logger.info(f"Results saved to {results_path}")

    return results


# ============================================================
# Multi-Seed Evaluation Aggregator
# ============================================================

def aggregate_multi_seed_results(config):
    """Aggregate test results across multiple seeds.

    Reads per-seed result files and computes mean ± std for each metric.

    Args:
        config: Full config dict.

    Returns:
        dict: Aggregated results.
    """
    import numpy as np

    seeds = config.get("seeds", [config["seed"]])
    results_dir = os.path.join(config["output_dir"], "raw")
    metric_names = config["evaluation"]["metrics"]
    validate_metric_names(metric_names)
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("Provide a nonempty, unique seed set for aggregation.")
    all_metrics = defaultdict(list)

    for seed in seeds:
        experiment_name = f"{config['experiment_name']}_seed{seed}"
        result_path = os.path.join(results_dir, f"{experiment_name}_test_results.json")
        with open(result_path, encoding="utf-8") as stream:
            result = json.load(stream)
        if result.get("seed") != seed or result.get("experiment_name") != experiment_name:
            raise ValueError(f"Result identity mismatch: {result_path}")
        for metric_name in metric_names:
            value = result.get("metrics", {}).get(metric_name)
            if type(value) not in (int, float) or not math.isfinite(value):
                raise ValueError(f"Missing or invalid metric {metric_name}: {result_path}")
            all_metrics[metric_name].append(value)

    # Aggregate
    aggregated = {}
    for metric_name, values in all_metrics.items():
        aggregated[metric_name] = {
            "mean": float(np.mean(values)),
            "std": float(np.std(values)),
            "min": float(np.min(values)),
            "max": float(np.max(values)),
            "values": values,
            "num_seeds": len(values),
        }

    # Save
    agg_path = os.path.join(config["output_dir"], f"{config['experiment_name']}_aggregated_test.json")
    save_results(aggregated, agg_path)

    # Print table
    print(f"\n{'Metric':<20} {'Mean':>10} {'± Std':>10} {'Min':>10} {'Max':>10} {'Seeds':>6}")
    print("-" * 70)
    for name, stats in aggregated.items():
        print(f"{name:<20} {stats['mean']:>10.4f} {stats['std']:>10.4f} "
              f"{stats['min']:>10.4f} {stats['max']:>10.4f} {stats['num_seeds']:>6}")

    return aggregated


# ============================================================
# Entry Point
# ============================================================

if __name__ == "__main__":
    config = load_config()

    if len(config["seeds"]) > 1:
        for seed in config["seeds"]:
            evaluate({**config, "seed": seed, "experiment_name": f"{config['experiment_name']}_seed{seed}"})
        aggregate_multi_seed_results(config)
    else:
        evaluate(config)
