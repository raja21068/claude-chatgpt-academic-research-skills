"""
Dataset loading and preprocessing scaffold.
Handles train/val/test splits, transforms, and data integrity checks.

SCAFFOLD — Claude fills # TODO: FILL sections only.
"""

import os
import json
import logging
from collections.abc import Mapping
from pathlib import Path

logger = logging.getLogger(__name__)


# ============================================================
# Dataset Class
# ============================================================

class ResearchDataset:
    """Base dataset class for research experiments.

    Subclass this and implement _load_data() and __getitem__()
    for your specific dataset.

    Args:
        data_dir: Root directory containing the dataset.
        split: One of 'train', 'val', 'test'.
        config: Data configuration dict.
        transform: Optional transform/preprocessing function.
    """

    def __init__(self, data_dir, split, config=None, transform=None):
        self.data_dir = Path(data_dir)
        self.split = split
        self.config = config or {}
        self.transform = transform

        # Validate split
        if not isinstance(split, str) or not split.strip():
            raise ValueError("Split name must be nonempty text.")

        # Validate data directory exists
        if not self.data_dir.is_dir():
            raise FileNotFoundError(f"Data directory not found: {self.data_dir}")

        # Load data
        self.samples = self._load_data()
        logger.info(f"Loaded {len(self.samples)} samples for split '{split}'")

    def _load_data(self):
        """Load and return list of samples for the current split.

        Returns:
            list: Each element is a sample (dict, tuple, or custom format).

        # TODO: FILL — implement dataset-specific loading logic.
        # Examples:
        #   - Read CSV: pd.read_csv(self.data_dir / f'{self.split}.csv')
        #   - Read images: glob(self.data_dir / self.split / '*.png')
        #   - Read JSON: json.load(open(self.data_dir / f'{self.split}.json'))
        #   - Read HuggingFace: datasets.load_dataset('name', split=self.split)
        """
        raise NotImplementedError("Implement _load_data() for your dataset.")

    def __getitem__(self, idx):
        """Return a single preprocessed sample.

        Args:
            idx: Sample index.

        Returns:
            dict: With keys like 'input', 'target', 'metadata', etc.

        # TODO: FILL — implement sample retrieval and preprocessing.
        """
        sample = self.samples[idx]

        if self.transform:
            sample = self.transform(sample)

        return sample

    def __len__(self):
        return len(self.samples)


# ============================================================
# Data Loaders (PyTorch)
# ============================================================

def create_dataloaders(config):
    """Create train, val, and test data loaders.

    Args:
        config: Full experiment config dict.

    Returns:
        dict: {'train': loader, 'val': loader, 'test': loader}
    """
    data_config = config.get("data", {})
    data_dir = data_config.get("data_dir", "./data")
    batch_size = data_config.get("batch_size", 32)
    num_workers = data_config.get("num_workers", 4)

    # TODO: FILL — define transforms for each split
    train_transform = None  # TODO: FILL — e.g., augmentation for training
    eval_transform = None   # TODO: FILL — e.g., normalize only for eval

    # Create datasets
    datasets = {}
    for split in ['train', 'val', 'test']:
        transform = train_transform if split == 'train' else eval_transform
        try:
            datasets[split] = ResearchDataset(
                data_dir=data_dir,
                split=data_config.get(f"{split}_split", split),
                config=data_config,
                transform=transform
            )
        except (FileNotFoundError, AssertionError) as e:
            logger.warning(f"Could not load split '{split}': {e}")
            datasets[split] = None

    # Create loaders
    try:
        from torch.utils.data import DataLoader

        loaders = {}
        for split, dataset in datasets.items():
            if dataset is None:
                loaders[split] = None
                continue
            loaders[split] = DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=(split == 'train'),
                num_workers=num_workers,
                pin_memory=True,
                drop_last=(split == 'train'),
            )
        return loaders

    except ImportError:
        logger.info("PyTorch not available. Returning raw datasets.")
        return datasets


# ============================================================
# Data Integrity Checks
# ============================================================

def load_split_ids(config):
    """Return stable sample or group IDs for each required split.

    Key the mapping by logical names such as train, val, and test. Resolve
    dataset split aliases the same way as create_dataloaders. Use patient,
    subject, or other group IDs when the protocol requires group isolation.
    """
    # TODO: FILL — read real split membership from the dataset or manifest.
    raise NotImplementedError("Split membership and leakage checks are not configured.")


def verify_data_integrity(config):
    """Check that required splits are nonempty and their identifiers do not overlap."""
    data_config = config.get("data", {})
    data_dir = Path(data_config.get("data_dir", "./data"))
    required_splits = data_config.get("required_splits", ["train", "val", "test"])
    report = {
        "data_dir": str(data_dir),
        "exists": data_dir.is_dir(),
        "splits": {},
        "leakage_check": "not_checked",
        "issues": [],
        "status": "FAIL",
    }

    if not report["exists"]:
        report["issues"].append(f"Data directory not found: {data_dir}")
        return report
    if (
        not isinstance(required_splits, list) or not required_splits
        or any(not isinstance(name, str) or not name.strip() for name in required_splits)
        or len(set(required_splits)) != len(required_splits)
    ):
        report["issues"].append("data.required_splits must be a nonempty list of unique split names.")
        return report

    try:
        split_ids = load_split_ids(config)
    except NotImplementedError as exc:
        report["status"] = "INCOMPLETE"
        report["issues"].append(str(exc))
        return report
    except (OSError, ValueError) as exc:
        report["issues"].append(f"Could not load split membership: {exc}")
        return report
    if not isinstance(split_ids, Mapping):
        report["issues"].append("load_split_ids must return a mapping from split names to identifiers.")
        return report

    seen = set()
    overlap_found = False
    all_splits_valid = True
    for split in required_splits:
        raw_ids = split_ids.get(split)
        report["splits"][split] = {"exists": raw_ids is not None, "count": 0}
        if raw_ids is None:
            report["issues"].append(f"Missing required split: {split}")
            all_splits_valid = False
            continue
        try:
            if isinstance(raw_ids, (str, bytes, Mapping)):
                raise ValueError("Expected an iterable of sample or group identifiers")
            identifiers = list(raw_ids)
            if any(
                identifier is None
                or (isinstance(identifier, (str, bytes)) and not identifier.strip())
                or identifier != identifier
                for identifier in identifiers
            ):
                raise ValueError("Split contains a missing identifier")
            unique_ids = set(identifiers)
        except (TypeError, ValueError) as exc:
            report["issues"].append(f"Invalid identifiers in split {split}: {exc}")
            all_splits_valid = False
            continue

        report["splits"][split]["count"] = len(identifiers)
        if not identifiers:
            report["issues"].append(f"Required split is empty: {split}")
            all_splits_valid = False
            continue

        overlap_count = len(seen.intersection(unique_ids))
        if overlap_count:
            overlap_found = True
            report["issues"].append(f"Split {split} shares {overlap_count} identifier(s) with earlier splits.")
        seen.update(unique_ids)

    if overlap_found:
        report["leakage_check"] = "FAIL"
    elif all_splits_valid and len(required_splits) > 1:
        report["leakage_check"] = "PASS"
    elif all_splits_valid:
        report["leakage_check"] = "not_applicable"
    if not report["issues"]:
        report["status"] = "PASS"
    return report


def require_data_integrity(config):
    report = verify_data_integrity(config)
    if report["status"] != "PASS":
        raise ValueError(f"Data integrity {report['status']}: " + "; ".join(report["issues"]))
    return report


if __name__ == "__main__":
    from src.config import load_config

    try:
        require_data_integrity(load_config())
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
    print("Data integrity check passed.")
