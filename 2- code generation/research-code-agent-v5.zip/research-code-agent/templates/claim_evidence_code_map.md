# Claim-Evidence-Code Map

| Paper claim | Requirement IDs | Code artifact | Dataset/split | Metric | Result file | Paper table/figure | Verification | Caveat |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |
