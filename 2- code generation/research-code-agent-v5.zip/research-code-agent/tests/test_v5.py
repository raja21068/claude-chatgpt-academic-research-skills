import json
import logging
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import yaml


ROOT = Path(__file__).resolve().parents[1]


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.contract = yaml.safe_load((ROOT / "templates/repository_contract.yaml").read_text())
        self.path = self.root / "contract.yaml"

    def validate(self, *args):
        self.path.write_text(yaml.safe_dump(self.contract), encoding="utf-8")
        return subprocess.run(
            [sys.executable, ROOT / "scripts/validate_repository_contract.py", self.path, *args],
            capture_output=True, text=True,
        )

    def test_dependency_order_and_files(self):
        self.assertIn("src/calibrate.py -> src/evaluate.py", self.validate("--mode", "full").stdout)
        self.assertIn("Contract file missing", self.validate("--repo-root", str(self.root)).stderr)
        for file in ("src/calibrate.py", "src/evaluate.py", "tests/test_evaluate.py", "tests/test_calibrate.py"):
            path = self.root / file
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("value = 1\n", encoding="utf-8")
        result = self.validate("--mode", "full", "--repo-root", str(self.root))
        self.assertEqual(result.returncode, 0, result.stderr)
        (self.root / "src/evaluate.py").write_text("return [", encoding="utf-8")
        self.assertEqual(self.validate("--repo-root", str(self.root)).returncode, 1)

    def test_draft_reports_unresolved_blocker_and_full_mode_rejects_it(self):
        self.contract["requirements"][0].update(
            provenance="unresolved", rationale="Threshold selection is unspecified.", verification=None,
        )
        result = self.validate()
        self.assertEqual(result.returncode, 0)
        self.assertIn("Unresolved blocking requirements: REQ-001", result.stdout)
        self.assertIn("Unresolved blocking requirements: REQ-001", self.validate("--mode", "full").stderr)

    def test_bad_owner_cycle_and_undeclared_interface_dependency(self):
        self.contract["requirements"][0]["owner"] = "../outside.py"
        self.assertIn("canonical repository-relative path", self.validate().stderr)
        self.contract["requirements"][0]["owner"] = "src/evaluate.py"
        self.contract["files"][0]["depends_on"] = ["src/evaluate.py"]
        self.assertIn("cycle", self.validate().stderr)
        self.contract["files"][0]["depends_on"] = []
        self.contract["files"][1]["depends_on"] = []
        self.assertIn("to depend on", self.validate().stderr)


class ScaffoldTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        shutil.copytree(ROOT / "scaffolds", self.root / "src")
        sys.path.insert(0, str(self.root))
        self.addCleanup(sys.path.remove, str(self.root))
        self.addCleanup(self.remove_modules)
        from src import config, data_loader, evaluate

        self.config = config
        self.data = data_loader
        self.evaluate = evaluate
        self.settings = {
            "data": {"data_dir": str(self.root)},
            "evaluation": {"metrics": ["accuracy"]},
            "experiment_name": "study",
            "output_dir": str(self.root / "results"),
            "seed": 42,
            "seeds": [42, 123],
        }

    @staticmethod
    def remove_modules():
        for name in list(sys.modules):
            if name == "src" or name.startswith("src."):
                del sys.modules[name]

    def register_accuracy(self):
        def accuracy(predictions, targets):
            return sum(p == t for p, t in zip(predictions, targets)) / len(targets)

        self.evaluate.METRIC_REGISTRY["accuracy"] = accuracy

    def test_data_checks_incomplete_empty_overlapping_and_disjoint_splits(self):
        report = self.data.verify_data_integrity(self.settings)
        self.assertEqual(report["status"], "INCOMPLETE")
        with self.assertRaisesRegex(ValueError, "INCOMPLETE"):
            self.data.require_data_integrity(self.settings)
        for splits, status, leakage in [
            ({"train": [1], "val": [], "test": [3]}, "FAIL", "not_checked"),
            ({"train": [1], "val": [2]}, "FAIL", "not_checked"),
            ({"train": [1], "val": [2], "test": [1]}, "FAIL", "FAIL"),
            ({"train": [1], "val": [2], "test": [3]}, "PASS", "PASS"),
        ]:
            with self.subTest(splits=splits), patch.object(self.data, "load_split_ids", return_value=splits):
                report = self.data.verify_data_integrity(self.settings)
                self.assertEqual((report["status"], report["leakage_check"]), (status, leakage))

    def test_metric_checks_reject_unknown_missing_incorrect_and_nonfinite_values(self):
        with self.assertRaisesRegex(ValueError, "Unknown"):
            self.evaluate.run_metric_sanity_checks(["accuracy"])
        self.register_accuracy()
        with self.assertRaisesRegex(ValueError, "Missing metric sanity"):
            self.evaluate.run_metric_sanity_checks(["accuracy"])
        self.evaluate.METRIC_SANITY_CASES.append(("accuracy", [1, 0], [1, 1], 1.0, 0.0))
        with self.assertRaisesRegex(ValueError, "failed its sanity check"):
            self.evaluate.run_metric_sanity_checks(["accuracy"])
        self.evaluate.METRIC_SANITY_CASES[0] = ("accuracy", [1, 0], [1, 1], 0.5, 0.0)
        self.evaluate.run_metric_sanity_checks(["accuracy"])
        self.evaluate.METRIC_REGISTRY["accuracy"] = lambda *_: float("nan")
        with self.assertRaisesRegex(ValueError, "non-finite"):
            self.evaluate.compute_metrics([1], [1], ["accuracy"])

    def test_partial_seed_results_cannot_produce_an_aggregate(self):
        self.register_accuracy()
        raw = Path(self.settings["output_dir"]) / "raw"
        raw.mkdir(parents=True)
        for seed in self.settings["seeds"]:
            name = f"study_seed{seed}"
            result = {"experiment_name": name, "seed": seed, "metrics": {"accuracy": 1.0}}
            (raw / f"{name}_test_results.json").write_text(json.dumps(result), encoding="utf-8")
            if seed == 42:
                with self.assertRaises(FileNotFoundError):
                    self.evaluate.aggregate_multi_seed_results(self.settings)
                self.assertFalse((raw.parent / "study_aggregated_test.json").exists())
        summary = self.evaluate.aggregate_multi_seed_results(self.settings)
        self.assertEqual(summary["accuracy"]["num_seeds"], 2)

    def test_evaluation_writes_results_only_after_validation(self):
        self.register_accuracy()
        self.evaluate.METRIC_SANITY_CASES.append(("accuracy", [1, 0], [1, 1], 0.5, 0.0))
        self.settings["log_dir"] = str(self.root / "logs")

        def close_eval_log():
            logger = logging.getLogger("eval_study")
            for handler in logger.handlers[:]:
                logger.removeHandler(handler)
                handler.close()

        self.addCleanup(close_eval_log)
        with (
            patch.object(self.data, "load_split_ids", return_value={"train": [1], "val": [2], "test": [3]}),
            patch.object(self.evaluate, "load_trained_model", return_value=object()),
            patch.object(self.evaluate, "create_dataloaders", return_value={"test": object()}),
            patch.object(self.evaluate, "run_inference", return_value=([1], [], {})) as inference,
        ):
            with self.assertRaisesRegex(ValueError, "matching counts"):
                self.evaluate.evaluate(self.settings)
            raw = Path(self.settings["output_dir"]) / "raw"
            self.assertFalse(raw.exists())

            inference.return_value = ([1, 0], [1, 1], {})
            result = self.evaluate.evaluate(self.settings)
            self.assertEqual(result["metrics"], {"accuracy": 0.5})
            self.assertEqual(json.loads((raw / "study_test_results.json").read_text()), result)
            self.assertTrue((raw / "study_predictions.json").is_file())

    def test_runner_config_selects_exactly_one_explicit_seed(self):
        config_file = self.root / "experiment.yaml"
        settings = {
            "data": {"data_dir": str(self.root)}, "device": "cpu",
            "output_dir": str(self.root / "results"), "checkpoint_dir": str(self.root / "checkpoints"),
            "log_dir": str(self.root / "logs"),
        }
        config_file.write_text(yaml.safe_dump(settings), encoding="utf-8")
        config = self.config.load_config(str(config_file), ["--seed", "23"])
        self.assertEqual((config["seed"], config["seeds"]), (23, [23]))
        for module, error in [
            ("src.data_loader", "Data integrity INCOMPLETE"),
            ("src.train", "Data integrity INCOMPLETE"),
            ("src.evaluate", "Configure at least one evaluation metric"),
        ]:
            with self.subTest(module=module):
                result = subprocess.run(
                    [sys.executable, "-m", module, "--config", str(config_file), "--seed", "23"],
                    cwd=self.root, capture_output=True, text=True,
                )
                self.assertNotEqual(result.returncode, 0)
                self.assertIn(error, result.stderr)


if __name__ == "__main__":
    unittest.main()
