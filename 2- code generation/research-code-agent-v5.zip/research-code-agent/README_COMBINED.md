# Research Code Agent V5

V5 extends the V4 experiment workflow with a repository contract and runnable verification checks. Use the package inside a Claude Code or Codex session. The local checks require Python 3.10+ and PyYAML. They run without a separate API key.

## What changed

- Trace each paper requirement to its source, owning file, and a check with an expected outcome.
- Declare shared APIs and artifact schemas. Validate file dependencies and reject unresolved blockers in full mode.
- Verify real split membership and cross-split overlap before training or evaluation. Fill `load_split_ids` with the project's sample or group IDs.
- Require a registered metric and an expected-value case for every requested metric. Reject missing results, non-finite metric values, and incomplete seed aggregates.
- Make `--seed` run one seed so the Bash and Windows runner loops use consistent checkpoint and result names.

## Use

Point the coding agent at `research-code-agent/SKILL.md` and provide the paper or method, data and split information, and the target claims. For a multi-file implementation, have it adapt `templates/repository_contract.yaml` before generating code. Follow the [repository contract protocol](references/repository-contract-protocol.md) for the validation sequence.

```bash
python -m pip install PyYAML
python scripts/validate_repository_contract.py templates/repository_contract.yaml --mode full
python -m unittest discover -s tests -v
```

The validator checks references, dependency order, and blockers. With `--repo-root` it also checks that the declared files and verification files exist and that Python sources parse. Run the project tests and experiments to confirm behavior. The sample contract is illustrative.

The ZIP includes scaffolds to adapt to a research project. Complete the data loader, model, training and evaluation logic for that project. The SSH queue workflow uses a separate ARIS installation and the reviewer workflow uses available reviewers or a local audit.

## Earlier changes

### V4 integration

The original folders remain:

- `references/`
- `scaffolds/`
- `templates/`
- `research-to-github-repo.skill`
- `SKILL.md`

Integrated additions:

- `references/experiment-plan-protocol.md`
- `references/experiment-bridge-protocol.md`
- `references/experiment-queue-protocol.md`
- `references/experiment-audit-protocol.md`
- `templates/one_shot_research_pipeline_contract.yaml`
- `templates/claim_gate.md`
- `templates/experiment_tracker.md`
- `templates/queue_manifest.yaml`
- `templates/results_summary.md`
- `templates/experiment_audit_report.md`
- `templates/method_summary_contract.yaml`
- `templates/missing_information_detector.md`
- `templates/code_readiness_gate.md`

### Workflow

```text
paper idea / method / code
        ↓
method summary contract
        ↓
missing-information detector
        ↓
code readiness gate
        ↓
claim gate
        ↓
domain evaluation contract
        ↓
experiment plan
        ↓
Claude Code implementation prompt
        ↓
sanity-first scaffold implementation
        ↓
experiment queue when needed
        ↓
results aggregation
        ↓
integrity audit
        ↓
claim-evidence-code map
        ↓
paper-ready tables, figures, and interpretation
```

### One-shot example

```text
Use research-code-agent in one-shot mode.
Create a complete claim-driven experiment pipeline for this paper idea/method.
Produce PROJECT_BRIEF.yaml, METHOD_SUMMARY_CONTRACT.yaml,
MISSING_INFORMATION_DETECTOR.md, CODE_READINESS_GATE.md, CLAIM_GATE.md,
DOMAIN_EVALUATION_CONTRACT.yaml, EXPERIMENT_PLAN.md, EXPERIMENT_TRACKER.md, IMPLEMENTATION_PLAN.md,
CLAUDE_CODE_IMPLEMENTATION_PROMPT.md, QUEUE_MANIFEST.yaml if needed,
RESULTS_SUMMARY.md, EXPERIMENT_AUDIT.md, and CLAIM_EVIDENCE_CODE_MAP.md.
Do not fabricate numeric results. Use assumptions only when labeled.
```

### V2 method summary and missing-information checks

This version makes two blocks mandatory before Claude Code implementation or queue execution:

1. **Method Summary Contract** (`templates/method_summary_contract.yaml`)
   - input
   - output
   - architecture
   - training process
   - losses
   - datasets
   - evaluation

2. **Missing Information Detector** (`templates/missing_information_detector.md`)
   - hidden hyperparameters
   - unspecified preprocessing
   - ambiguous equations
   - missing optimizer settings
   - missing seeds
   - missing data filtering

The full-queue execution gate now requires all BLOCKER items from the missing-information detector to be resolved before large runs or paper claims.


### V3 Code Readiness Gate

This version adds the mandatory **Code Readiness Gate**:

- `templates/code_readiness_gate.md`

The gate must run after the Method Summary Contract and Missing Information Detector, before Claude Code implementation. It gives one of three decisions:

1. `READY_FOR_FULL_CODE` — generate full runnable code.
2. `READY_FOR_SCAFFOLD_ONLY` — generate scaffold, TODO markers, config placeholders, and sanity tests only.
3. `NOT_READY_FOR_CODE` — do not generate full code; produce missing-information report and minimal blocking questions.

This prevents the LLM from inventing hidden hyperparameters, preprocessing, filtering rules, optimizer settings, seeds, metrics, baselines, equations, dataset splits, or result numbers.
