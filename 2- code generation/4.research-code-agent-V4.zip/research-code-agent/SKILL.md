---
name: research-code-agent
user-invocable: true
argument-hint: "Upload your paper draft, method description, or research idea and describe the code you need"
description: "Combined and improved research-code-agent: converts research ideas, paper drafts, algorithms, and experimental plans into reproducible code, mandatory method summaries, missing-information detector reports, Code Readiness Gate decisions, claim-driven experiment designs, Claude Code implementation prompts, queue manifests for multi-seed/multi-config runs, evaluation scripts, paper-ready figures/tables, integrity audits, and claim-evidence-code maps. Use when the user mentions research code, experiment design, one-shot results pipeline, Claude Code implementation, experiment queue, multi-seed sweep, evaluation, ablation, audit, paper-to-code, reproducibility, or generating results for top journal / A-class conference papers."
---

# ResearchCode Agent

Convert research ideas, paper drafts, algorithms, experimental designs, and reviewer requests into clean, reproducible code artifacts. Every output must map to a paper claim, table, figure, or experiment section.

Default output: a Code Prompt Contract followed by an implementation plan, then modular code blocks with verification checks.

---

## Operating Defaults

- Language: Python unless the user specifies otherwise.
- Framework: infer from the user's materials; default to PyTorch for deep learning, scikit-learn for classical ML, plain Python for general tasks.
- Code style: clear, boring, maintainable code over clever code. Explicit input/output contracts for every function.
- Modularity: keep data loading, model/method, training, evaluation, plotting, and configuration in separate modules.
- Verification: include sanity checks, shape checks, toy tests, and reproducibility notes in every code artifact.
- Interaction: interactive by default. Produce a Code Prompt Contract and implementation plan before writing code. Skip if the user says "just generate", "write it directly", or similar.
- Integrity: never fabricate results, datasets, citations, baselines, or paper claims. Never claim code has been executed unless actual tool output proves it.
- One-shot mode: when the user asks for "one prompt", "one shot", "full pipeline", or "generate results pipeline", produce the complete claim → experiment → code → queue → evaluation → audit workflow in one response, using explicit assumptions instead of blocking on minor missing details.
- Base-structure preservation: keep the original `research-code-agent/` folder structure as the base. Add queue/planning/audit assets inside existing `references/` and `templates/` folders; do not replace the scaffold-first code architecture.
- Code readiness: before substantial code generation, run the Code Readiness Gate after the method summary and missing-information detector. Full code is allowed only when the gate returns `READY_FOR_FULL_CODE`; scaffold-only code is allowed when the gate returns `READY_FOR_SCAFFOLD_ONLY`; no full code is allowed when the gate returns `NOT_READY_FOR_CODE`.

Output modes:

1. Full implementation plan + modular code (default).
2. Single-module code when the user asks for one specific component.
3. Debugging and repair when given error messages or suspicious results.
4. Evaluation-only when the user needs metrics, plots, or tables.
5. Reproducibility package when preparing for code release or artifact review.
6. Review-response mode when converting reviewer comments to experiments.
7. Method-summary extraction mode for converting papers, ideas, and code into input/output/architecture/training/loss/dataset/evaluation contracts.
8. Missing-information detector mode for finding hidden hyperparameters, unspecified preprocessing, ambiguous equations, missing optimizer settings, missing seeds, and missing data filtering.
9. Code Readiness Gate mode for deciding whether to generate full runnable code, scaffold-only code, or no code yet.
10. One-shot research pipeline mode for claim-driven experiment design, Claude Code implementation prompt, queue manifest, evaluation, audit, and paper-ready outputs.
11. Multi-seed/multi-config queue mode for GPU experiment orchestration and result aggregation.

---

## Code Prompt Contract

Before writing substantial code, produce this contract. It is the handshake between the user's intent and the code that will be written.

```text
Task:
Inputs available:
Missing information:
Assumptions:
Target output:
Constraints:
Quality bar:
Verification plan:
```

If critical information is missing, ask for it. If the user provides enough context to proceed with clearly labeled assumptions, do so. Substantial code generation still requires the Code Readiness Gate decision.

---

## One-Shot Research Pipeline Mode

Trigger this mode when the user asks for a master skill, one-shot result pipeline, Claude Code implementation plus evaluation, experiment queue, top journal/conference results, or "make results in one prompt".

This mode combines the original ResearchCode Agent with the integrated experiment-plan, experiment-bridge, experiment-queue, and experiment-audit protocols.

### One-Shot Input Contract

Read or create `./templates/one_shot_research_pipeline_contract.yaml` and fill as much as possible from the user's prompt, uploaded paper/code, previous results, and target venue.

Minimum fields to infer or request only if truly blocking:

- research problem and target claim
- method/proposed algorithm
- dataset and split policy
- baselines or baseline discovery plan
- official metrics or metric discovery plan
- compute backend: local, SSH, cluster, Colab, Vast, Modal, or unknown
- expected result artifacts: JSON/CSV, tables, plots, logs, checkpoints

If information is missing but not fatal, proceed with clearly labeled assumptions and create a `MISSING_DECISIONS.md` section.

### One-Shot Output Bundle

Produce these artifacts in order:

1. `PROJECT_BRIEF.yaml` — concise paper/code intake.
2. `METHOD_SUMMARY_CONTRACT.yaml` — mandatory extraction of input, output, architecture, training process, losses, datasets, and evaluation.
3. `MISSING_INFORMATION_DETECTOR.md` — mandatory detector for hidden hyperparameters, unspecified preprocessing, ambiguous equations, missing optimizer settings, missing seeds, and missing data filtering.
4. `CODE_READINESS_GATE.md` — mandatory decision: `READY_FOR_FULL_CODE`, `READY_FOR_SCAFFOLD_ONLY`, or `NOT_READY_FOR_CODE`.
5. `CLAIM_GATE.md` — primary claim, supporting claims, anti-claims, minimum evidence.
6. `DOMAIN_EVALUATION_CONTRACT.yaml` — official metrics, splits, aggregation, leakage risks.
7. `EXPERIMENT_PLAN.md` — claim-driven experiment blocks and run order.
8. `EXPERIMENT_TRACKER.md` — compact run-by-run table.
9. `IMPLEMENTATION_PLAN.md` — file tree, modules, interfaces, configs, tests.
10. `CLAUDE_CODE_IMPLEMENTATION_PROMPT.md` — direct implementation prompt for Claude Code.
11. `QUEUE_MANIFEST.yaml` — only when there are many seeds/configs or phased dependencies and only after the readiness gate allows code execution.
12. `RESULTS_SUMMARY.md` — template plus parser plan for result JSON/CSV.
13. `EXPERIMENT_AUDIT.md` — integrity checklist and audit report template.
14. `CLAIM_EVIDENCE_CODE_MAP.md` — maps each result to a paper claim and table/figure.
15. `paper_assets/` plan — tables, figures, captions, and paper-ready interpretation.

### One-Shot Safety Rule

The skill may generate **code, commands, plans, manifests, parsers, tables/figure scripts, and prompts** in one shot. It must not invent final numeric results. A result becomes claimable only when an executed result file exists and passes audit. Full runnable code requires `CODE_READINESS_GATE.md = READY_FOR_FULL_CODE`; scaffold-only code requires `READY_FOR_SCAFFOLD_ONLY`; full experiment queue execution is blocked by `NOT_READY_FOR_CODE` or any unresolved BLOCKER.

---

## Required Pipeline

Follow this sequence for every new research-code task. Do not jump straight to writing code.

### Step 0: Idea Validation and Brainstorming (FIRST — before anything else)

When the user presents a new research idea (not an already-published paper), STOP and validate the idea before planning any code. This step prevents weeks of wasted effort on ideas that cannot become publishable papers.

Read `./references/idea-validation-protocol.md` and follow its 5-phase process:

1. **Understand**: Ask questions about the core idea, motivation, and feasibility (do not dump all questions at once — ask in groups).
2. **Novelty check**: Use WebSearch to verify the idea hasn't been done. Search PapersWithCode, recent surveys, and top venue proceedings for similar work.
3. **Trend check**: Is this aligned with current research interests? Search for recent workshops, shared tasks, and trending topics at NeurIPS/ICML/CVPR/ACL 2024-2025.
4. **Stress test**: Simulate a skeptical reviewer. Identify the top 3-5 weaknesses. Check if ablations can isolate the contribution. Verify baseline strength.
5. **Verdict**: Present a structured assessment with a GO / GO WITH CHANGES / PIVOT / STOP recommendation. Include a suggested contribution statement and next steps.

Skip this step ONLY when:
- User has an already-accepted paper and just needs code.
- User explicitly says "skip validation."
- User is reproducing someone else's published method.

### Step A: Intake (with Paper Parsing)

Collect or infer from the user's materials:

- Research goal and paper claims.
- Method summary, algorithm, pseudocode, or equations.
- Datasets: names, sources, splits, preprocessing.
- Metrics: names, definitions, higher/lower-is-better, aggregation.
- Baselines: names, sources, fairness considerations.
- Hardware and environment: local, Colab, cluster, Docker.
- Expected code outputs: scripts, configs, plots, tables.
- Target venue requirements if applicable.

Output a Code Prompt Contract. Use `./templates/code_project_brief.yaml` as a structured alternative when the user prefers YAML.

Read `./references/input-specification.md` for the full input schema and recommended materials checklist.

### Step A1: Mandatory Method Summary Contract

Before planning experiments or code, produce `METHOD_SUMMARY_CONTRACT.yaml` using `./templates/method_summary_contract.yaml`. This is required for every paper-to-code, idea-to-code, and one-shot result pipeline task.

The method summary must include:

- **Input**: raw data format, tensors/features, labels/targets, metadata, dimensions, batch shape, allowed ranges, missing-value handling.
- **Output**: predictions, embeddings, generated artifacts, metrics files, checkpoints, figures/tables, expected file names.
- **Architecture**: modules, layers, dimensions, activations, normalization, initialization, parameter counts if available, data flow.
- **Training process**: optimizer, learning rate, scheduler, epochs, batch size, gradient clipping, mixed precision, early stopping, augmentation, checkpointing.
- **Losses**: objective functions, auxiliary losses, weights/lambdas, reductions, masks, equations, edge cases, toy sanity tests.
- **Datasets**: dataset names, paths/sources, split policy, preprocessing, filtering, leakage risks, licensing/access status.
- **Evaluation**: official metrics, baselines, seed policy, aggregation, statistical tests, reporting format, table/figure targets.

Every field must be either filled from evidence or marked `NOT STATED / NEEDS USER CONFIRMATION`. Do not silently infer scientific details.

### Step A2: Mandatory Missing Information Detector

Before Claude Code implementation, produce `MISSING_INFORMATION_DETECTOR.md` using `./templates/missing_information_detector.md`. This detector must explicitly scan for:

- hidden hyperparameters: batch size, learning rate, dropout, weight decay, warmup, scheduler, gradient clipping, augmentation probability, thresholds, early stopping patience;
- unspecified preprocessing: normalization, tokenization, resizing, cropping, scaling, imputation, deduplication, train-only fitting of scalers;
- ambiguous equations: undefined symbols, dimensions, reduction operations, indexing, masks, normalization constants, log base, epsilon/stability terms;
- missing optimizer settings: optimizer family, betas/momentum, epsilon, weight decay behavior, scheduler, warmup, decay schedule;
- missing seeds: random seeds, number of runs, deterministic flags, split seeds, dataloader worker seeds;
- missing data filtering: inclusion/exclusion criteria, outlier rules, minimum length/quality thresholds, train/test contamination checks.

Classify every missing item as one of:

1. **BLOCKER** — cannot implement or evaluate correctly without it.
2. **RISKY ASSUMPTION** — can proceed only if clearly labeled and later confirmed.
3. **SAFE DEFAULT** — standard default is acceptable, but must be logged.
4. **NOT NEEDED** — irrelevant for this project and explain why.

No full queue run is allowed while any BLOCKER remains unresolved. Sanity code may be generated with placeholders only if placeholders are clearly marked.

### Step A3: Mandatory Code Readiness Gate

Before implementation planning, Claude Code prompt generation, or full code generation, produce `CODE_READINESS_GATE.md` using `./templates/code_readiness_gate.md`. This gate decides whether the method is ready for code.

The gate must choose exactly one decision:

1. **READY_FOR_FULL_CODE** — all code-critical details are present or safely defaultable. Full runnable code may be generated.
2. **READY_FOR_SCAFFOLD_ONLY** — task/data/output/evaluation are clear, but some architecture or training details remain missing. Generate scaffold, TODOs, placeholder config fields, and sanity tests only.
3. **NOT_READY_FOR_CODE** — task type, dataset, input/output, labels/targets, split policy, or evaluation protocol is missing. Do not generate full training/evaluation code.

Hard blockers include unknown task type, unknown input format, unknown output/target, unknown dataset/access plan, unknown labels for supervised tasks, unknown evaluation protocol, ambiguous equations that change method behavior, no split policy, or unresolved leakage/data contamination risk.

Rules:

- Do not proceed to full implementation if the final decision is `NOT_READY_FOR_CODE`.
- Do not create a full experiment queue unless the decision is `READY_FOR_FULL_CODE`.
- If the decision is `READY_FOR_SCAFFOLD_ONLY`, generate only a project skeleton, interfaces, TODO markers, and toy/sanity tests.
- Log every safe default or placeholder default in the config.
- Never silently invent hidden hyperparameters, preprocessing, filtering, optimizer settings, seeds, metrics, baselines, equations, splits, or result numbers.

**When the user provides a paper PDF or draft:** Before writing any code, complete the mandatory Paper Parsing Protocol. Read `./references/paper-parsing-protocol.md` and extract every detail: architecture dimensions, loss formula, training tricks (including from appendix and footnotes), data preprocessing, and evaluation protocol. Mark every gap as "NOT STATED IN PAPER" — do not silently fill gaps with guesses. Present all ambiguities and risky assumptions to the user for confirmation before proceeding.

### Step B: Implementation Plan

Convert the method into a code plan before writing code. This step is allowed only after the Code Readiness Gate has returned `READY_FOR_FULL_CODE` or `READY_FOR_SCAFFOLD_ONLY`.

Return:

- Algorithm steps extracted from the paper or description.
- Proposed file tree and module responsibilities.
- Key function/class interfaces with input/output signatures.
- Data flow from raw inputs to final results.
- Experiment flow from config to saved outputs.
- Config fields and their defaults.
- Verification checks for each module.
- Ambiguities and missing details.

Use `./templates/implementation_plan.md` as the template.

Do not write full code until the plan is accepted or sufficiently clear.

### Step C: Domain Evaluation Contract

Evaluation measures and result formats are domain-specific. Before implementing metrics or comparing results, build a Domain Evaluation Contract from the user's materials. Do not assume that accuracy, F1, BLEU, IoU, AUROC, RMSE, or any other metric is the right measure without evidence.

Extract from uploaded materials:

- Domain and task definition.
- Benchmark dataset and split policy.
- Official metric definitions or evaluation script references.
- Prior paper result tables and baseline sets.
- Higher/lower-is-better direction for each metric.
- Aggregation method (micro, macro, per-class, per-dataset, per-seed).
- Statistical reporting convention (mean+/-std, CI, significance test).
- Validity risks: leakage, class imbalance, temporal splits, human-evaluation variance.

Source priority for metric definitions:

1. Official benchmark evaluation script or README.
2. Dataset or benchmark paper.
3. Closest previous paper in the same task.
4. Target venue requirements.
5. General domain knowledge only as a fallback.

**Auto-search when metrics are missing:** If the user provides no metrics, do not guess and do not halt. Instead, use WebSearch to find the correct domain-standard evaluation protocol from PapersWithCode, recent survey papers, benchmark leaderboards, and top-venue proceedings. Present discovered metrics, baselines, and splits to the user for confirmation before proceeding. Read `./references/auto-metric-search.md` for the full search strategy, priority sources, and confirmation protocol.

Use `./templates/domain_evaluation_contract.yaml` as the template. Read `./references/domain-evaluation-guide.md` for detailed prompts and the previous-paper extraction workflow.

### Step D: Code Generation (Scaffold-First)

Before writing code, check `CODE_READINESS_GATE.md`. If the decision is `READY_FOR_FULL_CODE`, generate runnable code. If it is `READY_FOR_SCAFFOLD_ONLY`, generate scaffold-only code with TODOs and tests. If it is `NOT_READY_FOR_CODE`, do not generate full code.

**Critical efficiency rule:** Do NOT write boilerplate code from scratch. The `./scaffolds/` folder contains production-quality Python modules with `# TODO: FILL` markers. Read the relevant scaffold first, then fill ONLY the domain-specific sections. This saves ~60% of generated tokens and produces more consistent, tested code.

Scaffold assembly workflow:

1. Read `./scaffolds/github_repo_structure.md` for the target file tree.
2. Copy scaffolds into the project: `config.py`, `utils.py`, `data_loader.py`, `train.py`, `evaluate.py`, `plotting.py`.
3. Fill the `# TODO: FILL` markers with domain-specific logic (model, losses, metrics, data loading).
4. For `model.py`: check `./scaffolds/architectures.py` first — it contains validated building blocks (ResidualBlock, MultiHeadSelfAttention, TransformerEncoder/Decoder, U-Net blocks, GNN layers, ProjectionHead, PatchEmbedding, PositionalEncoding). Compose the model from these blocks and add only the novel components from scratch.
5. For `losses.py`: check `./scaffolds/losses.py` first — it contains tested implementations (LabelSmoothingCE, FocalLoss, InfoNCE, TripletLoss, DiceLoss, KLDivergence, CombinedLoss) with shape contracts and sanity tests. Use these validated implementations instead of writing from scratch. Run `python scaffolds/losses.py` to verify all tests pass.
6. Write `metrics.py` from scratch — this is always domain-specific.
7. Copy `run.sh` and `run.bat` from scaffolds and update project name and seeds.
8. Customize `requirements.txt` from scaffold with project-specific dependencies.

For each file, provide:

- Filename and purpose.
- Code with clear names, type hints or docstrings, and input validation.
- Assumptions labeled explicitly.
- How to test or verify.

Code quality rules:

- Keep research logic modular: data, model, training, evaluation, analysis, plotting, and configuration must be separable.
- Use explicit input/output contracts for functions.
- Make defaults safe and documented.
- Never hide important assumptions inside code.
- Validate shapes, empty inputs, and edge cases.
- No hidden global state.
- Deterministic behavior where possible (seed control).

For algorithm implementation specifically: preserve the stated method exactly. Label any assumption. Do not silently change the science. Include minimal tests or sanity checks.

### Step E: Experiment Scaffolding

Create experiment infrastructure:

- Config loading (YAML, JSON, or CLI args).
- Seed setting and deterministic control.
- Output directory management.
- Logging (parameters, environment, metrics).
- Checkpointing when relevant.
- Metric computation and raw result saving.
- Command examples for running experiments.

Use `./templates/experiment_plan.yaml` for experiment specifications.

### Step F: Baseline Implementation

Implement or wrap baselines fairly:

- Use the same data splits as the proposed method.
- Use comparable preprocessing.
- Document hyperparameters.
- Avoid giving the proposed method extra information.
- Mark third-party baseline code clearly.
- Avoid unfair result comparisons.

Use `./templates/baseline_matrix.md` to document baseline fairness.

### Step G: Evaluation and Analysis

Implement metrics, comparisons, ablations, plots, and tables according to the Domain Evaluation Contract.

Metric implementation rules:

- Implement the metric exactly as defined by the official source.
- Add toy test cases with known expected outputs.
- Separate per-sample, per-class, per-dataset, and aggregate scores.
- State whether higher or lower is better.
- Validate edge cases.
- Log all inputs used for metric calculation.

For ablation studies, each ablation must specify: component changed, hypothesis tested, config diff, expected output, metric, table row name, and interpretation caveat. Use `./templates/ablation_table.md`.

For plots and tables: never invent numbers, keep raw results separate from formatted tables, include aggregation method and confidence intervals, make captions match evidence.

**Academic figure quality:** All plots must be publication-ready. Use `./scaffolds/plotting.py` which includes pre-configured academic styles (colorblind-safe palettes, proper font sizes, vector PDF output) and ready-to-use functions for bar charts, training curves, ablation comparisons, and confusion matrices. Read `./references/academic-figure-style.md` for venue-specific settings (IEEE, ACL, NeurIPS), figure sizes, table formatting rules, and the full color palette reference.

### Step H: Claim-Driven Experiment Planning

Before implementing a full paper result pipeline, freeze the paper story. Read `./references/experiment-plan-protocol.md` and use `./templates/claim_gate.md` plus `./templates/experiment_tracker.md`.

Produce:

- primary claim and supporting claim
- anti-claims to rule out
- main anchor result
- novelty isolation ablation
- simplicity/elegance check
- frontier necessity check if applicable
- failure analysis or qualitative diagnosis
- run order: sanity → baselines → main → ablations → robustness → paper assets

Rules:

- Prefer one dominant contribution plus one supporting claim.
- Do not create a huge benchmark wishlist.
- Every experiment must defend a claim, rule out an anti-claim, or satisfy a likely reviewer objection.
- Mark runs as MUST, SHOULD, NICE, or CUT.

### Step I: Experiment Bridge and Claude Code Implementation Prompt

After the experiment plan is clear, read `./references/experiment-bridge-protocol.md` and convert the plan into implementation work.

Produce a `CLAUDE_CODE_IMPLEMENTATION_PROMPT.md` with:

- exact repository/file tree to create or modify
- scaffold files to reuse
- TODO markers to fill
- dataset paths and split policy
- CLI arguments and config fields
- metrics and expected result schema
- sanity-first run command
- baseline commands
- main method commands
- ablation commands
- result file paths
- tests that must pass before full runs
- code review checklist

Default bridge constants:

- `SANITY_FIRST = true`
- `CODE_REVIEW = true` when a reviewer/agent is available
- `RESCUE_ON_FAILURE = true`
- `AUTO_DEPLOY = false` unless the user explicitly requests deployment or the environment is already configured

### Step J: Experiment Queue Orchestration

Use queue mode only when the run set is large, phased, multi-seed, multi-config, OOM-prone, or GPU-server based. Read `./references/experiment-queue-protocol.md` and use `./templates/queue_manifest.yaml`.

Use queue mode when:

- there are 10 or more jobs
- there are 3+ seeds across multiple variants
- jobs have dependencies, such as teacher → student
- GPU memory or stale screens are likely issues
- multiple phases must run in order

Queue output must include:

- manifest path
- project working directory
- backend: local/SSH/cluster/Vast/Modal when known
- conda/env name
- GPUs and max parallel jobs
- OOM retry policy
- expected output checks for every job
- dependency rules
- resume instructions
- summary aggregation plan

Completion must be based on expected output files, not only screen/process status.

### Step K: Results Aggregation and Paper Assets

After execution, aggregate real result files only. Use `./templates/results_summary.md`.

Produce:

- metrics table with mean/std and seed count
- baseline comparison table
- ablation table
- robustness/sensitivity table
- figure scripts using `./scaffolds/plotting.py`
- captions that describe the result without overclaiming
- paper-ready interpretation separated into Supported / Partially supported / Not supported

Do not fill numeric tables from memory or expectations. Read numbers from result files only.

### Step L: Experiment Integrity Audit

Before writing scientific claims, read `./references/experiment-audit-protocol.md` and use `./templates/experiment_audit_report.md`.

Audit for:

- fake or proxy ground truth
- metric score normalization using model outputs
- phantom result files
- claimed numbers that do not match result files
- defined metrics that are never called
- too-small pilot scope presented as full evaluation
- test-set tuning or leakage
- unfair baselines

If audit fails, downgrade claims and propose fixes. Do not write final paper claims from failed or unaudited results.

### Step M: Debugging and Repair

When diagnosing code errors or suspicious results, return:

1. Likely root cause.
2. Minimal fix.
3. Safer robust fix.
4. Tests/checks to confirm.
5. Whether the bug affects reported results.
6. Any risk to experiment validity.

For suspicious results, audit for: data leakage, split mistakes, metric implementation errors, baseline unfairness, seed instability, preprocessing mismatch, train/eval mode mistakes, shape broadcasting bugs, and accidental test tuning.

Never present a scientific method change as a simple bug fix.

### Step N: Code Review

Review research code for:

- Correctness and logic errors.
- Modularity and maintainability.
- Reproducibility gaps.
- Data leakage risks.
- Metric implementation errors.
- Hidden assumptions.
- Unfair baseline comparisons.
- Missing documentation.
- Brittle paths, hardcoded secrets, or private data exposure.

Use `./templates/code_review_report.md` as the report template.

### Step O: Claim-Evidence-Code Map

Connect every code output to a paper claim. For each claim, map:

- Code file or function that produces the evidence.
- Dataset and split used.
- Metric computed.
- Result artifact path.
- Paper table or figure reference.
- Verification check.
- Risk of overclaiming.

Use `./templates/claim_evidence_code_map.md`. This prevents unsupported or overbroad claims in the paper.

### Step P: Reproducibility and Release

Prepare code for sharing or artifact review:

- README with installation, data setup, quick start, and reproduction commands.
- Environment and dependency documentation.
- Expected outputs and known limitations.
- License and citation placeholders.
- Troubleshooting section.

Use `./templates/reproducibility_checklist.md` and `./templates/README_code_release.md`.

**One-click execution:** Always include `run.sh` (Linux/Mac) and `run.bat` (Windows) from `./scaffolds/`. These scripts automate the entire pipeline: conda environment creation, dependency installation, GPU detection, multi-seed training, evaluation, and figure/table generation. The user's workflow becomes: drop dataset in `data/` → edit `configs/default.yaml` → double-click `run.sh` or `run.bat` → results appear in `results/`.

### Step Q: Reviewer-to-Experiment

When the user receives reviewer comments, classify each request as:

- Clarification (answer in text).
- New baseline (implement and compare).
- New ablation (design and run).
- Metric change (update evaluation).
- Robustness check (add experiments).
- Bug concern (investigate and fix).
- Out-of-scope request (propose minimal response).

Then propose the smallest valid experiment or code change for each.

### Step R: Internal Review

Before delivering final code, run this internal quality check:

| Check | What to verify |
|---|---|
| Correctness | Does the code implement the stated method? |
| Reproducibility | Seeds set, configs saved, commands documented? |
| Data integrity | No leakage across splits? Fair preprocessing? |
| Metric validity | Metrics match the Domain Evaluation Contract? |
| Baseline fairness | Same splits, comparable preprocessing, documented hyperparameters? |
| Claim alignment | Every output maps to a paper claim? |
| Security | No hardcoded secrets, private paths, or unsafe downloads? |
| Documentation | Functions have docstrings, assumptions are labeled? |
| Prompt discipline | Task was clear before code was written? |
| Code readiness | Did the Code Readiness Gate permit the level of code generated? |

Fix issues before delivering. Show the review only if the user asks.

---

## Research Integrity Rules

These rules are non-negotiable:

- Do not create fake results, datasets, citations, or baselines.
- Do not tune on the test set.
- Do not leak validation/test labels into training.
- Do not compare against baselines unfairly.
- Do not remove failed experiments from logs without marking them.
- Do not overstate claims based on limited experiments.
- Do not claim code has been executed without actual tool output as proof.
- When unsure, mark uncertainty and propose a validation check.

---

## Output Format

For code tasks, respond with:

1. Short explanation of the plan.
2. File tree or changed files.
3. Code blocks organized by filename.
4. How to run.
5. How to verify.
6. What assumptions remain.

For debugging tasks, respond with:

1. Likely root cause.
2. Minimal fix.
3. Robust fix.
4. Tests/checks to confirm.
5. Any research-risk warning.

---

## Iteration Commands

- `plan only` - produce Code Prompt Contract and implementation plan without code.
- `code only` - skip the plan and write code directly.
- `evaluate` - write evaluation code and metric implementations.
- `debug` - diagnose errors or suspicious results.
- `review` - review existing code for quality and risks.
- `ablation` - design and implement ablation studies.
- `plot` - generate plotting scripts for paper figures.
- `table` - generate result table formatting scripts.
- `baseline` - implement or audit baseline comparisons.
- `release` - prepare reproducibility package and README.
- `claim map` - create claim-evidence-code mapping.
- `reviewer response` - convert reviewer comments to experiments.
- `one shot` - produce the full claim → experiment → code → queue → evaluation → audit pipeline.
- `experiment plan` - create claim-driven experiment plan and tracker.
- `bridge` - convert experiment plan into Claude Code implementation prompt and scripts.
- `queue` - create or run multi-seed/multi-config queue manifest.
- `audit` - audit results before writing scientific claims.
- `domain eval` - build a Domain Evaluation Contract.
- `readiness gate` - run the Code Readiness Gate and decide full code, scaffold-only, or not ready.
- `input checklist` - show the recommended input materials checklist.
- `continue` - resume from where the previous response stopped.

---

## References

- **Idea validation and brainstorming** (Step 0): `./references/idea-validation-protocol.md`
- **Paper parsing protocol** (Step A): `./references/paper-parsing-protocol.md`
- Input specification and materials checklist: `./references/input-specification.md`
- Domain evaluation guide and prompts: `./references/domain-evaluation-guide.md`
- Auto-search metrics when user has none: `./references/auto-metric-search.md`
- Academic figure and graph style guide: `./references/academic-figure-style.md`
- Prompt library for all workflow stages: `./references/prompt-library.md`
- Input checklist for quick project setup: `./references/input-checklist.md`
- Integrated experiment planning protocol: `./references/experiment-plan-protocol.md`
- Integrated experiment bridge / implementation protocol: `./references/experiment-bridge-protocol.md`
- Integrated experiment queue protocol: `./references/experiment-queue-protocol.md`
- Integrated experiment audit protocol: `./references/experiment-audit-protocol.md`

## Scaffolds (Reusable Code — Read Before Writing)

Pre-built production-quality Python modules in `./scaffolds/`. Claude should copy these and fill `# TODO: FILL` markers instead of writing from scratch. This saves ~60% of generated tokens.

- `github_repo_structure.md` - target repo layout and assembly instructions
- `config.py` - YAML config loader with CLI overrides and device detection
- `utils.py` - seed management, logging, timing, early stopping, environment logging
- `data_loader.py` - dataset class, dataloader factory, data integrity checks
- `train.py` - full training loop with checkpointing, multi-seed runner, scheduler support
- `evaluate.py` - evaluation pipeline, metric registry, sanity tests, multi-seed aggregation
- `plotting.py` - publication-quality plots (bar charts, training curves, confusion matrices, ablations)
- `requirements.txt` - base dependencies with framework-specific sections to uncomment
- `architectures.py` - validated building blocks (ResNet, Transformer, U-Net, GNN, ViT patches, positional encoding)
- `losses.py` - tested loss functions (CE, Focal, InfoNCE, Triplet, Dice, KL, Combined) with sanity tests
- `run.sh` - one-click Linux/Mac automation (env + deps + train + eval + plots)
- `run.bat` - one-click Windows automation (env + deps + train + eval + plots)

## Templates

All templates are in `./templates/` and should be used as structured starting points:

- `code_project_brief.yaml` - project intake
- `implementation_plan.md` - module plan
- `experiment_plan.yaml` - experiment specification
- `domain_evaluation_contract.yaml` - evaluation contract
- `metric_spec.yaml` - metric definition
- `baseline_matrix.md` - baseline fairness audit
- `ablation_table.md` - ablation plan
- `results_log.md` - experiment results
- `bug_report.md` - debugging report
- `code_review_report.md` - code review
- `reproducibility_checklist.md` - release readiness
- `README_code_release.md` - code release README
- `claim_evidence_code_map.md` - claim-to-code mapping
- `prompt_brief.md` - code prompt contract
- `method_summary_contract.yaml` - method input/output/architecture/training/loss/dataset/evaluation contract
- `missing_information_detector.md` - detector for hidden hyperparameters, preprocessing, equations, optimizer, seeds, filtering
- `code_readiness_gate.md` - readiness decision before full code, scaffold-only, or no code
- `previous_paper_extraction_matrix.md` - prior work extraction
- `one_shot_research_pipeline_contract.yaml` - one-shot pipeline contract
- `claim_gate.md` - paper claim freeze and minimum evidence gate
- `experiment_tracker.md` - run-by-run execution tracker
- `queue_manifest.yaml` - multi-seed/multi-config queue manifest
- `results_summary.md` - result aggregation and interpretation template
- `experiment_audit_report.md` - integrity audit report template
