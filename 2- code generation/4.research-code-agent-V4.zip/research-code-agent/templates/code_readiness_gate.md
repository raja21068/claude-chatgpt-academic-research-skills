# CODE_READINESS_GATE.md

## Purpose

Decide whether the method description is sufficiently specified for Claude Code to generate full runnable research code, scaffold-only code, or no code yet. This gate must run after `METHOD_SUMMARY_CONTRACT.yaml` and `MISSING_INFORMATION_DETECTOR.md`, and before `IMPLEMENTATION_PLAN.md` or `CLAUDE_CODE_IMPLEMENTATION_PROMPT.md`.

## Inputs Required

Use evidence from the user prompt, uploaded paper/draft/code, previous results, and filled templates:

- `METHOD_SUMMARY_CONTRACT.yaml`
- `MISSING_INFORMATION_DETECTOR.md`
- `DOMAIN_EVALUATION_CONTRACT.yaml` if already available
- any user-provided dataset paths, paper equations, algorithm descriptions, config files, notebooks, or prior code

## Gate Checklist

For each item, mark one status: `PRESENT`, `MISSING_BLOCKER`, `MISSING_RISKY`, `SAFE_DEFAULT_ALLOWED`, or `NOT_NEEDED`.

| Area | Item | Status | Evidence / source | Action required |
|---|---|---:|---|---|
| Task | task type is known |  |  |  |
| Task | research claim or target outcome is known |  |  |  |
| Input | raw data format is known |  |  |  |
| Input | tensor/feature shape or schema is known |  |  |  |
| Output | prediction/target/output artifact is known |  |  |  |
| Labels | labels/targets and label semantics are known |  |  |  |
| Dataset | dataset name/source/path is known |  |  |  |
| Dataset | train/validation/test split policy is known |  |  |  |
| Dataset | data filtering and exclusion rules are known |  |  |  |
| Preprocessing | preprocessing steps are known |  |  |  |
| Preprocessing | scalers/tokenizers/normalizers are fit only on training data |  |  |  |
| Architecture | model/method modules are specified |  |  |  |
| Architecture | dimensions/layers/hidden sizes are specified or safely configurable |  |  |  |
| Equations | equations have defined symbols, dimensions, reductions, masks, constants |  |  |  |
| Loss | main objective/loss is specified |  |  |  |
| Loss | auxiliary losses and weights are specified or not needed |  |  |  |
| Training | optimizer family and settings are specified |  |  |  |
| Training | learning rate, batch size, epochs, scheduler are specified or safely defaulted |  |  |  |
| Training | seed policy and number of runs are specified |  |  |  |
| Evaluation | metrics and higher/lower-is-better direction are specified |  |  |  |
| Evaluation | baseline list or baseline discovery plan exists |  |  |  |
| Evaluation | result schema and output file paths are specified |  |  |  |
| Compute | device/backend constraints are known |  |  |  |
| Reproducibility | configs, logs, checkpoints, and environment capture are planned |  |  |  |

## Decision Labels

Choose exactly one final decision.

### READY_FOR_FULL_CODE

Use this only when all code-critical items are `PRESENT`, `SAFE_DEFAULT_ALLOWED`, or `NOT_NEEDED`, and there are no unresolved `BLOCKER` items in the Missing Information Detector.

Action:

- Generate full runnable code.
- Reuse `./scaffolds/` first.
- Include configs, training, evaluation, plotting, sanity tests, README, and run commands.
- Include defaults only when they are explicit and logged in config.
- Generate queue manifest only after sanity-first path exists.

### READY_FOR_SCAFFOLD_ONLY

Use this when the task, data, output, and evaluation direction are clear, but some architecture/training details remain incomplete.

Action:

- Generate project scaffold and interfaces.
- Add TODO markers for unresolved scientific details.
- Use placeholder defaults only when clearly labeled as placeholders.
- Generate toy/sanity tests and config schema.
- Do not create final experiment queue or paper claims.

### NOT_READY_FOR_CODE

Use this when any of these are missing: task type, dataset/source, input/output definition, labels/targets, split policy, or evaluation protocol.

Action:

- Do not generate full training/evaluation code.
- Produce a missing-information report and minimal project brief.
- Ask only the smallest set of blocking questions, or propose clearly labeled options if the user requested one-shot mode.
- Do not queue experiments.

## Hard Blockers

The final decision must be `NOT_READY_FOR_CODE` if any of these are unresolved:

- unknown task type;
- unknown input format;
- unknown output/target;
- unknown dataset or no dataset access plan;
- unknown labels/target variable for supervised tasks;
- unknown evaluation metric/protocol;
- ambiguous equation that changes the method behavior;
- no split policy for any empirical evaluation;
- suspected leakage or data contamination not resolved.

## Anti-Hallucination Rules

Never silently invent:

- hidden hyperparameters;
- preprocessing or filtering rules;
- optimizer settings;
- random seeds;
- loss weights/lambdas;
- evaluation metrics;
- baselines;
- dataset splits;
- equation definitions;
- result numbers.

If a default is used, it must appear in the config and be labeled as either `SAFE_DEFAULT` or `PLACEHOLDER_DEFAULT`.

## Output Format

```markdown
# Code Readiness Gate

## Final Decision
READY_FOR_FULL_CODE / READY_FOR_SCAFFOLD_ONLY / NOT_READY_FOR_CODE

## Reason
One short paragraph explaining the decision.

## Gate Checklist
[filled checklist table]

## Blockers
- [BLOCKER item, evidence, required action]

## Risky Assumptions
- [assumption, why risky, how to confirm]

## Safe Defaults Allowed
- [default, why acceptable, where it will be logged]

## Allowed Next Action
- If READY_FOR_FULL_CODE: create implementation plan and Claude Code prompt.
- If READY_FOR_SCAFFOLD_ONLY: create scaffold with TODOs and sanity tests only.
- If NOT_READY_FOR_CODE: create missing-information report and minimum clarification list.
```

## Example Decisions

### Example A: READY_FOR_FULL_CODE

Task, dataset, input/output, split, architecture, loss, optimizer, seeds, metrics, and baselines are known. Generate runnable code.

### Example B: READY_FOR_SCAFFOLD_ONLY

Task, dataset, input/output, and metrics are known, but exact loss weights and hidden dimensions are missing. Generate scaffold with TODOs and placeholder config fields.

### Example C: NOT_READY_FOR_CODE

The idea says “make a new fake-news model,” but dataset, labels, preprocessing, metrics, and splits are unknown. Do not generate full code.
