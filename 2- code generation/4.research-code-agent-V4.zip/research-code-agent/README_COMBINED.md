# research-code-agent — combined improved version

This package preserves the original `research-code-agent/` structure as the base and integrates the experiment planning, bridge, queue, and audit skills from `experiment-queue.zip`.

## What changed

The original folders remain:

- `references/`
- `scaffolds/`
- `templates/`
- `research-to-github-repo.skill`
- `SKILL.md`

Integrated additions:

- `references/experiment-plan-protocol.md`
- `references/experiment-bridge-protocol.md`
- `references/experiment-queue-protocol.md`
- `references/experiment-audit-protocol.md`
- `templates/one_shot_research_pipeline_contract.yaml`
- `templates/claim_gate.md`
- `templates/experiment_tracker.md`
- `templates/queue_manifest.yaml`
- `templates/results_summary.md`
- `templates/experiment_audit_report.md`
- `templates/method_summary_contract.yaml`
- `templates/missing_information_detector.md`
- `templates/code_readiness_gate.md`

## Main workflow

```text
paper idea / method / code
        ↓
method summary contract
        ↓
missing-information detector
        ↓
code readiness gate
        ↓
claim gate
        ↓
domain evaluation contract
        ↓
experiment plan
        ↓
Claude Code implementation prompt
        ↓
sanity-first scaffold implementation
        ↓
experiment queue when needed
        ↓
results aggregation
        ↓
integrity audit
        ↓
claim-evidence-code map
        ↓
paper-ready tables, figures, and interpretation
```

## One-shot command idea

```text
Use research-code-agent in one-shot mode.
Create a complete claim-driven experiment pipeline for this paper idea/method.
Produce PROJECT_BRIEF.yaml, METHOD_SUMMARY_CONTRACT.yaml,
MISSING_INFORMATION_DETECTOR.md, CODE_READINESS_GATE.md, CLAIM_GATE.md,
DOMAIN_EVALUATION_CONTRACT.yaml, EXPERIMENT_PLAN.md, EXPERIMENT_TRACKER.md, IMPLEMENTATION_PLAN.md,
CLAUDE_CODE_IMPLEMENTATION_PROMPT.md, QUEUE_MANIFEST.yaml if needed,
RESULTS_SUMMARY.md, EXPERIMENT_AUDIT.md, and CLAIM_EVIDENCE_CODE_MAP.md.
Do not fabricate numeric results. Use assumptions only when labeled.
```

## v2 Strengthening Added

This version makes two blocks mandatory before Claude Code implementation or queue execution:

1. **Method Summary Contract** (`templates/method_summary_contract.yaml`)
   - input
   - output
   - architecture
   - training process
   - losses
   - datasets
   - evaluation

2. **Missing Information Detector** (`templates/missing_information_detector.md`)
   - hidden hyperparameters
   - unspecified preprocessing
   - ambiguous equations
   - missing optimizer settings
   - missing seeds
   - missing data filtering

The full-queue execution gate now requires all BLOCKER items from the missing-information detector to be resolved before large runs or paper claims.


## v3 Strengthening Added

This version adds the mandatory **Code Readiness Gate**:

- `templates/code_readiness_gate.md`

The gate must run after the Method Summary Contract and Missing Information Detector, before Claude Code implementation. It gives one of three decisions:

1. `READY_FOR_FULL_CODE` — generate full runnable code.
2. `READY_FOR_SCAFFOLD_ONLY` — generate scaffold, TODO markers, config placeholders, and sanity tests only.
3. `NOT_READY_FOR_CODE` — do not generate full code; produce missing-information report and minimal blocking questions.

This prevents the LLM from inventing hidden hyperparameters, preprocessing, filtering rules, optimizer settings, seeds, metrics, baselines, equations, dataset splits, or result numbers.
