# Idea Discovery Pipeline — Complete User Guide

## What This Is

You have a set of research papers on a topic. You want to find **novel research ideas** hiding in the gaps between those papers. This pipeline automates the entire process:

```
Your papers → Extract → Cluster → Find gaps → Generate ideas → Verify novelty → Report
```

The output is a ranked list of research ideas with novelty verdicts, plus an interactive dashboard.

---

## The Two Ways to Use This

### Way 1: Run Locally (Full Power)

You run the Python pipeline on your own machine. This gives you full control, the interactive dashboard, embedding visualizations, and human checkpoint review.

**Best for**: Serious research projects, PhD students, research labs.

### Way 2: Upload Outputs to Claude (Quick Analysis)

You run the pipeline, then upload the output files to Claude for deeper discussion, brainstorming, and refinement.

**Best for**: Getting Claude's help interpreting results, iterating on ideas.

---

## STEP-BY-STEP GUIDE

### Phase 1: Collect Your Papers (15-100 papers)

**What to collect:**
- 15-100 papers on your research topic (sweet spot: 30-50)
- Mix of: seminal papers, recent work (last 2 years), papers from adjacent fields
- Formats: PDF (preferred), TXT, or MD

**How to find them:**
1. Start with 5-10 papers you already know
2. Snowball: check their references + who cites them
3. Use Semantic Scholar, Google Scholar, or Connected Papers
4. Add 5-10 papers from adjacent fields (this is where the best gaps hide)

**Pro tips:**
- More papers = better clusters, but more API cost (~$0.02-0.05 per paper for ingestion)
- 100 papers ≈ $2-5 in API costs for the full pipeline
- Don't add textbooks or survey papers (they confuse the extractor)
- Name files clearly: `smith-2024-transformer-pruning.pdf`

**File naming matters:**
```
input_papers/
├── chen-2024-efficient-attention.pdf
├── liu-2023-sparse-transformers.pdf
├── wang-2025-pruning-at-scale.pdf
├── ... (30-50 more papers)
```

### Phase 2: Setup (One Time, 5 minutes)

```bash
# 1. Unzip the pipeline
unzip idea-discovery-pipeline-v3.1.zip
cd idea-discovery-pipeline

# 2. Set your API key
cp .env.example .env
# Edit .env with your text editor:
#   ANTHROPIC_API_KEY=sk-ant-your-actual-key-here

# 3. (Optional) For multi-model verification, also add:
#   OPENAI_API_KEY=sk-your-openai-key
#   GOOGLE_API_KEY=your-google-key
```

**Requirements:**
- Python 3.10+
- Anthropic API key (get one at console.anthropic.com)
- The run.sh script auto-creates a virtual environment and installs dependencies

### Phase 3: Run the Pipeline

**Option A: Full run (recommended first time)**
```bash
./run.sh
```
This runs all 8 steps with embeddings, knowledge graph, quality checks, and dashboard.
Takes 10-30 minutes for 30-50 papers depending on paper length.

**Option B: Fast run (skip ML dependencies)**
```bash
./run.sh --lite
```
Skips embeddings and quality checks. Uses LLM-only clustering.
Takes 5-15 minutes. Good for a quick first look.

**Option C: With human review (most thorough)**
```bash
# Step 1: Run until gaps, then pause
./run.sh --checkpoint

# Step 2: Open the checkpoint file
# Edit: output/CHECKPOINT_REVIEW.yaml
# - Set gaps you don't like to: approved: false
# - Change priority scores with: priority_override: 25
# - Add your own gaps under custom_gaps
# - Set: proceed: true

# Step 3: Resume
./run.sh --resume
```
This is where your domain expertise makes the biggest difference.

### Phase 4: Read Your Results

After the pipeline finishes, open `output/` and look at:

```
output/
├── FINAL_REPORT.md          ← Start here. Full summary.
├── dashboard.html            ← Open in browser. Interactive charts.
├── idea_report.md            ← All generated ideas with details
├── novelty_report.md         ← Novelty verdicts per idea
├── gap_report.md             ← All gaps found
├── cluster_report.md         ← How papers cluster
├── conflict_report.md        ← Contradictions between papers
│
├── paper_corpus.json         ← Structured extraction of every paper
├── research_space_map.json   ← Cluster data
├── embeddings.json           ← Paper vectors + 2D coordinates
├── graph_data.json           ← Knowledge graph (D3-ready)
├── gap_analysis.json         ← Scored gaps
├── idea_report.json          ← Ideas as structured data
├── novelty_report.json       ← Novelty data
├── pipeline_summary.json     ← Timing and metadata
└── quality_*.json            ← Quality check results
```

**Reading order:**
1. `FINAL_REPORT.md` — the big picture
2. `dashboard.html` — visual exploration (open in any browser)
3. `idea_report.md` — deep dive into each idea
4. `novelty_report.md` — which ideas survived novelty check

### Phase 5: Iterate with Claude

This is the powerful part. Take your pipeline output and bring it back to Claude for deeper analysis.

**Option A: Upload output files to Claude**

1. Zip the output folder: `zip -r my-results.zip output/`
2. Start a new Claude conversation
3. Upload `my-results.zip`
4. Ask Claude questions like:

```
Here are the results from my idea discovery pipeline
analyzing 45 papers on [your topic].

Can you:
1. Look at the top 3 ideas marked PROCEED and help me
   pick the strongest one for a NeurIPS submission?
2. The pipeline found 2 ideas marked PIVOT — can you
   help me figure out how to reframe them?
3. Are there any gaps the pipeline missed that you can
   see from the paper corpus?
```

**Option B: Upload specific files for focused discussion**

- Upload `idea_report.json` + `novelty_report.json` → "Help me refine Idea #3"
- Upload `gap_analysis.json` → "Are these gaps real? Which should I pursue?"
- Upload `conflict_report.json` → "Help me resolve these contradictions"
- Upload `paper_corpus.json` → "What patterns do you see across these papers?"

**Option C: Use the deep-research skill (if installed)**

If you've installed the deep-research skill in your Claude project:

```
@deep-research idea-discovery

Papers: [upload your PDFs]
Focus: [your specific research question]
```

The skill agents will coordinate the same analysis with Claude's full reasoning.

---

## COST ESTIMATION

| Papers | Mode | API Calls | Estimated Cost |
|--------|------|-----------|----------------|
| 20 | --lite | ~35 | $0.50-1.00 |
| 20 | full | ~55 | $1.00-2.00 |
| 50 | --lite | ~70 | $1.50-3.00 |
| 50 | full | ~120 | $3.00-6.00 |
| 100 | --lite | ~130 | $3.00-5.00 |
| 100 | full | ~220 | $5.00-10.00 |

Costs depend on paper length and model used. Sonnet is the default (cheaper).
Quality gates add ~3 extra API calls. Multi-model adds ~2x for novelty step.

---

## CONFIGURATION CHEAT SHEET

Edit `config/settings.json`:

| Setting | Default | What it does |
|---------|---------|-------------|
| `api.model` | `claude-sonnet-4-20250514` | Which Claude model (Sonnet = cheaper, Opus = better) |
| `pipeline.max_ideas_per_gap` | 2 | Ideas generated per gap (1-3) |
| `embeddings.enabled` | true | Real vector clustering (needs ML deps) |
| `quality_gates.enabled` | true | Self-critique between steps |
| `multi_model.enabled` | false | Use GPT-4 + Gemini for novelty (needs API keys) |
| `citation_expansion.enabled` | true | Search citation graph for prior work |

---

## WORKFLOW DIAGRAM

```
┌─────────────────────────────────────────────────────────┐
│                    YOU (Researcher)                       │
│                                                          │
│  1. Collect 30-50 papers on your topic                  │
│  2. Drop PDFs into input_papers/                        │
│  3. Run: ./run.sh --checkpoint                          │
│                                                          │
│         ┌──────────────────────────┐                    │
│         │     PIPELINE RUNS        │                    │
│         │  Steps 1-4 automatically │                    │
│         └──────────┬───────────────┘                    │
│                    ▼                                     │
│  4. Review CHECKPOINT_REVIEW.yaml                       │
│     - Approve/reject gaps                               │
│     - Add your own gaps                                 │
│     - Re-prioritize                                     │
│                                                          │
│  5. Run: ./run.sh --resume                              │
│                                                          │
│         ┌──────────────────────────┐                    │
│         │     PIPELINE CONTINUES   │                    │
│         │  Steps 5-8 automatically │                    │
│         └──────────┬───────────────┘                    │
│                    ▼                                     │
│  6. Read FINAL_REPORT.md + dashboard.html               │
│  7. Upload results to Claude for deeper discussion      │
│  8. Pick your best idea → Start writing the paper       │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

---

## TROUBLESHOOTING

**"No papers found in input_papers/"**
→ Make sure your PDFs are directly in `input_papers/`, not in a subfolder.

**"ANTHROPIC_API_KEY not set"**
→ Copy `.env.example` to `.env` and add your key. Make sure there are no spaces around the `=`.

**"sentence-transformers not found"**
→ Run with `--skip-embeddings` or install manually: `pip install sentence-transformers`

**API rate limits**
→ The pipeline has built-in retries. If you hit persistent limits, reduce `citation_expansion.max_papers_per_hop` in config, or process fewer papers.

**Pipeline crashes mid-run**
→ All intermediate outputs are saved. Fix the issue and run again — completed steps will be overwritten (they're fast). Or jump to a specific step:
```bash
cd idea-discovery-pipeline
source .venv/bin/activate
python scripts/step5_ideas.py    # Run just step 5
```

**Dashboard is blank**
→ Run with embeddings enabled (`--lite` skips them). Or regenerate: `./run.sh --dashboard-only`

---

## WHAT MAKES A GOOD RUN

The quality of output depends entirely on your input papers. Here's what works:

**Good input (will find real gaps):**
- 30-50 papers spanning 3-5 research subgroups
- Mix of methods (some do X, some do Y, some do Z)
- Include recent papers (2024-2025) for concurrent work detection
- Include a few papers from adjacent fields

**Bad input (will find fake gaps):**
- All papers from the same research group (too homogeneous)
- Only survey papers (no specific methods to cluster)
- Papers from completely unrelated fields (gaps aren't actionable)
- Fewer than 10 papers (not enough for meaningful clustering)

---

## EXAMPLE: Full Run Walkthrough

```bash
# Researcher studying "efficient transformers for edge devices"

# 1. Collected 42 papers from Semantic Scholar
ls input_papers/
# dao-2022-flashattention.pdf
# sze-2017-efficient-processing.pdf
# ... 40 more papers

# 2. First run with checkpoint
./run.sh --checkpoint
# [Pipeline runs steps 1-4: ~8 minutes]
# → CHECKPOINT saved

# 3. Review gaps
cat output/CHECKPOINT_REVIEW.yaml
# Found 12 gaps. I reject 3 (not relevant), add 1 custom gap:
# "No work on combining pruning + quantization + flash attention together"

# 4. Resume
./run.sh --resume
# [Pipeline runs steps 5-8: ~6 minutes]

# 5. Check results
open output/dashboard.html     # Interactive viz
open output/FINAL_REPORT.md    # Full report
# → 7 ideas generated, 3 marked PROCEED, 2 CAUTION, 1 PIVOT, 1 ABANDON

# 6. Upload to Claude for discussion
zip -r results.zip output/
# Upload results.zip to claude.ai
# "Help me develop IDEA-003 into a paper outline..."
```
