@echo off
REM ╔═══════════════════════════════════════════════════════════╗
REM ║       IDEA DISCOVERY PIPELINE — Launcher (Windows)       ║
REM ║ Auto-installs dependencies, then runs the full pipeline  ║
REM ╚═══════════════════════════════════════════════════════════╝

cd /d "%~dp0"

echo ==============================================
echo   Idea Discovery Pipeline v3.0.0
echo ==============================================
echo.

REM ── Check Python ───────────────────────────────────
where python >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo ERROR: Python is not installed or not in PATH.
    echo Install Python 3.10+: https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

python --version
echo.

REM ── Check API Key ──────────────────────────────────
if "%ANTHROPIC_API_KEY%"=="" (
    REM Try loading from .env
    if exist .env (
        for /f "usebackq tokens=1,2 delims==" %%a in (".env") do (
            if "%%a"=="ANTHROPIC_API_KEY" set ANTHROPIC_API_KEY=%%b
        )
    )
)

if "%ANTHROPIC_API_KEY%"=="" (
    echo.
    echo WARNING: ANTHROPIC_API_KEY is not set.
    echo.
    echo Option 1: Set it in command prompt:
    echo   set ANTHROPIC_API_KEY=sk-ant-...
    echo.
    echo Option 2: Create a .env file in this directory:
    echo   ANTHROPIC_API_KEY=sk-ant-...
    echo.
    set /p api_key="Enter your API key now (or press Enter to abort): "
    if "%api_key%"=="" (
        pause
        exit /b 1
    )
    set ANTHROPIC_API_KEY=%api_key%
)

echo [OK] ANTHROPIC_API_KEY is set

REM ── Create virtual environment ─────────────────────
if not exist ".venv" (
    echo.
    echo [...] Creating virtual environment...
    python -m venv .venv
    echo [OK] Virtual environment created
)

REM Activate
call .venv\Scripts\activate.bat

REM ── Install dependencies ───────────────────────────
echo.
echo [...] Installing/updating dependencies...
pip install --upgrade pip -q 2>nul
pip install -r requirements.txt -q 2>nul
echo [OK] Dependencies installed

REM ── Create folders ─────────────────────────────────
if not exist "input_papers" mkdir input_papers
if not exist "output" mkdir output
if not exist "logs" mkdir logs

REM ── Check for input papers ─────────────────────────
set PAPER_COUNT=0
for %%f in (input_papers\*.pdf input_papers\*.txt input_papers\*.md) do set /a PAPER_COUNT+=1

if %PAPER_COUNT%==0 (
    echo.
    echo ╔═══════════════════════════════════════════╗
    echo ║  No papers found in input_papers\          ║
    echo ║                                           ║
    echo ║  Add your PDF, TXT, or MD files there     ║
    echo ║  and run this script again.               ║
    echo ╚═══════════════════════════════════════════╝
    pause
    exit /b 0
)

echo.
echo [OK] Found %PAPER_COUNT% papers in input_papers\

REM ── Run pipeline ───────────────────────────────────
echo.
echo Starting pipeline...
echo ----------------------------------------------
echo.

python scripts\run_pipeline.py

echo.
echo Done! Open output\FINAL_REPORT.md to see results.
pause
