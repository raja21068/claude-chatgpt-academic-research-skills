# 🔬 Idea Discovery Pipeline v3.0.0

**100 papers → structured parsing → clustering → conflict detection → gap analysis → idea generation → novelty verification → final report**

A fully automated research idea discovery system powered by Claude API. Drop your papers in a folder, run one script, get ranked, novelty-verified research ideas.

## Quick Start

### 1. Get an API key
Get your Anthropic API key from https://console.anthropic.com/

### 2. Set the key

**Linux/Mac:**
```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

**Windows:**
```cmd
set ANTHROPIC_API_KEY=sk-ant-...
```

Or create a `.env` file in this directory:
```
ANTHROPIC_API_KEY=sk-ant-...
```

### 3. Add your papers
Put PDF, TXT, or MD files in the `input_papers/` folder.

### 4. Run

**Linux/Mac:**
```bash
chmod +x run.sh
./run.sh
```

**Windows:**
```cmd
run.bat
```

That's it. The script installs all dependencies automatically and runs the full 7-step pipeline.

## Pipeline Steps

```
input_papers/          ← Your papers (PDF/TXT/MD)
    │
    ▼
┌─────────────────────────────────────────────────┐
│ Step 1: INGEST                                   │
│ Parse papers → structured JSON records            │
│ (problem, method, claims, limitations, metrics)   │
│ Output: output/paper_corpus.json                  │
└─────────────────┬───────────────────────────────┘
                  ▼
┌─────────────────────────────────────────────────┐
│ Step 2: CLUSTER                                  │
│ Cluster by method, problem, dataset, metric       │
│ Build cross-dimensional matrices                  │
│ Find dense, sparse, orphan regions                │
│ Output: output/research_space_map.json            │
│         output/cluster_report.md                  │
└─────────────────┬───────────────────────────────┘
                  ▼
┌─────────────────────────────────────────────────┐
│ Step 3: CONFLICTS                                │
│ Detect contradictions between papers              │
│ Classify: result/claim/assumption/reproduction    │
│ Propose resolution paths                          │
│ Output: output/conflict_report.json               │
│         output/conflict_report.md                 │
└─────────────────┬───────────────────────────────┘
                  ▼
┌─────────────────────────────────────────────────┐
│ Step 4: GAPS                                     │
│ Detect missing combinations, weaknesses           │
│ Audit shared assumptions                          │
│ Mine convergent future work                       │
│ Score: Impact × Feasibility × Novelty             │
│ Output: output/gap_analysis.json                  │
│         output/gap_report.md                      │
└─────────────────┬───────────────────────────────┘
                  ▼
┌─────────────────────────────────────────────────┐
│ Step 5: IDEAS                                    │
│ Generate ideas from gaps (no gap = no idea)       │
│ 5-axis scoring rubric                             │
│ Hard filters: testable, feasible, traceable       │
│ Output: output/idea_report.json                   │
│         output/idea_report.md                     │
└─────────────────┬───────────────────────────────┘
                  ▼
┌─────────────────────────────────────────────────┐
│ Step 6: NOVELTY CHECK                            │
│ Search Semantic Scholar + arXiv                   │
│ Assess overlap with existing work                 │
│ Detect concurrent work threats                    │
│ Verdict: PROCEED / CAUTION / PIVOT / ABANDON      │
│ Output: output/novelty_report.json                │
│         output/novelty_report.md                  │
└─────────────────┬───────────────────────────────┘
                  ▼
┌─────────────────────────────────────────────────┐
│ Step 7: FINAL REPORT                             │
│ Merge everything into a single report             │
│ Recommended research agenda                       │
│ Output: output/FINAL_REPORT.md                    │
│         output/pipeline_summary.json              │
└─────────────────────────────────────────────────┘
```

## Output Files

| File | Description |
|------|-------------|
| `output/paper_corpus.json` | Structured records for all papers |
| `output/research_space_map.json` | Cluster map with cross-matrices |
| `output/cluster_report.md` | Human-readable cluster analysis |
| `output/conflict_report.json` | Detected conflicts between papers |
| `output/conflict_report.md` | Human-readable conflict analysis |
| `output/gap_analysis.json` | Detected research gaps with scores |
| `output/gap_report.md` | Human-readable gap analysis |
| `output/idea_report.json` | Generated ideas with scoring |
| `output/idea_report.md` | Human-readable idea report |
| `output/novelty_report.json` | Novelty verification results |
| `output/novelty_report.md` | Human-readable novelty report |
| `output/FINAL_REPORT.md` | **Complete merged report** |
| `output/pipeline_summary.json` | Compact summary for programmatic use |

## Running Individual Steps

You can run any step independently (useful for re-running after tweaking):

```bash
# Activate venv first
source .venv/bin/activate   # Linux/Mac
.venv\Scripts\activate      # Windows

# Run individual steps
python scripts/step1_ingest.py
python scripts/step2_cluster.py
python scripts/step3_conflicts.py
python scripts/step4_gaps.py
python scripts/step5_ideas.py
python scripts/step6_novelty.py
python scripts/step7_report.py
```

Each step reads from and writes to `output/`, so you can modify intermediate files and re-run downstream steps.

## Configuration

Edit `config/settings.json`:

```json
{
  "api": {
    "model": "claude-sonnet-4-20250514",  // Model to use
    "max_tokens": 8096,                    // Max response tokens
    "batch_size": 5,                       // Papers per API call batch
    "retry_attempts": 3                    // Retries on API failure
  },
  "pipeline": {
    "max_papers": 200,                     // Max papers to process
    "top_ideas": 5,                        // Number of top ideas to generate
    "novelty_search_months": 6             // Months to search for concurrent work
  }
}
```

## Cost Estimate

Approximate Claude API costs per run (Sonnet model):

| Papers | Estimated API Calls | Estimated Cost |
|--------|-------------------|----------------|
| 10     | ~15-20            | ~$0.50-1.00    |
| 50     | ~60-80            | ~$3-5          |
| 100    | ~120-160          | ~$6-10         |

Costs depend on paper length and model used. Sonnet is recommended for cost-efficiency.

## Requirements

- Python 3.10+
- Anthropic API key
- Internet access (for Semantic Scholar + arXiv novelty search)

All Python dependencies are auto-installed by the launcher script.

## Troubleshooting

**"No module named 'anthropic'"** — Run `pip install anthropic` or use the launcher script.

**API rate limits** — The pipeline includes retry logic with backoff. For large corpora (100+ papers), expect 10-20 minutes.

**PDF extraction fails** — Some scanned PDFs won't parse. Convert to text first or use OCR tools.

**JSON parse errors** — Occasionally the API returns malformed JSON. The pipeline retries automatically. Check `logs/` for details.
