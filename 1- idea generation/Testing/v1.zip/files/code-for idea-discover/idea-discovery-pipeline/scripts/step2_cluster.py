"""
step2_cluster.py — Research Space Clustering
Takes paper_corpus.json, clusters papers by method/problem/dataset/metric,
builds cross-dimensional matrices, identifies dense & sparse regions.
Outputs: output/research_space_map.json, output/cluster_report.md
"""

import sys
import json
import numpy as np
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent))
from utils import (
    ClaudeClient, load_config, load_json, save_json, save_markdown,
    log, print_banner
)

SYSTEM_PROMPT = """You are a research clustering agent. Given a batch of structured paper records, you analyze and cluster them along multiple dimensions.

RESPOND WITH ONLY valid JSON — no markdown fences, no explanation.

Your task: Given these paper records, produce clusters and a cross-dimensional analysis.

Output this JSON structure:
{
  "method_clusters": [
    {
      "cluster_id": "M1",
      "label": "short descriptive label",
      "category": "broad category",
      "paper_ids": ["paper-id-1", "paper-id-2"],
      "paper_count": 5,
      "year_range": [2022, 2025],
      "trend": "growing | stable | declining",
      "key_methods": ["specific method names in this cluster"]
    }
  ],
  "problem_clusters": [
    {
      "cluster_id": "P1",
      "label": "short descriptive label",
      "domain": "broad domain",
      "paper_ids": ["paper-id-1"],
      "paper_count": 3,
      "key_problems": ["specific problem descriptions"]
    }
  ],
  "dataset_clusters": [
    {
      "cluster_id": "D1",
      "label": "dataset family name",
      "datasets": ["dataset1", "dataset2"],
      "paper_ids": ["paper-id-1"],
      "paper_count": 4,
      "overused": true
    }
  ],
  "metric_clusters": [
    {
      "cluster_id": "R1",
      "label": "metric family",
      "metrics": ["metric1", "metric2"],
      "paper_ids": ["paper-id-1"],
      "paper_count": 6
    }
  ],
  "cross_matrix_method_problem": {
    "M1_P1": {"count": 3, "paper_ids": ["p1","p2","p3"]},
    "M1_P2": {"count": 0, "paper_ids": []},
    "M2_P1": {"count": 1, "paper_ids": ["p4"]}
  },
  "sparse_regions": [
    {
      "cell": "M2_P3",
      "method_cluster": "M2 label",
      "problem_cluster": "P3 label",
      "paper_count": 0,
      "is_valid_gap": true,
      "reason": "Why this empty cell is a genuine opportunity (or why not)"
    }
  ],
  "dense_regions": [
    {
      "cell": "M1_P1",
      "method_cluster": "M1 label",
      "problem_cluster": "P1 label",
      "paper_count": 12,
      "saturation_risk": true
    }
  ],
  "orphan_methods": ["methods only applied to 1 problem domain"],
  "orphan_problems": ["problems only tackled by 1 method type"],
  "dataset_monocultures": ["problem areas where all papers use same dataset"],
  "metric_deserts": ["problem areas where important metrics are never reported"],
  "trend_analysis": {
    "growing": [{"cluster": "label", "evidence": "why"}],
    "declining": [{"cluster": "label", "evidence": "why"}],
    "emerging": [{"cluster": "label", "evidence": "why"}]
  }
}

Rules:
- Every paper must appear in at least one cluster per dimension
- Cluster labels must be specific and actionable (not just "deep learning")
- Empty cross-matrix cells must be flagged as potential gaps
- Assess whether each sparse region is a genuine gap or empty for good reason
- Use consistent cluster IDs (M1, M2... P1, P2... D1, D2... R1, R2...)
"""


def prepare_paper_summaries(papers: list) -> str:
    """Create a compact summary of all papers for the clustering prompt."""
    summaries = []
    for p in papers:
        if "_error" in p:
            continue
        s = {
            "paper_id": p.get("paper_id", "unknown"),
            "title": p.get("title", ""),
            "year": p.get("year"),
            "method": p.get("method", {}),
            "problem": p.get("problem", {}),
            "datasets": [d.get("name", "") for d in p.get("datasets", [])],
            "metrics": [m.get("name", "") for m in p.get("metrics", [])],
        }
        summaries.append(s)
    return json.dumps(summaries, indent=1, ensure_ascii=False)


def generate_cluster_report(space_map: dict) -> str:
    """Generate a readable markdown report from the cluster data."""
    lines = ["# Research Space Clustering Report\n"]
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")

    # Method clusters
    lines.append("## Method Clusters\n")
    lines.append("| ID | Label | Papers | Trend | Key Methods |")
    lines.append("|-----|-------|--------|-------|-------------|")
    for mc in space_map.get("method_clusters", []):
        methods_str = ", ".join(mc.get("key_methods", [])[:3])
        lines.append(f"| {mc['cluster_id']} | {mc['label']} | {mc['paper_count']} | {mc.get('trend','-')} | {methods_str} |")

    # Problem clusters
    lines.append("\n## Problem Clusters\n")
    lines.append("| ID | Label | Papers | Key Problems |")
    lines.append("|-----|-------|--------|-------------|")
    for pc in space_map.get("problem_clusters", []):
        probs_str = ", ".join(pc.get("key_problems", [])[:2])
        lines.append(f"| {pc['cluster_id']} | {pc['label']} | {pc['paper_count']} | {probs_str} |")

    # Cross-dimensional matrix
    lines.append("\n## Method × Problem Cross-Matrix\n")
    mc_ids = [mc["cluster_id"] for mc in space_map.get("method_clusters", [])]
    pc_ids = [pc["cluster_id"] for pc in space_map.get("problem_clusters", [])]

    if mc_ids and pc_ids:
        header = "| | " + " | ".join(pc_ids) + " |"
        sep = "|-----|" + "|".join(["-----"] * len(pc_ids)) + "|"
        lines.append(header)
        lines.append(sep)
        matrix = space_map.get("cross_matrix_method_problem", {})
        for mid in mc_ids:
            row = f"| **{mid}** |"
            for pid in pc_ids:
                key = f"{mid}_{pid}"
                cell = matrix.get(key, {})
                count = cell.get("count", 0) if isinstance(cell, dict) else 0
                indicator = "█" * min(count, 5) if count > 0 else "·"
                row += f" {indicator} ({count}) |"
            lines.append(row)

    # Sparse regions (gaps)
    lines.append("\n## Sparse Regions (Potential Gaps)\n")
    for sr in space_map.get("sparse_regions", []):
        valid = "✓ VALID GAP" if sr.get("is_valid_gap") else "✗ Not a gap"
        lines.append(f"- **{sr['cell']}**: {sr.get('method_cluster','')} × {sr.get('problem_cluster','')} — {valid}")
        lines.append(f"  > {sr.get('reason', '')}")

    # Dense regions
    lines.append("\n## Dense Regions (Well-Explored)\n")
    for dr in space_map.get("dense_regions", []):
        sat = "⚠️ Saturation risk" if dr.get("saturation_risk") else ""
        lines.append(f"- **{dr['cell']}**: {dr.get('method_cluster','')} × {dr.get('problem_cluster','')} ({dr['paper_count']} papers) {sat}")

    # Findings
    lines.append("\n## Structural Findings\n")
    if space_map.get("orphan_methods"):
        lines.append("### Orphan Methods (applied to only 1 problem)")
        for om in space_map["orphan_methods"]:
            lines.append(f"- {om}")

    if space_map.get("orphan_problems"):
        lines.append("\n### Orphan Problems (only 1 method type)")
        for op in space_map["orphan_problems"]:
            lines.append(f"- {op}")

    if space_map.get("dataset_monocultures"):
        lines.append("\n### Dataset Monocultures")
        for dm in space_map["dataset_monocultures"]:
            lines.append(f"- {dm}")

    if space_map.get("metric_deserts"):
        lines.append("\n### Metric Deserts")
        for md in space_map["metric_deserts"]:
            lines.append(f"- {md}")

    # Trends
    trends = space_map.get("trend_analysis", {})
    if trends:
        lines.append("\n## Trend Analysis\n")
        for direction in ["growing", "declining", "emerging"]:
            items = trends.get(direction, [])
            if items:
                lines.append(f"### {direction.title()}")
                for item in items:
                    lines.append(f"- **{item.get('cluster','')}**: {item.get('evidence','')}")

    return "\n".join(lines)


def run_clustering(config: dict) -> dict:
    """Run the clustering pipeline."""
    print_banner("STEP 2: Research Space Clustering")

    cfg = config["pipeline"]
    output_dir = cfg["output_dir"]

    # Load corpus
    corpus_path = f"{output_dir}/paper_corpus.json"
    corpus = load_json(corpus_path)
    papers = [p for p in corpus["papers"] if "_error" not in p]
    log.info(f"Clustering {len(papers)} papers...")

    if len(papers) == 0:
        log.error("No valid papers in corpus")
        sys.exit(1)

    # Initialize client
    client = ClaudeClient(config=config)

    # For large corpora, process in chunks and merge
    MAX_PAPERS_PER_CALL = 40
    if len(papers) <= MAX_PAPERS_PER_CALL:
        summaries = prepare_paper_summaries(papers)
        user_msg = f"""Analyze and cluster these {len(papers)} research papers.

PAPER RECORDS:
{summaries}

Respond with ONLY the JSON clustering result."""

        space_map = client.ask_json(SYSTEM_PROMPT, user_msg)
    else:
        # Multi-pass: cluster in chunks, then merge
        log.info(f"Large corpus ({len(papers)} papers) — clustering in chunks...")

        # First pass: cluster each chunk
        chunk_results = []
        for i in range(0, len(papers), MAX_PAPERS_PER_CALL):
            chunk = papers[i:i + MAX_PAPERS_PER_CALL]
            log.info(f"  Chunk {i // MAX_PAPERS_PER_CALL + 1}: papers {i+1}-{i+len(chunk)}")
            summaries = prepare_paper_summaries(chunk)
            user_msg = f"""Analyze and cluster these {len(chunk)} research papers (batch {i // MAX_PAPERS_PER_CALL + 1}).

PAPER RECORDS:
{summaries}

Respond with ONLY the JSON clustering result."""
            result = client.ask_json(SYSTEM_PROMPT, user_msg)
            chunk_results.append(result)

        # Merge pass: combine chunk results
        merge_prompt = f"""You previously clustered {len(papers)} papers in {len(chunk_results)} batches.
Here are the cluster results from each batch. Merge them into a single unified clustering.
Reconcile cluster labels, merge paper_ids, rebuild the cross-matrix, and identify gaps.

BATCH RESULTS:
{json.dumps(chunk_results, indent=1, ensure_ascii=False)[:50000]}

Respond with ONLY the merged JSON clustering result using the same schema."""

        space_map = client.ask_json(SYSTEM_PROMPT, merge_prompt)

    # Save outputs
    save_json(space_map, f"{output_dir}/research_space_map.json")

    report = generate_cluster_report(space_map)
    save_markdown(report, f"{output_dir}/cluster_report.md")

    # Summary stats
    n_method = len(space_map.get("method_clusters", []))
    n_problem = len(space_map.get("problem_clusters", []))
    n_sparse = len(space_map.get("sparse_regions", []))
    n_dense = len(space_map.get("dense_regions", []))
    log.info(f"\nClustering complete:")
    log.info(f"  Method clusters:  {n_method}")
    log.info(f"  Problem clusters: {n_problem}")
    log.info(f"  Sparse regions:   {n_sparse}")
    log.info(f"  Dense regions:    {n_dense}")
    log.info(f"  API stats: {client.stats()}")

    return space_map


if __name__ == "__main__":
    config = load_config()
    run_clustering(config)
