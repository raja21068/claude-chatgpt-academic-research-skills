"""
run_pipeline.py — Main Orchestrator
Runs all 7 steps of the Idea Discovery Pipeline in sequence.
Usage: python scripts/run_pipeline.py
"""

import sys
import time
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent))

from utils import load_config, log, print_banner

def main():
    start = time.time()
    print_banner("IDEA DISCOVERY PIPELINE v3.0.0")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Place your PDF/TXT papers in: input_papers/\n")

    config = load_config()

    # Verify input directory has papers
    input_dir = Path(config["pipeline"]["input_dir"])
    if not input_dir.exists():
        input_dir.mkdir(parents=True)
        print(f"Created '{input_dir}/' — add your papers there and run again.")
        sys.exit(0)

    papers = list(input_dir.glob("*.pdf")) + list(input_dir.glob("*.txt")) + list(input_dir.glob("*.md"))
    if not papers:
        print(f"No papers found in '{input_dir}/'.")
        print(f"Add PDF, TXT, or MD files and run again.")
        sys.exit(0)

    print(f"Found {len(papers)} papers in '{input_dir}/'\n")

    # ── Step 1: Ingest ───────────────────────────────────────────────────────
    from step1_ingest import run_ingestion
    corpus = run_ingestion(config)

    # ── Step 2: Cluster ──────────────────────────────────────────────────────
    from step2_cluster import run_clustering
    space_map = run_clustering(config)

    # ── Step 3: Conflicts ────────────────────────────────────────────────────
    from step3_conflicts import run_conflict_detection
    conflicts = run_conflict_detection(config)

    # ── Step 4: Gaps ─────────────────────────────────────────────────────────
    from step4_gaps import run_gap_detection
    gaps = run_gap_detection(config)

    # ── Step 5: Ideas ────────────────────────────────────────────────────────
    from step5_ideas import run_idea_generation
    ideas = run_idea_generation(config)

    # ── Step 6: Novelty ──────────────────────────────────────────────────────
    from step6_novelty import run_novelty_verification
    novelty = run_novelty_verification(config)

    # ── Step 7: Report ───────────────────────────────────────────────────────
    from step7_report import compile_final_report
    compile_final_report(config)

    # ── Done ─────────────────────────────────────────────────────────────────
    elapsed = time.time() - start
    mins = int(elapsed // 60)
    secs = int(elapsed % 60)

    print(f"\n{'='*60}")
    print(f"  PIPELINE COMPLETE in {mins}m {secs}s")
    print(f"  Open: output/FINAL_REPORT.md")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
