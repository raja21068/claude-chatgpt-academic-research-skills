"""
step6_novelty.py — Novelty Verification
Checks each idea against Semantic Scholar, arXiv, and web search.
Verdicts: PROCEED / PROCEED_WITH_CAUTION / PIVOT / ABANDON
Outputs: output/novelty_report.json, output/novelty_report.md
"""

import sys
import json
import time
import urllib.parse
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent))
from utils import (
    ClaudeClient, load_config, load_json, save_json, save_markdown,
    log, print_banner
)

# ── External Search Functions ────────────────────────────────────────────────

def search_semantic_scholar(query: str, limit: int = 10) -> list:
    """Search Semantic Scholar API for related papers."""
    import requests
    url = "https://api.semanticscholar.org/graph/v1/paper/search"
    params = {
        "query": query,
        "limit": limit,
        "fields": "title,year,venue,abstract,citationCount,url",
    }
    try:
        resp = requests.get(url, params=params, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            return data.get("data", [])
        elif resp.status_code == 429:
            log.warning("Semantic Scholar rate limit — waiting 5s...")
            time.sleep(5)
            resp = requests.get(url, params=params, timeout=15)
            if resp.status_code == 200:
                return resp.json().get("data", [])
        log.warning(f"Semantic Scholar returned {resp.status_code}")
        return []
    except Exception as e:
        log.warning(f"Semantic Scholar search failed: {e}")
        return []


def search_arxiv(query: str, max_results: int = 10) -> list:
    """Search arXiv API for related papers."""
    import requests
    import xml.etree.ElementTree as ET

    url = "http://export.arxiv.org/api/query"
    params = {
        "search_query": f"all:{query}",
        "start": 0,
        "max_results": max_results,
        "sortBy": "submittedDate",
        "sortOrder": "descending",
    }
    try:
        resp = requests.get(url, params=params, timeout=15)
        if resp.status_code != 200:
            return []

        root = ET.fromstring(resp.text)
        ns = {"atom": "http://www.w3.org/2005/Atom"}
        results = []
        for entry in root.findall("atom:entry", ns):
            title = entry.find("atom:title", ns)
            summary = entry.find("atom:summary", ns)
            published = entry.find("atom:published", ns)
            link = entry.find("atom:id", ns)
            results.append({
                "title": title.text.strip() if title is not None else "",
                "abstract": summary.text.strip()[:500] if summary is not None else "",
                "published": published.text[:10] if published is not None else "",
                "url": link.text.strip() if link is not None else "",
            })
        return results
    except Exception as e:
        log.warning(f"arXiv search failed: {e}")
        return []


def run_literature_search(idea: dict) -> dict:
    """Run multi-source search for a single idea."""
    title = idea.get("title", "")
    hypothesis = idea.get("hypothesis", {}).get("statement", "")
    method = idea.get("method_sketch", {}).get("approach", "")
    closest = idea.get("positioning", {}).get("closest_work", "")

    # Build multiple search queries from different angles
    queries = set()
    # From title
    if title:
        queries.add(title[:100])
    # From method keywords
    if method:
        words = method.split()[:8]
        queries.add(" ".join(words))
    # From closest work reference
    if closest:
        queries.add(closest[:80])

    queries = list(queries)[:4]  # Max 4 queries

    all_ss_results = []
    all_arxiv_results = []

    for q in queries:
        log.info(f"    Searching: '{q[:60]}...'")
        ss = search_semantic_scholar(q, limit=5)
        all_ss_results.extend(ss)
        time.sleep(1)  # Rate limit

        ax = search_arxiv(q, max_results=5)
        all_arxiv_results.extend(ax)
        time.sleep(0.5)

    # Deduplicate by title similarity
    seen_titles = set()
    unique_ss = []
    for r in all_ss_results:
        t = r.get("title", "").lower().strip()
        if t and t not in seen_titles:
            seen_titles.add(t)
            unique_ss.append(r)

    unique_arxiv = []
    for r in all_arxiv_results:
        t = r.get("title", "").lower().strip()
        if t and t not in seen_titles:
            seen_titles.add(t)
            unique_arxiv.append(r)

    return {
        "queries_used": queries,
        "semantic_scholar_results": unique_ss[:10],
        "arxiv_results": unique_arxiv[:10],
        "total_unique_papers_found": len(unique_ss) + len(unique_arxiv),
    }


SYSTEM_PROMPT = """You are a novelty verification agent. You assess whether a research idea is genuinely novel by analyzing search results from academic databases.

BE BRUTALLY HONEST. A killed idea saves months; a false positive wastes them.

RESPOND WITH ONLY valid JSON — no markdown fences, no explanation.

For each idea, produce a novelty assessment:

{
  "idea_id": "IDEA-001",
  "title": "idea title",

  "core_claims_assessment": [
    {
      "claim_number": 1,
      "claim": "The specific novelty claim",
      "novelty_level": "HIGH | MEDIUM | LOW",
      "closest_prior_work": "Paper title + year that is most similar",
      "delta": "What specifically differentiates this idea from the prior work"
    }
  ],

  "closest_papers": [
    {
      "title": "paper title",
      "year": 2025,
      "venue": "venue",
      "overlap_type": "method+problem | method_only | problem_only | approach",
      "overlap_level": "HIGH | MEDIUM | LOW",
      "key_difference": "What makes our idea different"
    }
  ],

  "concurrent_work_threats": [
    {
      "paper": "title",
      "date": "2025-03",
      "threat_level": "HIGH | MEDIUM | LOW",
      "differentiation_strategy": "How to differentiate if this is concurrent"
    }
  ],

  "overall_assessment": {
    "novelty_score": 7,
    "verdict": "PROCEED | PROCEED_WITH_CAUTION | PIVOT | ABANDON",
    "key_differentiator": "What makes this unique, if anything",
    "reviewer_risk": "What a reviewer would cite as prior work",
    "positioning_advice": "2-3 sentences on how to frame the contribution"
  }
}

Verdict rules:
- PROCEED: No overlapping work found, high confidence
- PROCEED_WITH_CAUTION: Overlap exists but clear differentiation possible
- PIVOT: Very similar recent work, needs reframing
- ABANDON: Core contribution already published

Rules:
- Assess ACTUAL overlap, not superficial similarity ("both use transformers" is not overlap)
- Check for concurrent work in last 6 months specifically
- "Apply X to Y" is NOT novel unless the combination reveals genuinely surprising insights
- Partial overlap is NORMAL — assess degree, not existence
- Be specific about what the delta is between this idea and closest work
"""


def generate_novelty_report_md(report: dict) -> str:
    """Generate readable markdown from novelty verification."""
    lines = ["# Novelty Verification Report\n"]
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")

    summary = report.get("summary", {})
    lines.append("## Summary\n")
    lines.append(f"- Ideas verified: {summary.get('total_verified', 0)}")
    lines.append(f"- PROCEED: {summary.get('proceed', 0)}")
    lines.append(f"- PROCEED WITH CAUTION: {summary.get('proceed_with_caution', 0)}")
    lines.append(f"- PIVOT: {summary.get('pivot', 0)}")
    lines.append(f"- ABANDON: {summary.get('abandon', 0)}")
    lines.append(f"- Total papers found in search: {summary.get('total_search_results', 0)}")

    for v in report.get("verifications", []):
        overall = v.get("overall_assessment", {})
        verdict = overall.get("verdict", "?")
        emoji = {"PROCEED": "✅", "PROCEED_WITH_CAUTION": "⚠️", "PIVOT": "🔄", "ABANDON": "❌"}.get(verdict, "?")

        lines.append(f"\n## {emoji} {v.get('idea_id','?')}: {v.get('title','?')}")
        lines.append(f"**Verdict: {verdict}** (Novelty score: {overall.get('novelty_score','?')}/10)\n")

        # Core claims
        claims = v.get("core_claims_assessment", [])
        if claims:
            lines.append("### Core Claim Novelty\n")
            lines.append("| # | Claim | Novelty | Closest Work | Delta |")
            lines.append("|---|-------|---------|-------------|-------|")
            for c in claims:
                lines.append(f"| {c.get('claim_number','')} | {c.get('claim','')} | {c.get('novelty_level','')} | {c.get('closest_prior_work','')} | {c.get('delta','')} |")

        # Closest papers
        closest = v.get("closest_papers", [])
        if closest:
            lines.append("\n### Closest Prior Work\n")
            for cp in closest[:5]:
                lines.append(f"- **{cp.get('title','')}** ({cp.get('year','')}, {cp.get('venue','')}) — Overlap: {cp.get('overlap_level','')} ({cp.get('overlap_type','')})")
                lines.append(f"  > Difference: {cp.get('key_difference','')}")

        # Concurrent threats
        threats = v.get("concurrent_work_threats", [])
        if threats:
            lines.append("\n### Concurrent Work Threats\n")
            for t in threats:
                lines.append(f"- ⚠️ **{t.get('paper','')}** ({t.get('date','')}) — Threat: {t.get('threat_level','')}")
                lines.append(f"  > Strategy: {t.get('differentiation_strategy','')}")

        lines.append(f"\n**Key differentiator**: {overall.get('key_differentiator','')}")
        lines.append(f"**Reviewer risk**: {overall.get('reviewer_risk','')}")
        lines.append(f"**Positioning**: {overall.get('positioning_advice','')}")

    return "\n".join(lines)


def run_novelty_verification(config: dict) -> dict:
    """Run novelty verification on generated ideas."""
    print_banner("STEP 6: Novelty Verification")

    cfg = config["pipeline"]
    output_dir = cfg["output_dir"]

    # Load ideas
    idea_data = load_json(f"{output_dir}/idea_report.json")
    ideas = idea_data.get("ideas", [])
    log.info(f"Verifying novelty of {len(ideas)} ideas...")

    client = ClaudeClient(config=config)

    verifications = []
    total_search_results = 0

    for i, idea in enumerate(ideas, 1):
        idea_id = idea.get("idea_id", f"IDEA-{i}")
        log.info(f"\n[{i}/{len(ideas)}] Verifying: {idea_id} — {idea.get('title','?')}")

        # Run literature search
        search_results = run_literature_search(idea)
        total_search_results += search_results["total_unique_papers_found"]
        log.info(f"  Found {search_results['total_unique_papers_found']} potentially related papers")

        # Ask Claude to assess novelty
        user_msg = f"""Assess the novelty of this research idea against search results.

IDEA:
{json.dumps(idea, indent=2, ensure_ascii=False)}

SEARCH RESULTS FROM SEMANTIC SCHOLAR:
{json.dumps(search_results['semantic_scholar_results'], indent=1, ensure_ascii=False)[:8000]}

SEARCH RESULTS FROM ARXIV:
{json.dumps(search_results['arxiv_results'], indent=1, ensure_ascii=False)[:8000]}

QUERIES USED: {search_results['queries_used']}

Be brutally honest. Assess actual overlap, not superficial similarity.
Respond with ONLY the JSON novelty assessment."""

        verification = client.ask_json(SYSTEM_PROMPT, user_msg)
        verification["_search_meta"] = {
            "queries": search_results["queries_used"],
            "ss_results": len(search_results["semantic_scholar_results"]),
            "arxiv_results": len(search_results["arxiv_results"]),
        }
        verifications.append(verification)

        verdict = verification.get("overall_assessment", {}).get("verdict", "?")
        score = verification.get("overall_assessment", {}).get("novelty_score", "?")
        log.info(f"  → Verdict: {verdict} (score: {score}/10)")

    # Build final report
    verdicts = [v.get("overall_assessment", {}).get("verdict", "") for v in verifications]
    report = {
        "verification_date": datetime.now().strftime("%Y-%m-%d"),
        "total_ideas": len(ideas),
        "verifications": verifications,
        "summary": {
            "total_verified": len(verifications),
            "proceed": verdicts.count("PROCEED"),
            "proceed_with_caution": verdicts.count("PROCEED_WITH_CAUTION"),
            "pivot": verdicts.count("PIVOT"),
            "abandon": verdicts.count("ABANDON"),
            "total_search_results": total_search_results,
        },
    }

    # Save
    save_json(report, f"{output_dir}/novelty_report.json")
    report_md = generate_novelty_report_md(report)
    save_markdown(report_md, f"{output_dir}/novelty_report.md")

    log.info(f"\nNovelty verification complete:")
    log.info(f"  PROCEED: {verdicts.count('PROCEED')}")
    log.info(f"  PROCEED WITH CAUTION: {verdicts.count('PROCEED_WITH_CAUTION')}")
    log.info(f"  PIVOT: {verdicts.count('PIVOT')}")
    log.info(f"  ABANDON: {verdicts.count('ABANDON')}")
    log.info(f"  API stats: {client.stats()}")

    return report


if __name__ == "__main__":
    config = load_config()
    run_novelty_verification(config)
