#!/usr/bin/env bash
# ╔═══════════════════════════════════════════════════════════╗
# ║        IDEA DISCOVERY PIPELINE — Launcher (Linux/Mac)    ║
# ║  Auto-installs dependencies, then runs the full pipeline ║
# ╚═══════════════════════════════════════════════════════════╝

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "=============================================="
echo "  Idea Discovery Pipeline v3.0.0"
echo "=============================================="
echo ""

# ── Check Python ─────────────────────────────────────────────
PYTHON=""
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null; then
        version=$("$cmd" --version 2>&1 | grep -oP '\d+\.\d+')
        major=$(echo "$version" | cut -d. -f1)
        minor=$(echo "$version" | cut -d. -f2)
        if [ "$major" -ge 3 ] && [ "$minor" -ge 10 ]; then
            PYTHON="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo "ERROR: Python 3.10+ is required but not found."
    echo "Install Python: https://www.python.org/downloads/"
    exit 1
fi

echo "[✓] Using: $($PYTHON --version)"

# ── Check API Key ────────────────────────────────────────────
if [ -z "$ANTHROPIC_API_KEY" ]; then
    # Try loading from .env file
    if [ -f ".env" ]; then
        export $(grep -v '^#' .env | xargs)
    fi
fi

if [ -z "$ANTHROPIC_API_KEY" ]; then
    echo ""
    echo "WARNING: ANTHROPIC_API_KEY is not set."
    echo ""
    echo "Option 1 — Export it:"
    echo "  export ANTHROPIC_API_KEY=sk-ant-..."
    echo ""
    echo "Option 2 — Create a .env file in this directory:"
    echo "  echo 'ANTHROPIC_API_KEY=sk-ant-...' > .env"
    echo ""
    read -p "Enter your API key now (or press Enter to abort): " api_key
    if [ -z "$api_key" ]; then
        exit 1
    fi
    export ANTHROPIC_API_KEY="$api_key"
fi

echo "[✓] ANTHROPIC_API_KEY is set"

# ── Create virtual environment ───────────────────────────────
VENV_DIR=".venv"
if [ ! -d "$VENV_DIR" ]; then
    echo ""
    echo "[...] Creating virtual environment..."
    $PYTHON -m venv "$VENV_DIR"
    echo "[✓] Virtual environment created"
fi

# Activate
source "$VENV_DIR/bin/activate"

# ── Install dependencies ─────────────────────────────────────
echo ""
echo "[...] Installing/updating dependencies..."
pip install --upgrade pip -q 2>/dev/null
pip install -r requirements.txt -q 2>/dev/null
echo "[✓] Dependencies installed"

# ── Create input folder if needed ────────────────────────────
mkdir -p input_papers
mkdir -p output
mkdir -p logs

# ── Check for input papers ───────────────────────────────────
PAPER_COUNT=$(find input_papers -maxdepth 1 \( -name "*.pdf" -o -name "*.txt" -o -name "*.md" \) 2>/dev/null | wc -l)

if [ "$PAPER_COUNT" -eq 0 ]; then
    echo ""
    echo "╔═══════════════════════════════════════════╗"
    echo "║  No papers found in input_papers/         ║"
    echo "║                                           ║"
    echo "║  Add your PDF, TXT, or MD files there     ║"
    echo "║  and run this script again.               ║"
    echo "╚═══════════════════════════════════════════╝"
    exit 0
fi

echo ""
echo "[✓] Found $PAPER_COUNT papers in input_papers/"

# ── Run pipeline ─────────────────────────────────────────────
echo ""
echo "Starting pipeline..."
echo "----------------------------------------------"
echo ""

$PYTHON scripts/run_pipeline.py

echo ""
echo "Done! Open output/FINAL_REPORT.md to see results."
