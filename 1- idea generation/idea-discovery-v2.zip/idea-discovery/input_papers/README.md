# Drop your papers here

Add 15-100 PDF, TXT, or MD files.

Sweet spot: 30-50 papers mixing:
- Seminal papers in your area
- Recent work (last 2 years)
- 5-10 papers from adjacent fields (best gaps hide here)

Then run: `./run.sh --topic "Your Topic"`
