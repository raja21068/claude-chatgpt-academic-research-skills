# Example: Idea Discovery — Full Pipeline

## User Request
```
I have read ~60 papers on LLM-based code generation. Help me find novel research gaps and generate verified ideas.
```

## Phase 1: PAPER INGESTION

### paper_ingestion_agent Output

**Corpus**: 60 papers on LLM-based code generation (2022–2026)

**Extraction Summary**: 60/60 papers parsed into structured JSON records.

**Sample Record** (1 of 60):
```json
{
  "paper_id": "P-017",
  "title": "CodeBenchX: A Multi-Language Benchmark for Evaluating LLM Code Generation",
  "year": 2025,
  "venue": "ICSE 2025",
  "problem": "Existing code generation benchmarks are Python-centric and do not test multi-language generalization",
  "method": {
    "name": "CodeBenchX",
    "category": "benchmark",
    "mechanism": "1200 problems across 8 languages with parallel test suites",
    "novelty_claim": "First benchmark with semantically equivalent problems across 8 languages"
  },
  "datasets": ["HumanEval", "MBPP", "CodeBenchX (new)"],
  "metrics": ["pass@1", "pass@10", "cross-language consistency score"],
  "claims": [
    {
      "statement": "LLMs show 30-50% performance drop from Python to Rust/Haskell",
      "evidence_type": "empirical",
      "strength": "strong",
      "conditions": "Tested on GPT-4, CodeLlama-34B, StarCoder2"
    }
  ],
  "limitations_acknowledged": ["No low-resource languages", "Problems are algorithmic, not systems-level"],
  "limitations_inferred": ["Static benchmark — no maintenance plan for evolving models"],
  "failure_cases": ["Template-based problems inflate pass@1 for weaker models"],
  "related_work_positioning": "Extends HumanEval/MBPP paradigm to multi-language",
  "future_work": ["Add systems programming tasks", "Include IDE-integrated evaluation"],
  "reproducibility": {
    "code_available": true,
    "data_available": true,
    "compute_requirements": "8×A100 for full evaluation sweep"
  }
}
```

**Corpus Statistics**:
| Category | Count |
|----------|-------|
| Method papers | 28 |
| Benchmark papers | 12 |
| Analysis/empirical studies | 11 |
| Survey/position papers | 9 |

**Temporal distribution**: 2022 (4), 2023 (14), 2024 (22), 2025 (18), 2026 (2)

---

## Phase 2: CLUSTERING

### clustering_agent Output

**Method Clusters**:
| Cluster | Papers | Key Methods |
|---------|--------|-------------|
| M1: Prompt engineering | 14 | Chain-of-thought, self-debug, structured prompting |
| M2: Fine-tuning / RLHF | 12 | CodeRL, RLTF, instruction tuning |
| M3: Retrieval-augmented | 8 | RAG for code, API retrieval, doc-conditioned generation |
| M4: Multi-agent / planning | 6 | ChatDev, MetaGPT, agent-based decomposition |
| M5: Benchmark / evaluation | 12 | HumanEval variants, competition-style, execution-based |

**Problem Clusters**:
| Cluster | Papers |
|---------|--------|
| P1: Function-level generation | 24 |
| P2: Repository-level generation | 11 |
| P3: Bug fixing / repair | 9 |
| P4: Test generation | 7 |
| P5: Multi-language generalization | 5 |
| P6: Security-aware generation | 4 |

**Cross-Dimensional Matrix** (Method × Problem):
```
           P1  P2  P3  P4  P5  P6
M1 Prompt   8   3   2   1   0   0
M2 Finetune 6   2   4   0   0   0
M3 RAG      3   4   1   0   0   0
M4 Agent    2   4   0   1   0   0
M5 Bench    5   1   2   5   5   2
```

**Sparse Regions Identified**:
- M1×P5: No prompt engineering for multi-language
- M3×P3: Almost no RAG for bug repair
- M4×P4: No agent-based test generation
- M1–M4 × P6: Security-aware generation has benchmarks but no methods
- M2×P5: No fine-tuning for cross-language transfer

---

## Phase 3: CONFLICT DETECTION

### conflict_detector_agent Output

**Conflicts Found**: 4

**CONF-001** (Result Conflict — Severity: HIGH)
- Paper P-009 claims "RLHF fine-tuning improves pass@1 by 15% on HumanEval"
- Paper P-031 claims "RLHF fine-tuning shows no significant improvement over SFT on HumanEval when controlling for data quality"
- Contextual difference: P-031 uses higher-quality SFT data baseline
- Resolution path: Controlled ablation isolating data quality from RLHF contribution

**CONF-002** (Claim Conflict — Severity: MEDIUM)
- P-012: "Larger models always generate more secure code"
- P-044: "Model scale has no significant effect on security vulnerability rate"
- Contextual difference: Different vulnerability taxonomies (CWE-based vs. custom)
- Resolution path: Standardized security evaluation with unified taxonomy

**CONF-003** (Reproduction Conflict — Severity: HIGH)
- P-006 reports 87.2% pass@1 for GPT-4 on HumanEval
- P-022 reports 79.1% pass@1 for GPT-4 on HumanEval
- Contextual difference: Different API versions / temperatures / prompt formats
- Resolution path: Standardized evaluation protocol with version pinning

**CONF-004** (Scope Conflict — Severity: LOW)
- P-019: "RAG eliminates hallucinated API calls"
- P-038: "RAG reduces but does not eliminate hallucinated APIs (8% remain)"
- Contextual difference: Different retrieval corpus coverage
- Resolution path: Already partially resolved — P-038 is the more careful claim

---

## Phase 4: GAP DETECTION

### gap_detection_agent Output

**Gaps Found**: 7

**GAP-001**: Missing Combination — Security-Aware Code Generation Methods
- Observation: Security-aware code generation (P6) has 4 benchmark papers but ZERO method papers
- All method clusters (M1–M4) have zero entries in column P6
- Priority: Impact=3, Feasibility=2, Novelty=3 → **Score: 18/27**

**GAP-002**: Missing Combination — Prompt Engineering for Multi-Language
- Observation: Prompt engineering cluster (M1, 14 papers) has zero papers targeting multi-language generalization (P5)
- Priority: Impact=2, Feasibility=3, Novelty=2 → **Score: 12/27**

**GAP-003**: Conflict-Derived — RLHF vs SFT Contribution (from CONF-001)
- No controlled study isolating RLHF reward signal from data quality
- Priority: Impact=3, Feasibility=2, Novelty=2 → **Score: 12/27**

**GAP-004**: Weakness — Repository-Level Evaluation
- 11 papers address repo-level generation, but only 1 benchmark exists (SWE-bench)
- All others evaluate on function-level proxies
- Priority: Impact=3, Feasibility=2, Novelty=2 → **Score: 12/27**

**GAP-005**: Missing Combination — RAG for Bug Repair
- Only 1 paper combines RAG with bug repair; all others use retrieval for generation only
- Priority: Impact=2, Feasibility=3, Novelty=2 → **Score: 12/27**

**GAP-006**: Assumption Gap — Execution-Based Evaluation Sufficiency
- 48/60 papers use pass@k as primary metric, assuming test-passing = correctness
- 0 papers validate whether pass@k correlates with real-world deployment quality
- Priority: Impact=3, Feasibility=1, Novelty=3 → **Score: 9/27**

**GAP-007**: Weakness — Temporal Benchmark Decay
- All benchmarks are static snapshots; no paper studies how LLM performance changes as training data includes benchmark solutions
- Priority: Impact=2, Feasibility=2, Novelty=3 → **Score: 12/27**

**Priority Ranking**:
1. GAP-001 (18) — Security-aware methods
2. GAP-002 (12) — Prompt engineering × multi-language
3. GAP-003 (12) — RLHF isolation
4. GAP-004 (12) — Repo-level benchmarks
5. GAP-005 (12) — RAG for repair
6. GAP-007 (12) — Benchmark decay
7. GAP-006 (9) — Evaluation validity

---

## Phase 5: IDEA GENERATION

### idea_generation_agent Output

**Ideas Generated**: 5 (top 3 shown)

**IDEA-001**: SecureCoGen — Constrained Decoding for Security-Aware Code Generation
- **Gap**: GAP-001 (Security-aware methods void)
- **Hypothesis**: Augmenting LLM decoding with CWE-pattern detectors at generation time reduces security vulnerabilities by ≥40% with ≤5% impact on functional correctness
- **Method sketch**: Train lightweight CWE classifier on labeled vulnerable/safe snippets; integrate as logit-bias filter during beam search; evaluate on SecurityEval benchmark
- **Experiment**: Compare base model vs. constrained decoding on SecurityEval + HumanEval (joint security + correctness); ablate per CWE category
- **Expected outcomes (positive)**: 40%+ vulnerability reduction, minimal correctness drop
- **Expected outcomes (negative)**: If <15% reduction → constrained decoding insufficient, need training-time intervention
- **Feasibility**: HIGH — reuses existing CWE data + standard decoding hooks
- **Ranking**: Gap importance 3 × Rigor 3 × Feasibility 3 × Either-way 2 × Novelty 3 = **weighted 2.75/3**

**IDEA-002**: CrossPrompt — Language-Agnostic Prompt Scaffolds for Multi-Language Generation
- **Gap**: GAP-002 (Prompt engineering × multi-language)
- **Hypothesis**: Language-agnostic pseudocode intermediate prompts improve cross-language consistency by ≥20% vs. direct language-specific prompting
- **Method sketch**: Two-stage prompting — first generate language-agnostic pseudocode plan, then translate to target language; compare against direct prompting and few-shot per-language
- **Experiment**: Evaluate on CodeBenchX across 8 languages; measure cross-language consistency score + per-language pass@1
- **Feasibility**: HIGH — prompt-only, no training needed
- **Ranking**: weighted **2.35/3**

**IDEA-003**: DataVsReward — Disentangling Data Quality from RLHF Signal in Code LLMs
- **Gap**: GAP-003 (from CONF-001)
- **Hypothesis**: ≥60% of reported RLHF gains are attributable to data quality filtering, not the RL reward signal
- **Method sketch**: 2×2 factorial design — {low/high quality SFT data} × {with/without RLHF} — on CodeLlama-13B
- **Experiment**: Train 4 variants, evaluate on HumanEval + MBPP + CodeContests; report effect sizes with confidence intervals
- **Feasibility**: MEDIUM — requires 4 training runs on 13B model
- **Ranking**: weighted **2.45/3**

---

## Phase 6: NOVELTY VERIFICATION

### novelty_verification_agent Output

**IDEA-001: SecureCoGen** → Verdict: **PROCEED WITH CAUTION**
- Similar: SafeCoder (2024) uses post-generation filtering, not constrained decoding — different mechanism
- Similar: SVEN (2023) trains security-aware models from scratch — different approach (decoding-time vs training-time)
- Overlap: ~30% conceptual, ~10% methodological
- Differentiation: Constrained decoding approach at inference time is genuinely novel
- Concurrent work threat: LOW
- Recommended pivot: Emphasize the decoding-time intervention angle; compare explicitly against post-hoc filtering and training-time approaches

**IDEA-002: CrossPrompt** → Verdict: **PROCEED**
- No prior work found on language-agnostic pseudocode intermediate prompts for code generation
- Related but distinct: CodeChain (2023) uses pseudocode but for single-language decomposition
- Overlap: ~15% conceptual, <5% methodological
- Concurrent work threat: MEDIUM (obvious idea — move fast)

**IDEA-003: DataVsReward** → Verdict: **PROCEED**
- No factorial ablation of data quality vs RLHF signal exists in code generation literature
- Related: Anthropic (2023) studies RLHF in general LLMs but not code-specific
- Overlap: ~20% conceptual, 0% methodological
- Concurrent work threat: LOW

---

## Phase 7: FINAL REPORT

### Deliverable Summary

**Corpus**: 60 papers, LLM-based code generation (2022–2026)
**Clusters**: 5 method × 6 problem clusters mapped
**Conflicts**: 4 detected (2 high severity)
**Gaps**: 7 structural gaps identified
**Ideas**: 5 generated, 3 top-ranked
**Novelty-verified**: 3/3 cleared (1 PROCEED WITH CAUTION, 2 PROCEED)

**Recommended Research Agenda** (priority order):
1. **IDEA-001 SecureCoGen** — High impact, novel mechanism, addresses major void
2. **IDEA-003 DataVsReward** — Resolves active conflict, clean experimental design
3. **IDEA-002 CrossPrompt** — Fast to execute, but concurrent work risk — start immediately

**Handoff**: Each idea includes sufficient detail for a 2-page research proposal or direct implementation via `full` mode.
