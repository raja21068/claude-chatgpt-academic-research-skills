# Example: Novelty Check — Standalone Mode

## User Request
```
Check whether this research idea is novel: "Using diffusion models to generate synthetic training data for low-resource medical NER"
```

## Phase A: CLAIM EXTRACTION

### novelty_verification_agent Output (Step 1)

**Core Novelty Claims Extracted**:
1. **C1**: Applying diffusion models (not standard LLMs) to generate synthetic NER training data
2. **C2**: Targeting medical NER specifically in low-resource languages
3. **C3**: The combination of diffusion-based text generation + medical NER + low-resource setting

**Search Queries Planned**:
- Web: "diffusion model synthetic data NER", "diffusion language model medical named entity recognition"
- Venues: ACL/EMNLP/NAACL 2024–2026 proceedings for diffusion + NER
- Corpus: semantic scholar API for medical NER data augmentation
- Code: GitHub search for diffusion-based NER data generation

---

## Phase B: MULTI-SOURCE SEARCH

**Source 1 — Web Search**:
- Found: Li et al. (2025) "DiffuNER: Diffusion-based Data Augmentation for Named Entity Recognition" — uses diffusion models to augment NER training data in English
- Found: MedSynth (2024) — uses GPT-4 for synthetic medical NER data, not diffusion models
- Found: Several papers on diffusion for tabular/image synthetic data, not text NER

**Source 2 — Venue Search**:
- ACL 2025: 1 paper on diffusion for text generation, 0 for NER-specific augmentation
- EMNLP 2024: 0 results for diffusion + NER
- Clinical NLP Workshop 2025: 0 results

**Source 3 — Corpus Search**:
- Semantic Scholar: 3 papers on diffusion for text augmentation (general), 0 for medical NER + low-resource
- ArXiv preprints (last 6 months): 1 preprint on diffusion for relation extraction, not NER

**Source 4 — Code Repositories**:
- GitHub: No repositories combining diffusion models + medical NER data generation
- HuggingFace: No models/datasets matching this combination

---

## Phase C: OVERLAP ASSESSMENT

| Claim | Closest Prior Work | Overlap | Assessment |
|-------|-------------------|---------|------------|
| C1: Diffusion for NER data | DiffuNER (Li 2025) | **HIGH** — same core mechanism | Directly overlapping for English NER |
| C2: Medical NER low-resource | MedSynth (2024) | MEDIUM — same target, different generator | GPT-4 based, not diffusion |
| C3: Combined | None found | LOW | No work combines all three elements |

**Key Distinction Analysis**:
- DiffuNER (C1 overlap): Works on English general-domain NER. Does NOT address medical domain or low-resource languages. Their diffusion architecture is entity-aware but not domain-adapted.
- MedSynth (C2 overlap): Targets medical NER augmentation but uses prompted LLM generation, not diffusion. Tested only on English and Chinese.

---

## Phase D: NOVELTY REPORT

### Verdict: **PROCEED WITH CAUTION**

**Novelty Assessment**:
- The core mechanism (diffusion for NER augmentation) is NOT novel — DiffuNER (2025) establishes this
- The medical + low-resource combination IS novel as an application context
- The contribution must be framed as domain adaptation of diffusion-based augmentation, not as inventing diffusion for NER

**Overlap Summary**:
- Conceptual overlap: ~50% (diffusion for NER exists)
- Methodological overlap: ~30% (would need to build on DiffuNER architecture)
- Application overlap: ~10% (medical low-resource setting is unexplored)

**Concurrent Work Threat**: MEDIUM
- DiffuNER authors may extend to medical domain
- Active area — multiple groups working on diffusion for text

**Recommended Pivots**:
1. **Reframe as extension**: Position as "DiffuNER for medical low-resource NER" with domain-specific contributions (medical entity-aware noise scheduling, cross-lingual transfer, low-resource calibration)
2. **Differentiate technically**: Propose a medical-ontology-conditioned diffusion process that DiffuNER lacks
3. **Must cite**: DiffuNER (Li 2025), MedSynth (2024) — failure to cite these would be a reviewer red flag

**Bottom Line**: The idea has a publishable core if scoped correctly. Frame as domain adaptation with novel technical contributions (ontology conditioning, cross-lingual transfer), not as "first to use diffusion for NER."
