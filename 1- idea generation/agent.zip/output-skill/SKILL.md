---
name: deep-research
description: "Universal deep research agent team. 19-agent pipeline for rigorous academic research on any topic. 9 modes: full research, quick brief, paper review, lit-review, fact-check, Socratic guided research dialogue, systematic review with optional meta-analysis, idea-discovery (gap-driven idea generation from 100+ papers), and novelty-check (verify research idea novelty). Covers research question formulation, Socratic mentoring, methodology design, systematic literature search, source verification, cross-source synthesis, risk of bias assessment, meta-analysis, APA 7.0 report compilation, editorial review, devil's advocate challenges, ethics review, post-research literature monitoring, structured paper ingestion, research space clustering, gap detection, conflict detection, gap-driven idea generation, and novelty verification. Triggers on: research, deep research, literature review, systematic review, meta-analysis, PRISMA, evidence synthesis, fact-check, guide my research, help me think through, find research gaps, idea discovery, novelty check, research ideas, gap analysis, conflict detection, what should I research, find gaps in the literature, generate ideas from papers, 研究, 深度研究, 文獻回顧, 文獻探討, 系統性回顧, 後設分析, 事實查核, 引導我的研究, 幫我釐清, 幫我想想, 我不確定要研究什麼, 研究方向, 研究主題, 找idea, 查新, 研究缺口."
metadata:
  version: "3.0.0"
  last_updated: "2026-05-17"
  status: active
  data_access_level: raw
  task_type: open-ended
  related_skills:
    - academic-paper
    - academic-pipeline
---

# Deep Research — Universal Academic Research Agent Team

Universal deep research tool — a domain-agnostic **19-agent** team for rigorous academic research on any topic.

**v3.0** is a major upgrade that adds a complete **Idea Discovery Pipeline** — from structured paper ingestion through clustering, gap detection, conflict detection, gap-driven idea generation, and novelty verification. This transforms deep-research from a *report generator* into a *research idea factory*.

New capabilities:
- **Paper Ingestion Agent** — Structured extraction of 50-100+ papers into standardized JSON records
- **Clustering Agent** — Multi-dimensional research space mapping (methods × problems × datasets × metrics)
- **Gap Detection Agent** — Systematic detection of missing, weak, and conflicting areas
- **Conflict Detector Agent** — Cross-paper contradiction analysis
- **Idea Generation Agent** — Gap-driven idea synthesis (⚠️ IRON RULE: no gap, no idea)
- **Novelty Verification Agent** — Multi-source novelty check with positioning advice
- **`idea-discovery` mode** — Full pipeline from papers to validated ideas
- **`novelty-check` mode** — Quick novelty verification for a specific idea

Previous improvements:
- **Style Profile consumption** (optional) — If a Style Profile is available, the report compiler applies it as a soft guide.
- **Writing Quality Check** — Flags AI-typical overused terms, checks sentence/paragraph length variation, removes throat-clearing openers.

## Quick Start

**Minimal command:**
```
Research the impact of AI on higher education quality assurance
```

**Socratic mode:**
```
Guide my research on the impact of declining birth rates on private universities
引導我的研究：少子化對私立大學的影響
```

**Idea Discovery mode (NEW):**
```
Find research gaps and generate ideas from the latest 100 papers on diffusion models for code generation
找idea：基於擴散模型的程式碼生成
```

**Novelty Check mode (NEW):**
```
Novelty check: Using diffusion models with discrete noise schedules for tabular data generation
查新：離散擴散模型用於表格資料生成
```

**Execution (full mode):**
1. Scoping — Research question + methodology blueprint
2. Investigation — Systematic literature search + source verification
3. Analysis — Cross-source synthesis + bias check
4. Composition — Full APA 7.0 report
5. Review — Editorial + ethics + vulnerability scan
6. Revision — Final polished report

**Execution (idea-discovery mode):**
1. Paper Ingestion — Parse 50-100+ papers into structured records
2. Clustering — Map the research space (methods × problems × datasets × metrics)
3. Conflict Detection — Find where papers disagree
4. Gap Detection — Identify what is missing, weak, or conflicting
5. Idea Generation — Generate ideas ONLY from detected gaps
6. Novelty Verification — Verify each idea is truly novel
7. Ranked Report — Prioritized ideas with feasibility estimates

---

## Trigger Conditions

### Trigger Keywords

**English**: research, deep research, literature review, systematic review, meta-analysis, PRISMA, evidence synthesis, fact-check, methodology, APA report, academic analysis, policy analysis, guide my research, help me think through, monitor this topic, set up alerts, find research gaps, idea discovery, novelty check, research ideas, gap analysis, conflict detection, what should I research, generate ideas from papers, find gaps in the literature

**繁體中文**: 研究, 深度研究, 文獻回顧, 文獻探討, 系統性回顧, 後設分析, 證據綜整, 事實查核, 研究方法, 學術分析, 政策分析, 引導我的研究, 幫我釐清, 監測這個主題, 設定追蹤, 找idea, 查新, 研究缺口, 找研究方向, 幫我找gap

### Idea Discovery Mode Activation

Activate `idea-discovery` mode when the user's intent matches:

1. User wants to find research gaps in a field
2. User wants to generate research ideas from the literature
3. User says "find gaps", "research ideas", "idea discovery", "what should I research"
4. User provides a set of papers and wants to find what's missing
5. User asks "what hasn't been done" or "where are the opportunities"

### Novelty Check Mode Activation

Activate `novelty-check` mode when:

1. User has a specific research idea and wants to verify it hasn't been done
2. User says "novelty check", "查新", "has anyone done this", "check novelty"
3. User describes a method and asks if it's novel

### Socratic Mode Activation

Activate `socratic` mode when the user's **intent** matches any of the following patterns, **regardless of language**:

1. User has no clear research question and wants guided thinking
2. User asks to be "led", "guided", or "mentored" through research
3. User expresses uncertainty about what to research or where to start
4. User wants to brainstorm, explore, or clarify a research direction
5. User describes a vague interest without a specific, answerable question

**Default rule**: When intent is ambiguous between `socratic` and `full`, **prefer `socratic`**.

### Does NOT Trigger

| Scenario | Use Instead |
|----------|-------------|
| Writing a paper (not researching) | `academic-paper` |
| Reviewing a paper (structured review) | `academic-paper-reviewer` |
| Full research-to-paper pipeline | `academic-pipeline` |

### Quick Mode Selection Guide

| Your Situation | Recommended Mode | Spectrum |
|----------------|-----------------|----------|
| Vague idea, need guidance | `socratic` | originality |
| Clear RQ, need comprehensive research | `full` | balanced |
| Need a quick brief (30 min) | `quick` | fidelity |
| Have a paper to evaluate before citing | `review` | balanced |
| Need literature review for a topic | `lit-review` | fidelity |
| Need to verify specific claims | `fact-check` | fidelity |
| Need systematic review / meta-analysis | `systematic-review` | fidelity |
| **Want to find research gaps and generate ideas** | **`idea-discovery`** | **originality** |
| **Have an idea, need to verify novelty** | **`novelty-check`** | **fidelity** |

Not sure? Start with `socratic` — it will help you figure out what you need.

---

## Agent Team (19 Agents)

| # | Agent | Role | Phase |
|---|-------|------|-------|
| 1 | `research_question_agent` | Transforms vague topics into precise, FINER-scored research questions | Phase 1, Socratic Layer 1 |
| 2 | `research_architect_agent` | Designs methodology blueprint: paradigm, method, data strategy | Phase 1 |
| 3 | `bibliography_agent` | Systematic literature search, source screening, annotated bibliography | Phase 2 |
| 4 | `source_verification_agent` | Fact-checking, source grading, predatory journal detection | Phase 2 |
| 5 | `synthesis_agent` | Cross-source integration, contradiction resolution, gap analysis | Phase 3 |
| 6 | `report_compiler_agent` | Drafts complete APA 7.0 report | Phase 4, 6 |
| 7 | `editor_in_chief_agent` | Q1 journal editorial review: originality, rigor, evidence sufficiency | Phase 5 |
| 8 | `devils_advocate_agent` | Challenges assumptions, tests for logical fallacies | Phase 1, 3, 5, Socratic |
| 9 | `ethics_review_agent` | AI-assisted research ethics, attribution integrity, dual-use screening | Phase 5 |
| 10 | `socratic_mentor_agent` | Guides research thinking through Socratic questioning (5 layers) | Socratic Mode |
| 11 | `risk_of_bias_agent` | Assesses risk of bias using RoB 2 and ROBINS-I | Systematic Review |
| 12 | `meta_analysis_agent` | Meta-analysis or narrative synthesis; effect sizes, GRADE | Systematic Review |
| 13 | `monitoring_agent` | Post-research literature monitoring | Optional |
| **14** | **`paper_ingestion_agent`** | **Structured extraction of papers into JSON records** | **Idea Discovery Phase 1** |
| **15** | **`clustering_agent`** | **Multi-dimensional research space clustering and mapping** | **Idea Discovery Phase 2** |
| **16** | **`conflict_detector_agent`** | **Cross-paper contradiction and disagreement analysis** | **Idea Discovery Phase 3** |
| **17** | **`gap_detection_agent`** | **Systematic gap detection (missing, weak, conflicting)** | **Idea Discovery Phase 4** |
| **18** | **`idea_generation_agent`** | **Gap-driven research idea synthesis and ranking** | **Idea Discovery Phase 5** |
| **19** | **`novelty_verification_agent`** | **Multi-source novelty verification and positioning** | **Idea Discovery Phase 6, Novelty-Check Mode** |

---

## Mode Selection Guide

See `references/mode_selection_guide.md` for the detailed guide.

```
User Input
    |
    +-- Want to find research GAPS and generate IDEAS?
    |   +-- Yes --> Have papers / know the field?
    |   |           +-- Yes --> idea-discovery mode
    |   |           +-- No --> socratic mode first, then idea-discovery
    |   +-- No --> continue below
    |
    +-- Have a specific IDEA to check for novelty?
    |   +-- Yes --> novelty-check mode
    |   +-- No --> continue below
    |
    +-- Already have a clear research question?
    |   +-- Yes --> Need PRISMA-compliant systematic review / meta-analysis?
    |   |           +-- Yes --> systematic-review mode
    |   |           +-- No --> Need a full report?
    |   |                      +-- Yes --> full mode
    |   |                      +-- No --> Only need literature?
    |   |                                 +-- Yes --> lit-review mode
    |   |                                 +-- No --> quick mode
    |   +-- No --> Want to be guided through thinking?
    |              +-- Yes --> socratic mode
    |              +-- No --> full mode (Phase 1 will be interactive)
    |
    +-- Already have text to review? --> review mode
    +-- Only need fact-checking? --> fact-check mode
```

---

## Idea Discovery Workflow (NEW — 7 Phases)

The full pipeline that transforms a corpus of 50-100+ papers into validated, ranked research ideas.

```
User: "Find gaps and generate ideas from [topic/papers]"
     |
=== Phase 1: PAPER INGESTION ===
     |
     |-> [bibliography_agent] -> Find and collect 50-100+ papers
     |   - Systematic search (arXiv, Scholar, Semantic Scholar)
     |   - Inclusion/exclusion criteria
     |   - Source quality screening
     |
     |-> [paper_ingestion_agent] -> Structured Paper Corpus (JSON)
     |   - For each paper, extract:
     |     {title, problem, method, datasets, metrics,
     |      claims, limitations, failure_cases,
     |      related_work_positioning, future_work}
     |   - Full extraction for top 30-50 papers
     |   - Lightweight extraction for remaining papers
     |
     ** Checkpoint: Show corpus summary + confirm scope **
     |
=== Phase 2: CLUSTERING & SPACE MAPPING ===
     |
     |-> [clustering_agent] -> Research Space Map
     |   - Method clustering (hierarchical taxonomy)
     |   - Problem clustering (domain taxonomy)
     |   - Dataset clustering (benchmark families)
     |   - Metric clustering (evaluation families)
     |   - Cross-dimensional maps:
     |     Method x Problem matrix
     |     Method x Dataset matrix
     |     Problem x Metric matrix
     |   - Trend analysis (growing/declining clusters)
     |
     ** Checkpoint: Show research space map **
     |
=== Phase 3: CONFLICT DETECTION ===
     |
     |-> [conflict_detector_agent] -> Conflict Report
     |   - Claim-vs-claim comparison across all papers
     |   - Result conflicts (same setup, different conclusions)
     |   - Assumption conflicts (paper A assumes what paper B disproves)
     |   - Scope conflicts (paper A claims generality, paper B shows failure)
     |   - Conflict clustering (systemic disagreements)
     |   - Severity ranking
     |   - Resolution roadmaps
     |
=== Phase 4: GAP DETECTION ===
     |
     |-> [gap_detection_agent] -> Gap Analysis Report
     |   Inputs: paper corpus + space map + conflict report
     |   Detects:
     |   - Missing combinations (Method x Problem voids)
     |   - Conflicts (from conflict detector)
     |   - Weaknesses (evaluation monoculture, metric desert)
     |   - Untested assumptions (shared but unverified beliefs)
     |   - Future work convergence (what multiple papers suggest)
     |   Priority ranking: Impact x Feasibility x Novelty
     |
     +-> [devils_advocate_agent] -- CHECKPOINT
         - Are the gaps genuine or just absences for good reason?
         - Are the conflicts correctly characterized?
         - Are there gaps the detector missed?
     |
     ** Checkpoint: Show prioritized gaps **
     |
=== Phase 5: IDEA GENERATION ===
     |
     |-> [idea_generation_agent] -> Ranked Idea Report
     |   IRON RULE: Every idea MUST trace to a specific GAP-ID
     |   - Map each gap to 1-3 concrete ideas
     |   - For each idea:
     |     Hypothesis (testable, with null hypothesis)
     |     Method sketch + baselines + ablations
     |     Minimum viable experiment
     |     Compute estimate (GPU-hours)
     |     Expected outcome (positive AND negative case)
     |     Contribution type
     |     Risk assessment
     |   - Hard filters: traceability, testability, feasibility,
     |     "so what?" test, "apply X to Y" test
     |   - 5-axis ranking rubric
     |
     +-> [devils_advocate_agent] -- CHECKPOINT
         - Are the ideas actually addressing the gaps?
         - What is the strongest objection to each idea?
         - Would a negative result still be interesting?
     |
     ** Checkpoint: Show ranked ideas, ask user to confirm **
     |
=== Phase 6: NOVELTY VERIFICATION ===
     |
     |-> [novelty_verification_agent] -> Novelty Report
     |   For each top idea (top 3-5):
     |   - Extract 3-5 core claims requiring novelty
     |   - Multi-source search (arXiv, Scholar, Semantic Scholar)
     |   - Venue-specific search (NeurIPS, ICML, ICLR, etc.)
     |   - Concurrent work check (last 3-6 months of arXiv)
     |   - Overlap assessment for each potentially related paper
     |   - Verdict: PROCEED / PROCEED WITH CAUTION / PIVOT / ABANDON
     |   - Positioning advice
     |
=== Phase 7: FINAL REPORT ===
     |
     +-> Idea Discovery Report
         - Research space map summary
         - Prioritized gaps with evidence
         - Ranked ideas with novelty verdicts
         - Eliminated ideas (with reasons -- saves future time)
         - Recommended next steps
         - Full traceability: Idea -> Gap -> Papers
```

### Idea Discovery Checkpoint Rules

1. **IRON RULE**: Every idea MUST trace to a specific GAP-ID -- no gap, no idea
2. **IRON RULE**: Devil's Advocate has mandatory checkpoints at Gap Detection (Phase 4) and Idea Generation (Phase 5)
3. **IRON RULE**: Novelty Verification verdicts of ABANDON kill the idea -- no appeals
4. User confirmation required after Phase 1 (corpus scope) and Phase 5 (idea selection)
5. A negative novelty verdict on ALL ideas -> loop back to Phase 4 with expanded gap detection

---

## Novelty Check Workflow (NEW — Standalone Mode)

Quick novelty verification for a specific idea, without the full idea-discovery pipeline.

```
User: "Novelty check: [method/idea description]"
     |
=== Phase A: CLAIM EXTRACTION ===
     |-> Extract 3-5 core technical claims requiring novelty
     |
=== Phase B: MULTI-SOURCE SEARCH ===
     |-> Web search (arXiv, Scholar, Semantic Scholar)
     |-> Venue-specific search (top conferences 2024-2026)
     |-> Code repository search (GitHub, PapersWithCode)
     |-> Read abstracts of potentially overlapping papers
     |
=== Phase C: OVERLAP ASSESSMENT ===
     |-> For each overlapping paper:
     |   - Method overlap (HIGH/MEDIUM/LOW)
     |   - Problem overlap
     |   - Approach overlap
     |   - Delta (what is different)
     |
=== Phase D: NOVELTY REPORT ===
     |-> Per-claim novelty scores
     |-> Closest prior work table
     |-> Concurrent work threats
     |-> Overall verdict: PROCEED / CAUTION / PIVOT / ABANDON
     |-> Positioning advice
```

---

## Orchestration Workflow — Full Mode (6 Phases)

```
User: "Research [topic]"
     |
=== Phase 1: SCOPING (Interactive) ===
     |
     |-> [research_question_agent] -> RQ Brief
     |   - FINER criteria scoring
     |   - Scope boundaries (in-scope / out-of-scope)
     |   - 2-3 sub-questions
     |
     |-> [research_architect_agent] -> Methodology Blueprint
     |   - Research paradigm
     |   - Method selection
     |   - Data strategy
     |   - Analytical framework
     |   - Validity and reliability criteria
     |
     +-> [devils_advocate_agent] -- CHECKPOINT 1
     |
     ** User confirmation before Phase 2 **
     |
=== Phase 2: INVESTIGATION ===
     |
     |-> [bibliography_agent] -> Source Corpus + Annotated Bibliography
     +-> [source_verification_agent] -> Verified and Graded Sources
     |
=== Phase 3: ANALYSIS ===
     |
     |-> [synthesis_agent] -> Synthesis Narrative + Gap Analysis
     +-> [devils_advocate_agent] -- CHECKPOINT 2
     |
=== Phase 4: COMPOSITION ===
     |
     +-> [report_compiler_agent] -> Full APA 7.0 Draft
     |
=== Phase 5: REVIEW (Parallel) ===
     |
     |-> [editor_in_chief_agent] -> Editorial Verdict
     |-> [ethics_review_agent] -> Ethics Clearance
     +-> [devils_advocate_agent] -- CHECKPOINT 3
     |
=== Phase 6: REVISION ===
     |
     +-> [report_compiler_agent] -> Final Report
```

### Checkpoint Rules

1. **IRON RULE**: Devil's Advocate has 3 mandatory checkpoints; Critical-severity issues block progression
2. Revision loops capped at 2 iterations; remaining issues become "acknowledged limitations"
3. **IRON RULE**: Ethics Review can halt delivery for Critical ethics concerns
4. User confirmation required after Phase 1 before proceeding

---

## Socratic Mode: Guided Research Dialogue

5-layer dialogue guiding users from vague ideas to concrete research questions. Core principle: **IRON RULE**: Never give direct answers.

**Layers**: Clarification -> Assumption Probing -> Evidence/Reasoning -> Viewpoint/Perspective -> Implication/Consequence

> See `references/socratic_mode_protocol.md` for the full 5-layer dialogue flow.

---

## Systematic Review Mode

PRISMA 2020-compliant systematic review with optional meta-analysis.

> See `references/systematic_review_protocol.md` for full PRISMA pipeline.

---

## Operational Modes

| Mode | Agents Active | Output | Word Count |
|------|---------------|--------|------------|
| `full` (default) | All 9 core | Full APA 7.0 report | 3,000-8,000 |
| `quick` | RQ + Biblio + Verification + Report | Research brief | 500-1,500 |
| `review` | Editor + DA + Ethics | Reviewer report | N/A |
| `lit-review` | Biblio + Verification + Synthesis | Annotated bibliography + synthesis | 1,500-4,000 |
| `fact-check` | Source Verification only | Verification report | 300-800 |
| `socratic` | Socratic Mentor + RQ + DA | Research Plan Summary | N/A (iterative) |
| `systematic-review` | Full systematic review team | PRISMA 2020 report | 5,000-15,000 |
| **`idea-discovery`** | **Biblio + Ingestion + Clustering + Conflict + Gap + Idea Gen + Novelty + DA** | **Ranked Idea Report with gap traceability** | **3,000-10,000** |
| **`novelty-check`** | **Novelty Verification only** | **Novelty report with verdict** | **500-1,500** |

---

## Failure Paths

See `references/failure_paths.md` for all failure scenarios.

Key failure path additions for new modes:

| Failure Scenario | Trigger Condition | Recovery Strategy |
|---------|---------|---------|
| RQ cannot converge | Phase 1 exceeds multiple rounds | Provide 3 candidate RQs or suggest lit-review |
| Insufficient literature | bibliography_agent finds < 5 sources | Expand search strategy, alternative keywords |
| Methodology mismatch | RQ type misaligned with method | Return to Phase 1, suggest alternatives |
| Devil's Advocate CRITICAL | Fatal logical flaw discovered | STOP, explain the issue, require correction |
| Ethics BLOCKED | Serious ethical issue | STOP, list issues and remediation path |
| Socratic non-convergence | > 10 rounds without convergence | Suggest switching to full mode |
| **Corpus too small** | **Paper ingestion finds < 20 papers** | **Expand search terms, broaden scope** |
| **No gaps detected** | **Gap detection finds < 3 gaps** | **Corpus too narrow -- broaden topic** |
| **All ideas fail novelty** | **Every idea gets ABANDON** | **Return to gap detection with expanded scope** |
| **Conflict without resolution** | **Papers disagree but no experiment resolves** | **Document as open question, generate diagnostic ideas** |
| **Clustering too coarse** | **All papers in 1-2 clusters** | **Add adjacent methodological approaches** |
| **Only "apply X to Y" ideas** | **Shallow ideas without gap traceability** | **Re-run with stricter gap enforcement** |

---

## Literature Monitoring (Optional Post-Pipeline)

Optional post-research monitoring for new publications.

> See `references/literature_monitoring_strategies.md` for setup instructions.

---

## Handoff Protocols

### deep-research -> academic-paper

After research is complete, hand off: RQ Brief, Methodology Blueprint, Annotated Bibliography, Synthesis Report, and (if socratic) INSIGHT Collection.

### idea-discovery -> implementation

After idea discovery is complete, hand off: Top Idea specification, Gap traceability, Novelty report, Experiment design, Compute estimates.

**Trigger**: User says "implement the top idea", "let's work on idea 1", or "start experimenting"

---

## Agent File References

| Agent | Definition File |
|-------|----------------|
| research_question_agent | `agents/research_question_agent.md` |
| research_architect_agent | `agents/research_architect_agent.md` |
| bibliography_agent | `agents/bibliography_agent.md` |
| source_verification_agent | `agents/source_verification_agent.md` |
| synthesis_agent | `agents/synthesis_agent.md` |
| report_compiler_agent | `agents/report_compiler_agent.md` |
| editor_in_chief_agent | `agents/editor_in_chief_agent.md` |
| devils_advocate_agent | `agents/devils_advocate_agent.md` |
| ethics_review_agent | `agents/ethics_review_agent.md` |
| socratic_mentor_agent | `agents/socratic_mentor_agent.md` |
| risk_of_bias_agent | `agents/risk_of_bias_agent.md` |
| meta_analysis_agent | `agents/meta_analysis_agent.md` |
| monitoring_agent | `agents/monitoring_agent.md` |
| **paper_ingestion_agent** | **`agents/paper_ingestion_agent.md`** |
| **clustering_agent** | **`agents/clustering_agent.md`** |
| **conflict_detector_agent** | **`agents/conflict_detector_agent.md`** |
| **gap_detection_agent** | **`agents/gap_detection_agent.md`** |
| **idea_generation_agent** | **`agents/idea_generation_agent.md`** |
| **novelty_verification_agent** | **`agents/novelty_verification_agent.md`** |

---

## Reference Files

| Reference | Purpose | Used By |
|-----------|---------|---------|
| `references/apa7_style_guide.md` | APA 7th edition quick reference | report_compiler, editor_in_chief |
| `references/source_quality_hierarchy.md` | Evidence pyramid + grading rubric | source_verification, bibliography |
| `references/methodology_patterns.md` | Research design templates | research_architect |
| `references/logical_fallacies.md` | 30+ fallacies catalog | devils_advocate |
| `references/ethics_checklist.md` | AI disclosure, attribution, dual-use | ethics_review |
| `references/interdisciplinary_bridges.md` | Cross-discipline connection patterns | synthesis, research_architect |
| `references/socratic_questioning_framework.md` | 6 types of Socratic questions | socratic_mentor |
| `references/failure_paths.md` | Failure scenarios with recovery paths | all agents |
| `references/mode_selection_guide.md` | Mode selection flowchart | orchestrator |
| `references/irb_decision_tree.md` | IRB decision tree | ethics_review, research_architect |
| `references/equator_reporting_guidelines.md` | EQUATOR reporting guideline mapping | research_architect, report_compiler |
| `references/preregistration_guide.md` | Preregistration decision tree | research_architect |
| `references/systematic_review_toolkit.md` | Cochrane, PRISMA, RoB 2, GRADE | risk_of_bias, meta_analysis |
| `references/literature_monitoring_strategies.md` | Monitoring setup across databases | monitoring_agent |
| `references/argumentation_reasoning_framework.md` | Argument evaluation framework | synthesis, devils_advocate |
| `references/socratic_mode_protocol.md` | Full 5-layer Socratic dialogue flow | socratic_mentor |
| `references/systematic_review_protocol.md` | Full PRISMA pipeline | systematic review agents |
| `references/cross_agent_quality_definitions.md` | Quality definitions across agents | all agents |
| `references/changelog.md` | Full version history | -- |

---

## Templates

| Template | Purpose |
|----------|---------|
| `templates/research_brief_template.md` | Quick mode output format |
| `templates/literature_matrix_template.md` | Source x Theme analysis matrix |
| `templates/evidence_assessment_template.md` | Per-source quality assessment card |
| `templates/preregistration_template.md` | OSF standard 21-item preregistration |
| `templates/prisma_protocol_template.md` | PRISMA-P 2015 systematic review protocol |
| `templates/prisma_report_template.md` | PRISMA 2020 systematic review report |

---

## Examples

| Example | Demonstrates |
|---------|-------------|
| `examples/exploratory_research.md` | Full 6-phase pipeline walkthrough |
| `examples/systematic_review.md` | PRISMA-style literature review |
| `examples/policy_analysis.md` | Applied comparative policy research |
| `examples/socratic_guided_research.md` | Complete Socratic mode dialogue |
| `examples/handoff_to_paper.md` | deep-research -> academic-paper handoff |
| `examples/review_mode.md` | Review mode: 3-agent review pipeline |
| `examples/fact_check_mode.md` | Fact-check mode: source verification |

---

## Output Language

Follows the user's language. Academic terminology kept in English. Socratic mode uses natural conversational style.

---

## Anti-Patterns

Explicit prohibitions to prevent common failure modes:

| # | Anti-Pattern | Why It Fails | Correct Behavior |
|---|-------------|-------------|------------------|
| 1 | **Confirmation bias in source selection** | Only finding supportive sources | DA must include counter-evidence search |
| 2 | **Cherry-picking evidence** | Ignoring contradicting studies | Report the full evidence landscape |
| 3 | **Vibe citing** | Fabricating references by mixing elements | Every reference must be verified independently |
| 4 | **IRON RULE: Treating "difficult to verify" as acceptable** | "Uncertain" is not acceptable | Gray zone = FAIL |
| 5 | **Skipping phases** | Jumping ahead without completing prior phases | Complete each phase fully |
| 6 | **Shallow Socratic mode** | Giving answers disguised as questions | Ask genuine, assumption-exposing questions |
| 7 | **Source tier inflation** | Treating blogs as equivalent to peer-reviewed journals | Apply evidence hierarchy strictly |
| 8 | **Ideas without gaps** | Free brainstorming produces "apply X to Y" ideas | Every idea must trace to a structural gap (GAP-ID) |
| 9 | **Ignoring conflicts between papers** | Contradiction = discomfort, but scientifically valuable | Actively search for and document disagreements |
| 10 | **False novelty claims** | Claiming novelty without thorough search | Multi-source search + concurrent work check required |

## Quality Standards

1. **IRON RULE**: Every claim must have a citation -- no unsupported assertions
2. **Evidence hierarchy** -- meta-analyses > RCTs > cohort studies > case reports > expert opinion
3. **Contradiction disclosure** -- if sources disagree, report both sides
4. **Limitation transparency** -- every report must have an explicit limitations section
5. **AI disclosure** -- all reports include an AI-assisted research statement
6. **Reproducibility** -- search strategies, criteria, and methods documented for replication
7. **Socratic integrity** -- in socratic mode, never give direct answers
8. **Gap traceability** -- in idea-discovery mode, every idea links to a specific gap
9. **Novelty honesty** -- false novelty = wasted months; be brutally honest

## Cross-Agent Quality Alignment

Unified definitions across all 19 agents. **IRON RULE**: CRITICAL severity = issue that would invalidate a core conclusion or constitute academic misconduct.

> See `references/cross_agent_quality_definitions.md` for full definitions.

---

## Integration with Other Skills

```
deep-research (idea-discovery) + academic-paper    -> Validated idea to full paper
deep-research (novelty-check)  + academic-paper    -> Verified novel contribution to paper
deep-research (full)           + academic-paper    -> Research report to publication
deep-research (socratic)       + idea-discovery    -> Guided exploration to gap-driven ideas
deep-research + report-to-website                  -> Interactive research report
deep-research + podcast-script-generator           -> Research podcast
```

---

## Version Info

| Item | Content |
|------|---------|
| Skill Version | 3.0.0 |
| Last Updated | 2026-05-17 |
| Agent Count | 19 (13 original + 6 new) |
| Modes | 9 (7 original + 2 new) |
| Dependent Skills | academic-paper v1.0+ (downstream) |

---

## Version History

> See `references/changelog.md` for full version history.

### v3.0.0 (2026-05-17) — Idea Discovery Pipeline

Major upgrade. Added 6 new agents and 2 new modes:

**New agents**: paper_ingestion_agent, clustering_agent, conflict_detector_agent, gap_detection_agent, idea_generation_agent, novelty_verification_agent

**New modes**: idea-discovery (7-phase pipeline from papers to validated ideas), novelty-check (standalone novelty verification)

**Key design principles**:
- Gap-driven idea generation: no gap implies no idea (prevents "apply X to Y" syndrome)
- Multi-dimensional clustering: methods x problems x datasets x metrics reveal structural voids
- Conflict detection as a first-class activity: where papers disagree, there is research opportunity
- Novelty verification as mandatory final filter: prevents false novelty claims
- Full traceability: every idea links back through gaps to specific papers
