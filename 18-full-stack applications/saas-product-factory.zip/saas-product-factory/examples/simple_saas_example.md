# Simple SaaS Example: Task Management App

**Product:** TaskFlow - Freelancer task & time tracking with automated invoicing  
**Complexity:** 20 PRs across 6 phases  
**Timeline:** 6-8 weeks  
**Features:** Projects, tasks, time tracking, invoicing, client portal

---

## Discovery Answers Summary

### Business (Q1.1-1.4)
- **Concept:** TaskFlow helps freelancers track billable time and generate professional invoices automatically
- **Personas:** Freelance Designer (primary), Small Agency Owner (secondary)
- **Revenue:** Subscription $15/mo per user, freemium (2 projects free)
- **Market:** US + Europe, English only, Stripe payments

### Features (Q2.1-2.3)
1. Time tracking (start/stop timer, manual entry)
2. Project management (organize by client/project)
3. Automated invoicing (generates from tracked time)
4. Client portal (clients see invoices, make payments)
5. Reporting (weekly summaries, profit tracking)

### AI Strategy (Q3.1-3.2)
- Smart time categorization (AI suggests task categories from descriptions)
- Invoice description generation (AI writes professional line items)
- Quality: Medium (85-95% accuracy OK with review)
- Cost: Low ($50-200/month budget)

### Design (Q6.1-6.2)
- Modern, clean, productivity-focused
- Primary color: Deep Blue (#2563EB)
- Desktop-first (freelancers work on laptops)
- Brand personality: 40% formal, 70% modern, 60% warm

---

## Generated PRD Highlights

### MVP Features (§ 6)

**6.1 Time Tracking**
- Start/stop timer per task
- Manual time entry with date/duration
- Edit/delete time entries
- Daily summary view
- Acceptance criteria: Timer accurate to ±1 second, entries persist across sessions

**6.2 Project Management**
- Create projects with client name, hourly rate
- Add tasks to projects
- Archive completed projects
- Acceptance criteria: Unlimited projects for paid tier, 2 for free tier

**6.3 Automated Invoicing**
- Generate invoice from time entries
- Customizable line item descriptions
- PDF export
- Send via email
- Track paid/unpaid status
- Acceptance criteria: Invoice generation <2 seconds, PDF matches brand identity

**6.4 Client Portal**
- Clients see their invoices
- Pay via Stripe
- View project progress
- Acceptance criteria: Secure access (no password = no access), mobile-friendly

**6.5 Reporting**
- Weekly time summary
- Revenue by client
- Profit margin tracking
- Acceptance criteria: Reports generate in <5 seconds, exportable to CSV

### Data Model (§ 9)
- users (auth, profile)
- projects (client_name, hourly_rate, status)
- tasks (project_id, name, description)
- time_entries (task_id, start_time, end_time, duration, billable)
- invoices (project_id, line_items, total, status, paid_at)
- payments (invoice_id, amount, stripe_payment_id, status)

### Phased Delivery (§ 15)
- Phase 0: Foundation (auth, database, admin)
- Phase 1: Time Tracking
- Phase 2: Project Management
- Phase 3: Invoicing
- Phase 4: Client Portal
- Phase 5: Reporting + Polish

---

## Generated Design System Highlights

### Colors
- Primary: Blue-600 (#2563EB)
- Success: Green-500 (#10B981) — for "paid" status
- Warning: Yellow-500 (#F59E0B) — for "pending" status
- Neutrals: Slate-50 to Slate-900

### Typography
- Headings: Inter 600
- Body: Inter 400
- Monospace (for time display): Fira Code

### Key Components
- Timer display (large, monospace, with start/stop buttons)
- Time entry card (shows task, duration, edit/delete actions)
- Invoice preview (PDF-like layout in UI)
- Project card (shows client, hours tracked, revenue to-date)

---

## Generated Task Roadmap (20 PRs)

### Phase 0: Foundation (4 PRs)
- PR-001: Repo setup
- PR-002: Design tokens + UI primitives
- PR-003: Database + multi-tenancy
- PR-004: Auth (NextAuth, email/password)

### Phase 1: Time Tracking (4 PRs)
- PR-005: Time entries schema + tRPC router [TESTS: timer accuracy]
- PR-006: Timer component (start/stop, display)
- PR-007: Manual entry form
- PR-008: Time entry list + edit/delete

### Phase 2: Project Management (3 PRs)
- PR-009: Projects schema + tRPC router
- PR-010: Project CRUD UI
- PR-011: Task management (add tasks to projects)

### Phase 3: Invoicing (4 PRs)
- PR-012: Invoices schema + generation logic [TESTS: line item totals, tax calc]
- PR-013: Invoice UI + PDF export
- PR-014: Email sending (Resend integration)
- PR-015: Payment webhook (Stripe) [TESTS: idempotency]

### Phase 4: Client Portal (3 PRs)
- PR-016: Client role + permissions
- PR-017: Client dashboard (view invoices)
- PR-018: Client payment flow

### Phase 5: Reporting + Polish (2 PRs)
- PR-019: Reports (weekly summary, revenue by client)
- PR-020: Polish (loading states, error handling, E2E tests)

---

## Key Learnings from This Example

### What Worked Well
- Clear personas → focused feature set
- Simple pricing → no complex payment logic
- Desktop-first → less responsive complexity
- English-only → no i18n overhead

### Challenges
- Timer accuracy across browser tabs/sleep (solved with server-side time tracking)
- PDF generation performance (solved with background job)
- Stripe test mode vs. production (documented in deployment notes)

### Timeline
- Actual: 7 weeks
- Estimated: 6-8 weeks
- Variance: On track (no scope creep)

---

*This example demonstrates a straightforward SaaS with clear value prop and manageable scope.*
