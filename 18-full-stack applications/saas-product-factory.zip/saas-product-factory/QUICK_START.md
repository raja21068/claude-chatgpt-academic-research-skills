# Quick Start Guide
## Build Your First SaaS Product in 5 Steps

**Time to First Spec:** ~2 hours  
**Time to First Deploy:** 4-16 weeks (depending on complexity)

---

## Step 1: Set Up Your Workspace (5 minutes)

### Create Project Directory
```bash
mkdir my-saas-project
cd my-saas-project
mkdir discovery docs
```

### Copy This Package
```bash
# Place the saas-product-factory/ folder in your project root
cp -r path/to/saas-product-factory .
```

**Your structure should look like:**
```
my-saas-project/
├── saas-product-factory/  # This package
├── discovery/             # Your discovery answers go here
├── docs/                  # Generated specs go here
└── [your code will go here after Phase 3]
```

---

## Step 2: Run Discovery Interview (1-2 hours)

### Open the Discovery Agent
```bash
cat saas-product-factory/agents/discovery_agent.md
```

### Answer the Questions

**Option A: Self-Interview (Solo Founder)**
1. Read each question from the discovery agent
2. Write your answers in `discovery/answers.md`
3. Be honest — say "UNCERTAIN" if you don't know
4. Provide examples and links where asked

**Option B: AI-Assisted Interview (Recommended)**
1. Start a conversation with Claude/GPT-4
2. Paste this prompt:

```
I'm using the SaaS Product Factory to build a product.

Read: saas-product-factory/agents/discovery_agent.md

Run the discovery interview. Ask me questions from Domain 1 
(Business Fundamentals) first. Wait for my answers before moving 
to the next domain.

After I've answered all 9 domains, save my answers to 
discovery/answers.md in a structured format.

Begin with Q1.1.
```

3. Answer the AI's questions
4. Review the generated `discovery/answers.md`

**Key Questions You'll Answer:**
- What problem does your product solve?
- Who are your users?
- What's your revenue model?
- What are the must-have features?
- Where should AI be used?
- What's your brand personality?
- What's your timeline?

---

## Step 3: Generate Specifications (2-4 hours)

### Generate PRD (Product Requirements Document)

**Prompt for AI:**
```
Read my discovery answers: discovery/answers.md

Read: saas-product-factory/agents/prd_generator_agent.md

Generate a Product Requirements Document following the PRD template 
in saas-product-factory/references/prd_template.md

First, show me the section outline and 3 sample sections.
Wait for my approval before generating the full PRD.

Save to: docs/prd.md
```

**Review Checklist:**
- [ ] All user personas have goals, pain points, tech proficiency
- [ ] All MVP features have acceptance criteria
- [ ] Data model includes entities and relationships
- [ ] Success metrics are specific and measurable
- [ ] Open questions are explicitly listed

**Expected output:** 40-80 page markdown document

---

### Generate Design System

**Prompt for AI:**
```
Read: docs/prd.md
Read: discovery/answers.md (brand preferences from Q6.1)

Read: saas-product-factory/agents/design_system_generator_agent.md

Generate a Design System following the template in 
saas-product-factory/references/design_system_template.md

First, show me:
1. Color palette (with hex codes)
2. Typography scale
3. 5 key component specs

Wait for my approval before generating the full Design System.

Save to: docs/DESIGN_SYSTEM.md
```

**Review Checklist:**
- [ ] Colors specified as hex codes (not "blue")
- [ ] Typography has exact px/rem/line-height/weight
- [ ] Components have anatomy, variants, sizes, states
- [ ] Accessibility requirements specified
- [ ] Dark mode strategy defined (if applicable)

**Expected output:** 30-50 page markdown document

---

### Generate Task Roadmap

**Prompt for AI:**
```
Read: docs/prd.md
Read: docs/DESIGN_SYSTEM.md

Read: saas-product-factory/agents/task_roadmap_generator_agent.md

Generate a Task Roadmap following best practices from 
saas-product-factory/references/testing_philosophy.md and
saas-product-factory/references/code_generation_standards.md

First, show me:
1. Phase breakdown (how work is grouped)
2. 3 sample PRs (one simple, one medium, one complex)
3. Testing strategy

Wait for my approval before generating the full roadmap.

Save to: docs/TASKS.md
```

**Review Checklist:**
- [ ] Every PR has explicit dependencies
- [ ] File structure is complete
- [ ] 10-15 PRs have mandatory tests
- [ ] Effort estimates provided
- [ ] Conventions documented

**Expected output:** 30-50 PRs across 8-10 phases

---

## Step 4: Review & Approve (30 minutes)

### Read All Three Documents

```bash
# PRD: Business logic and features
cat docs/prd.md | less

# Design System: Visual specifications
cat docs/DESIGN_SYSTEM.md | less

# Tasks: Implementation roadmap
cat docs/TASKS.md | less
```

### Check for Consistency

**Cross-document validation:**
- [ ] Every feature in PRD has corresponding PRs in TASKS.md
- [ ] Every component in Design System is built in TASKS.md
- [ ] Color tokens in Design System match brand from Discovery
- [ ] Success metrics in PRD are measurable from the built system

### Request Changes if Needed

If something is wrong, prompt:
```
In docs/prd.md, Section 6.3 (AI Chatbot) is missing the acceptance 
criteria for handling multi-language support. Please add:

- Chatbot detects user language from first message
- Supports English and [your language]
- Falls back to English if language unsupported
```

---

## Step 5: Start Implementation (Ongoing)

### Initialize Git Repository

```bash
git init
git add docs/ discovery/
git commit -m "Initial commit: Discovery and specifications"
```

### Start Building PR-001

**Prompt for AI (Claude/GPT-4/Cursor/etc.):**
```
I'm building a SaaS product with complete specifications.

SOURCE DOCUMENTS:
- docs/prd.md (Product Requirements)
- docs/DESIGN_SYSTEM.md (Visual specifications)
- docs/TASKS.md (Task roadmap)

METHODOLOGY:
Read: saas-product-factory/agents/implementation_orchestrator_agent.md

This defines the 7-step PR cycle I want you to follow.

YOUR TASK:
Build PR-001 from docs/TASKS.md

WORKFLOW:
1. Read TASKS.md and find PR-001
2. Read the implementation orchestrator methodology
3. Show me your implementation plan
4. Wait for my approval
5. Then implement following the plan

CRITICAL RULES:
- Follow specifications exactly (no improvising)
- Use Design System tokens only (no magic values)
- If tests are required, they must pass before merge
- If spec is ambiguous, ASK before proceeding

Begin by showing me your plan for PR-001.
```

### The AI Will:
1. Read PR-001 requirements from TASKS.md
2. Gather context from PRD and Design System
3. Show you a detailed implementation plan
4. Wait for your approval
5. Implement the code
6. Run tests (if PR has tests)
7. Create a pull request for your review

### Review & Merge
- Review the code
- Check that all subtasks are complete
- Run tests yourself to verify
- Merge to main
- Move to PR-002

---

## Step 6: Repeat for All PRs

**For each subsequent PR:**
```
Build PR-XXX: [Title from TASKS.md]

Follow the same workflow as PR-001.
Read TASKS.md for requirements, show me your plan, implement after approval.

[If PR has tests:]
CRITICAL: This PR has mandatory tests. The test cases in TASKS.md are 
the source of truth. DO NOT modify them to make tests pass — fix your 
implementation instead.
```

---

## Progress Tracking

### Mark PRs Complete in TASKS.md

After each PR merges:
```bash
# Edit docs/TASKS.md
# Check off subtasks: - [ ] → - [x]
# Commit the update
git add docs/TASKS.md
git commit -m "chore: mark PR-XXX complete"
```

### Monitor Overall Progress

```bash
# Count completed PRs
grep -c "^- \[x\]" docs/TASKS.md

# Find next PR to work on
grep -A 20 "^### PR-" docs/TASKS.md | grep -B 5 "^- \[ \]"
```

---

## Common First-Time Questions

### Q: Do I need to answer EVERY discovery question?
**A:** Core questions are required. Optional ones can be skipped, but you'll get generic defaults. Answering 80% gives high-quality output.

### Q: Can I change the PRD after it's generated?
**A:** Yes, but changes are cheapest BEFORE Task Roadmap generation. After implementation starts, changes may invalidate completed PRs.

### Q: What if I don't know how to code?
**A:** This system is designed for AI coding agents. You review and approve; the AI writes the code. You need to understand concepts, not write syntax.

### Q: How do I know if the AI is following the spec?
**A:** Check three things:
1. Colors match Design System hex codes (not random values)
2. Component structure matches Design System anatomy
3. Tests pass (tests verify correctness)

### Q: What if a test fails?
**A:** Read the error, tell the AI to fix the IMPLEMENTATION (not the test). The test defines correct behavior.

---

## Next Steps After Quick Start

Once you've completed your first PR:

1. **Read the examples** in `examples/` to see full project walkthroughs
2. **Study the references** in `references/` for deeper understanding
3. **Customize the templates** in `references/templates/` for your stack
4. **Document your decisions** in docs/TASKS.md § Decision Log

---

## Getting Help

**Stuck on Discovery?**
→ Read `references/discovery_question_bank.md` for examples

**Stuck on PRD?**
→ Read `references/prd_template.md` for section explanations

**Stuck on Implementation?**
→ Read `references/common_pitfalls.md` for anti-patterns

**AI going off-spec?**
→ Read `references/code_generation_standards.md` and copy relevant rules into your prompt

---

## Success Criteria

You've successfully completed Quick Start when you have:

- [x] `discovery/answers.md` with your answers to all domains
- [x] `docs/prd.md` (40-80 pages, all sections complete)
- [x] `docs/DESIGN_SYSTEM.md` (30-50 pages, all components specified)
- [x] `docs/TASKS.md` (30-50 PRs, dependencies clear)
- [x] PR-001 merged (repo initialized, tooling set up)
- [x] PR-002 in progress or complete

**You're now building a professional SaaS product with AI assistance.**

---

**Estimated time from zero to first merged PR:** 4-6 hours  
**Estimated time from first PR to MVP deploy:** 4-16 weeks

**Ready to scale?** Continue through the PR roadmap until complete.
