# Common Pitfalls & Anti-Patterns
## What Goes Wrong and How to Avoid It

**Purpose:** Learn from common mistakes in SaaS development  
**Audience:** Implementation teams, AI coding agents, project managers

---

## Pitfall 1: "I'll Improve the Spec"

**Symptom:** You think the Design System button height should be 44px instead of 40px, so you change it without asking.

**Why it's wrong:**
- Breaks consistency (other components reference 40px)
- Your "improvement" might conflict with accessibility guidelines
- Specs exist for a reason — often decided after research

**Fix:** Implement as written. Note your suggestion in PR description. Discuss improvement in next planning cycle.

---

## Pitfall 2: "This Test is Too Hard"

**Symptom:** Test requires complex setup or mocking, so you simplify the test or skip it entirely.

**Why it's wrong:**
- Hard tests often guard complex, bug-prone code
- Simplifying test = not actually testing the behavior
- Skipping test = shipping untested code to production

**Fix:** If genuinely stuck, ASK how to approach it. But assume test IS doable — the difficulty is a feature, not a bug.

---

## Pitfall 3: "I'll Come Back and Add That Later"

**Symptom:** You skip a subtask or leave a TODO, planning to fix it in a future PR.

**Why it's wrong:**
- "Later" often becomes "never"
- Incomplete PRs create technical debt
- Next PR might depend on the skipped work

**Fix:** PR is not complete until ALL subtasks checked. If something is genuinely out of scope, ASK to move it to a new PR.

---

## Pitfall 4: "The Migration Failed, I'll Just Fix the DB Manually"

**Symptom:** Schema migration has an error, so you edit the database directly instead of fixing the migration file.

**Why it's wrong:**
- Manual changes aren't in version control
- Not reproducible in other environments
- Production deploy will fail with same migration error

**Fix:** ALWAYS fix the migration file and re-run. Never touch the database directly except for debugging.

---

## Pitfall 5: "I'll Merge First, Test Later"

**Symptom:** You want to move fast, so you merge a PR before tests are written or passing.

**Why it's wrong:**
- Tests are quality gates, not optional polish
- Merging untested code = shipping bugs
- "Later" tests are harder (code already in use)

**Fix:** Tests must pass BEFORE merge. If a PR has "Tests Required", it's blocked until green.

---

## Pitfall 6: "This is Taking Too Long, I'll Cut Corners"

**Symptom:** A PR is complex, so you skip accessibility checks, use magic values, or don't handle errors to finish faster.

**Why it's wrong:**
- Technical debt compounds
- Accessibility can't be "added later" easily
- Error handling prevents production fires

**Fix:** If a PR is too large, ASK to split it. But don't ship low-quality work to save time.

---

## Pitfall 7: "I Don't Need to Read the Design System"

**Symptom:** You know how to build a button, so you code it from memory instead of reading the spec.

**Why it's wrong:**
- Your memory ≠ the Design System
- Inconsistency breaks UX (different buttons across the app)
- Missing states (forgot to handle disabled, loading)

**Fix:** ALWAYS read Design System § 9.X before building any component, even "simple" ones.

---

## Pitfall 8: "Magic Values Are Fine, It's Just One Place"

**Symptom:** You hard-code a color (#2563EB) or spacing (16px) instead of using design tokens.

**Why it's wrong:**
- "One place" becomes 50 places
- Design System changes = find/replace nightmare
- No dark mode support
- Accessibility issues (contrast ratios)

**Fix:** Use tokens ALWAYS. `bg-primary` not `bg-blue-600`. `px-4` not custom padding.

---

## Pitfall 9: "I'll Modify the Test to Make It Pass"

**Symptom:** Your code returns `[1, 2, 3]` but test expects `[1, 2]`, so you change the test to expect 3 items.

**Why it's wrong:**
- Test defines correct behavior
- Changing test = changing requirements without approval
- Your code is probably wrong, not the test

**Fix:** Assume test is correct. Fix your implementation. Only change test if you have PROOF it's wrong (and document why).

---

## Pitfall 10: "Forgot to Check Dependencies"

**Symptom:** You start PR-025 before PR-020 is merged because they seem unrelated.

**Why it's wrong:**
- TASKS.md dependencies exist for a reason
- PR-025 might import types from PR-020
- Merge conflicts and wasted work

**Fix:** Check "Depends on" list in TASKS.md. If dependencies not merged, work on a different PR.

---

## Pitfall 11: "I'll Just Console.Log for Debugging"

**Symptom:** You add `console.log()` everywhere while debugging, then forget to remove them before committing.

**Why it's wrong:**
- Production logs get polluted
- Sensitive data might leak (API keys, user emails)
- Looks unprofessional

**Fix:** Use a proper logger (with log levels). Remove all console.logs before commit. Lint rule should catch these.

---

## Pitfall 12: "Auth Can Wait"

**Symptom:** You build features without permission checks, planning to "add auth later."

**Why it's wrong:**
- Security holes in production
- Harder to retrofit auth into existing features
- Unauthorized access to sensitive data

**Fix:** Every tRPC mutation should have permission check from day one. Use `protectedProcedure` and `requirePermission()`.

---

## Pitfall 13: "Forgot About Multi-Tenancy"

**Symptom:** You query `SELECT * FROM orders` instead of filtering by `tenant_id`.

**Why it's wrong:**
- Data leaks across tenants (Company A sees Company B's orders)
- Critical security/privacy violation
- Lawsuit-level bad

**Fix:** EVERY query must scope to `tenant_id`. Add lint rule to catch this. Code review must verify.

---

## Pitfall 14: "That Edge Case Won't Happen"

**Symptom:** Test spec says "handle concurrent updates," but you think "users won't do that" so you skip it.

**Why it's wrong:**
- Edge cases happen in production
- Especially with multiple users/devices
- Race conditions cause data corruption

**Fix:** If the test spec lists an edge case, it's not optional. Implement it.

---

## Pitfall 15: "I'll Just Guess the Business Rule"

**Symptom:** PRD says "calculate referral payout" but doesn't specify the formula, so you guess 10%.

**Why it's wrong:**
- Guess might be wrong (maybe it's 15%)
- Financial calculations can't be arbitrary
- Legal/contractual implications

**Fix:** If spec is ambiguous, ASK. Never guess business rules.

---

## How to Avoid These Pitfalls

### 1. Read the Spec
- PRD for business logic
- Design System for visuals
- TASKS for implementation plan

### 2. Follow the Process
- 7-step PR cycle
- Quality gates
- Test requirements

### 3. When in Doubt, ASK
- Ambiguous spec → ask before coding
- Test seems wrong → ask before changing
- Timeline pressure → ask to split PR

### 4. Trust the System
- Specs are researched decisions
- Tests define correctness
- Gates prevent shipping broken code

---

## Summary

**Most pitfalls come from:**
1. Not reading the spec
2. Trying to save time by cutting corners
3. Modifying tests instead of fixing code
4. Working out of order (skipping dependencies)

**The fix is always:**
- Read the spec
- Follow the process
- Ask when uncertain
- Complete the PR fully before moving on

---

*End of Common Pitfalls*
