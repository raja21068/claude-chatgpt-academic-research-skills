# Testing Philosophy
## When and How to Test in SaaS Product Factory

**Purpose:** Define which code gets tested and why  
**Audience:** Implementation teams and AI coding agents

---

## Core Principle

**Not all code needs tests. But critical code MUST have tests.**

Tests are expensive (time to write, maintain, debug). Use them where they provide the highest value:
1. Preventing costly bugs (payments, data loss)
2. Verifying complex logic (state machines, calculations)
3. Catching regressions (integration points)

---

## Which PRs Get Tests

### ✅ ALWAYS Test
- Payment processing (webhooks, milestones, calculations)
- Workflow state machines (order lifecycle, approval flows)
- External integrations (API clients, webhooks, auth)
- Data transformations (OCR, parsing, validation)
- AI routing (provider selection, caching, cost tracking)
- Business calculations (pricing, discounts, totals)

### ⚠️ SOMETIMES Test
- Complex utilities (if >50 lines with branching logic)
- Permission/RBAC systems (if custom, not if using library)
- Background jobs (if not idempotent by design)

### ❌ RARELY Test
- UI components (validated by Storybook + manual QA + E2E)
- CRUD operations (standard patterns, low risk)
- Database schemas (migrations are code review + manual testing)
- Configuration files
- Simple utilities (<20 lines, no branching)

---

## Test Types

### Unit Tests
**What:** Test individual functions in isolation  
**When:** Pure functions, business logic, utilities  
**Example:** Milestone percentage calculator, template merge function  
**Command:** `pnpm test tests/unit/path/to/file.test.ts`  
**Coverage Target:** ≥80% of tested modules

### Integration Tests
**What:** Test multiple layers together (DB + service + API)  
**When:** External integrations, multi-step workflows  
**Example:** Stripe webhook → DB update → workflow advance  
**Command:** `pnpm test tests/integration/path/to/file.test.ts`  
**Coverage Target:** Happy path + 2 edge cases minimum

### E2E Tests
**What:** Full user journeys in real browser  
**When:** Final PR only, critical paths  
**Example:** Sign up → create project → track time → generate invoice → pay  
**Command:** `pnpm test:e2e`  
**Coverage Target:** 5-10 critical flows

---

## Test Specification Format

When a PR requires tests, specify:

1. **Exact test file path**
2. **Exact command to run**
3. **Specific test cases (with testable assertions)**
4. **Edge cases that must pass**

**Example:**
```markdown
#### Tests Required
- [ ] Unit test: `tests/unit/server/payments/milestones.test.ts`
  - **Must pass before PR merge:** `pnpm test tests/unit/server/payments/milestones.test.ts`
  - **Test cases (DO NOT modify these to make tests pass — fix the code instead):**
    - `generateMilestones(orderId)` with 40/60 split → creates 2 invoices with correct amounts
    - `generateMilestones(orderId)` with 100% upfront → creates 1 invoice
    - Service has 3 milestones (30/30/40) → creates 3 invoices
  - **Edge cases:**
    - Percentages don't sum to 100 → throws validation error
    - Milestone 2 trigger before Milestone 1 paid → queues for later
```

---

## Rules for AI Coding Agents

When a PR includes "Tests Required":

### Rule 1: Test is Source of Truth
The test defines correct behavior. DO NOT modify test cases or expected values to make tests pass. Fix the implementation instead.

### Rule 2: Tests Must Pass Before Merge
Run the exact command listed. If it fails, the code is wrong. The PR is blocked until all tests are green.

### Rule 3: Edge Cases Are Not Optional
Every listed edge case must have a corresponding test. If you don't understand an edge case, ASK before skipping it.

### Rule 4: Use Provided Fixtures
Some tests reference files in `tests/fixtures/`. Use them as-is. Don't create your own unless the test spec says to.

### Rule 5: No Mocking Critical Logic
You can mock external APIs (Stripe, OCR services) but NEVER mock:
- The workflow engine
- Payment milestone logic
- Referral payout state machine
- Your own business logic

---

## Test File Naming

Mirror source structure:
```
tests/
  unit/
    server/
      ai/
        router.test.ts          # tests src/server/ai/router.ts
      workflow/
        engine.test.ts          # tests src/server/workflow/engine.ts
    lib/
      template-merge.test.ts    # tests src/lib/template-merge.ts
      
  integration/
    payments/
      stripe-webhook.test.ts   # tests full webhook flow
    chatbot/
      tool-execution.test.ts   # tests conversation loop
      
  fixtures/
    documents/
      transcript.pdf
      passport.jpg
```

---

## Writing Good Tests

### Good Test Case
```typescript
it('generates 2 invoices for 40/60 milestone split', async () => {
  const order = await createTestOrder({ total: 1000 });
  const service = await createTestService({ 
    milestones: [
      { percentage: 40, trigger: 'order_placed' },
      { percentage: 60, trigger: 'deliverable_approved' }
    ]
  });
  
  const invoices = await generateMilestones(order.id);
  
  expect(invoices).toHaveLength(2);
  expect(invoices[0].amount).toBe(400);
  expect(invoices[1].amount).toBe(600);
});
```

**Why it's good:**
- Tests one specific behavior
- Clear setup (40/60 split)
- Testable assertion (length, amounts)
- Self-documenting (name describes behavior)

### Bad Test Case
```typescript
it('works', async () => {
  const result = await doSomething();
  expect(result).toBeTruthy();
});
```

**Why it's bad:**
- Vague name ("works" doesn't describe behavior)
- No context (what input?)
- Weak assertion (just "truthy"?)

---

## Test Failures = PR Blocked

If a required test fails:

1. **Read the error message** — it tells you what broke
2. **Look at the test case** — what behavior was expected?
3. **Check the PRD** — does the business logic match?
4. **Fix the implementation** (not the test)
5. **Re-run** until green

**If you're stuck:**
- The test case description explains expected behavior
- The PRD section defines the business rule
- ASK for clarification if genuinely ambiguous

**Never:**
- Change expected values to match your output
- Comment out failing tests
- Skip tests marked "required"
- Modify fixtures to make tests pass

---

## Example: Payment Webhook Test

```typescript
describe('Stripe webhook handler', () => {
  it('marks invoice paid and advances workflow on success event', async () => {
    // Setup
    const invoice = await createTestInvoice({ status: 'pending', amount: 500 });
    const webhookEvent = createStripeEvent('checkout.session.completed', {
      payment_intent: 'pi_test123',
      amount_total: 50000, // cents
      metadata: { invoice_id: invoice.id }
    });
    
    // Execute
    const response = await POST('/api/webhooks/stripe', {
      body: webhookEvent,
      headers: { 'stripe-signature': signWebhook(webhookEvent) }
    });
    
    // Assert
    expect(response.status).toBe(200);
    
    const updatedInvoice = await db.query.invoices.findFirst({
      where: eq(invoices.id, invoice.id)
    });
    expect(updatedInvoice.status).toBe('paid');
    expect(updatedInvoice.paid_at).toBeTruthy();
    
    // Verify workflow advanced
    const order = await db.query.orders.findFirst({
      where: eq(orders.id, updatedInvoice.order_id)
    });
    expect(order.current_stage).toBe('in_progress'); // from 'pending_payment'
  });
  
  it('is idempotent - duplicate webhook does not double-process', async () => {
    const invoice = await createTestInvoice();
    const event = createStripeEvent('checkout.session.completed', {
      id: 'evt_unique123',
      metadata: { invoice_id: invoice.id }
    });
    
    // First call
    await POST('/api/webhooks/stripe', { body: event });
    
    // Second call (duplicate)
    const response = await POST('/api/webhooks/stripe', { body: event });
    
    expect(response.status).toBe(200); // Still 200 (not an error)
    
    // Verify only one payment record
    const payments = await db.query.payments.findMany({
      where: eq(payments.invoice_id, invoice.id)
    });
    expect(payments).toHaveLength(1);
  });
});
```

**This example shows:**
- Clear test names (describe exact behavior)
- Setup → Execute → Assert pattern
- Multiple assertions per test (invoice + workflow)
- Edge case testing (idempotency)

---

## Summary

**Test the critical 20% that prevents 80% of bugs.**

- Payment logic → prevent financial errors
- State machines → prevent stuck workflows
- Integrations → prevent data loss
- Calculations → prevent wrong numbers

**Everything else:** Manual QA + code review.

---

*End of Testing Philosophy*
