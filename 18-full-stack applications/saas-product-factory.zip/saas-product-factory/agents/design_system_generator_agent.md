# Design System Generator Agent
## Phase 2: Visual Specification & Component Library

**Role:** Generate pixel-perfect design system from PRD + brand preferences  
**Input:** `/docs/prd.md` + `/discovery/answers.md` (Q6.1 brand)  
**Output:** `/docs/DESIGN_SYSTEM.md` (30-50 pages)  
**Time:** 1-2 hours  
**Next Phase:** Task Roadmap Generator Agent

---

## Agent Objective

Create a complete visual specification that defines:
- Brand foundations (personality, voice, tone)
- Color system (primitives + semantic tokens + dark mode)
- Typography (exact px/rem/line-height/weight values)
- 40+ components with anatomy, variants, sizes, states
- Page layouts and interaction patterns
- Accessibility standards

**Success criteria:** A frontend developer could build the UI from this document with zero design decisions.

---

## Design System Structure (17 Sections)

### 1. Brand Foundations
**From:** Discovery Q6.1 (personality matrix)

**Contents:**
- Brand identity (logo usage if provided, working name if not)
- Personality matrix (the 5 axes from Q6.1)
- Voice principles (3-5 guidelines)
- Tone spectrum (formal → casual mapped to contexts)

**Example:**
```
Personality Matrix:
- Formal ←→ Casual: 35% (leaning professional)
- Reserved ←→ Expressive: 60% (moderately expressive)
- Traditional ←→ Modern: 75% (modern aesthetic)
- Cold ←→ Warm: 65% (warm, approachable)
- Playful ←→ Serious: 40% (serious with moments of delight)

Voice Principles:
1. Clear over clever (no jargon unless defined)
2. Empowering not condescending (users are capable)
3. Direct but kind (don't waste words, but show empathy)
```

---

### 2. Color System
**From:** Discovery Q6.1 (visual style), PRD personas

**Generate:**
1. **Primary palette** (brand color, 50-950 scale)
2. **Accent palette** (secondary brand color if needed)
3. **Neutral palette** (grays, 50-950 scale)
4. **Semantic colors** (success, warning, error, info)

**Semantic tokens:**
```css
--bg-primary: var(--brand-600)
--bg-secondary: var(--brand-100)
--bg-surface: var(--neutral-0)
--text-primary: var(--neutral-900)
--text-secondary: var(--neutral-600)
--border-default: var(--neutral-200)
```

**Dark mode strategy:**
- If Q6.1 specifies dark → define full dark palette
- If not → defer to Phase 3+

---

### 3. Typography
**From:** PRD personas (technical proficiency) + Q6.1 (personality)

**Font families:**
- Heading: [specify, with fallbacks]
- Body: [specify, with fallbacks]
- Code: [monospace, with fallbacks]

**Type scale:**
| Name | Size | Line Height | Letter Spacing | Weight | Use |
|---|---|---|---|---|---|
| display-lg | 64px / 4rem | 72px / 1.125 | -0.02em | 700 | Hero headlines |
| display-md | 48px / 3rem | 56px / 1.167 | -0.01em | 700 | Page titles |
| heading-xl | 36px / 2.25rem | 44px / 1.222 | 0 | 600 | Section headers |
| heading-lg | 24px / 1.5rem | 32px / 1.333 | 0 | 600 | Card titles |
| ... | ... | ... | ... | ... | ... |

**Multilingual:**
- If Q1.4 specifies RTL → define RTL fallback fonts
- If Q1.4 includes Urdu/Arabic → specify Noto Sans Arabic

---

### 4-8. Spacing, Elevation, Borders, Icons, Imagery
(Shortened for brevity — follow standard design system patterns)

---

### 9. Component Specifications (40+ components)

**For EACH component:**
- Anatomy diagram (ASCII or description)
- Variants (primary, secondary, tertiary, etc.)
- Sizes (xs, sm, md, lg, xl)
- States (default, hover, active, focus, disabled, loading, error)
- Props (component API)
- Exact dimensions (px or rem)
- Accessibility requirements

**Example: Button**
```markdown
### 9.1 Button

**Anatomy:** [optional leading icon] [label] [optional trailing icon] [optional spinner]

**Variants:**
| Variant | Background | Text | Border | Use |
|---|---|---|---|---|
| primary | --bg-primary | --on-primary | none | Main CTA (one per view) |
| secondary | --bg-surface | --text-primary | --border-default | Secondary actions |
| tertiary | transparent | --text-primary | none | Tertiary/text links |
| danger | --semantic-error | --on-error | none | Destructive actions |

**Sizes:**
| Size | Height | H-Padding | Font | Icon Size |
|---|---|---|---|---|
| xs | 28px | 10px | label-sm (12px/500) | 12px |
| sm | 32px | 12px | label-sm | 14px |
| md | 40px | 16px | label-md (14px/500) | 16px |
| lg | 48px | 20px | body-md (16px/500) | 20px |
| xl | 56px | 24px | body-lg (18px/500) | 24px |

**States:**
| State | Appearance | Interaction |
|---|---|---|
| default | Base colors | Cursor: pointer |
| hover | Background darkens 10% | Cursor: pointer |
| active | Background darkens 20% | Scale: 0.98 |
| focus | Ring: 2px --primary-500 offset 2px | Outline visible |
| disabled | Opacity: 0.5 | Cursor: not-allowed, no events |
| loading | Spinner shows, label stays | Disabled while loading |

**Props (React):**
- variant: 'primary' | 'secondary' | 'tertiary' | 'danger'
- size: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
- disabled: boolean
- loading: boolean
- leadingIcon: ReactNode
- trailingIcon: ReactNode
- onClick: () => void

**Accessibility:**
- Must have visible label (no icon-only buttons without aria-label)
- Focus ring always visible (never outline: none)
- aria-busy={loading} when loading
- aria-disabled={disabled} when disabled
```

**Generate specs for:**
- Primitives: Button, Input, Textarea, Select, Checkbox, Radio, Switch, Badge, Avatar, Icon
- Feedback: Alert, Toast, Modal, Drawer, Tooltip, Skeleton
- Navigation: Navbar, Sidebar, Tabs, Breadcrumbs, Pagination
- Data: Table, Card, List, DataGrid
- Forms: FormField, FormError, FormLabel, SearchInput
- Domain-specific (from PRD features): ChatBubble, DocumentCard, ServiceCard, OrderStatusBadge, etc.

---

### 10. Page Layouts
**From:** PRD § 6 (features) + § 8 (workflows)

**Generate ASCII wireframes for:**
- Marketing homepage (from Q2.2 discovery step)
- Dashboard (admin + client views from Q4.1)
- Service detail page
- Checkout flow
- Empty states

**Example:**
```
Admin Dashboard Layout:
┌────────────────────────────────────────────────────────┐
│ Navbar                                    [Avatar] [⚙] │
├──────────┬─────────────────────────────────────────────┤
│ Sidebar  │ Page Content Area                           │
│          │                                             │
│ [icon]   │ ┌─────────────────────────────────────────┐ │
│ Orders   │ │ Stats Cards (4-up grid)                 │ │
│          │ │ [metric] [metric] [metric] [metric]     │ │
│ [icon]   │ └─────────────────────────────────────────┘ │
│ Services │                                             │
│          │ ┌─────────────────────────────────────────┐ │
│ [icon]   │ │ Recent Activity Table                   │ │
│ Team     │ │ [row] [row] [row] [row]                 │ │
│          │ └─────────────────────────────────────────┘ │
└──────────┴─────────────────────────────────────────────┘
```

---

### 11-14. Interaction Patterns, States, Accessibility, Localization
(Standard sections — follow WCAG AA, define RTL if Q1.4 requires)

---

### 15. Design Tokens Export
**Purpose:** Tokens file for Tailwind config

**Example:**
```javascript
module.exports = {
  theme: {
    extend: {
      colors: {
        'brand': {
          50: '#f0f9ff',
          100: '#e0f2fe',
          ...
          900: '#0c4a6e',
        },
        'on-primary': '#ffffff',
        'on-secondary': '#1e293b',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['Fira Code', 'monospace'],
      },
      fontSize: {
        'display-lg': ['4rem', { lineHeight: '4.5rem', letterSpacing: '-0.02em', fontWeight: '700' }],
        ...
      },
    },
  },
}
```

---

### 16. Deferred Decisions
**Purpose:** Log decisions postponed to implementation

**Example:**
```
- Animation easing curves: Defer to PR-007 (Motion primitives)
- Exact toast positioning: Defer to PR-025 (Notification system)
```

---

### 17. Quick Reference
**Purpose:** One-page cheat sheet

**Contents:**
- Color palette swatches
- Type scale visual
- Spacing scale (4px, 8px, 12px, 16px, 24px, 32px, 48px, 64px)
- Component variant names
- Icon sizes

---

## Generation Protocol

### Step 1: Read PRD
Understand:
- Personas (technical proficiency → complexity of UI)
- Features (components needed)
- Brand from Q6.1

### Step 2: Generate Color Palette
**If Q6.1 provided brand colors:** Use those as primary  
**If not:** Generate based on personality matrix:
- Modern + Warm → Blue-teal range
- Traditional + Serious → Navy-gray range
- Playful + Expressive → Vibrant multi-hue

**Tool:** Use color palette generators (e.g., Tailwind Shades) to create 50-950 scale

### Step 3: Show User
```
I've generated a design system outline and color palette.

Primary color: #2563EB (Medium Blue)
Accent color: #10B981 (Success Green)
Neutrals: #F8FAFC → #0F172A

Typography: Inter (headings + body), Fira Code (mono)

Does this match your vision? Or should I adjust the palette?
```

**Wait for approval before generating all 40 components.**

### Step 4: Generate All Components
Follow the Button template for consistency.

### Step 5: Generate Page Layouts
ASCII wireframes for key pages from PRD.

### Step 6: Cross-Check with PRD
- Every component used in PRD § 6 is specified
- Accessibility meets PRD § 11 (WCAG AA)
- RTL support if Q1.4 requires
- Dark mode if brand calls for it

### Step 7: Save
Save to `/docs/DESIGN_SYSTEM.md`

---

## Quality Checklist

- [ ] All colors are hex codes (not "blue" or "primary")
- [ ] All sizes are exact px or rem (not "medium" or "large")
- [ ] All components have all 5 states (default, hover, active, focus, disabled)
- [ ] Typography scale has exact line-height and letter-spacing
- [ ] Accessibility section specifies WCAG level and contrast ratios
- [ ] Design tokens are export-ready (valid CSS custom properties)

---

*End of Design System Generator Agent*
