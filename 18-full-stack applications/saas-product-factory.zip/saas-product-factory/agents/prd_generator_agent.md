# PRD Generator Agent
## Phase 1: Product Requirements Document Generation

**Role:** Transform discovery answers into professional PRD  
**Input:** `/discovery/answers.md`  
**Output:** `/docs/prd.md` (40-80 pages)  
**Time:** 30 minutes - 2 hours  
**Next Phase:** Design System Generator Agent

---

## Agent Objective

Generate a complete Product Requirements Document with 18 sections that:
- Translates user answers into technical specifications
- Defines all features with acceptance criteria
- Maps data model and workflows
- Identifies risks and open questions
- Creates phased delivery plan

**Success criteria:** A developer could build this system from the PRD alone (with Design System for visuals).

---

## PRD Structure (18 Sections)

### 1. Executive Summary
**Purpose:** 2-page overview for stakeholders  
**Contents:**
- Product name and tagline
- Problem statement (1 paragraph)
- Solution overview (1 paragraph)
- Target market and user count estimates
- Revenue model summary
- Key differentiators (3-5 bullets)
- Success metrics snapshot

**Source:** Q1.1 (concept), Q1.3 (revenue), Q7.1 (metrics)

---

### 2. Vision & Mission
**Purpose:** Strategic direction  
**Contents:**
- Vision (what world looks like when product succeeds)
- Mission (how we'll get there)
- Core values (3-5 principles guiding decisions)

**Source:** Inferred from Q1.1, Q8.2 (concerns reveal values)

---

### 3. Market & Competition Analysis
**Purpose:** Position product in landscape  
**Contents:**
- Market size and opportunity
- Direct competitors (from Q9.1) with SWOT analysis
- Indirect competitors and why users might choose them
- Our competitive advantages
- Market gaps we're filling

**Source:** Q9.1 (competitors), Q1.1 (unique approach)

---

### 4. User Personas
**Purpose:** Define who we're building for  
**Contents:** For each persona from Q1.2:
- Name and role
- Demographics (if relevant)
- Goals (3-5 bullets)
- Pain points (3-5 bullets)
- Technical proficiency
- Preferred channels
- Quote (fictional but representative)

**Source:** Q1.2 directly

---

### 5. User Stories
**Purpose:** Feature justification from user perspective  
**Format:** "As a [persona], I want to [action] so that [benefit]"

**Generate 10-20 stories** covering all personas and must-have features from Q2.1.

**Example:**
```
As a University Applicant, I want to chat with an AI advisor so that 
I can get instant answers to my questions without booking a call.

As a Manager, I want to see all pending approvals in one dashboard 
so that I can prioritize my review queue efficiently.
```

**Source:** Q1.2 (personas), Q2.1 (features)

---

### 6. MVP Feature Specification
**Purpose:** Detail every feature with acceptance criteria  
**Format:** One subsection per feature from Q2.1

**For each feature:**
- Name
- Description (2-3 paragraphs)
- User story reference
- Acceptance criteria (5-10 bullets, testable)
- Out of scope for MVP (what we're NOT building yet)
- Dependencies (what else must exist first)
- Success metrics (how we measure this feature works)

**Example:**
```markdown
### 6.2 AI Chatbot Consultant

The chatbot is the primary entry point for prospects...

**User Story:** US-003 (As a prospect, I want instant answers...)

**Acceptance Criteria:**
- Chatbot responds within 2 seconds (p95)
- Can look up services, compute prices, create draft orders
- Conversation history persists across sessions
- Anonymous users can chat; account created on first order
- Supports English and Urdu (from Q1.4)

**Out of Scope:**
- Voice interface (Phase 3)
- Video chat (not planned)

**Dependencies:**
- Services catalog (PR-009)
- AI provider pool (PR-024)

**Success Metrics:**
- 60% of visitors engage with chatbot
- 30% of chatbot conversations → draft orders
```

**Source:** Q2.1 (features), Q2.2 (journey), Q3.1 (AI use cases)

---

### 7. AI/ML Strategy
**Purpose:** Define where and how AI is used  
**Contents:**
- AI use cases (from Q3.1) with priority
- Provider strategy (multiple providers, routing, failover)
- Quality vs. cost trade-offs (from Q3.2)
- Human-in-the-loop requirements
- Prompt templates and evaluation criteria
- Fallback behavior when AI fails

**Source:** Q3.1, Q3.2

---

### 8. Core Workflows
**Purpose:** Map end-to-end processes  
**Format:** ASCII flowcharts or numbered steps

**Generate workflows for:**
1. User onboarding (from Q2.2)
2. Service delivery lifecycle (from Q2.2)
3. Payment processing (from Q1.3, Q5.1)
4. Admin configuration (from Q4.2)

**Example:**
```
Order Lifecycle Workflow:
┌─────────┐     ┌─────────┐     ┌──────────┐     ┌─────────┐
│  Draft  │ --> │ Pending │ --> │ In Prog. │ --> │  Ready  │
└─────────┘     └─────────┘     └──────────┘     └─────────┘
     ^                |                |                |
     |          [pay initial]    [deliver]        [pay final]
     |                v                v                v
     |          ┌─────────┐     ┌──────────┐     ┌─────────┐
     └──────────│Cancelled│     │  Failed  │     │Complete │
                └─────────┘     └──────────┘     └─────────┘
```

**Source:** Q2.2 (journey), Q1.3 (payment structure)

---

### 9. Data Model
**Purpose:** Define all entities, relationships, key fields  
**Format:** Entity list with fields and relationships

**Example:**
```
Entity: users
Fields:
- id (uuid, PK)
- tenant_id (int, FK to tenants)
- email (text, unique per tenant)
- role (enum: client, consultant, manager, admin)
- created_at (timestamp)

Relationships:
- belongs to one tenant
- has many orders
- has many conversations
```

**Generate entities for:**
- Users and auth
- Core business objects (orders, services, etc.)
- Configuration (from Q4.2)
- Integrations (from Q5.1)

**Source:** Q2.1 (features imply data), Q2.3 (data collected)

---

### 10. Tech Stack Recommendation
**Purpose:** Specify technologies and justify choices  
**Contents:**
- Frontend (Next.js 15, React, TypeScript, Tailwind)
- Backend (tRPC, Drizzle ORM, Zod)
- Database (from Q5.2)
- Hosting (from Q5.2)
- External services (from Q5.1)
- Rationale for each choice

**Source:** Q5.1, Q5.2, Q8.1 (constraints)

---

### 11. Architectural Principles
**Purpose:** Guiding decisions during implementation  
**Contents:**
- Multi-tenancy pattern (every table has tenant_id)
- API-first (tRPC for type safety)
- Configuration over code (from Q4.2)
- Security-first (auth, RBAC, audit logs)
- Accessibility (WCAG AA minimum)
- Performance targets (from success metrics)

**Source:** Q4.2 (no-code config), Q2.3 (compliance)

---

### 12. Cost & Resource Planning
**Purpose:** Budget and team requirements  
**Contents:**
- Development costs (tools, services, API usage)
- Operational costs (hosting, database, AI, integrations)
- Team size (from Q4.1)
- Zero-cost alternatives (if Q8.1 specifies)

**Source:** Q4.1 (team), Q8.1 (budget constraints)

---

### 13. Out of MVP Scope
**Purpose:** Explicitly list what we're NOT building  
**Contents:**
- Features mentioned but deferred (from Q2.1 if >5 features)
- Nice-to-have items
- Future phases (mobile app, advanced analytics, etc.)

**Source:** Q2.1 (features beyond top 5), Q7.2 (phased approach)

---

### 14. Success Metrics
**Purpose:** How we measure if product works  
**Format:** SMART metrics (Specific, Measurable, Achievable, Relevant, Time-bound)

**From Q7.1:**
- North Star metric with target
- Secondary KPIs with targets
- Per-feature metrics (from § 6)

**Example:**
```
North Star: $50,000 revenue in first 3 months

Secondary KPIs:
- Conversion rate (visitor → signup): 15%
- Activation rate (signup → first order): 40%
- NPS: 50+
- AI draft approval rate: 85%
```

**Source:** Q7.1 directly

---

### 15. Phased Delivery Plan
**Purpose:** Break work into deployable milestones  
**Format:** 8-12 phases, each builds on prior

**Phase naming:**
- Phase 0: Foundation (auth, admin shell, database)
- Phase 1: Core Features (first 2 must-haves from Q2.1)
- Phase 2-N: Remaining features
- Final Phase: Production hardening (monitoring, backups, compliance)

**For each phase:**
- Name
- Duration estimate (1-3 weeks)
- Features delivered
- Success criteria (how we know phase is done)

**Source:** Q2.1 (features), Q7.2 (timeline)

---

### 16. Open Questions
**Purpose:** Explicitly list what needs deciding  
**Format:** Question + who decides + urgency

**Example:**
```
Q1: Should referral payouts be % of revenue or fixed amount?
Decided by: Business owner
Urgency: Before PR-038 (Phase 7)
Default if not decided: 10% of revenue

Q2: Which plagiarism detection service to use?
Decided by: Technical lead
Urgency: Before PR-030 (Phase 5)
Default if not decided: Copyleaks (has free tier)
```

**Source:** 
- Any UNCERTAIN from discovery
- Ambiguities in Q2.1, Q3.1, Q5.1
- Trade-offs you identified

---

### 17. Risks & Mitigations
**Purpose:** Identify what could go wrong  
**Format:** Risk + impact + likelihood + mitigation

**From Q8.2:**
- User's top 3 concerns → map to specific risks
- Add technical risks you identify
- Add market/competitive risks

**Example:**
```
Risk: AI costs exceed budget
Impact: High (could make product unprofitable)
Likelihood: Medium
Mitigation: 
- Implement aggressive caching (cache hit = no cost)
- Use cheapest-first routing strategy
- Set hard quota limits per tenant
- Monitor costs daily with alerts
```

**Source:** Q8.2 (concerns)

---

### 18. Glossary
**Purpose:** Define domain-specific terms  
**Format:** Alphabetical list

**Include:**
- Business terms (e.g., "SOP" = Statement of Purpose)
- Technical terms used in PRD
- Acronyms

---

## Generation Protocol

### Step 1: Review Discovery Answers
Read `discovery/answers.md` in full. Note any contradictions or gaps.

### Step 2: Generate Outline
Create section outline (just headings, no content). Show to user for approval.

**User approves outline → continue**  
**User requests changes → adjust and re-show**

### Step 3: Generate Sample Sections
Write 3 complete sections:
- § 6.X (one feature spec)
- § 9 (data model excerpt)
- § 16 (open questions)

Show to user. This sets quality bar.

**User approves samples → continue**  
**User requests changes → adjust style**

### Step 4: Generate Full PRD
Write all 18 sections following approved style.

### Step 5: Cross-Check Consistency
Verify:
- Every feature in § 6 appears in § 15 (phases)
- Every persona in § 4 has stories in § 5
- Every tech choice in § 10 justified by constraints in § 8.1
- Success metrics in § 14 are measurable from data model in § 9

### Step 6: Save and Hand Off
Save to `/docs/prd.md`

**Prompt for user:**
```
PRD generated: docs/prd.md (XX pages)

Open questions identified: X
[list them]

Ready for Phase 2: Design System Generation?
Use: agents/design_system_generator_agent.md
```

---

## Quality Checklist

Before finalizing PRD:
- [ ] All 18 sections complete (no "TBD" or "TODO")
- [ ] Every feature has 5+ acceptance criteria
- [ ] Data model includes tenant_id on all multi-tenant tables
- [ ] Tech stack choices justified
- [ ] Open questions explicitly listed with decision owners
- [ ] Success metrics are measurable
- [ ] Phased delivery sums to complete product

---

*End of PRD Generator Agent*
