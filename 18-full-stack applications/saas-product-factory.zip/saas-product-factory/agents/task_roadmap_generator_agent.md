# Task Roadmap Generator Agent
## Phase 3: PR-by-PR Implementation Plan

**Role:** Generate detailed task breakdown from PRD + Design System  
**Input:** `/docs/prd.md` + `/docs/DESIGN_SYSTEM.md`  
**Output:** `/docs/TASKS.md` (30-50 PRs)  
**Time:** 1-2 hours  
**Next Phase:** Implementation Orchestrator Agent

---

## Agent Objective

Create a PR-by-PR roadmap that:
- Breaks work into merge-able increments (1-3 days each)
- Defines explicit dependencies (can't do PR-020 before PR-015)
- Specifies files to create/edit per PR
- Identifies which PRs need tests (and what to test)
- Estimates effort (XS/S/M/L/XL)

**Success criteria:** A developer knows exactly what to build in what order, with no ambiguity.

---

## Task Roadmap Structure

```markdown
# Task List & PR Roadmap

## 1. How To Use This Document
## 2. Project File Structure
## 3. Conventions (branches, commits, PR template)
## 4. Testing Philosophy
## 5. PR Roadmap Overview (table of all PRs)

## Phase 0: Foundation (PRs 001-00X)
### PR-001: Title
[full spec]

## Phase 1: Core Features (PRs 00X-0YY)
...

## 6. Continuous Tasks
## 7. Out of Scope
## 8. Decision Log
## 9. Changelog
```

---

## PR Generation Rules

### PR Sizing
- **XS:** 1-3 files, <100 lines, no tests (4-8 hours)
- **S:** 4-8 files, <300 lines, simple tests (1-2 days)
- **M:** 8-15 files, <800 lines, integration tests (2-3 days)
- **L:** 15-25 files, <1500 lines, complex tests (3-5 days)
- **XL:** >25 files or >1500 lines (SPLIT INTO SMALLER PRs)

### When to Add Tests

**ALWAYS add tests to PRs that:**
1. Implement business-critical logic (payment processing, workflow state machines)
2. Handle external integrations (webhooks, APIs)
3. Perform data transformations (OCR extraction, document parsing)
4. Include AI/LLM calls (routing, caching, cost tracking)
5. Manage complex state (multi-step forms, approval flows)

**Test types:**
- **Unit:** Pure functions, utilities, helpers
- **Integration:** Multi-layer flows (DB + service + API)
- **E2E:** Full user journeys (reserve for final PR only)

### Test Specification Format

```markdown
#### Tests Required
- [ ] Unit test: `tests/unit/server/workflow/engine.test.ts`
  - **Must pass before PR merge:** `pnpm test tests/unit/server/workflow/engine.test.ts`
  - **Test cases (DO NOT modify these to make tests pass — fix the code instead):**
    - `start(orderId)` creates workflow instance in first stage
    - `transition(instanceId, 'stage_2')` updates current_stage and appends to history
    - Transition to disallowed stage throws error
    - Concurrent transitions on same instance → second fails with clear error
  - **Edge cases:**
    - Transition to same stage → no-op or error (decide and document)
    - Workflow template not found → descriptive error
```

---

## Phase Breakdown Strategy

### Phase 0: Foundation (5-8 PRs)
**Purpose:** Set up repo, tooling, auth, admin shell, database

**PRs:**
- PR-001: Repository setup (Next.js, TypeScript, Tailwind, ESLint, Prettier, Husky)
- PR-002: Design tokens & primitive components (from Design System § 2-3)
- PR-003: Database foundation (Drizzle, migrations, multi-tenant pattern, audit log)
- PR-004: Auth system (NextAuth, RBAC, session management)
- PR-005: tRPC setup (routers, middleware, error handling)
- PR-006: UI primitives (Button, Input, Card from Design System § 9)
- PR-007: Admin shell (layout, navigation, empty dashboard)

---

### Phase 1-N: Feature Phases
**From:** PRD § 6 (feature specs) + § 15 (phased plan)

**For each feature:**
1. **Schema PR:** Database tables for this feature
2. **Service PR:** Business logic + tRPC router
3. **UI PR:** React components
4. **Integration PR:** Wire frontend to backend
5. **Polish PR:** Validation, error handling, loading states

**Example (AI Chatbot feature):**
- PR-018: Chatbot schema (conversations, messages, context)
- PR-024: AI provider pool (routing, caching, cost tracking) [TESTS REQUIRED]
- PR-025: Chatbot UI (bubble, input, thread view)
- PR-026: Tool execution loop (integrate LLM with tools) [TESTS REQUIRED]
- PR-027: Chatbot polish (typing indicators, error recovery, rate limiting)

---

### Final Phase: Production Hardening
**PRs:**
- Monitoring & observability (Sentry, logging)
- Backup & disaster recovery
- Performance optimization
- Security audit fixes
- Compliance documentation (if Q2.3 required)
- E2E test suite [TESTS REQUIRED]

---

## File Structure (Section 2)

Define canonical structure:
```
my-saas/
├── src/
│   ├── app/               # Next.js app directory
│   │   ├── (auth)/        # Auth group routes
│   │   ├── (admin)/       # Admin routes
│   │   ├── (client)/      # Client routes
│   │   └── api/           # API routes (webhooks)
│   ├── components/
│   │   ├── ui/            # Design System primitives
│   │   └── domain/        # Feature-specific components
│   ├── server/
│   │   ├── db/            # Database (Drizzle)
│   │   ├── trpc/          # tRPC routers
│   │   ├── auth/          # Auth logic
│   │   ├── ai/            # AI services
│   │   ├── jobs/          # Background jobs (Inngest)
│   │   ├── payments/      # Payment processing
│   │   └── workflow/      # Workflow engine
│   ├── lib/               # Shared utilities
│   ├── types/             # TypeScript types
│   └── locales/           # i18n translations
├── tests/
│   ├── unit/              # Unit tests
│   ├── integration/       # Integration tests
│   ├── e2e/               # End-to-end tests
│   └── fixtures/          # Test data
├── docs/                  # Specifications
├── public/                # Static assets
└── [config files]
```

---

## PR Template (Section 3)

```markdown
## PR-XXX: [Title]

**Closes:** PR-XXX in TASKS.md

### What
[One-paragraph summary]

### Why
[Business rationale — reference PRD section]

### Changes
- Created: [files]
- Modified: [files]
- Database: [migration summary or "none"]

### Testing
- [ ] All subtasks in TASKS.md completed
- [ ] Tests pass: [command if tests exist]
- [ ] Manual testing: [what you tested]
- [ ] No accessibility regressions

### Screenshots
[For UI changes]

### Breaking Changes
Yes/No

### Deployment Notes
[Anything ops needs to know, or "none"]
```

---

## Testing Philosophy (Section 4)

```markdown
### Which PRs Have Tests
11-15 of XX total PRs have mandatory tests. Selected based on:
- Business-critical logic
- Complex state machines
- External integrations
- Data transformations

PRs without tests: UI-only, admin CRUD, scaffolding

### Test Types
| Type | When | Command | Coverage |
|---|---|---|---|
| Unit | Pure functions, business logic | `pnpm test tests/unit/...` | ≥80% |
| Integration | Multi-layer flows | `pnpm test tests/integration/...` | Happy + 2 edges |
| E2E | Full journeys | `pnpm test:e2e` | Critical paths |

### Critical Rules for AI Agents
1. Test is source of truth — DO NOT modify to pass
2. Tests must pass before merge
3. Edge cases are not optional
4. Use provided fixtures
5. No mocking critical business logic

### Test Failures = PR Blocked
If test fails: read error, fix code (not test), re-run.
```

---

## Generation Protocol

### Step 1: Read PRD + Design System
Extract:
- Features from PRD § 6
- Phased plan from PRD § 15
- Components from Design System § 9
- Workflows from PRD § 8

### Step 2: Map Features to Phases
For each feature, identify:
- Schema needs (entities, fields)
- Service needs (tRPC routers, business logic)
- UI needs (components, pages)
- Dependencies (what must exist first)

### Step 3: Generate PR Outline
Show user:
```
I've mapped your features to 34 PRs across 8 phases:

Phase 0: Foundation (7 PRs)
Phase 1: Services Catalog (5 PRs)
Phase 2: Order Management (8 PRs)
Phase 3: AI Chatbot (6 PRs)
...

PRs with mandatory tests: 12 (shown below)
- PR-003: Database foundation (audit log helper)
- PR-013: Workflow engine (state machine)
...

Approve this breakdown?
```

Wait for approval.

### Step 4: Generate Each PR Spec
For each PR, write:
- Branch name
- Goal (1 sentence)
- Subtasks (checklist)
- Files to create
- Files to edit
- Tests (if applicable, with exact test cases)
- Dependencies
- Effort estimate

### Step 5: Identify Test PRs
For each business-critical PR, add test section with:
- Exact test file path
- Exact command to run
- Specific test cases (testable assertions)
- Edge cases

### Step 6: Cross-Check
- Every PRD feature appears in roadmap
- Every Design System component is built
- Dependencies form valid DAG (no circular dependencies)
- Total effort estimate matches PRD § 15 timeline

### Step 7: Save
Save to `/docs/TASKS.md`

---

## Quality Checklist

- [ ] Every PR has explicit dependencies
- [ ] File paths are complete and consistent
- [ ] 10-15 PRs have tests with specific test cases
- [ ] No PR exceeds L effort (if so, split)
- [ ] Subtasks are actionable (not vague)
- [ ] PR template defined
- [ ] Testing philosophy documented

---

*End of Task Roadmap Generator Agent*
