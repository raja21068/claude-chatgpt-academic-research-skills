# Before and After Bullet Examples

## Finance / FP&A

Weak:
- Responsible for financial reports.

Stronger:
- Prepared monthly and quarterly financial reports using SAP S/4HANA and Excel, improving reporting accuracy and reducing manual work by [X%].

## Research / Economics

Weak:
- Worked on datasets for research.

Stronger:
- Cleaned and merged 100,000+ observations across CPS, ACS, and SIPP datasets using R and Stata to support labor market analysis and econometric reporting.

## Data analysis

Weak:
- Helped create dashboards.

Stronger:
- Built Power BI dashboards to track [KPI category], enabling stakeholders to monitor trends and reduce recurring manual reporting by [X hours/month].

## Teaching / mentoring

Weak:
- Assisted students in class.

Stronger:
- Managed two first-year seminar sections and provided individualized coaching to students, improving academic transition support and engagement tracking.
