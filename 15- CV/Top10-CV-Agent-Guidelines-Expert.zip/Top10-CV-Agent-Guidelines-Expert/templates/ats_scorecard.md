# ATS + Recruiter Readiness Scorecard

| Dimension | Score / Weight | Notes | Fix |
|---|---:|---|---|
| Role fit | /20 |  |  |
| ATS keyword coverage | /20 |  |  |
| Evidence density | /20 |  |  |
| Metrics and impact | /15 |  |  |
| Readability and formatting | /15 |  |  |
| Credibility and defensibility | /10 |  |  |
| **Total** | **/100** |  |  |

Final recommendation: Submit / revise first.
