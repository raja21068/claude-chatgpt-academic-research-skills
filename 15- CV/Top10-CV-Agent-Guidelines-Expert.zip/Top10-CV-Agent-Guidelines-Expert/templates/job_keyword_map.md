# Job Keyword Map

| Keyword / Phrase | Category | Importance | JD Evidence | CV Evidence | Strength | Recommended Placement |
|---|---|---:|---|---|---|---|
|  | Required | High |  |  | Strong / Partial / Missing | Summary / Skills / Experience |
