# [Full Name]
[City, Country] | [Phone] | [Email] | [LinkedIn] | [Portfolio/GitHub optional]

## Professional Summary
[2 to 4 lines targeted to the role.]

## Core Competencies
[Keyword group 1] | [Keyword group 2] | [Keyword group 3] | [Tool] | [Tool]

## Professional Experience

### [Job Title] | [Organization] | [Location]
[Month Year] – [Month Year]
- [Action verb + task/problem + tool/method + scale + result.]
- [Action verb + task/problem + tool/method + scale + result.]
- [Action verb + task/problem + tool/method + scale + result.]

## Projects / Research Experience

### [Project Name]
- [Relevant project bullet.]

## Education
[Degree] | [Institution] | [Dates]

## Technical Skills
Technical: [tools]
Analysis: [methods]
Research/Business: [competencies]
