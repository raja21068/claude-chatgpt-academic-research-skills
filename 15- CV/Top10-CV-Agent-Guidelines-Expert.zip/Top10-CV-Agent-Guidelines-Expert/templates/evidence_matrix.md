# Evidence Matrix

| CV Claim | Source / Proof | Confirmed? | Role Relevance | Risk | Final Wording |
|---|---|---|---|---|---|
|  | CV / user note / project | Yes / Needs verification | High / Medium / Low | None / Overclaim / Missing metric |  |
