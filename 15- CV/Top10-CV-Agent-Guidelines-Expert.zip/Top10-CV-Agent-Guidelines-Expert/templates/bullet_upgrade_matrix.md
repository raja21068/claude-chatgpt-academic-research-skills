# Bullet Upgrade Matrix

| Original Bullet | Problem | Job Keyword Target | Upgraded Bullet | Missing Metric / TODO |
|---|---|---|---|---|
|  | vague / no impact / no tool |  |  |  |
