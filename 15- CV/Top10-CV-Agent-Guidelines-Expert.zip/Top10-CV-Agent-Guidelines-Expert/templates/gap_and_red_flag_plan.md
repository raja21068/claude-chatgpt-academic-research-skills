# Gap and Red Flag Plan

| Issue | Why It Matters | Severity | Honest Fix | Interview Explanation |
|---|---|---|---|---|
| Missing required skill | ATS/recruiter concern | High / Medium / Low | Transferable evidence or TODO |  |
