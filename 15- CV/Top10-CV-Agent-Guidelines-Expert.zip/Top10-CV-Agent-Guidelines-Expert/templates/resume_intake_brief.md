# Resume Intake Brief

## Target role
- Job title:
- Company:
- Industry:
- Country/style:
- Seniority:

## User constraints
- Preserve layout? yes/no
- One page or two pages:
- Metrics placeholders allowed? yes/no
- Full rewrite or surgical edit:

## Candidate evidence
- Roles:
- Education:
- Tools:
- Projects:
- Reports/outputs:
- Metrics:
- Missing evidence:

## Final output requested
- [ ] Full CV
- [ ] ATS check
- [ ] Bullet rewrite
- [ ] Recruiter review
- [ ] Cover message
- [ ] LinkedIn summary
