# Final CV Submission Checklist

- [ ] Target job title reflected in summary.
- [ ] Top keywords included naturally.
- [ ] No invented or unsupported claims.
- [ ] Metrics are true or clearly marked as placeholders.
- [ ] Each experience has 3 to 4 strong bullets unless otherwise required.
- [ ] Bullets start with strong action verbs.
- [ ] Skills section is relevant and grouped.
- [ ] Grammar, spelling, punctuation, and tense are consistent.
- [ ] Dates and locations are consistent.
- [ ] Formatting is ATS-safe.
- [ ] CV fits required page limit.
- [ ] File name is professional, e.g., `FirstName_LastName_CV_Role.pdf`.
