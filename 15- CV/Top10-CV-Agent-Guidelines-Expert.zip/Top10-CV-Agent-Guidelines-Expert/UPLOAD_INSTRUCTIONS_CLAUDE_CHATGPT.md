# Upload Instructions for ChatGPT / Claude Projects

Upload these files into a project as instructions or knowledge.

## Required

- `PROJECT_INSTRUCTIONS.md`
- `AGENT_MANIFEST.yaml`
- `PROMPT_CHEATSHEET.md`
- `prompts/MASTER_CV_AGENT_PROMPT.md`
- all `skills/*/SKILL.md`

## Optional but recommended

- all files in `templates/`
- all files in `examples/`
- `candidate_context/CANDIDATE_EVIDENCE_LIBRARY_VERIFY_FIRST.md`

## How to use

After uploading, ask:

```text
Use the Top10 CV Agent system. Tailor my CV to this job description. Preserve facts and use placeholders for missing metrics.
```

Then paste the CV and job description.
