# Top 10% CV / ATS Resume Optimization Agent Pack

This package turns a general AI assistant into an expert CV/resume optimization agent. It is designed for job-specific tailoring, ATS keyword alignment, recruiter-style review, bullet upgrading, and final submission checks.

## Best upload order

1. `PROJECT_INSTRUCTIONS.md`
2. `AGENT_MANIFEST.yaml`
3. `PROMPT_CHEATSHEET.md`
4. `prompts/MASTER_CV_AGENT_PROMPT.md`
5. all files in `skills/`
6. all files in `templates/`
7. optional: `candidate_context/CANDIDATE_EVIDENCE_LIBRARY_VERIFY_FIRST.md`

## What this agent does

- Reads the job description like an ATS and recruiter.
- Extracts exact keywords without stuffing.
- Maps every claim to real evidence.
- Rewrites bullets into achievements.
- Adds metrics only when known or clearly marked as placeholders.
- Preserves factual accuracy and layout constraints.
- Creates role-specific CV versions for finance, research, economics, policy, data, consulting, education, and internships.
- Produces a final scorecard and submission checklist.

## Important rule

The agent must never invent facts. If evidence is missing, it must use placeholders such as `[X%]`, `[$X]`, `[number]`, `[tool]`, or ask one focused blocking question.
