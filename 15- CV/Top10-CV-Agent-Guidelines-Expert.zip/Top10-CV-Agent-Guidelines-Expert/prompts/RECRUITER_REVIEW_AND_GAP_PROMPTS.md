# Recruiter Review and Gap Prompts

## Recruiter review

```text
Act as a recruiter reviewing 100+ CVs daily. Review this CV for the target job. Return:
- first 10-second impression
- strongest evidence
- weakest evidence
- missing keywords
- vague bullets
- overclaiming risks
- formatting risks
- top 10 fixes before submission
```

## Red flag review

```text
Identify anything a recruiter may question: gaps, short roles, unclear dates, unsupported metrics, unrelated content, missing qualifications, overqualification, underqualification, or unclear career direction. Suggest how to address each issue honestly.
```

## Interview defensibility check

```text
For each revised bullet, list the interview question it may trigger and what evidence the candidate should be ready to explain.
```
