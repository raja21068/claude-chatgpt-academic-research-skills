# ATS Keyword and Job Match Prompts

## Extract exact keywords

```text
Act as an ATS parser and recruiter. Extract the top 15 to 25 exact keywords from the job description. Categorize them as:
- required qualifications
- preferred qualifications
- technical tools
- analytical methods
- domain knowledge
- communication/stakeholder skills
- action verbs/responsibilities
Then rank them by likely importance.
```

## Map keywords to CV evidence

```text
Create a keyword-to-evidence map. For each job keyword, show:
- keyword from job description
- where it appears in the CV
- evidence strength: strong / partial / missing
- recommended wording to add naturally
- risk of keyword stuffing
```

## Hidden hiring signals

```text
Read this job description like a hiring manager. Identify hidden signals, such as pace, ownership level, stakeholder exposure, reporting expectations, industry knowledge, tool maturity, and seniority. Then explain how the CV should be positioned.
```
