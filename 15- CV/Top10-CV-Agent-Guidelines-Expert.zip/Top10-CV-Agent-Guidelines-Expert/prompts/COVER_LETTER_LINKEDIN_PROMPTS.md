# Cover Letter, LinkedIn, and Employer Message Prompts

## Short employer message

```text
Write a 200 to 250 word message to the employer explaining why I am a strong fit. Match the job description, use my actual experience, avoid exaggeration, and keep it professional and specific.
```

## LinkedIn About section

```text
Rewrite my LinkedIn About section for this target role. Use a professional first-person voice, mention my strongest evidence, tools, and career direction. Avoid buzzwords and unsupported claims.
```

## Cover letter

```text
Write a concise cover letter for this role using my CV and the job description. Structure it as: opening fit, evidence paragraph, role motivation, closing. Do not repeat the CV word for word.
```
