# Bullet Achievement Upgrade Prompts

## Responsibility to achievement

```text
Rewrite these CV bullets using achievement language. Each bullet must include as many as possible:
- strong action verb
- task/problem
- tool/method
- scale
- result/impact
Do not invent numbers. Use placeholders for missing metrics. Keep each bullet concise and interview-defensible.
```

## RATS bullet method

Use **Result + Action + Tool + Scope** when possible.

Example:

Weak: `Responsible for monthly financial reports.`

Strong: `Prepared monthly and quarterly financial reports using SAP S/4HANA and Excel, improving data accuracy and reducing manual reporting work by [X%].`

## Bullet quality test

For every bullet, ask:

1. Does it prove a skill the job needs?
2. Does it include tool, scale, or method?
3. Does it show impact?
4. Can the candidate defend it in an interview?
5. Is it concise enough for a recruiter scan?
