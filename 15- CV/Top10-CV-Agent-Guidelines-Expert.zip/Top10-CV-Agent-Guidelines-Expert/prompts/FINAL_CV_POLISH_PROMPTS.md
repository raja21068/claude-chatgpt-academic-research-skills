# Final CV Polish Prompts

## Grammar and consistency

```text
Proofread this CV for grammar, spelling, punctuation, tense consistency, parallel structure, capitalization, dates, and formatting consistency. Do not change facts. Return only corrected lines unless a full rewrite is requested.
```

## Final submission check

```text
Run a final submission audit for this CV. Check ATS formatting, keyword coverage, bullet strength, metrics, credibility, grammar, length, and file naming. Give a final readiness score and the exact remaining TODOs.
```

## One-page compression

```text
Compress this CV to one page without weakening role fit. Preserve the strongest evidence and remove repetition, weak bullets, and unrelated content. Keep the style professional and ATS-safe.
```
