# Role-Specific Tailoring Prompts

## Financial analyst / FP&A
Prioritize: financial reporting, budgeting, forecasting, variance analysis, financial modeling, Excel, Power BI, SAP/ERP, stakeholder collaboration, cost analysis, dashboards, month-end/quarter-end reporting, planning accuracy.

## Research assistant / economics / policy
Prioritize: literature review, data cleaning, econometric analysis, large datasets, R, Stata, Python, survey design, policy memos, technical reports, reproducibility, statistical methods, evidence synthesis.

## Data analyst
Prioritize: SQL, Python/R, dashboards, data cleaning, automation, ETL, visualization, KPI reporting, stakeholder insights, data quality, business impact.

## Consulting / strategy
Prioritize: problem structuring, market research, financial analysis, presentation, stakeholder communication, recommendations, data-backed insights, business cases.

## Education / edtech / tutoring
Prioritize: curriculum design, student outcomes, LMS, AI tools, content creation, teaching, assessment, community scale, accessibility, learning impact.

## Internship / entry-level
Prioritize: transferable projects, tools, coursework, leadership, research, reports, internships, communication, learning speed, relevant academic work.
