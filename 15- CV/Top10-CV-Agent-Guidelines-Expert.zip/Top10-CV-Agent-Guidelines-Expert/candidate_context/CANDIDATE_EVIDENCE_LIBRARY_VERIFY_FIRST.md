# Candidate Evidence Library: Verify Before Use

This file contains candidate-specific evidence that may be useful for CV tailoring. Treat everything here as **candidate context requiring confirmation before final submission**. Do not include any item in a final CV unless it matches the user's current CV or the user confirms it.

## Possible target profiles

- Financial Analyst / FP&A / finance internship.
- Research Assistant / economics / policy analyst.
- Data analyst / business analyst.
- Education / edtech / AI-LMS / tutoring venture roles.

## Education and research context

- Georgia State University experience has been referenced for Graduate Research Assistant and Graduate Teaching Assistant work.
- Research work has included cleaning and merging large national microdata such as CPS, ACS, SIPP, PSID, and OEWS.
- Tools referenced: R, Stata, Python, SPSS, Excel, SQL, Power BI, Tableau.
- Possible research outputs referenced: technical reports, research memos, econometric specifications, robustness checks, analytic variables.

## Finance / industry context

- DVAGO financial analyst experience has been referenced.
- SAP S/4HANA, Excel, monthly/quarterly reporting, financial models, cost build-ups, forecasting, annual budgets, quarterly refreshes, variance analysis, and FP&A collaboration have been referenced.
- Possible metrics referenced in prior context include reduced manual effort, improved data integrity, planning accuracy, reporting sources, and budget size. Verify before use.

## Teaching / education context

- GSU 1010 First-Year Seminar teaching/mentoring experience has been referenced.
- Federal Ka Manjan / FKM education venture has been referenced with YouTube, notes, online classes, AI-powered LMS, student support, and board-specific learning resources.

## Writing preferences remembered

- Preserve layout when requested.
- Avoid invented or exaggerated claims.
- Use ATS keywords naturally, not stuffed.
- Prefer 3 to 4 bullets per experience.
- Bullets should be concise, action-oriented, and quantified where true.
- Use placeholders such as `[X%]` or `[$X]` for missing metrics.
- When showing edits, user often likes bold additions and strikethrough deletions.

## Warning

This is not a final CV. It is a memory-based evidence pool. Always cross-check against the actual CV and job description.
