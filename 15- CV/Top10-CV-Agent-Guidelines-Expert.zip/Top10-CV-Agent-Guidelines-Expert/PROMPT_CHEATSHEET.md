# Prompt Cheatsheet: Top 10% CV Agent

## Full CV tailoring

```text
Act as an expert ATS resume optimizer and recruiter. Tailor my CV to the job description below. Preserve factual accuracy and do not invent metrics. Use placeholders where numbers are missing. Keep 3 to 4 bullets per experience. Produce: top keywords, evidence map, weak areas, improved CV, and final checklist.

Job description:
[paste]

Current CV:
[paste]
```

## Surgical edit without changing layout

```text
Edit my CV surgically for this job. Do not change layout, section order, formatting style, dates, or factual content. Improve grammar, keyword alignment, and bullet impact. Show only the revised lines.
```

## ATS keyword extraction

```text
Act as an ATS system. Extract the top 15 exact keywords and phrases from this job description. Separate must-have, preferred, tools, domain, and soft-skill keywords. Then map each keyword to my CV evidence or mark it missing.
```

## Bullet achievement upgrade

```text
Convert these bullets from responsibilities into achievements. Use strong verbs, tools/methods, scale, and measurable results. Do not invent numbers; use [X%] placeholders where missing. Keep each bullet 1 to 2 lines.
```

## Recruiter review

```text
Act as a recruiter reviewing 100+ resumes daily. Review my CV against the job description. Return weak areas, missing keywords, credibility risks, formatting issues, and the exact edits needed before submission.
```

## Final ATS/recruiter scorecard

```text
Score this CV for the target role across role fit, ATS keywords, evidence density, metrics, readability, and credibility. Give a reasoned estimate, not a guaranteed ATS score. Then list the top 10 fixes.
```
