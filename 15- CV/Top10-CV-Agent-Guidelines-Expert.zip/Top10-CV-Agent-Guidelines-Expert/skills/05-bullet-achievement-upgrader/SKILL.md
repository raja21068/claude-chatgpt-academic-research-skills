# Skill: Bullet Achievement Upgrader

## Purpose
Turn responsibility-based CV bullets into achievement-based bullets.

## Formula
`Action Verb + Task/Problem + Tool/Method + Scale + Result/Impact`

## Add where true
- dataset size,
- number of reports,
- budget size,
- number of stakeholders,
- number of students,
- time saved,
- error reduction,
- efficiency improvement,
- decision supported.

## Rules
- Keep bullets concise.
- Use metrics only when true or marked as placeholders.
- Avoid excessive adjectives.
- Make each bullet relevant to the target role.
