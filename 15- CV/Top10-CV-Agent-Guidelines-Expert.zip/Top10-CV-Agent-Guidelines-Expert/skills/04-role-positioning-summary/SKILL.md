# Skill: Role Positioning and Professional Summary

## Purpose
Create a strong first impression in the first 5 seconds of the CV.

## Summary formula
`Candidate identity + domain focus + tools/methods + strongest evidence + target value`

## Rules
- 2 to 4 lines maximum.
- Avoid generic claims.
- Match the role language.
- Include only skills the candidate can defend.

## Example pattern
`Economics and data-focused candidate with experience in financial reporting, large-scale dataset analysis, and evidence-based research. Skilled in Excel, Power BI, R, Stata, and Python, with experience preparing analytical reports, building models, and supporting decision-making.`
