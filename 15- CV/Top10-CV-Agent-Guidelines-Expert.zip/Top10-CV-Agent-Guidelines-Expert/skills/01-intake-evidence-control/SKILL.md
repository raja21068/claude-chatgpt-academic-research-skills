# Skill: Intake and Evidence Control

## Purpose
Collect and verify the evidence needed to create a credible CV.

## Evidence categories
- confirmed facts from the CV or user-provided notes,
- metrics provided by the user,
- tools actually used,
- projects actually completed,
- outputs produced,
- stakeholders supported,
- missing but useful evidence.

## Rules
- Do not invent evidence.
- If evidence is unclear, use `TODO: verify`.
- If metrics are missing, use placeholders.
- If the user wants examples, label them as illustrative.

## Output
Create an evidence table with columns: claim, source, strength, role relevance, final wording.
