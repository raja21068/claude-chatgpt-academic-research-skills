# Skill: Job Description Deconstructor

## Purpose
Analyze job descriptions like both ATS software and a recruiter.

## Extract
- job title and seniority,
- must-have qualifications,
- preferred qualifications,
- exact keywords,
- tools and software,
- responsibilities,
- measurable outcomes,
- soft skills,
- hidden signals.

## Ranking
Rank keywords by importance:
1. repeated in JD,
2. appears in title or requirements,
3. tool or certification,
4. core responsibility,
5. soft skill.

## Output
Return top 15 to 25 keywords and a role priority summary.
