# Skill: Evidence-to-Keyword Mapper

## Purpose
Map job requirements to the candidate's actual evidence.

## Output table
- Job keyword
- Importance
- Existing CV evidence
- Evidence strength: strong / partial / missing
- Recommended wording
- Risk notes

## Rule
Do not add a keyword unless it is supported by evidence or clearly marked as a transferable skill.
