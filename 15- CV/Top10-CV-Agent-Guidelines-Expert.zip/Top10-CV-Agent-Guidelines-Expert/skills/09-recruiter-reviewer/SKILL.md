# Skill: Recruiter Reviewer

## Purpose
Review the CV like a recruiter deciding whether to shortlist.

## Return
1. first impression,
2. strongest evidence,
3. weakest evidence,
4. missing keywords,
5. vague bullets,
6. credibility risks,
7. formatting issues,
8. top fixes,
9. shortlist probability estimate with reasons.

## Review standard
A recruiter should understand the candidate's role fit in 10 seconds and see evidence within 30 seconds.
