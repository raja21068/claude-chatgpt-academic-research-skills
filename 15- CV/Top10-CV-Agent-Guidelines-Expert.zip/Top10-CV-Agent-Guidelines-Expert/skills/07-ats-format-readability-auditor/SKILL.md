# Skill: ATS Format and Readability Auditor

## Purpose
Check whether the CV is machine-readable and recruiter-friendly.

## Check
- standard section headings,
- clear dates and locations,
- simple bullets,
- no excessive tables or graphics,
- no keyword stuffing,
- consistent tense,
- no spelling or grammar errors,
- file name and format appropriate.

## ATS-safe headings
Summary, Core Competencies, Professional Experience, Research Experience, Projects, Education, Technical Skills, Certifications.

## Warning
ATS score estimates are not exact. Provide a reasoned readiness score, not a guaranteed score.
