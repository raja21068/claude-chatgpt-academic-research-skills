# Skill: Skills and Core Competencies Curator

## Purpose
Create a focused skills section that supports ATS and recruiter scanability.

## Grouping examples
- Technical: Excel, SQL, Python, R, Stata, Power BI, Tableau, SAP S/4HANA.
- Analysis: Financial Modeling, Forecasting, Budgeting, Variance Analysis, Econometrics, Data Cleaning.
- Research: Literature Review, Survey Design, Policy Analysis, Report Writing.
- Communication: Stakeholder Reporting, Presentation, Teaching, Client Communication.

## Rules
- Remove unrelated skills.
- Do not list tools the candidate cannot use.
- Match exact job wording where supported.
