# Skill: CV Orchestrator

## Purpose
Coordinate the full CV optimization workflow from intake to final submission.

## Procedure
1. Identify the requested output: full CV, section rewrite, ATS check, bullet rewrite, or recruiter review.
2. Build a CV Optimization Contract.
3. Route work through the right sub-skills.
4. Keep facts separate from assumptions.
5. Produce final output in the user's requested format.

## Quality gate
Before final response, confirm:
- target role is clear,
- job keywords are addressed,
- claims are supported,
- placeholders are marked,
- layout constraints are respected,
- final CV is concise and readable.
