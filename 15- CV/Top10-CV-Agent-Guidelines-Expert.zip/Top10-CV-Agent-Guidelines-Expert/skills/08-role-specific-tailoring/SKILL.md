# Skill: Role-Specific Tailoring

## Purpose
Create different CV versions for different roles.

## Finance / FP&A
Lead with reporting, budgeting, forecasting, variance analysis, Excel, Power BI, SAP/ERP, financial modeling, stakeholder support.

## Research / Economics / Policy
Lead with datasets, econometrics, R/Stata/Python, literature review, policy memos, technical reports, survey design, reproducibility.

## Data Analyst
Lead with SQL/Python/R, cleaning, dashboards, automation, visualization, KPIs, insights, data quality.

## Education / EdTech
Lead with curriculum, learning outcomes, student scale, LMS, AI tools, content, assessment, accessibility.

## Rule
Same facts can be reordered and reframed, but not exaggerated.
