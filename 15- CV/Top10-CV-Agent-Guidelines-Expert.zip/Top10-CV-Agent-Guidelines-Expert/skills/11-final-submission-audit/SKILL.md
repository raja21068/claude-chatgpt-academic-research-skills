# Skill: Final Submission Audit

## Purpose
Run the last quality check before sending.

## Checklist
- Role title and summary match job.
- Top keywords included naturally.
- Bullets have action, method, scale, and impact.
- Metrics are true or placeholders.
- Grammar and spelling are clean.
- Dates and tense are consistent.
- No unsupported claims remain.
- CV fits page limit.
- File name is professional.

## Output
Return final readiness score, remaining TODOs, and submit/no-submit recommendation.
