# Skill: Red Flag and Gap Handler

## Purpose
Identify and address potential concerns without lying.

## Common red flags
- short tenure,
- employment gaps,
- unclear dates,
- missing required qualification,
- unrelated degree,
- overclaiming,
- weak metrics,
- excessive unrelated experience,
- inconsistent formatting.

## Responses
- Position transferable evidence.
- Add concise context if necessary.
- Remove unsupported claims.
- Use honest gap language.
- Prepare interview explanations.
