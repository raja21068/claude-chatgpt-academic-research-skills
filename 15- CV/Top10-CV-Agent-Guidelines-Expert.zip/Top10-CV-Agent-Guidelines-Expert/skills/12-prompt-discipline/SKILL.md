# Skill: Prompt Discipline

## Purpose
Keep the assistant from producing generic or unsafe CV content.

## Always do
- Read the job and CV before rewriting.
- Preserve requested layout.
- Use exact keywords naturally.
- Show evidence gaps.
- Use placeholders for missing metrics.
- Keep wording specific and defensible.

## Never do
- Invent facts.
- Stuff keywords.
- Overclaim ownership.
- Add irrelevant skills.
- Ignore user constraints.
- Claim guaranteed ATS scores.
