# career-ultimate

The definitive AI career agent — merging the best of three open-source projects into one unified plugin.

| Source | What We Took | Why |
|---|---|---|
| **One-Shot Elite CV v5** | 12-stage document pipeline, anti-fabrication system, computed match scoring, evidence matrices, style linting, LaTeX templates | Deepest document quality |
| **career-ops** | Job evaluation (A-F blocks), 15 industry archetypes, application tracker, company scanner, opportunity comparisons, outreach drafts, company research | Broadest job-search operations |
| **Proficiently** | Browser-based ATS form filling (Greenhouse/Lever/Workday), LinkedIn network scanning, Telegram bot, onboarding interview | Most automation |
| **Real ATS Parser (v6)** | Structural resume parser mirroring Workday/Greenhouse/Taleo/iCIMS/Lever, PDF/DOCX extraction, per-platform simulation with BLOCKER/WARNING/INFO | Real ATS behavior |
| **Skills Database (v6)** | ~400 curated skills from O*NET 28.0 + ESCO v1.1.1 with synonyms, misspelling correction, per-role weights, compliance vocabulary | Smart keyword matching |
| **Template Library (v6)** | 20+ role-specific ATS-safe templates (resumes, CVs, cover letters, emails, LinkedIn) auto-selected by role family | Professional starting points |

## Quick Start

1. Install the plugin
2. Say **"set up my profile"** and paste your resume
3. Paste a job posting and say **"evaluate this"**
4. Say **"tailor my resume"** for elite-quality, ATS-optimized documents
5. Say **"apply"** to auto-fill application forms in your browser
6. Say **"help"** anytime

## Skills

| Skill | Command | What It Does |
|-------|---------|--------------|
| **Setup** | `setup` | One-time onboarding: resume, preferences, work-history interview, LinkedIn contacts import |
| **Evaluate** | `evaluate` | Score a job A-F with 15 industry archetypes, honest 1-5 scoring, STAR interview prep |
| **Tailor Resume** | `tailor-resume` | Elite 12-stage pipeline: evidence extraction → keyword mapping → computed match score → ATS-optimized resume with anti-fabrication audit |
| **Cover Letter** | `cover-letter` | Evidence-based cover letter matched to evaluation + tailored resume |
| **Scan** | `scan` | Search company career portals (Greenhouse, Lever, Ashby, Workday, SmartRecruiters) |
| **Track** | `track` | Application tracker with stats dashboard and status transitions |
| **Compare** | `compare` | Side-by-side opportunity comparison with pros/cons and recommendation |
| **Research** | `research` | Company intelligence brief: culture, news, team, contacts, Glassdoor |
| **Outreach** | `outreach` | Personalized LinkedIn/email messages with hook + proof + proposal structure |
| **Apply** | `apply` | Browser-based ATS form filling on Greenhouse, Lever, and Workday |
| **Network Scan** | `network-scan` | Scan LinkedIn contacts' companies for matching openings |
| **Telegram** | `jobsearch-telegram` | Manage your job search from Telegram — apply, search, check status by chat |

## How It Works: The Elite Document Pipeline

When you say "tailor my resume", the plugin runs a 12-stage chained pipeline where each stage reads shared state, does one job, and passes verified output to the next:

```
Stage 1   auto_profile_detector       → detect role family, domain, seniority
Stage 2   jd_deconstructor            → extract tiered keywords + domain jargon
Stage 3   cv_evidence_extractor       → inventory every provable claim
Stage 4   keyword_evidence_mapper     → map each keyword to evidence + strength
Stage 5   match_scorer (computed)     → weighted score from evidence table
Stage 6   positioning_strategist      → gaps, role thesis, framing strategy
Stage 7   resume_writer               → ATS-optimized resume
Stage 8   ats_parse_simulator         → deterministic ATS parse check
Stage 9   cover_letter_writer         → evidence-backed cover letter
Stage 10  supporting_assets           → email, LinkedIn, interview prep
Stage 11  self_auditor                → fabrication + quality audit
Stage 12  final_review_board          → multi-reviewer scorecard
```

### Honest Scoring (Not LLM Guesses)

```
weighted_score = 100 × (0.60 × tier1_coverage + 0.30 × tier2_coverage + 0.10 × tier3_coverage)

where: strong = 1.0, partial = 0.5, weak = 0.25, missing = 0.0
```

### The Cardinal Rule

**Never write a beautiful document that is less true than the evidence.** Every claim maps to a source. Unsupported claims get `[TODO: verify]` markers, never fabrication.

## Industry Support (15 Archetypes)

Each archetype adjusts evaluation weights and resume advice:

Technology, Finance, Healthcare, Legal, Creative/Marketing, Operations,
Sales/BD, Education, Executive, Trades, Customer Success, People/HR,
Government/Nonprofit, Scientific/R&D, Non-Software Engineering

Healthcare, Legal, Trades, and Non-Software Engineering use **PASS/FAIL** credential checks — missing a required license caps your score at 2.0.

## Browser Automation

The `apply` skill fills out application forms on:
- **Greenhouse** — form_input for fields, checkbox for privacy
- **Lever** — form_input with combobox handling
- **Workday** — click-based dropdowns, hierarchical filters, radio buttons

Requires [Claude in Chrome](https://chromewebstore.google.com/detail/claude-in-chrome) extension.

## File Structure

```
career-ultimate/
├── .claude-plugin/plugin.json
├── references/                    # 18 reference docs
│   ├── 00-operating-principles.md
│   ├── 01-evidence-and-anti-fabrication.md
│   ├── ...
│   └── 18-priority-hierarchy.md
├── scripts/
│   ├── ats_parser/                # ← NEW: Real structural ATS parser
│   │   ├── __init__.py
│   │   ├── cli.py                 # CLI entry point
│   │   ├── extractor.py           # PDF/DOCX text extraction (pdfminer, python-docx)
│   │   ├── parser.py              # Section detection, contact extraction, skill tokenization
│   │   └── simulator.py           # Per-platform simulation (Workday, Greenhouse, Taleo, iCIMS, Lever)
│   ├── compute_match_score.py
│   ├── elite_style_linter.py
│   ├── check_claim_markers.py
│   ├── validate_application_package.py
│   └── seed_skills_db.py          # ← NEW: Import skills from O*NET/ESCO
├── skills_db/                     # ← NEW: Curated skills taxonomy
│   ├── README.md                  # Schema docs and provenance
│   ├── skills_core.json           # ~400 skills with synonyms, per-role weights
│   ├── role_profiles.json         # 8 role families → expected skill clusters
│   ├── compliance_skills.json     # IRB, HIPAA, GCP, FDA, GDPR with expansion rules
│   ├── synonyms.json              # Misspelling/tokenization correction map
│   └── personal_additions.json    # Your custom skills (grows over time)
├── skills/                        # 13 skill modules
│   ├── setup/SKILL.md
│   ├── evaluate/SKILL.md
│   ├── tailor-resume/SKILL.md
│   ├── ...
│   └── jobsearch-telegram/SKILL.md
└── templates/                     # ← NEW: Role-specific template library
    ├── TEMPLATE_LIBRARY.md        # Index and selection logic
    ├── resumes/                   # 9 industry resume templates
    │   ├── research_scientist_resume.md
    │   ├── research_engineer_resume.md
    │   ├── ml_engineer_resume.md
    │   ├── clinical_ai_resume.md
    │   ├── phd_student_industry_resume.md
    │   ├── data_scientist_resume.md
    │   ├── software_engineer_resume.md
    │   ├── product_manager_resume.md
    │   └── finance_analyst_resume.md
    ├── cvs/                       # 3 academic CV templates
    │   ├── academic_cv_full.md
    │   ├── postdoc_application_cv.md
    │   └── phd_application_cv.md
    ├── cover_letters/             # 3 cover letter templates
    │   ├── cover_letter_industry_research.md
    │   ├── cover_letter_academic.md
    │   └── cover_letter_phd_application.md
    ├── emails/                    # 3 email templates
    │   ├── email_referral_request.md
    │   ├── email_cold_outreach_researcher.md
    │   └── email_followup.md
    ├── linkedin/                  # 2 LinkedIn templates
    │   ├── linkedin_headline_research_track.md
    │   └── linkedin_about_section.md
    ├── session_context.yaml
    ├── evidence_matrix.md
    ├── keyword_evidence_table.md
    ├── elite_readiness_scorecard.md
    └── profile.md
```

## Privacy

Your data stays local in `~/.career-ultimate/`. Nothing is sent to external services beyond Claude's own web searches and browser automation for ATS form-filling.

## Credits

Built by combining:
- [One-Shot Elite CV Agent v5](https://github.com/) — evidence-based document pipeline
- [career-ops](https://github.com/andrewshwetzer/career-ops-plugin) by Andrew Shwetzer — job search operations
- [Proficiently](https://github.com/proficientlyjobs/proficiently-claude-skills) by Proficiently — browser automation

## License

MIT
