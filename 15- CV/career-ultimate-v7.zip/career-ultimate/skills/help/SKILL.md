---
name: help
description: "Show all available commands and what they do. Use when someone says 'help', 'what can you do', or 'commands'."
argument-hint: ""
user-invocable: true
allowed-tools:
  - Read
---

# Help

Show the user what's available.

## Output

```
## career-ultimate — Your AI Career Agent

### Getting Started
| Command | What It Does |
|---------|-------------|
| **setup** | One-time profile setup: resume, preferences, work history interview |
| **audit** | Audit your base resume before applying (ATS + evidence + style check) |

### Evaluate & Research
| Command | What It Does |
|---------|-------------|
| **evaluate** | Score a job posting (A-F analysis, 1-5 score, 15 industry archetypes) |
| **research {company}** | Company intelligence brief (culture, news, team, contacts) |
| **compare** | Side-by-side comparison of your top opportunities |

### Generate Documents
| Command | What It Does |
|---------|-------------|
| **tailor-resume** | Full 12-stage elite pipeline → ATS-optimized resume + evidence audit |
| **cover-letter** | Evidence-based cover letter matched to the evaluation |

### Find & Apply
| Command | What It Does |
|---------|-------------|
| **scan {company}** | Search career portals for matching openings |
| **discover** | Find jobs across the web you haven't thought of |
| **network-scan** | Scan your LinkedIn contacts' companies for jobs |
| **pipeline** | Auto-process: fetch → evaluate → filter → tailor → ready queue |
| **pipeline add {URL}** | Queue a job URL for processing |
| **pipeline status** | See pipeline counts by status |
| **apply** | Auto-fill application forms (Greenhouse, Lever, Workday) |

### Track & Network
| Command | What It Does |
|---------|-------------|
| **track** | View/update your application tracker + stats + pattern detection |
| **digest** | Weekly summary: metrics, funnel, action items |
| **outreach** | Draft personalized LinkedIn/email messages |

### Automation
| Command | What It Does |
|---------|-------------|
| **jobsearch-telegram** | Manage your search via Telegram bot |

### Typical Workflow (manual)
1. **setup** → paste your resume, configure preferences
2. **audit** → check your base resume for ATS issues and weak bullets
3. **scan Stripe** → find matching openings
4. **evaluate** → paste a job posting, get honest A-F analysis
5. **tailor-resume for Stripe** → 12-stage pipeline produces full package
6. **apply** → auto-fill the application form
7. **track** → monitor your pipeline + see rejection patterns
8. **digest** → weekly summary of your search

### Automated Workflow (pipeline)
1. **setup** → one-time profile setup
2. **audit** → fix base resume issues first
3. **discover** → find jobs across the web matching your profile
4. **pipeline run** → auto-evaluates all, filters by score, tailors resumes for winners
5. **apply** → you review and confirm each submission
6. **digest** → weekly check-in on progress
```
