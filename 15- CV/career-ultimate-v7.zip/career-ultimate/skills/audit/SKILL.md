---
name: audit
description: "Audit your base resume before applying anywhere. Runs ATS parser, style linter, evidence checker, and skills gap analysis against your target roles. Catches problems once instead of inheriting them into every tailored version. Use when someone says 'audit my resume', 'check my resume', 'is my resume good', or at the start of a job search."
argument-hint: ""
user-invocable: true
allowed-tools:
  - Read
  - Write
  - Bash
  - Glob
---

# Resume Audit

Find problems in your base resume BEFORE you start tailoring it for jobs.
Catches issues once instead of repeating them across 20 tailored versions.

## Step 0: Load Resume

Read `DATA_DIR/resume.md` or find a PDF/DOCX in `DATA_DIR/resume/`.
Read `DATA_DIR/profile.yml` for target roles and skills.
Read `skills_db/role_profiles.json` for expected skill clusters.

If no resume exists:
> "I need your resume to audit. Paste it or say 'setup'."

## Step 1: ATS Parse Check

Run the real ATS parser (`scripts/ats_parser/`):

1. Extract text (simulating what an ATS sees)
2. Section detection — are standard headings used?
3. Contact info extraction — email, phone, LinkedIn, GitHub found?
4. Date format check — ambiguous dates flagged
5. Per-platform simulation (Workday, Greenhouse, Taleo, iCIMS, Lever)

Report: blockers, warnings, and info-level issues.

## Step 2: Evidence Inventory

Scan every bullet in Experience/Projects/Research sections:

For each bullet, check:
- Has an action verb? (led, built, designed, not "responsible for")
- Has a scope/object? (what was acted on)
- Has a method/tool? (using what)
- Has an outcome? (measurable result or impact)
- Has a metric? (number, percentage, dollar amount)

Count:
- Bullets with all 4 parts (strong)
- Bullets missing outcome (medium)
- Bullets missing method AND outcome (weak)
- Bullets that are just responsibilities, not achievements (rewrite needed)

## Step 3: Skills Gap Analysis

Match resume skills against the expected skill clusters for each target role
in `skills_db/role_profiles.json`:

For each target role:
- Tier 1 skills present vs missing
- Tier 1 skills listed-only (in Skills section) vs demonstrated (in a bullet)
- Tier 2 skills coverage
- Compliance skills (if medical/clinical role)

Use `skills_db/synonyms.json` to catch misspellings and tokenization issues.

## Step 4: Style & AI Fingerprint Check

Check against `references/11-ai-fingerprint-polish.md`:

- Overused AI phrases ("leverage", "passionate", "innovative", "spearheaded")
- Vague claims without evidence ("significant impact", "various projects")
- Buzzword density (flag if > 3 per section)
- Em dash overuse
- Inconsistent formatting (mixed bullet styles, date formats)
- Generic summary (could apply to anyone)

## Step 5: Structural Check

- Page count appropriate for seniority? (1 page early-career, 2 max for mid-senior)
- Summary/objective present and role-specific?
- Experience listed reverse-chronological?
- Education section present?
- Skills section present with categorization?
- Gaps > 6 months between roles? (flag, don't judge)

## Step 6: Output Report

```
## Resume Audit Report — {date}

### ATS Readiness
| Platform | Status | Issues |
|---|---|---|
| Universal | {Pass/Fail} | {count} blockers, {count} warnings |
| Workday | {Pass/Warn} | {detail} |
| Greenhouse | {Pass/Warn} | {detail} |
| Taleo | {Pass/Warn} | {detail} |
| iCIMS | {Pass/Warn} | {detail} |

### Evidence Quality
- **Strong bullets** (action+scope+method+outcome): {n}/{total} ({pct}%)
- **Medium bullets** (missing outcome): {n}
- **Weak bullets** (need rewrite): {n}
- **Bullets with metrics**: {n}/{total}

### Skills Coverage for Target Roles
| Target Role | Tier 1 Coverage | Tier 1 Demonstrated | Tier 2 Coverage |
|---|---|---|---|
| {role} | {x}/{y} ({pct}%) | {x}/{y} | {x}/{y} |

**Missing Tier 1 skills:** {list}
**Listed but not demonstrated:** {list — these need bullets proving use}

### Style Issues
- {issue 1}
- {issue 2}
- ...

### Top 5 Fixes (do these before applying anywhere)
1. {highest impact fix}
2. {second}
3. {third}
4. {fourth}
5. {fifth}
```

Save to `DATA_DIR/audit-{date}.md`.

> "Fix these 5 issues in your base resume, then every tailored version
> will be stronger. Want me to help rewrite the weak bullets?"
