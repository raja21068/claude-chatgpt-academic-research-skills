---
name: digest
description: "Weekly summary of your job search. Shows what happened, what's pending, and what needs attention. Use when someone says 'weekly digest', 'how's my search going', 'weekly summary', 'what happened this week', or 'digest'."
argument-hint: "'week' (default), 'month', or 'all'"
user-invocable: true
allowed-tools:
  - Read
  - Glob
---

# Weekly Digest

One-screen summary. No fluff.

## Step 0: Determine Time Window

- `week` (default): last 7 days
- `month`: last 30 days
- `all`: everything

## Step 1: Gather Data

Read these files and filter by time window:

- `DATA_DIR/applications.md` — tracker table
- `DATA_DIR/pipeline.md` — pipeline status
- `DATA_DIR/evaluations/` — count files by date
- `DATA_DIR/scan-history.md` — scans performed

## Step 2: Compute Metrics

```
## Job Search Digest — {start_date} to {end_date}

### This Week
| Metric | Count |
|---|---|
| Jobs discovered | {new entries in pipeline + scan-history} |
| Jobs evaluated | {new evaluations written} |
| Resumes tailored | {new entries in applications/} |
| Applications sent | {status changed to Applied} |
| Responses received | {status changed to Interview/Rejected/Offer} |
| Interviews scheduled | {status = Interview} |

### Response Funnel
Discovered ({n}) → Evaluated ({n}) → Applied ({n}) → Response ({n}) → Interview ({n})
Conversion: {applied/evaluated}% apply rate, {response/applied}% response rate

### Needs Attention
```

## Step 3: Action Items

Check for and list:

1. **Stale applications** — applied > 7 days ago, no status change
   → "{Company} — {days} days, no response. Follow up?"

2. **Pipeline backlog** — "New" entries in pipeline.md not yet processed
   → "{n} jobs queued. Say 'pipeline run' to process."

3. **High-scoring unapplied** — evaluations ≥ 4.0 with no tailored resume
   → "{Company} scored {score} but no resume yet. Say 'tailor for {company}'."

4. **Upcoming follow-ups** — applied 5-7 days ago (the follow-up window)
   → "{Company} — day 6. Good time to follow up."

5. **No activity** — if zero actions this week
   → "Quiet week. Say 'discover' to find new opportunities or 'scan' a company."

## Step 4: Output

Keep it to one screen. No details on individual evaluations — the user
can drill into any item by asking. The digest is a dashboard, not a report.

```
### Suggested Next Steps
1. {highest priority action}
2. {second}
3. {third}
```
