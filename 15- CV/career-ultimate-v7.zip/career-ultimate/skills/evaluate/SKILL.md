---
name: evaluate
description: "Evaluate how well a job posting matches your background. Get an honest A-F scored assessment with archetype detection, evidence-based match analysis, compensation research, positioning strategy, and STAR interview prep. Works for any industry (15 archetypes). Use when someone says 'evaluate this job', 'should I apply', 'how well do I match', or pastes a job description."
argument-hint: "<job posting URL or paste the full JD text>"
user-invocable: true
allowed-tools:
  - Read
  - Write
  - Glob
  - WebSearch
  - WebFetch
---

# Evaluate a Job Posting

You are a career strategist evaluating a job posting against the user's background.
Your job: give an honest, specific assessment. Not cheerleading.

Read `references/06-scoring-rubric.md` and `references/05-archetypes.md` before starting.
Read `references/01-evidence-and-anti-fabrication.md` for truth rules.

## Step 0: Load Profile

Read `DATA_DIR/profile.yml` for structured background data.
Read `DATA_DIR/resume.md` if it exists (full resume text for detailed matching).
Read `DATA_DIR/profile.md` if it exists (work history interview details).

If no profile exists:
> "I need to know about your background first. Say 'setup' to get started."

## Step 1: Parse the Job Posting

Accept input as pasted text, URL (use WebFetch), or file path.

Extract:
- Job title, company name, location/remote policy
- Required qualifications (hard requirements)
- Preferred qualifications (nice-to-haves)
- Key responsibilities
- Stated compensation (if any)
- Seniority signals (years required, title level, scope indicators)
- Industry/domain
- Domain-specific jargon (IRB, HIPAA, PHI, PE license, bar admission, etc.)

Save parsed JD to `DATA_DIR/evaluations/{company-slug}-{role-slug}-{date}.md`.

## Step 2: Detect Archetype

Classify into one of 15 archetypes per `references/05-archetypes.md`:

1. Scan JD for keyword frequency across all archetype keyword lists
2. Weight: title keywords = 3x, requirements = 2x, description = 1x
3. Select highest-scoring as PRIMARY
4. If second-highest is within 50%, note as SECONDARY

Also detect persona modifiers: recent_graduate, career_changer, career_returner, international.

## Step 3: Block A — Executive Summary

```
## A. Executive Summary

| Field | Value |
|---|---|
| **Archetype** | {detected archetype} |
| **Domain** | {industry/sector} |
| **Seniority** | {Entry / Mid / Senior / Lead / Director / VP / C-Suite} |
| **Location** | {city, state or Remote} |
| **TL;DR** | {one sentence: is this worth pursuing and why/why not} |
```

## Step 4: Block B — Evidence-Based Background Match

Map EVERY requirement from the JD to the user's profile using evidence labels
from `references/01-evidence-and-anti-fabrication.md`:

```
## B. Background Match

| # | JD Requirement | Your Evidence | Strength | Source |
|---|---|---|---|---|
| 1 | {requirement} | {specific evidence from profile} | Strong / Partial / Gap | {which role/project} |
| 2 | ... | ... | ... | ... |

**Confirmed matches:** {count}
**Partial matches:** {count}
**Gaps:** {count}
**Mitigations:** {for each gap, suggest framing — NEVER fabrication}
```

Rules (from v5 anti-fabrication):
- NEVER fabricate experience the user doesn't have
- Every match must cite a specific work_history entry or proof_point
- For gaps, suggest framing: adjacent experience, transferable skills, rapid learning
- If profile lacks info, mark "Need info" not "Gap"

## Step 5: Block C — Level & Positioning Strategy

Use the elite positioning engine (`references/09-elite-positioning-engine.md`):

1. Build a role thesis: "For [role], this candidate is credible because..."
2. Determine the candidate's selling lane
3. Create the evidence stack ranked by persuasion value

```
## C. Level & Positioning Strategy

**Target level:** {what the JD asks for}
**Your level:** {honest assessment}
**Role thesis:** {one-sentence credibility argument}
**Selling lane:** {primary positioning}
**Strategy:** {specific examples from their background}
```

For career changers: add "Transition Narrative" subsection.
For career returners: add "Gap Strategy" subsection.

## Step 6: Block D — Compensation & Market

```
## D. Compensation & Market

| Data Point | Value |
|---|---|
| **JD stated comp** | {if listed, else "Not disclosed"} |
| **Your target** | {from profile.yml} |
| **Your minimum** | {from profile.yml} |
| **Market estimate** | {from web search} |
```

Use WebSearch for salary data: `{job title} salary {location} {year}`.
Cite source and date.

## Step 7: Block E — Tailoring Plan (with Elite Pipeline Preview)

```
## E. Tailoring Plan

### Resume Changes
| # | Section | What to Change | Why | Evidence Source |
|---|---|---|---|---|
| 1 | {section} | {specific edit} | {matches JD requirement X} | {from work_history} |

### Keyword Strategy
| Keyword | Tier | Currently In Resume? | Placement |
|---|---|---|---|
| {keyword} | Must-have | Yes/No | Summary / Bullet / Skills |

### LinkedIn Updates
| # | Section | Change | Why |
|---|---|---|---|
| 1 | Headline | {edit} | {matches target language} |
```

## Step 8: Block F — Interview Preparation (STAR + Reflection)

```
## F. Interview Prep

### Story 1: {JD requirement it addresses}
- **Situation:** {from their actual experience}
- **Task:** {their responsibility}
- **Action:** {what they did, specific}
- **Result:** {measurable outcome}
- **Reflection:** {what they learned}
```

6-10 stories. Map each to a specific JD requirement. Use ONLY real experience.
Mark incomplete stories: "Fill in your specific numbers/details."

### Story Bank Update

After generating stories, append any NEW stories (not duplicates) to
`DATA_DIR/story-bank.md`. Create from `templates/story_bank.md` if missing.

For each story, tag it with the themes it covers:
`<!-- themes: leadership, technical-challenge, conflict, failure, impact -->`

Skip stories that duplicate an existing entry (same situation + same result).
Over time, this file becomes the user's master interview prep resource.

## Step 9: Computed Score

Calculate score from 1.0 to 5.0 using weighted dimensions from `references/06-scoring-rubric.md`.
Apply archetype weight adjustments.
Apply persona modifiers.
Apply PASS/FAIL credential rules for regulated industries.

```
## Overall Score: {X.X}/5.0 — {Label}

### Score Breakdown
| Dimension | Weight | Score | Notes |
|---|---|---|---|
| Hard requirement coverage | {adj%} | {x}/10 | {detail} |
| Seniority alignment | {adj%} | {x}/10 | |
| Domain/industry match | {adj%} | {x}/10 | |
| Compensation alignment | {adj%} | {x}/10 | |
| Location/remote fit | {adj%} | {x}/10 | |
| Career trajectory fit | {adj%} | {x}/10 | |
| Credentials/licenses | {adj%} | {x}/10 | |
| Skills/portfolio | {adj%} | {x}/10 | |

{Honest summary paragraph}
```

For scores below 3.0:
> "This is a stretch. The main gap is {X}. Your time is better spent on
> roles that match your {strength}."

## Step 10: Save & Track

Save to `DATA_DIR/evaluations/{company-slug}-{role-slug}-{date}.md`.
Add row to `DATA_DIR/applications.md`.

## Step 11: Next Steps

- **4.5+:** "Strong match! Say 'tailor my resume for {company}' to generate an elite application package."
- **3.0-4.4:** "Solid fit. Say 'tailor my resume' to run the full 12-stage pipeline."
- **Below 3.0:** "This one's a stretch. Want me to scan for better-matched roles?"
