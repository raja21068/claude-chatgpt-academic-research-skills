---
name: discover
description: "Find job openings you haven't thought of. Searches the open web using your profile — target roles, skills, location, seniority — to surface jobs beyond your known companies. Use when someone says 'find me jobs', 'discover opportunities', 'what's out there', or 'surprise me'."
argument-hint: "'broad' for wide search, 'niche' for specialized, or specific terms like 'remote ML engineer climate tech'"
user-invocable: true
allowed-tools:
  - Read
  - Write
  - WebSearch
  - WebFetch
  - Glob
---

# Job Discovery

Find jobs you'd never find by scanning known companies.
Uses your profile to build targeted web searches.

## Step 0: Load Profile

Read `DATA_DIR/profile.yml` for: target roles, skills, seniority, location,
industries, preferences, dealbreakers.

If no profile:
> "I need your profile to search effectively. Say 'setup' first."

## Step 1: Build Search Queries

Construct 4-6 targeted queries from profile data.

**Query patterns:**

```
"{primary_role}" "{top_skill_1}" "{location}" remote {year}
"{secondary_role}" hiring "{top_skill_2}" {year}
"{primary_role}" "{industry}" startup hiring {year}
"{primary_role}" site:jobs.lever.co OR site:boards.greenhouse.io {year}
"{primary_role}" "{top_skill_1}" salary {comp_range} {year}
```

**Argument modifiers:**
- `broad`: Use secondary roles + adjacent titles. More results, less precise.
- `niche`: Use only primary role + top 2 skills. Fewer results, higher match.
- Custom terms: Append to every query.

**Smart additions based on profile:**
- If preferences include "remote": add "remote" to all queries
- If seniority = "senior": add "senior OR lead OR staff"
- If industries specified: run separate queries per industry
- If dealbreakers include "no startups": add "-startup -seed -series-a"

## Step 2: Search and Collect

Run each query via WebSearch. For each result:

1. Check URL — is it a job posting? (contains /jobs/, /careers/, /apply/, lever.co, greenhouse.io)
2. Dedup against `DATA_DIR/scan-history.md` and `DATA_DIR/applications.md`
3. Dedup against other results in this run (same company+role = skip)
4. Extract: title, company, URL, source snippet

Keep top 15 unique job postings across all queries.

## Step 3: Quick Relevance Score

For each posting, compute a quick 1-10 relevance from the search snippet:
- Title matches target roles: 0-4
- Skills/keywords visible in snippet: 0-3
- Location/remote match: 0-2
- Seniority alignment: 0-1

Sort by relevance descending.

## Step 4: Fetch Top Matches

For the top 5 results (relevance ≥ 6), use WebFetch to get the full
job posting. Extract: title, company, location, requirements, salary if stated.

## Step 5: Output

```
## Discovery Results — {date}

Searched: {n} queries across {sources}

### Top Matches (full details fetched)

#### 1. {Title} — {Company}
**Location:** {location} · **Source:** {url}
**Why it matches:** {1 sentence connecting to your profile}
**Key requirements:** {top 3}

#### 2. ...

### Other Finds (snippet only — say 'evaluate #N' for details)

| # | Role | Company | Relevance | URL |
|---|---|---|---|---|
| 6 | {title} | {company} | {score}/10 | {url} |
| ... |

### Search Terms Used
{list queries so user can refine}
```

## Step 6: Integration

Add all top matches (relevance ≥ 6) to `DATA_DIR/pipeline.md` with status "New".
Log all results to `DATA_DIR/scan-history.md`.

> "Found {n} matches. Top {x} added to your pipeline.
> Say 'pipeline run' to evaluate them all, or 'evaluate #1' for one."
