---
name: pipeline
description: "Automated job search pipeline. Processes a list of job URLs or JDs: fetches each, evaluates, filters by score threshold, tailors resumes for winners, and queues them for apply. Use when someone says 'process my pipeline', 'run the pipeline', 'auto-process', or 'find and prepare jobs for me'."
argument-hint: "'run' to process pipeline.md, 'add URL' to queue a URL, 'status' to see pipeline state, threshold number like '3.5'"
user-invocable: true
allowed-tools:
  - Read
  - Write
  - Glob
  - Bash
  - WebSearch
  - WebFetch
---

# Automated Pipeline

Chains: intake → evaluate → filter → tailor → apply-queue.
One command processes many jobs. You review at the end, not at each step.

## How It Works

```
pipeline.md (URLs/JDs)
    │
    ▼ for each entry
  fetch JD text (WebFetch if URL)
    │
    ▼
  evaluate (inline, lightweight — blocks B+C only, not full A-F)
    │
    ▼
  score ≥ threshold?
    │
   no ──→ log to pipeline.md as "Skipped (X.X)"
    │
   yes
    │
    ▼
  full evaluate (A-F blocks, save to evaluations/)
    │
    ▼
  tailor-resume (12-stage pipeline)
    │
    ▼
  update applications.md as "Resume Ready"
    │
    ▼
  log to pipeline.md as "Ready"
```

## Step 0: Prerequisite Check

Read `DATA_DIR/profile.yml`. If missing:
> "Run 'setup' first — I need your profile to evaluate jobs."
Stop.

Read `DATA_DIR/resume.md`. If missing:
> "I need your resume. Paste it or say 'setup'."
Stop.

## Step 1: Parse Input

Parse `$ARGUMENTS`:

- **"run"** or no argument: Process all "New" entries in `DATA_DIR/pipeline.md`
- **"add {URL}"**: Append URL to pipeline.md with status "New", then stop
- **"add" + pasted JD text**: Save JD to `DATA_DIR/jds/{slug}.md`, add to pipeline.md
- **"status"**: Show pipeline summary (counts by status), then stop
- **Number (e.g. "3.5")**: Set score threshold for this run (default: 3.5)
- **"clear skipped"**: Remove all "Skipped" entries from pipeline.md

## Step 2: Load or Create Pipeline File

Read `DATA_DIR/pipeline.md`. If missing, create:

```markdown
# Job Pipeline

| # | Date | Company | Role | Source | Score | Status | Notes |
|---|---|---|---|---|---|---|---|
```

Status values: `New` → `Evaluating` → `Skipped (X.X)` → or → `Evaluated (X.X)` → `Tailoring` → `Ready` → `Applied`

## Step 3: Process Each "New" Entry

For each row with Status = "New":

### 3a. Fetch the JD

- If Source is a URL: `WebFetch` the page, extract the job posting text
- If Source is a file path: read the file
- If fetch fails: mark status "Fetch Failed", continue to next

### 3b. Quick Score (lightweight — saves tokens)

Do NOT run the full A-F evaluation. Instead, do a quick match:

1. Extract: title, company, location, top 5 requirements
2. Compare against `profile.yml`: target roles, skills, seniority, location preferences
3. Check dealbreakers from `preferences.md` (if exists)
4. Compute a quick score (1.0-5.0) based on:
   - Title match to target roles: 0-2 points
   - Top requirements overlap with skills: 0-2 points
   - Location/remote match: 0-0.5 points
   - No dealbreakers hit: 0-0.5 points

Update pipeline.md row: set Score = quick score.

### 3c. Filter

Default threshold: 3.5 (override with argument).

- **Below threshold**: Set status to `Skipped ({score})`. Continue to next.
- **At or above threshold**: Continue to 3d.

### 3d. Full Evaluate

Run the evaluate skill logic (blocks A-F) inline.
Save evaluation to `DATA_DIR/evaluations/{company-slug}-{role-slug}-{date}.md`.
Add row to `DATA_DIR/applications.md`.
Update pipeline.md: status = `Evaluated ({score})` with the full score.

### 3e. Decide: Tailor or Not

- **Score ≥ 4.0**: Auto-proceed to tailoring.
- **Score 3.5-3.9**: Mark as `Evaluated ({score})`, do NOT auto-tailor. User decides.

### 3f. Tailor Resume (for ≥ 4.0 only)

Run the tailor-resume skill logic (12-stage pipeline).
Update pipeline.md: status = `Ready`.
Update applications.md: status = `Resume Ready`.

## Step 4: Summary Report

After processing all entries, show:

```
## Pipeline Run Complete — {date}

**Processed:** {n} jobs
**Skipped (below {threshold}):** {n}
**Evaluated:** {n}
**Resumes tailored:** {n}
**Failed to fetch:** {n}

### Ready to Apply (score ≥ 4.0)
| Company | Role | Score | Resume |
|---|---|---|---|
| {company} | {role} | {score} | {path to resume} |

### Needs Your Decision (score 3.5-3.9)
| Company | Role | Score | Why |
|---|---|---|---|
| {company} | {role} | {score} | {one-line summary} |

### Skipped
| Company | Role | Score | Reason |
|---|---|---|---|
| {company} | {role} | {score} | {main gap} |
```

## Step 5: Next Actions

Based on results:

- If "Ready" jobs exist:
  > "You have {n} jobs ready to apply. Say 'apply for {company}' or
  > 'apply all' to fill out applications. I'll ask for confirmation
  > before submitting each one."

- If "Evaluated" (3.5-3.9) jobs exist:
  > "You have {n} borderline matches. Say 'tailor for {company}' for
  > any you want to pursue, or 'skip {company}' to remove them."

- If pipeline is empty:
  > "Pipeline is empty. Say 'scan {company}' to find jobs, or
  > 'pipeline add {URL}' to queue one."

## Token Efficiency Rules

This skill exists to save tokens across many jobs. Follow these rules:

1. **Quick score is cheap.** It reads ~20 lines of JD + profile. It does NOT
   read reference files, templates, or the skills database. One paragraph of
   reasoning, one number. That's it.

2. **Full evaluate only for survivors.** The A-F blocks only run for jobs that
   pass the quick score. A pipeline of 20 URLs might only fully evaluate 5.

3. **Tailor only for strong matches.** The 12-stage pipeline (the most
   expensive operation) only runs for score ≥ 4.0. A pipeline of 20 URLs
   might only tailor 2-3 resumes.

4. **Batch the output.** Don't show evaluation details for skipped jobs.
   One line per skip in the summary. Details only for survivors.

5. **Never re-process.** If a pipeline entry already has a non-"New" status,
   skip it. The user can reset it to "New" manually if they want to re-run.
