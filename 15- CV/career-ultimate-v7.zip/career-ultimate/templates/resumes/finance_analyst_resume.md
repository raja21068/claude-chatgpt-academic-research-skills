# {First Name} {Last Name}

{City, State} · {email} · {phone} · [LinkedIn](linkedin.com/in/{handle}) · [GitHub](github.com/{handle})

## Professional Summary

{Role thesis: 2-3 sentences. First sentence = years of experience + core domain + highest-impact result. Second sentence = primary methodology/toolchain. Third sentence = why this specific role is a fit. Mirror JD keywords naturally.}

## Experience

### {Most Recent Title} — {Company}
{Mon YYYY – Present} · {City, State or Remote}

- {Action verb} {scope/object} {method/tool} {measurable outcome} [evidence: confirmed]
- {Action verb} {scope/object} {method/tool} {measurable outcome} [evidence: confirmed]
- {Action verb} {scope/object} {method/tool} {measurable outcome} [evidence: confirmed]
- [TODO: verify metric for this bullet if adding]

### {Previous Title} — {Company}
{Mon YYYY – Mon YYYY} · {City, State}

- {Bullet following same formula}
- {Bullet following same formula}
- {Bullet following same formula}

## Education

**{Degree}** — {University}, {Year}
{Relevant coursework, honors, GPA only if recent graduate}

## Skills

**{Category from JD}:** {JD keywords first, then additional. Both acronym and full form: "Search Engine Optimization (SEO)"}
**{Category}:** {Skills}

## Certifications

{Only if applicable to this role}

---
_Template: Finance Analyst Resume | ATS-safe single-column | Bullets: action + scope + method + outcome_
_Evidence tags are internal only — remove before submission_
