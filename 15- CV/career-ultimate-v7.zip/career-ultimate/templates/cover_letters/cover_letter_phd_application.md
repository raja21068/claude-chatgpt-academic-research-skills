Dear {Admissions Committee / Prof. {Last Name}},

{HOOK: Why this program. Reference specific faculty, research group, or paper.}

{RESEARCH EXPERIENCE: 3-4 sentences. Your most relevant research, what you contributed, and what you learned. Mirror the advisor's methodology.}

{PREPARATION: 2-3 sentences. Coursework, skills, projects that prepare you. Connect to the program's strengths.}

{FUTURE: 2-3 sentences. What you want to study and why this program is the right place. Be specific about research questions.}

Sincerely,
{First Name} {Last Name}

---
_Template: PhD Application Cover Letter | 1 page | Research-interest forward_
