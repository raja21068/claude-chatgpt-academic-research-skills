Dear {Search Committee / Dr. {Last Name}},

{HOOK: Reference specific research at the department/lab. Show you understand their work.}

{RESEARCH PROGRAM: 4-5 sentences. Your research trajectory, key results, methodology. Publications as evidence. Mirror the posting's research area language.}

{TEACHING (if relevant): 2-3 sentences. Courses taught or designed, teaching philosophy in brief.}

{FIT: 2-3 sentences. Why this department/lab/program specifically — name collaborators, facilities, synergies.}

{CLOSING: Forward-looking. Mention enclosed materials (CV, research statement, teaching statement).}

Sincerely,
{First Name} {Last Name}, {Degree}

---
_Template: Academic Cover Letter | Faculty/Postdoc | Publication-forward_
