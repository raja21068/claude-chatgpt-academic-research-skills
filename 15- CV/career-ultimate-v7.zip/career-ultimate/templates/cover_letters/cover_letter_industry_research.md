{Date}

{Hiring Manager Name, if known}
{Company Name}
{City, State}

Dear {Hiring Manager / Hiring Committee},

{HOOK: 2 sentences. Reference something specific about the company's recent work, publication, product, or mission. Connect it to your research. NOT "I am excited to apply."}

{BODY 1: 3-4 sentences. Strongest evidence match to top JD requirement. Include a specific metric or outcome from your work. Mirror JD language. "At {Company}, I {action} {scope} using {method}, resulting in {outcome}."}

{BODY 2: 3-4 sentences. Secondary matches spanning 2-3 other requirements. Bridge to what makes you uniquely suited. Mention specific tools/methods from JD.}

{GAP BRIDGE (if applicable): 2-3 sentences. Address biggest gap with honest framing. Show adjacent experience or genuine interest in growing.}

{CLOSING: 2 sentences. Forward-looking statement connecting to company mission. Clear call to action.}

Sincerely,
{First Name} {Last Name}

---
_Template: Industry Research Cover Letter | Under 400 words | Evidence-backed_
