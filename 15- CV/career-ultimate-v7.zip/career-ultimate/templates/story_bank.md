# Interview Story Bank

Stories accumulate here across evaluations. After 10+ evaluations, you'll
have 5-10 master stories that answer any behavioral question.

## How to use

Each story maps to common interview themes (leadership, conflict, failure,
technical challenge, etc.). When prepping for an interview, find stories
that match the JD's key requirements — don't memorize, just review.

---

## Stories

<!-- New stories are appended below by evaluate and tailor-resume skills -->
