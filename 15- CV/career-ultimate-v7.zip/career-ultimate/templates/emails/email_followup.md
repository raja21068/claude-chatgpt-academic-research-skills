Subject: Following up — {Role} application ({Your Name})

Hi {First Name},

I submitted my application for the {Role} position on {Date} and wanted to follow up. {1 sentence: reiterate your strongest fit point.}

I'm happy to provide any additional information. Looking forward to hearing from you.

Best,
{Your Name}

---
_Template: Application Follow-up | Under 50 words | 5-7 days after applying_
