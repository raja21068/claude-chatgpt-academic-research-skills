Subject: Your work on {specific paper/project} — question from a {Your Title}

Dear Prof./Dr. {Last Name},

{1 sentence: what caught your attention in their recent work. Be specific — paper title, finding, method.}

{1-2 sentences: your relevant background. One concrete result. Mirror their methodology.}

{1 sentence: specific question or request. "I'm exploring whether {X} could extend to {Y} — would you have 15 minutes to discuss?"}

Best regards,
{Your Name}
{Affiliation}

---
_Template: Cold Outreach to Researcher | Under 80 words | Paper-specific hook_
