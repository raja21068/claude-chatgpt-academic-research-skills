Subject: Quick question about {Role/Team} at {Company}

Hi {First Name},

{HOOK: 1 sentence about them — recent work, shared connection, something specific.}

{PROOF: 1 sentence. Your most relevant credential. One number.}

{ASK: 1 sentence. "Would you be open to a quick chat about what the team looks for?" or "Would you feel comfortable referring me?"}

Thanks,
{Your Name}

---
_Template: Referral Request Email | Under 100 words | Hook + proof + ask_
