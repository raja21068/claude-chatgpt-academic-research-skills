# LinkedIn Headline Patterns — Research / AI Track

## Formula
{Title} at {Company} | {Domain 1} · {Domain 2} | {Key differentiator}

## Examples by Role

**Research Scientist:**
- Research Scientist at DeepMind | NLP · Reasoning · LLMs | NeurIPS '25 spotlight
- AI Research Scientist | Computer Vision · Medical Imaging | 12 peer-reviewed papers

**Research Engineer:**
- Research Engineer at Anthropic | LLM Infrastructure · Distributed Training | PyTorch core contributor
- ML Platform Engineer at Meta | MLOps · Training at Scale | 10x throughput improvements

**ML Engineer:**
- Senior ML Engineer at Stripe | Fraud Detection · Real-time ML | Deployed models serving 1B+ requests/day

**PhD Student (job market):**
- PhD Candidate (NLP) at Stanford | Graduating May 2026 | First-author at ACL, EMNLP
- AI/ML PhD Student at MIT | Reinforcement Learning · Robotics | Seeking research scientist roles

**Clinical AI:**
- Clinical AI Scientist at PathAI | Medical Imaging · FDA Regulatory | IRB-approved multi-site studies

## Rules
- Under 120 characters
- Title first, company second
- Research domains as keywords (ATSs index headlines)
- One differentiator (publication, metric, unique skill)
- No buzzwords ("passionate", "innovative", "thought leader")

---
_Template: LinkedIn Headlines | Research/AI Track | Under 120 chars_
