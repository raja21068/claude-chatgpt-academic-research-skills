# LinkedIn About Section — Structure

## Formula (4 paragraphs, ~200 words total)

**Paragraph 1 — The hook (2 sentences):**
What you do and your biggest result. Mirror target role keywords.

**Paragraph 2 — The proof (3-4 sentences):**
Key accomplishments with numbers. Tools and methods. Domain expertise.

**Paragraph 3 — The differentiation (2 sentences):**
What makes you different from others with similar titles. Unique intersection of skills.

**Paragraph 4 — The signal (1-2 sentences):**
What you're looking for or open to. Call to action.

## Example — Research Scientist

I build and evaluate large language models, with a focus on reasoning and factuality. My work at {Company} reduced hallucination rates by 34% on internal benchmarks through novel training-time interventions.

Previously at {Company}, I led a team of 4 researchers developing multimodal architectures that became the foundation for our flagship product. I've published 8 papers at NeurIPS, ICML, and ACL, including a best paper honorable mention.

What sets me apart is the bridge between research rigor and production impact — every paper I publish ships as a model improvement within 6 months.

Open to research scientist and research lead roles in LLM reasoning, alignment, and evaluation. Reach me at {email}.

---
_Template: LinkedIn About Section | 200 words | Hook + proof + differentiation + signal_
