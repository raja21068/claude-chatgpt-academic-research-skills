# {First Name} {Last Name}, {Degree}

{email} · {phone} · ORCID: {ID} · [Google Scholar]({url})

## Research Summary

{3-4 sentences: current research, methodology, key results, future direction. Mirror the lab/posting's language.}

## Education

**{PhD}** — {University}, {Year}
Dissertation: "{Title}" · Advisor: {Name}

## Publications

{Prioritize first-author and most relevant to the target lab. Bold your name.}

1. **{Last, F.}**, et al. (YYYY). "{Title}." *{Journal/Conference}*.
2. ...

## Research Experience

### {Title} — {Lab/PI Name}, {University}
{Mon YYYY – Mon YYYY}
- {Key contribution 1 with method and outcome}
- {Key contribution 2}

## Skills

**Methods:** {Relevant to target lab}
**Tools:** {PyTorch, etc.}
**Compliance:** {IRB, HIPAA if medical — expand at first use}

## References

Available upon request.

---
_Template: Postdoc Application CV | Concise, publication-forward | 2-3 pages_
