# {First Name} {Last Name}, {Degree}

{Department} · {University}
{Address} · {email} · {phone}
ORCID: {0000-0000-0000-0000} · [Google Scholar]({url})

## Research Interests

{2-3 sentences describing research program. Mirror JD/posting language.}

## Education

**{Degree}** — {University}, {Year}
Dissertation: "{Title}"
Advisor: {Name}
{Committee: if relevant}

## Academic Appointments

### {Title} — {Department}, {University}
{Mon YYYY – Present}
- {Research focus and key contributions}

## Publications

### Peer-Reviewed Journal Articles
{Reverse chronological. Bold your name. Include DOI.}

1. **{Last, F.}**, Co-Author, A., & Co-Author, B. (YYYY). "{Title}." *{Journal}*, {volume}({issue}), {pages}. doi:{DOI}

### Conference Publications
1. **{Last, F.}**, et al. (YYYY). "{Title}." In *{Conference}*. {Location}.

### Preprints
1. **{Last, F.}**, et al. (YYYY). "{Title}." *arXiv:{ID}*.

## Grants and Funding

- {Grant Name}, {Agency}, ${Amount}, {YYYY-YYYY}. Role: {PI/Co-PI/Key Personnel}

## Teaching

### {Course Name} — {University}
{Role: Instructor / TA / Guest Lecturer}, {Semester YYYY}

## Mentoring

- {Student Name}, {Program}, {YYYY}. {Outcome if known.}

## Service

- {Reviewer for {Journal/Conference}, YYYY–Present}
- {Committee membership}

## Awards and Honors

- {Award Name}, {Organization}, {YYYY}

## Skills

**Languages:** {Python, R, etc.}
**Frameworks:** {PyTorch, etc.}
**Methods:** {from research}

---
_Template: Full Academic CV | No page limit | Publication-forward | ATS-safe_
