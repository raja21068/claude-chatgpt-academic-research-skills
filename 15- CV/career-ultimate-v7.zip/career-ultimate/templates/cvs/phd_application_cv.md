# {First Name} {Last Name}

{email} · {phone} · [GitHub]({url})

## Research Interests

{2-3 sentences aligned with target program/advisor's work.}

## Education

**{Degree}** — {University}, {Year}
GPA: {X.X/4.0} · {Honors}
Relevant coursework: {Course 1, Course 2, Course 3}

## Research Experience

### {Title} — {Lab/PI}, {University}
{Mon YYYY – Mon YYYY}
- {Contribution with method and outcome}
- {Contribution}

## Publications / Preprints

1. **{Last, F.}**, et al. (YYYY). "{Title}." *{Venue}*.

## Projects

### {Project Name}
- {Description with tools used and outcome}

## Skills

**Programming:** {Languages}
**ML/AI:** {Frameworks}
**Methods:** {Statistical, experimental}

## Awards

- {Award}, {YYYY}

---
_Template: PhD Application CV | Education + research forward | 1-2 pages_
