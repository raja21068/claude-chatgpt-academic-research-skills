"""Real ATS parser — extract, parse, and simulate per-platform ATS behavior.

Replaces the v5 regex-only ats_parse_simulator.py with a structural parser
that mirrors how Workday, Greenhouse, Taleo, iCIMS, and Lever actually parse resumes.

Usage:
    python -m scripts.ats_parser.cli resume.pdf
    python -m scripts.ats_parser.cli resume.pdf --platform workday --json
"""
from .parser import parse, ParsedResume, skill_strength, find_skill_mentions
from .extractor import extract, ExtractionResult
from .simulator import simulate_all, simulate_one, Issue
