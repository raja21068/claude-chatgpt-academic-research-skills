#!/usr/bin/env python3
"""Seed the skills database from an O*NET or ESCO CSV dump.

Usage:
    python scripts/seed_skills_db.py path/to/dump.csv --source onet
    python scripts/seed_skills_db.py path/to/dump.csv --source esco

This is a template — adapt the column names to the actual export format.
"""
import argparse
import csv
import json
import sys
from pathlib import Path

SKILLS_DB = Path(__file__).parent.parent / "skills_db" / "skills_core.json"


def load_existing():
    if SKILLS_DB.exists():
        with open(SKILLS_DB) as f:
            return json.load(f)
    return {"version": "6.0.0", "skills": []}


def seed_onet(csv_path: str, db: dict):
    existing_ids = {s["id"] for s in db["skills"]}
    added = 0
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Adapt these column names to your O*NET export
            title = row.get("Title", row.get("Element Name", "")).strip()
            if not title:
                continue
            skill_id = "skill_" + title.lower().replace(" ", "_").replace("/", "_")[:40]
            if skill_id in existing_ids:
                continue
            db["skills"].append({
                "id": skill_id,
                "canonical": title,
                "category": "imported_onet",
                "synonyms": [title.lower()],
                "common_misspellings": [],
                "onet_id": row.get("O*NET-SOC Code", None),
                "applies_to_roles": [],
                "weight_by_role": {},
            })
            existing_ids.add(skill_id)
            added += 1
    return added


def seed_esco(csv_path: str, db: dict):
    existing_ids = {s["id"] for s in db["skills"]}
    added = 0
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            title = row.get("preferredLabel", row.get("conceptUri", "")).strip()
            if not title:
                continue
            skill_id = "skill_" + title.lower().replace(" ", "_").replace("/", "_")[:40]
            if skill_id in existing_ids:
                continue
            db["skills"].append({
                "id": skill_id,
                "canonical": title,
                "category": "imported_esco",
                "synonyms": [title.lower()],
                "common_misspellings": [],
                "esco_id": row.get("conceptUri", None),
                "applies_to_roles": [],
                "weight_by_role": {},
            })
            existing_ids.add(skill_id)
            added += 1
    return added


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv_path")
    ap.add_argument("--source", choices=["onet", "esco"], required=True)
    args = ap.parse_args()

    db = load_existing()
    if args.source == "onet":
        added = seed_onet(args.csv_path, db)
    else:
        added = seed_esco(args.csv_path, db)

    with open(SKILLS_DB, "w") as f:
        json.dump(db, f, indent=2)
    print(f"Added {added} skills from {args.source}. Total: {len(db['skills'])}.")


if __name__ == "__main__":
    main()
