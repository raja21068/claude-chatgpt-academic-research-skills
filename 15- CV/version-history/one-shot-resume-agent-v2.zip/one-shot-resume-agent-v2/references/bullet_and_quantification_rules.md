# Bullet and Quantification Rules

## Good bullet anatomy

A strong bullet contains:

- action verb
- object of work
- method/tool
- scale/context
- result/impact

## Formulas

X-Y-Z:

```text
Accomplished X as measured by Y by doing Z.
```

CAR:

```text
Challenge + Action + Result.
```

STAR condensed:

```text
Situation/task + Action + Result.
```

Technical:

```text
Built [system] using [tools] to produce [outcome].
```

Research:

```text
Estimated [question] using [data/method] to show [finding].
```

## Metric discovery

Look for:

- counts
- frequency
- before/after
- time saved
- cost saved
- accuracy improved
- errors reduced
- users served
- documents produced
- stakeholders supported
- datasets handled
- model performance
- adoption
- grades or rankings

If unknown, use TODO placeholders.
