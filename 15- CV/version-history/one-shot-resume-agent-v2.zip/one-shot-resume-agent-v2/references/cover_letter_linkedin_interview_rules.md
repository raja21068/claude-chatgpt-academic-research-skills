# Cover Letter, LinkedIn, and Interview Rules

## Cover letter

Write a specific, human letter. Do not restate the full resume.

Recommended structure:

1. Hook tied to role.
2. Fit with evidence.
3. Contribution and motivation.
4. Closing.

Industry: 250 to 350 words.
Academic/research: 350 to 650 words.
Internship/student: 220 to 320 words.

## LinkedIn

LinkedIn can be warmer than resume but must stay true.

Deliver:

- headline
- About section
- experience bullets
- top skills
- featured section ideas

## Interview prep

Deliver:

- 30-second pitch
- 60-second pitch
- likely questions
- STAR stories
- gap responses
- questions to ask

## Reference list

Only include real references with permission.
