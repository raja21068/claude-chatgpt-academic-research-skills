# Critique Framework

Run critique before final output.

## Five readers

| Reader | Question |
|---|---|
| ATS robot | Do keywords and sections parse? |
| Recruiter | Is fit clear in 10 seconds? |
| HR screen | Are minimum requirements met? |
| Hiring manager | Does this person solve our problem? |
| Technical or academic reviewer | Are claims credible and deep? |

## Eight scores

| Dimension | Weight |
|---|---:|
| ATS keyword match | 15 |
| Role relevance | 20 |
| Evidence density | 15 |
| Impact and metrics | 10 |
| Recruiter scanability | 10 |
| Domain credibility | 10 |
| Gap handling and honesty | 10 |
| Tone and polish | 10 |

## Output

- readiness score
- strongest points
- rejection risks
- fixes made
- missing keywords safe to add
- keywords not safe to add
- truthfulness table
- final checklist
