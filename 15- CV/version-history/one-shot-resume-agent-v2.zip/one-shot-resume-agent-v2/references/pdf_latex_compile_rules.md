# PDF and LaTeX Compile Rules

## Compile commands

```bash
pdflatex -interaction=nonstopmode 04_TAILORED_RESUME.tex
pdflatex -interaction=nonstopmode 04_TAILORED_RESUME.tex
pdflatex -interaction=nonstopmode 05_COVER_LETTER.tex
pdflatex -interaction=nonstopmode 05_COVER_LETTER.tex
```

or

```bash
latexmk -pdf -interaction=nonstopmode 04_TAILORED_RESUME.tex
latexmk -pdf -interaction=nonstopmode 05_COVER_LETTER.tex
```

## Escape characters

Escape these in LaTeX text:

```text
& % $ # _ { } ~ ^ \
```

## Common fixes

- Replace smart quotes with straight quotes.
- Replace en dash and em dash if unsupported.
- Escape ampersands in company names.
- Shorten long URLs.
- Remove unsupported icons.
- Use text-based links.
