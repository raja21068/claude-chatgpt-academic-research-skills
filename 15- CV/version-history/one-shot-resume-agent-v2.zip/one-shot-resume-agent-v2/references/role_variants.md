# Role Variants

## Academic CV

Lead with education, research, publications, working papers, teaching, presentations, grants, service, and technical methods.

## Technical resume

Lead with skills, systems, data/modeling tools, architecture, deployment, testing, and measurable outputs.

## Research or policy resume

Lead with methods, data, identification strategy, policy domain, writing, presentations, and reproducibility.

## Finance resume

Lead with forecasting, variance analysis, reporting, budgeting, SQL/Excel, dashboards, and business decisions.

## EdTech resume

Lead with curriculum, student outcomes, LMS, teacher coordination, assessment, content quality, operations, and growth.

## Executive resume

Lead with scope, strategy, team size, budget, revenue, transformation, board/stakeholder influence, and measurable outcomes.

## Career changer

Lead with transferable skills and proof. Keep previous domain honest.
