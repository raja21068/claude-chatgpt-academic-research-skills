# Anti-Fabrication and Evidence Rules

Use these rules for every resume, CV, cover letter, LinkedIn section, and interview answer.

## Evidence labels

| Label | Meaning | Allowed use |
|---|---|---|
| Confirmed | Explicitly in candidate evidence | Can use directly |
| Derived | Directly inferable without adding facts | Can use carefully |
| Needs verification | Plausible but not confirmed | Use TODO or ask later |
| Missing | Required by job but absent | Mark as gap |
| Excluded | Not relevant or risky | Do not use |

## Never invent

- Dates
- Degrees
- Employers
- Job titles
- Publications
- Awards
- Certifications
- Tools
- Metrics
- Company facts
- References
- Links
- Legal or visa status

## Claim test

Before final output, every important claim must answer:

1. Where did this fact come from?
2. Is it worded at the right level of confidence?
3. Does it match the candidate's real role?
4. Does it risk sounding inflated?
5. Is it necessary for this job?

If no source exists, remove or mark TODO.
