# ATS and Formatting Rules

## ATS-safe defaults

- Use standard section headings.
- Use text, not images, for all important content.
- Avoid tables for main experience.
- Avoid icons in ATS version.
- Avoid text boxes and unusual columns.
- Keep dates consistent.
- Use common fonts.
- Use simple bullets.
- Keep file names clear.

## Keyword process

1. Extract Tier 1, Tier 2, Tier 3 keywords from JD.
2. Map each keyword to candidate evidence.
3. Add exact phrase only if true.
4. Use semantic alternatives if exact phrase would be dishonest.
5. Re-score after tailoring.

## Common ATS failure points

- Missing exact job title family.
- Skills hidden in graphics.
- Non-standard headings.
- Keyword stuffing with no evidence.
- PDF not text-extractable.
- Multiple contact details in headers/footers only.
- Inconsistent dates.
- Abbreviations without full version.
