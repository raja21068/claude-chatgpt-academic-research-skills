# Application Intake

## Candidate
- Name:
- Email:
- Phone:
- Location:
- LinkedIn:
- Portfolio:
- Target country/style:

## Target role
- Company:
- Role title:
- Location/work mode:
- Deadline:
- Documents required:

## Constraints
- Resume or CV:
- Page length:
- Format:
- Tone:
- Must include:
- Must exclude:

## Candidate evidence
Paste resume, CV, raw bullets, projects, achievements, publications, portfolio, or notes here.

## Job description
Paste full job description here.
