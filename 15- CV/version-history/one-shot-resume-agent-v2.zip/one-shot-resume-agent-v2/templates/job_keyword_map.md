# Job Keyword Map

| Keyword or phrase | Type | Priority | Exact JD wording | Candidate evidence | Safe to use? | Placement |
|---|---|---:|---|---|---|---|

## Tier definitions

- Tier 1: required, repeated, title-level, responsibility-level.
- Tier 2: preferred, secondary, useful.
- Tier 3: culture or nice-to-have.
