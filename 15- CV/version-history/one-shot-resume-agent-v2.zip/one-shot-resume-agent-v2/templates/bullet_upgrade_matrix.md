# Bullet Upgrade Matrix

| Original bullet | Evidence | Formula used | Upgraded bullet | Missing metric/TODO |
|---|---|---|---|---|

## Formula options

- X-Y-Z
- CAR
- STAR condensed
- Technical
- Research
