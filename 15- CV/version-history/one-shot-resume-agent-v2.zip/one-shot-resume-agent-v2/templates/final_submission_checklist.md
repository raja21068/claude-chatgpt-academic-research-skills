# Final Submission Checklist

- [ ] Name, email, phone, and links are correct.
- [ ] File names are professional.
- [ ] Resume is text-based and ATS-safe.
- [ ] Dates are consistent.
- [ ] No unsupported claims.
- [ ] No invented metrics.
- [ ] Top keywords are used naturally.
- [ ] Cover letter names correct role and company.
- [ ] Attachments match employer instructions.
- [ ] Remaining TODOs resolved or intentionally left out.
