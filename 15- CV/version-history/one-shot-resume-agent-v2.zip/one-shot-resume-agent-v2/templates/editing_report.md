# Editing Report

| Area | Before | After | Reason |
|---|---|---|---|

## Claims removed or softened

| Claim | Action | Reason |
|---|---|---|
