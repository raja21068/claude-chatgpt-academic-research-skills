# ATS and Recruiter Scorecard

| Dimension | Weight | Score | Notes |
|---|---:|---:|---|
| ATS keyword match | 15 |  |  |
| Role relevance | 20 |  |  |
| Evidence density | 15 |  |  |
| Impact and metrics | 10 |  |  |
| Recruiter scanability | 10 |  |  |
| Domain credibility | 10 |  |  |
| Gap handling and honesty | 10 |  |  |
| Tone and polish | 10 |  |  |

## Estimated readiness score

`__/100`

## Top fixes completed

1.
2.
3.

## Remaining TODOs

1.
2.
3.
