# LinkedIn Optimization Package

## Headline

## About section

## Experience updates

## Featured section suggestions

## Skills to add or prioritize

| Skill | Reason | Evidence |
|---|---|---|
