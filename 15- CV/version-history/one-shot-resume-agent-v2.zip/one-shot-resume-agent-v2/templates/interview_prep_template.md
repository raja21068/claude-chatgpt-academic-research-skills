# Interview Prep

## 30-second pitch

## 60-second pitch

## Why this role

## Why this company

## Likely questions

| Question | What they test | Suggested answer angle |
|---|---|---|

## STAR story bank

| Story type | Situation | Task | Action | Result | Evidence |
|---|---|---|---|---|---|

## Gap answers

| Gap | Honest answer | Bridge evidence |
|---|---|---|

## Questions to ask

1.
2.
3.
