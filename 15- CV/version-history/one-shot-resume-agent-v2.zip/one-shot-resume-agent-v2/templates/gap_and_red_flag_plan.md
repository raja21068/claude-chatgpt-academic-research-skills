# Gap and Red Flag Plan

| Gap or red flag | Severity | Evidence available | Honest positioning | Action |
|---|---|---|---|---|

## Job posting red flags

| Red flag phrase | Interpretation | Risk level | Notes |
|---|---|---|---|
