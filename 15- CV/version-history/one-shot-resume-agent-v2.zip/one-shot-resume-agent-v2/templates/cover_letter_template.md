# Cover Letter Template

Dear [Hiring Manager/Selection Committee],

[Specific hook connected to the role and candidate evidence.]

[Fit paragraph with two or three strongest evidence points.]

[Contribution paragraph: what the candidate can do for the team.]

[Concise closing.]

Sincerely,
[Candidate Name]
