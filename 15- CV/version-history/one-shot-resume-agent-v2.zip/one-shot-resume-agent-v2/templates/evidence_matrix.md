# Evidence Matrix

| Job requirement | Priority | Candidate evidence | Evidence status | Resume placement | Cover letter angle | Risk/TODO |
|---|---:|---|---|---|---|---|
|  |  |  | Confirmed / Derived / Needs verification / Missing / Excluded |  |  |  |

## Unsupported claims removed

| Claim | Reason removed | Safer replacement |
|---|---|---|
