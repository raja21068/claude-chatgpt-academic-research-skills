# Application Email

**Subject:** Application for [Role] - [Candidate Name]

Dear [Hiring Manager/Recruiting Team],

I am writing to apply for the [Role] position at [Company]. [One sentence strongest fit.]

Attached are my resume and cover letter. I would welcome the opportunity to discuss how my experience in [evidence area] can support [role need].

Regards,
[Candidate Name]
