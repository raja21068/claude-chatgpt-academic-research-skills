# Agent: PDF Compiler

Compile LaTeX files to PDFs when tools are available.

Steps:

1. Save resume source as `04_TAILORED_RESUME.tex`.
2. Save cover letter source as `05_COVER_LETTER.tex`.
3. Run `pdflatex -interaction=nonstopmode` twice or `latexmk -pdf`.
4. Move PDFs to the application folder as `resume.pdf` and `cover_letter.pdf`.
5. Clean auxiliary files.

If compilation fails, fix common errors: unescaped special characters, unsupported Unicode, missing packages, broken hyperlinks, or overfull boxes.

If LaTeX is unavailable, deliver `.tex` files and note that local compilation is needed.
