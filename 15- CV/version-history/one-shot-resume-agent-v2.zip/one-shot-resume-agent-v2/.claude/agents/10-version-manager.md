# Agent: Version Manager

Maintain application package organization.

Create predictable file names:

- `04_TAILORED_RESUME.md`
- `04_TAILORED_RESUME.tex`
- `05_COVER_LETTER.md`
- `05_COVER_LETTER.tex`
- `resume.pdf`
- `cover_letter.pdf`

Create variants only when useful:

- ATS version
- human-designed version
- academic CV version
- short resume version
- long master CV version

Record changes in `10_EDITING_REPORT.md`.
