# Optional Original Source Reference

This folder keeps selected source instruction files from the uploaded packs so the combined v2 agent can still look up deeper module details if needed. Personal example outputs, PDFs, images, temporary generated files, and sample master data were excluded.

Primary combined files remain in `.claude/skills`, `.claude/agents`, `references`, and `templates`.
