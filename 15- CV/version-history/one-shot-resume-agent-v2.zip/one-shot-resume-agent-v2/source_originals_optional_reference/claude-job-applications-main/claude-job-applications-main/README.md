# AI Job Application Generator with Claude Code

Automatically tailors a resume and cover letter for any job post — as PDFs — using Claude Code and a multi-agent pipeline.

Paste a job post → get two PDFs in `applications/{Company}_{Role}/` in seconds.

---

## How It Works

1. **Job Analyzer** — extracts company name, job type, key skills, and ATS keywords from the post
2. **Resume Tailor** — picks the right bullets and summary from your master data, mirrors ATS keywords
3. **Cover Letter Writer** — writes a targeted, no-fluff cover letter mapped to job requirements
4. **PDF Compiler** — compiles both LaTeX files to PDF and saves them in a named output folder

---

## Project Structure

```
job-applications/
│
├── master_data.yaml              # Your full candidate profile — edit this with your real info
├── master_data_example.yaml      # Starter template — copy to master_data.yaml and fill in
├── rules.md                      # Tone, ATS rules, and tailoring instructions for the agents
│
├── templates/
│   ├── resume.tex                # LaTeX resume template (agents fill the placeholder sections)
│   └── cover_letter.tex          # LaTeX cover letter template (agents fill the placeholder sections)
│
├── applications/                 # Output folder — one subfolder per job application
│   └── Company_JobTitle/
│       ├── your_resume.pdf
│       ├── your_cover_letter.pdf
│       ├── your_resume.tex       # Source kept for reference / re-compilation
│       └── your_cover_letter.tex
│
├── .claude/
│   ├── CLAUDE.md                     # Orchestration instructions — tells Claude how to run the pipeline
│   └── agents/
│       ├── job-analyzer.md           # Extracts structured info from the job post
│       ├── resume-tailor.md          # Fills resume.tex with tailored content
│       ├── cover-letter-writer.md    # Fills cover_letter.tex with tailored content
│       └── pdf-compiler.md           # Runs pdflatex and cleans up aux files
```

---

## Setup

### 1. Install Claude Code

```bash
npm install -g @anthropic/claude-code
```

### 2. Install LaTeX

You need `pdflatex` on your system. Choose one option:

**Option A — BasicTeX (recommended, ~100 MB):**

```bash
# macOS
brew install --cask basictex

# Install the packages used by the default templates
sudo tlmgr update --self
sudo tlmgr install inter xhfill soul fontawesome5 sourcesanspro lastpage fancyhdr enumitem titlesec xcolor geometry hyperref
```

**Option B — Full TeX Live (~4 GB, all packages included — nothing extra to install):**

```bash
# macOS
brew install --cask mactex

# Linux (Debian/Ubuntu)
sudo apt install texlive-full

# Linux (Fedora)
sudo dnf install texlive-scheme-full
```

After installing BasicTeX on macOS, add it to your PATH:

```bash
# Add to ~/.zshrc or ~/.bashrc
export PATH="/Library/TeX/texbin:$PATH"
```

### 3. Fill In Your Data

```bash
cp master_data_example.yaml master_data.yaml
```

Edit `master_data.yaml` with your:
- Personal info (name, location, email, LinkedIn, portfolio)
- Multiple summary variants for different job types (backend, frontend, fullstack, ai_ml)
- Work experience with tagged bullets
- Education, skills, projects, certifications, languages

Each bullet and skill group has `tags` — the agents use these to pick the most relevant content for each job type.

### 4. Update `rules.md`

Edit `rules.md` to describe your profile, tone preferences, and ATS strategy. The agents read this before generating any content.

### 5. Update the Templates

The LaTeX templates in `templates/` have a banner section with the candidate's name and contact links hardcoded. **Update both files with your own name and details:**

- `templates/resume.tex` — find `%====== BANNER ======` and replace the name/links
- `templates/cover_letter.tex` — same

You can also replace the templates entirely with your own LaTeX design. If you do, update the agent files in `.claude/agents/` so they know what placeholders to fill and what structure to follow.

---

## Usage

Open Claude Code in this folder:

```bash
cd job-applications
claude
```

Paste any job post into the chat. The pipeline runs automatically and outputs:

```
applications/CompanyName_JobTitle/
  your_resume.pdf
  your_cover_letter.pdf
  your_resume.tex
  your_cover_letter.tex
```

---

## Customizing

**Agent behavior** — each file in `.claude/agents/` is a plain markdown prompt. Edit them to change how bullets are selected, how the cover letter is structured, what sections are conditional, etc.

**Orchestration order** — defined in `.claude/CLAUDE.md`.

**Output naming** — controlled by `.claude/CLAUDE.md` and the agent files.

---

## Troubleshooting

**`pdflatex: command not found`**

Add TeX to your PATH:
```bash
export PATH="/Library/TeX/texbin:$PATH"
```

**Missing package error during compilation**
```bash
sudo tlmgr install <package-name>
```

**Special character compile error**

Characters like `&`, `%`, `#`, `$` must be escaped in LaTeX: `\&`, `\%`, `\#`, `\$`

**Output looks wrong / wrong summary used**

Check that `master_data.yaml` is fully filled out and that `rules.md` accurately describes your profile and job type preferences.
