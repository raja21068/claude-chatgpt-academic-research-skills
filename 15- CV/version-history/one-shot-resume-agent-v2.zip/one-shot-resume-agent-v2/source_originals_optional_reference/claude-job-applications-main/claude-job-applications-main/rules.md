# ============================================================
# RULES.MD — Agent Instructions
# Claude Code reads this before generating any application docs
# ============================================================

## My Profile
- Software Engineer, 3+ years experience
- Strong in backend (Python, Node.js, TypeScript) and AI/LLM systems
- Also capable in frontend (React, Next.js)
- Based in Norway, open to relocation
- Masters degree from NTNU (AI/ML focus)

## Tone & Voice
- Professional but not stiff — conversational and confident
- Do not use em dash (—) in sentences.
- Avoid buzzword stuffing — only use keywords that genuinely apply
- First person in cover letter ("I built...", "I led...")
- No "I am passionate about" or "I am excited to" — be specific instead
- Keep sentences concise and direct

## ATS Rules
- Mirror exact keywords from the job post (e.g. if they say "REST API" don't write "RESTful services")
- Avoid tables, columns, images in resume (LaTeX template already handles this)
- Use standard section names: Experience, Education, Skills, Projects
- Spell out acronyms at least once if uncommon
- Include both spelled-out and acronym versions of key skills where space allows

