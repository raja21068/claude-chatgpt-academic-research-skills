# Academic CV Prompt

Use the one-shot-resume skill for an academic/research CV.

Create:

- academic CV
- research cover letter
- research fit statement
- publication/status accuracy check
- interview prep for research role
- evidence matrix
- scorecard

Do not list unpublished work as published. Preserve author order and publication status.

Candidate evidence:
[paste]

Role/fellowship/PhD/postdoc description:
[paste]
