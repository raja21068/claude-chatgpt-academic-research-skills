# One-Shot Prompt

Use the one-shot-resume skill.

Target output: full application package.

Create:

- ATS resume
- cover letter
- recruiter/application email
- LinkedIn headline and About section
- interview prep
- evidence matrix
- ATS/recruiter scorecard
- final checklist
- LaTeX and PDF if possible

Rules:

- Do not invent metrics, tools, dates, awards, or experience.
- Use TODO placeholders for missing numbers.
- Keep resume ATS-friendly.
- Use the job description's language only where it fits my real evidence.

Candidate evidence:
[paste resume, CV, profile, projects, achievements]

Job description:
[paste full job post]
