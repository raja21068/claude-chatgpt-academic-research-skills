# Fast Resume-Only Prompt

Use the one-shot-resume skill, but output only:

1. Tailored ATS resume.
2. Evidence matrix.
3. ATS/recruiter scorecard.
4. Missing evidence TODO list.

Candidate evidence:
[paste]

Job description:
[paste]
