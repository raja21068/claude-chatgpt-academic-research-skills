#!/usr/bin/env python3
"""Simple rendered-character checker for resume bullets.
Removes common LaTeX commands and returns approximate rendered character count.
"""
import re
import sys

text = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else sys.stdin.read()
text = re.sub(r"\\(textbf|textit|emph)\{([^{}]*)\}", r"\2", text)
text = re.sub(r"\\href\{[^{}]*\}\{([^{}]*)\}", r"\1", text)
text = re.sub(r"\\[a-zA-Z]+", "", text)
text = re.sub(r"[{}$]", "", text)
text = re.sub(r"\s+", " ", text).strip()
print(len(text))
print(text)
