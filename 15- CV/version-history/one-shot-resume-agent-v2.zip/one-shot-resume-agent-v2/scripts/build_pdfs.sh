#!/usr/bin/env bash
set -euo pipefail
folder="${1:-.}"
cd "$folder"
for f in 04_TAILORED_RESUME.tex 05_COVER_LETTER.tex; do
  if [ -f "$f" ]; then
    pdflatex -interaction=nonstopmode "$f" || true
    pdflatex -interaction=nonstopmode "$f" || true
  fi
done
[ -f 04_TAILORED_RESUME.pdf ] && mv 04_TAILORED_RESUME.pdf resume.pdf
[ -f 05_COVER_LETTER.pdf ] && mv 05_COVER_LETTER.pdf cover_letter.pdf
rm -f *.aux *.log *.out *.fls *.fdb_latexmk
