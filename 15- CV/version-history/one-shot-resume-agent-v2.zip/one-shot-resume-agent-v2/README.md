# One-Shot Resume Agent v2

A combined Claude Code skill/agent pack for generating a full job application package in one run.

## What it creates

- Tailored ATS resume or academic CV
- Cover letter
- Recruiter/application email
- LinkedIn headline and About section
- Interview prep
- Evidence matrix
- Job keyword map
- Gap and red flag plan
- ATS/recruiter scorecard
- Editing report
- Final submission checklist
- Optional LaTeX and PDF files

## Why v2 is stronger

This version combines the strongest parts of four uploaded packs:

1. One-shot job application pipeline.
2. Research/academic CV and anti-fabrication discipline.
3. ResumeSkills modules for ATS, bullets, LinkedIn, interview, portfolio, references, and role variants.
4. Top 10 percent CV workflow with evidence mapping, scorecards, gap handling, and final audit.

## Install in Claude Code

Copy this folder into a project, then use:

```text
Use the one-shot-resume skill.
```

Or copy `.claude/skills/one-shot-resume/SKILL.md` into your Claude skills folder.

## Quick prompt

```text
Use the one-shot-resume skill.
Target output: full application package.
Do not invent metrics. Use TODO placeholders for missing numbers.
Keep resume ATS-friendly and evidence-based.
Create resume, cover letter, recruiter email, LinkedIn update, interview prep, evidence matrix, ATS scorecard, and final checklist.

Candidate evidence:
[paste]

Job description:
[paste]
```

## Folder map

```text
.claude/skills/one-shot-resume/SKILL.md
.claude/agents/
templates/
references/
examples/
workflows/
scripts/
docs/
applications/
```

## Recommended workflow

1. Fill `templates/master_profile_template.yaml` with verified candidate data.
2. Paste job description using `templates/application_intake.md`.
3. Run the one-shot skill.
4. Review TODOs and missing evidence.
5. Compile PDFs with `scripts/build_pdfs.sh` if LaTeX is installed.


## Optional source reference

The folder `source_originals_optional_reference/` includes selected original source instructions from the uploaded packs, excluding sample personal outputs and temporary files. This prevents useful niche modules from being lost while keeping the main v2 skill clean.
