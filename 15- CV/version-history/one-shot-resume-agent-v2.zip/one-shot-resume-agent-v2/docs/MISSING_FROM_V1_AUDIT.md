# Missing From First Merge Audit

The first merged package was useful but incomplete. Rechecking the ZIP contents showed the following important items were underrepresented or missing:

## From claude-job-applications

- PDF compiler agent.
- Output folder naming discipline.
- LaTeX compile troubleshooting.
- Master data style profile workflow.
- Full one-shot pipeline sequence.

## From claude-resume-kit

- Setup and knowledge-base extraction workflow.
- Academic CV generation logic.
- Strict anti-fabrication and provenance rules.
- Critique framework with ATS, recruiter, HR, hiring manager, and technical/academic lenses.
- Character count and page budget controls.
- AI-fingerprint avoidance rules.
- LaTeX templates and compile checks.
- Cover letter hook verification.
- Edit and revise workflow.

## From ResumeSkills

- 20 skill modules, including ATS optimizer, bullet writer, quantifier, formatter, resume tailor, section builder, tech resume, academic CV, executive resume, career changer, LinkedIn, interview prep, offer comparison, portfolio case study, reference list, and salary negotiation.

## From Top10 CV Agent Guidelines

- 12-skill top 10 percent CV workflow.
- Evidence-to-keyword mapping.
- Gap and red flag plan.
- Recruiter reviewer.
- Final submission audit.
- Prompt discipline.
- Templates for scorecard, evidence matrix, bullet upgrade matrix, and final checklist.

## What v2 added

- Comprehensive one-shot SKILL.md.
- 10 subagents.
- Expanded references.
- Templates for every output document.
- Optional PDF build scripts.
- Audit and source coverage matrix.
- Better full-package workflow.
