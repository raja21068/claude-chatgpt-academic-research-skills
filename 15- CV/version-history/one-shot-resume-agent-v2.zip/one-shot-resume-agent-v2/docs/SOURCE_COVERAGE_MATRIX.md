# Source Coverage Matrix

| Source pack | Integrated into v2 |
|---|---|
| claude-job-applications | One-shot pipeline, subagents, output folder, LaTeX/PDF compiler behavior |
| claude-resume-kit | Evidence control, anti-fabrication, academic CV, critique, page/character awareness, cover letter rules |
| ResumeSkills | ATS optimizer, bullet formulas, quantifier, formatter, tailor, LinkedIn, interview, portfolio, references, role variants |
| Top10 CV Agent Guidelines | Top 10 percent strategy, evidence matrix, keyword map, gap plan, recruiter scorecard, final checklist |

## Design choice

The v2 pack does not simply dump all original files into one folder. It consolidates them into a single usable skill plus modular agents, references, templates, workflows, examples, and scripts.


## Optional source reference

The folder `source_originals_optional_reference/` includes selected original source instructions from the uploaded packs, excluding sample personal outputs and temporary files. This prevents useful niche modules from being lost while keeping the main v2 skill clean.
