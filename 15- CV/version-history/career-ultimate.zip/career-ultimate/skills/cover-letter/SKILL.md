---
name: cover-letter
description: "Write an evidence-based, compelling cover letter tailored to a specific job posting. Uses the evaluation and evidence matrix to ensure every claim is backed. Use when someone says 'write a cover letter', 'cover letter for', or after tailoring a resume."
argument-hint: "<company name, 'last' for most recent job, or paste a JD>"
user-invocable: true
allowed-tools:
  - Read
  - Write
  - Glob
  - WebSearch
---

# Cover Letter Writer

Write natural, persuasive cover letters where every proof point maps to real evidence.

Read `references/01-evidence-and-anti-fabrication.md` before writing.

## Step 0: Load Context

1. Read `DATA_DIR/profile.yml` and `DATA_DIR/resume.md`
2. Read `DATA_DIR/profile.md` if it exists (work history interview for richer detail)
3. Find the target job:
   - Check `DATA_DIR/applications/{Company}_{Role}/` for session_context.yaml
   - Check `DATA_DIR/evaluations/` for matching evaluation
   - If "last", use most recent
   - If no evaluation exists, accept a pasted JD

If a full application package exists (from tailor-resume), use:
- `session_context.yaml` for keyword_evidence and gaps
- `02_EVIDENCE_MATRIX.md` for source evidence
- `04_POSITIONING_STRATEGY.md` for role thesis and selling lane

## Step 1: Identify the Narrative

From the evaluation or positioning strategy, determine:
1. **Role thesis:** Why this candidate is credible for this specific role
2. **Top 3 evidence points:** The strongest matches to JD requirements
3. **Key gap (if any):** The biggest weakness to address through framing
4. **Company hook:** Something specific about the company (from research, evaluation, or web search)

## Step 2: Write the Cover Letter

### Structure

**Opening (2-3 sentences):**
- Specific hook about the company (NOT generic "I'm excited to apply")
- Connect the hook to the candidate's experience
- Name the exact role

**Body Paragraph 1 (3-4 sentences):**
- Strongest evidence match to top JD requirement
- Include a specific metric or outcome from proof_points
- Mirror JD language

**Body Paragraph 2 (3-4 sentences):**
- Secondary matches + differentiation
- Show breadth across 2-3 other requirements
- Bridge to what makes this candidate uniquely suited

**Body Paragraph 3 — Gap Bridge (2-3 sentences, if applicable):**
- Address the biggest gap with honest framing
- Show adjacent experience or transferable skills
- Express genuine interest in growing in this area

**Closing (2 sentences):**
- Forward-looking statement connecting to company mission/goals
- Clear, confident call to action

### Rules

- Under 400 words total
- Every proof point maps to evidence matrix or profile
- NEVER fabricate achievements, metrics, or experiences
- Mirror JD language naturally (not keyword stuffing)
- Match the language of the JD (if JD is in German, write in German)
- No em dashes, no buzzwords, no AI-sounding phrases
- Professional but warm — a real person's voice, not a template

## Step 3: Quality Check

Verify against `references/11-ai-fingerprint-polish.md`:
- No overused AI phrases ("leverage", "passionate about", "dynamic")
- No vague claims without evidence
- Specific company details (not interchangeable with any company)
- Natural voice, not template-sounding

## Step 4: Save

Save to `DATA_DIR/applications/{Company}_{Role}/06_COVER_LETTER.md` if pipeline exists.
Otherwise save to `DATA_DIR/jobs/{company-slug}-{date}/cover-letter.md`.

> "Cover letter ready for {role} at {company}.
>
> **Next:** Say 'apply' to fill out the application, or 'outreach for {company}'
> to draft a networking message."
