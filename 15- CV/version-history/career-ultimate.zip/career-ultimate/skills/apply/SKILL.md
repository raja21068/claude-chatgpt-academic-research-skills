---
name: apply
description: "Fill out a job application on Greenhouse, Lever, or Workday using browser automation. Auto-fills forms using your profile, tailored resume, and cover letter. Tracks the application automatically. Use when someone says 'apply to this', 'fill out the application', or 'help me apply'."
argument-hint: "job URL, 'last' to use most recent job, or 'current' to fill the active browser tab"
user-invocable: true
allowed-tools:
  - Read
  - Write
  - Glob
  - Bash
  - WebFetch
  - mcp__claude-in-chrome__tabs_context_mcp
  - mcp__claude-in-chrome__tabs_create_mcp
  - mcp__claude-in-chrome__navigate
  - mcp__claude-in-chrome__read_page
  - mcp__claude-in-chrome__find
  - mcp__claude-in-chrome__form_input
  - mcp__claude-in-chrome__javascript_tool
  - mcp__claude-in-chrome__computer
  - mcp__claude-in-chrome__upload_image
  - mcp__claude-in-chrome__get_page_text
  - mcp__claude-in-chrome__read_console_messages
---

# Apply to a Job

Fill out job application forms on Greenhouse, Lever, and Workday using browser automation.
Read `references/13-browser-setup.md` and `references/14-ats-patterns.md` before starting.

## Step 0: Check Prerequisites

1. Read `DATA_DIR/profile.yml` — required
2. Load `DATA_DIR/application-data.md` if it exists (common form answers)
3. Check for Claude in Chrome browser extension

If no application-data.md, create one in Step 2.

## Step 1: Determine Target Job

Parse `$ARGUMENTS`:

- **URL:** Navigate to the URL
- **"last":** Find the most recent job folder in `DATA_DIR/jobs/` or `DATA_DIR/applications/`
- **"current":** Use the currently active browser tab
- **No argument:** Ask for a URL or show recent evaluations

Load the job's evaluation, tailored resume, and cover letter if they exist.

If no tailored resume exists:
> "I should tailor your resume first for the best results. Want me to
> run the full pipeline? Say 'tailor-resume for {company}'."

## Step 2: Prepare Application Data

Build a field mapping from profile.yml + application-data.md:

```yaml
first_name: ""
last_name: ""
email: ""
phone: ""
location: ""
linkedin_url: ""
website: ""
current_company: ""
current_title: ""
years_experience: ""
education_degree: ""
education_school: ""
work_authorization: ""
salary_expectation: ""
start_date: ""
gender: ""  # optional, only if user provided
veteran_status: ""  # optional
disability_status: ""  # optional
referral_source: ""
cover_letter_text: ""  # from cover letter file
```

If `DATA_DIR/application-data.md` doesn't exist, ask the user for the fields
not in profile.yml (work authorization, EEO data, start date). Save for reuse.

## Step 3: Detect ATS Type

From the URL, detect:
- `boards.greenhouse.io/{slug}` or `{company}.greenhouse.io` → Greenhouse
- `jobs.lever.co/{slug}` → Lever
- `{tenant}.myworkdayjobs.com` or `{tenant}.wd5.myworkdayjobs.com` → Workday
- Other → Unknown

## Step 4: Navigate to Application Form

1. Open the job posting URL in a browser tab
2. Find and click the "Apply" button
3. Wait for the application form to load
4. Read the page to identify all form fields

## Step 5: Map Fields to Values

Read the page and match each form field label to the prepared application data.

For each field:
1. Identify the field type (text input, dropdown, textarea, checkbox, radio, file upload)
2. Find the matching value from application data
3. Build the field mapping: `{label, value, ref, type}`

For fields not in the prepared data:
- If it's a standard EEO/demographic field: use "Prefer not to say" or "Decline to answer"
- If it's a custom question: present it to the user and ask for their answer
- Save new answers to `DATA_DIR/application-data.md` for future use

## Step 6: Fill the Form

Use the form-filling subagent (`scripts/fill-page.md`):

**By ATS type:**

### Greenhouse
- `form_input(tabId, ref, value)` for text inputs and dropdowns
- Handle country/location dropdowns
- Check privacy policy checkbox
- Flag file uploads for manual handling

### Lever
- `form_input(tabId, ref, value)` for text inputs and dropdowns
- Handle comboboxes (location): type value, select from suggestions
- Flag file uploads

### Workday
- `form_input` for text inputs
- Click-based dropdown selection (click → wait → find option → click)
- Search-based hierarchical dropdowns
- `find("Yes")`/`find("No")` + `computer(click)` for radio buttons
- Scroll through multi-page forms
- Flag file uploads

### Unknown ATS
- Try `form_input` first
- Fall back to `computer(click)` + `computer(type)` for resistant fields

## Step 7: Handle Multi-Page Forms

After filling the current page:
1. Review all filled fields
2. Present a summary to the user for approval
3. On approval, click "Next" / "Continue" / "Save and Continue"
4. Read the next page and repeat Steps 5-6
5. Continue until reaching the review/submit page

**NEVER click Submit/Send without explicit user confirmation.**

## Step 8: File Uploads

For resume and cover letter upload fields:
> "I need you to manually upload these files:
> - **Resume:** {path to tailored resume HTML/PDF}
> - **Cover Letter:** {path to cover letter}
>
> Click the upload button for each and select the file. Tell me when done."

## Step 9: Review and Submit

On the final review page:
1. Read all fields and show a summary
2. Highlight any fields that were left blank or need attention
3. Ask: "Everything look good? Say 'submit' to send, or tell me what to change."

**Only click Submit after explicit user confirmation.**

## Step 10: Track the Application

Update `DATA_DIR/applications.md`:

| Date Added | Date Applied | Company | Role | Score | Status | Evaluation | Notes |
|---|---|---|---|---|---|---|---|
| {date} | {today} | {company} | {role} | {score} | Applied | [View](...) | Auto-applied via browser |

> "Application submitted for {role} at {company}!
>
> **Next steps:**
> - Set a follow-up reminder for 1 week
> - Say 'outreach for {company}' to draft a networking message
> - Say 'track' to see your full pipeline"
