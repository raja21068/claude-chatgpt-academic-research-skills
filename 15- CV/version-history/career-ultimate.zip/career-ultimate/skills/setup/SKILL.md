---
name: setup
description: "One-time onboarding: paste your resume, configure job preferences, import LinkedIn contacts, and complete a work-history interview. Use when someone says 'set up my profile', 'get started', or is using the plugin for the first time."
argument-hint: ""
user-invocable: true
allowed-tools:
  - Read
  - Write
  - Glob
  - Bash
---

# Profile Setup

One-time onboarding that builds a comprehensive profile for all other skills to use.
Data is stored at `~/.career-ultimate/` (the DATA_DIR).

## Step 0: Check Existing Profile

If `DATA_DIR/profile.yml` exists, show a summary and ask:
> "You already have a profile set up. Want to update it, or start fresh?"

## Step 1: Resume Upload

Ask the user to paste their resume or provide a file path.

Save raw resume text to `DATA_DIR/resume.md`.
If a file is provided, copy it to `DATA_DIR/resume/`.

## Step 2: Parse Resume into Structured Profile

Extract and save to `DATA_DIR/profile.yml`:

```yaml
name: ""
email: ""
phone: ""
location: ""
current_role: ""
current_company: ""

target_roles:
  primary: ""
  secondary: []
seniority: ""  # entry | mid | senior | lead | director | vp | c-suite
industries: []

work_history:
  - company: ""
    title: ""
    dates: ""
    highlights: []
    proof_points: []  # quantified achievements

education:
  - degree: ""
    institution: ""
    year: ""

skills:
  technical: []
  tools: []
  methods: []
  soft: []

credentials: []  # certifications, licenses, bar admissions

publications: []  # for academic/research roles

compensation:
  target: ""
  minimum: ""
  currency: ""

preferences:
  remote: ""  # remote | hybrid | onsite | flexible
  locations: []
  exclude_keywords: []
  must_haves: []
  dealbreakers: []
  nice_to_haves: []

narrative:
  headline: ""  # one-line positioning statement
  selling_lane: ""  # from elite positioning engine
```

## Step 3: Work History Interview

Run the work-history interview per `scripts/conduct-interview.md`.

For each role in their history, probe for:
- Specific accomplishments with numbers
- Tools and technologies used
- Team size and scope
- Key projects and outcomes
- Leadership or mentorship examples

Update `DATA_DIR/profile.yml` with enriched proof_points.
Save the detailed interview transcript to `DATA_DIR/profile.md`.

## Step 4: Job Preferences

Ask about:
1. Target roles (primary + secondary)
2. Industries of interest
3. Location/remote preferences
4. Compensation expectations
5. Dealbreakers (e.g., no travel, no startups, must sponsor visa)
6. Nice-to-haves (e.g., equity, learning budget, specific tech stack)

Save to `DATA_DIR/preferences.md` AND update `DATA_DIR/profile.yml`.

## Step 5: LinkedIn Contacts (Optional)

> "Do you have a LinkedIn contacts export? It lets me scan your network's
> companies for job openings. You can export it from LinkedIn Settings >
> Data Privacy > Get a copy of your data > Connections."

If provided, copy to `DATA_DIR/linkedin-contacts.csv`.

## Step 6: Summary

Show a summary of what was captured:

```
## Profile Ready

**Name:** {name}
**Current:** {role} at {company}
**Target:** {primary target role}
**Seniority:** {level}
**Location:** {preference}
**Key Skills:** {top 5}
**Proof Points:** {count} quantified achievements captured

### What You Can Do Now
- **Evaluate a job:** Paste a job posting
- **Scan for jobs:** "scan {company}" or "scan my watchlist"
- **Network scan:** "network-scan" (requires LinkedIn contacts)
- **Help:** See all available commands
```
