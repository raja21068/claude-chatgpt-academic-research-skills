# Attribution

career-ultimate combines and extends work from three open-source projects:

## One-Shot Elite CV Agent v5
- **What we used:** 12-stage chained pipeline, session_context.yaml architecture, evidence matrix, keyword evidence table, computed match scoring formula, anti-fabrication rules, ATS parse simulator, style linter, claim marker checker, bullet writing rules, elite positioning engine, recruiter psychology reference, AI fingerprint polish, review rubrics, operating principles, LaTeX templates
- **License:** Personal use

## career-ops by Andrew Shwetzer
- **Repository:** https://github.com/andrewshwetzer/career-ops-plugin
- **What we used:** A-F evaluation blocks, 15 industry archetypes with detection algorithm and evaluation lenses, scoring rubric with archetype weight adjustments and PASS/FAIL credential rules, persona modifiers, scan skill (ATS endpoint detection, site-scoped search strategy), track skill (application tracker with state machine), compare skill (side-by-side comparison with recommendation), research skill (company intelligence brief), outreach skill (hook + proof + proposal structure), ATS rules for HTML resume output, profile schema, state transitions
- **License:** MIT

## Proficiently by Proficiently
- **Repository:** https://github.com/proficientlyjobs/proficiently-claude-skills
- **What we used:** Apply skill (browser-based ATS form filling for Greenhouse, Lever, Workday), form-filling subagent architecture, network-scan skill (LinkedIn contacts → company careers → job matching), careers page resolver with parallel subagents, Telegram bot integration, browser setup reference, ATS navigation patterns, fit scoring criteria, priority hierarchy, profile template, onboarding interview script
- **License:** MIT
