# Multi-ATS Platform Awareness

Different Applicant Tracking Systems parse resumes differently. This reference encodes platform-specific quirks so the resume can be tuned per platform when the target ATS is known. Default to the most conservative ruleset across all platforms when the ATS is unknown.

## Common ATS platforms and parsing quirks

### Workday
- **Header detection**: relies on standard section names. Use `Experience`, `Education`, `Skills`, `Projects` — not creative variants like "Where I've Been".
- **Date parsing**: prefers `Month Year – Month Year` (`Jun 2024 – Jul 2025`). Mixed formats break role timelines.
- **Tables**: silently breaks multi-column tables. Single-column only.
- **Bullet symbols**: `•` and `-` are safe. Avoid `▪`, `◆`, `→`, custom symbols.
- **Contact in header/footer**: Workday often does not parse text inside PDF header/footer regions. Keep contact at the top of the body.

### Greenhouse
- **PDF-first**: handles well-structured PDFs reliably. DOCX support is good but PDF is canonical.
- **Skill matching**: tokenizes skills aggressively; "PyTorch" and "Py Torch" are different matches. Use canonical spelling.
- **Custom questions**: many Greenhouse roles add questions outside the resume. Tailor cover letter to anticipate them.

### Taleo (Oracle)
- **Aggressive keyword extraction**: rewards exact-phrase matches from the JD. Lower-cases everything, strips punctuation.
- **Section parsing**: weaker than Workday. Use explicit `EXPERIENCE` section headings, not just bold formatting.
- **Acronyms**: expand at first use — "Institutional Review Board (IRB)" — because Taleo's keyword expander is unreliable.
- **Two-column layouts**: read top-down per column, often scrambling the order. Single column required.

### iCIMS
- **DOCX preferred over PDF** for parsing fidelity in many iCIMS configurations.
- **Skill blocks**: pulls a structured Skills section reliably when categorized (`Languages:`, `Frameworks:`).
- **Education parsing**: expects `Degree, Institution, Year` order.

### Lever
- **Light-touch parser**: less aggressive than Workday/Taleo. Recruiters often read directly.
- **Cover letter weight is higher** because Lever surfaces the cover letter prominently to reviewers.

### SmartRecruiters
- **Mid-tier parsing**: similar to iCIMS. Standard section names matter.

### Ashby (research labs, AI startups)
- **Often used by ML/AI labs**: parses well but recruiters read directly.
- **Publications and links matter**: hyperlinks in PDF are preserved and used.

### Bullhorn (agency/staffing)
- **Skill-heavy matching**: surface a comprehensive Skills section near the top.

### BambooHR / JazzHR (smaller employers)
- **Lower parsing fidelity**: keep formatting maximally simple.

## Cross-platform safe defaults

When the target ATS is unknown, apply ALL of these:

1. Single-column layout for the entire document.
2. Standard section names from references/02.
3. Contact information in the body, not in the PDF header or footer.
4. No tables containing experience, projects, or publications.
5. Bullets use `•` or `-` only.
6. Dates in `Mon YYYY – Mon YYYY` format throughout.
7. Acronyms expanded at first use, then abbreviated.
8. File saved as PDF generated from text (not scanned, not flattened to image).
9. File name: `Lastname_Firstname_Resume.pdf` or `Lastname_Firstname_CV.pdf`.
10. Fonts: Calibri, Arial, Helvetica, Garamond, or Computer Modern. Size 10–11 pt body.
11. No icons in the contact line. No progress bars. No skill rating stars.
12. Hyperlinks present but the URL text also visible in plain form for parsers that strip hyperlink metadata.

## ATS detection from the job posting

Clues that reveal the ATS in use:

- URL pattern `*.myworkdayjobs.com` → Workday.
- URL pattern `boards.greenhouse.io/*` or `jobs.lever.co/*` → Greenhouse or Lever.
- URL pattern `*.taleo.net` → Taleo.
- URL pattern `careers-*.icims.com` → iCIMS.
- URL pattern `jobs.ashbyhq.com/*` → Ashby.
- URL pattern `*.smartrecruiters.com` → SmartRecruiters.

Record the detected ATS in `session_context.yaml` under `target_ats`. Apply platform-specific rules from the section above in addition to the cross-platform safe defaults.

## What this reference does NOT do

This reference does not run an ATS parser. Use `scripts/ats_parse_simulator.py` to test whether sections, dates, and skills are extractable in a deterministic way before exporting.
