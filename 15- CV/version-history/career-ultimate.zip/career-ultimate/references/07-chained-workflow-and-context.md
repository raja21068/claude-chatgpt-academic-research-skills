# Chained Workflow and Session Context

This reference defines how the v5 pipeline carries state across stages so each stage builds on verified output from the previous stage instead of re-guessing from scratch.

## The session_context.yaml file

A single file at `applications/{Company}_{Role}/session_context.yaml` is created at intake and updated by every stage. Every subsequent stage MUST read this file before generating output.

Schema:

```yaml
session_id: "{Company}_{Role}_{YYYYMMDD}"
created: "{ISO_DATE}"
last_updated: "{ISO_DATE}"

# Stage 1: Auto-detect from CV + JD
role_profile:
  detected_role_family: ""        # research | postdoc | phd_student | research_engineer | data_scientist | clinical_ai | software_engineer | other
  detected_domain: []             # [medical_ai, nlp, cv, security, ...]
  detected_seniority: ""          # early | mid | senior | faculty
  publication_weight: ""          # high | medium | low
  ats_vs_human_priority: ""       # ats_first | balanced | human_first
  target_country: ""              # affects CV conventions
  target_ats: ""                  # workday | greenhouse | taleo | icims | lever | ashby | unknown
  detection_confidence: 0.0       # 0.0 to 1.0

# Stage 2: JD deconstruction
jd_keywords:
  tier_1_must_have: []            # required, repeated, screening-level
  tier_2_preferred: []            # nice-to-have, preferred quals
  tier_3_culture: []              # culture, soft, general
  domain_jargon: []               # IRB, HIPAA, PHI, etc. from reference 18
  tools: []
  methods: []

# Stage 3: CV evidence inventory
cv_evidence:
  confirmed_skills: []            # actually demonstrated with project/role
  listed_only_skills: []          # in skills section but no bullet shows use
  publications:
    first_author: 0
    co_first_author: 0
    co_author: 0
    preprints: 0
  funding_evidence: []
  irb_evidence: ""                # none | adjacent | confirmed_protocol
  compliance_training: []         # CITI, GCP, HIPAA training, etc.

# Stage 4: Keyword evidence table (the honest scoring)
keyword_evidence:
  - keyword: ""
    tier: 1                       # 1, 2, or 3
    found_in_cv: false
    location: ""                  # bullet, skills, projects, education, none
    strength: ""                  # strong | weak | partial | missing
    placement_decision: ""        # surface_in_summary | bullet_rewrite | skills_section | cover_letter | omit

# Stage 5: Computed match score (from keyword_evidence above)
match_score:
  tier_1_coverage: 0.0
  tier_2_coverage: 0.0
  tier_3_coverage: 0.0
  weighted_score: 0.0             # see scoring formula below
  band: ""                        # strong | competitive | possible | stretch
  computed_at: ""

# Stage 6: Gaps and risks
gaps:
  hard_blockers: []               # citizenship, clearance, degree-not-yet-completed
  soft_gaps: []                   # missing tools that can be addressed in cover letter
  framing_opportunities: []       # candidate has X which can be reframed as Y

# Stage 7: Tracks what's been generated
artifacts_generated:
  - filename: ""
    stage: ""
    timestamp: ""
```

## Stage order and contract

Each stage has a strict contract: read `session_context.yaml`, do exactly one job, update `session_context.yaml`, produce exactly one artifact file.

| # | Stage | Reads | Writes | Output artifact |
|---|---|---|---|---|
| 1 | `auto_profile_detector` | CV + JD raw | `role_profile` block | `00_INPUT_SUMMARY.md` |
| 2 | `jd_deconstructor` | JD raw + `role_profile` | `jd_keywords` block | `01_JOB_ANALYSIS.md` |
| 3 | `cv_evidence_extractor` | CV raw + `role_profile` | `cv_evidence` block | `02_EVIDENCE_MATRIX.md` |
| 4 | `keyword_evidence_mapper` | `jd_keywords` + `cv_evidence` | `keyword_evidence` rows | `03_KEYWORD_EVIDENCE_TABLE.md` |
| 5 | `match_scorer` | `keyword_evidence` | `match_score` block | included in `11_SCORECARD.md` |
| 6 | `positioning_strategist` | all above | `gaps`, role thesis | `04_POSITIONING_STRATEGY.md` |
| 7 | `resume_writer` | all above | — | `05_TAILORED_RESUME.md` |
| 8 | `ats_parse_simulator` | `05_TAILORED_RESUME.md` | parse report | `05a_ATS_PARSE_REPORT.md` |
| 9 | `cover_letter_writer` | all above | — | `06_COVER_LETTER.md` |
| 10 | `supporting_assets` | all above | — | `07_EMAIL.md`, `08_LINKEDIN.md`, `09_INTERVIEW_PREP.md` |
| 11 | `self_auditor` | all artifacts | issue list | `10_AUDIT_REPORT.md` |
| 12 | `final_review_board` | all artifacts | scorecard | `11_SCORECARD.md` |

## Match scoring formula (computed, not guessed)

```text
tier_1_coverage = (sum of strengths in Tier 1) / (count of Tier 1 keywords)
tier_2_coverage = (sum of strengths in Tier 2) / (count of Tier 2 keywords)
tier_3_coverage = (sum of strengths in Tier 3) / (count of Tier 3 keywords)

where strength contributes:
  strong  = 1.0
  partial = 0.5
  weak    = 0.25
  missing = 0.0

weighted_score = 100 * (
  0.60 * tier_1_coverage +
  0.30 * tier_2_coverage +
  0.10 * tier_3_coverage
)
```

The score is computed deterministically by `scripts/compute_match_score.py` from the `keyword_evidence` block. It is never invented by the LLM.

## Why this is more honest than v4

- v4 asked the LLM to estimate a match score. v5 computes it from a verifiable table.
- v4 produced isolated keyword lists per stage. v5 carries one shared evidence table.
- v4 did not distinguish "listed in Skills" from "demonstrated in a bullet." v5 does.
- v4 had no ATS parse step. v5 simulates parsing and produces a report before export.

## When session_context.yaml does not yet exist

The orchestrator creates it from `templates/session_context.yaml` on the first invocation for a given `{Company}_{Role}` directory. Subsequent stages read and update — they do not recreate.
