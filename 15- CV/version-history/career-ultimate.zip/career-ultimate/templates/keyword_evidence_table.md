# Keyword Evidence Table — {Company} / {Role}

This table is the single source of truth for match scoring. Every keyword from the
job description is mapped to candidate evidence with a strength label. The
computed match score is derived from this table by `scripts/compute_match_score.py`
— it is never invented or estimated.

## Strength labels

- **strong**: the keyword is demonstrated in a specific bullet with action + outcome.
- **partial**: the keyword appears in the CV but only in a skills list or course mention with no demonstrated outcome.
- **weak**: only adjacent evidence (e.g. used a related tool, same methodology family).
- **missing**: no evidence in the CV.

## Placement decisions

- **surface_in_summary**: pull into the 2–4 line role summary at the top.
- **bullet_rewrite**: rewrite or add a bullet that demonstrates this keyword.
- **skills_section**: add to skills only if truthful and not already present.
- **cover_letter**: address in cover letter, especially for gaps.
- **omit**: not relevant or unsupported; do not insert.

## Table

| Keyword | Tier | Found in CV? | Location | Strength | Placement decision |
|---|---:|:---:|---|---|---|
| {keyword_1} | 1 | ✅/❌ | {section: specifics} | strong/partial/weak/missing | {placement} |
| {keyword_2} | 1 | ✅/❌ | {section: specifics} | strong/partial/weak/missing | {placement} |
| {keyword_3} | 2 | ✅/❌ | {section: specifics} | strong/partial/weak/missing | {placement} |

## Computed match summary

To be filled by `scripts/compute_match_score.py` after the table is complete:

```text
Tier 1 coverage:  __ / __  (__%)
Tier 2 coverage:  __ / __  (__%)
Tier 3 coverage:  __ / __  (__%)
Weighted score:   __ / 100
Band:             {strong | competitive | possible | stretch}
```

## Rules

1. Do **not** mark a keyword "strong" unless there is a specific bullet, role, or
   project that demonstrates it with an outcome. "Listed in Skills" alone is at
   most **partial**.
2. Do **not** invent strength to inflate the score. The score is for the
   candidate's strategic awareness, not for the recruiter.
3. If the JD uses jargon from `references/18-academic-research-compliance.md`
   (IRB, HIPAA, GCP, etc.), treat that jargon as Tier 1 unless the JD context
   clearly demotes it.
4. When in doubt between two strength labels, choose the lower one.
