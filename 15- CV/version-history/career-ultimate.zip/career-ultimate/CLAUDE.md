# career-ultimate — Master Configuration

## Overview

career-ultimate is a unified career agent combining:
- **Elite document generation** (12-stage chained pipeline with computed scoring and anti-fabrication)
- **Full job-search operations** (15 industry archetypes, evaluation, scanning, tracking, comparison)
- **Browser automation** (ATS form filling on Greenhouse/Lever/Workday, LinkedIn network scanning)

## Data Directory

All user data is stored at `~/.career-ultimate/` (the DATA_DIR).

```
~/.career-ultimate/
├── profile.yml              # Structured profile (from setup)
├── resume.md                # Raw resume text
├── resume/                  # Resume file (PDF/DOCX)
├── profile.md               # Work history interview transcript
├── preferences.md           # Job preferences and dealbreakers
├── application-data.md      # Common form answers (for apply skill)
├── applications.md          # Application tracker table
├── pipeline.md              # Scanned job pipeline
├── scan-history.md          # Dedup log for scanned postings
├── linkedin-contacts.csv    # LinkedIn contacts export
├── company-careers.json     # Cached company careers URLs
├── network-scan-history.md  # Network scan results log
├── evaluations/             # Job evaluations (one per posting)
├── applications/            # Full application packages (from tailor-resume)
│   └── {Company}_{Role}/
│       ├── session_context.yaml
│       ├── 00_INPUT_SUMMARY.md
│       ├── ...
│       └── 11_SCORECARD.md
├── jobs/                    # Job folders (from scan/network-scan)
│   └── {company-slug}-{date}/
│       ├── posting.md
│       ├── tailored-resume.html
│       └── cover-letter.md
└── research/                # Company research briefs
```

## Routing

When the user's intent is ambiguous, use this priority:
1. If they paste a JD or URL → **evaluate**
2. If they say "tailor" or "resume" → **tailor-resume**
3. If they say "apply" or "fill out" → **apply**
4. If they say "scan" or "find jobs" → **scan**
5. If they say "track" or "my applications" → **track**
6. If no profile exists → **setup** first

## Cross-Skill Integration

Skills share data through DATA_DIR:
- **evaluate** → saves to `evaluations/`, updates `applications.md`
- **tailor-resume** → reads `evaluations/`, writes full package to `applications/`
- **cover-letter** → reads `evaluations/` + `applications/` package
- **apply** → reads `profile.yml` + `applications/` package, fills browser forms
- **scan** → writes to `pipeline.md` and `scan-history.md`
- **track** → reads/writes `applications.md`
- **compare** → reads `evaluations/`
- **research** → writes to `research/`
- **outreach** → reads `research/` + `evaluations/`
- **network-scan** → reads `linkedin-contacts.csv`, writes `company-careers.json`

## Non-Negotiable Rules

1. **Never fabricate.** Every claim maps to evidence or gets `[TODO: verify]`.
2. **Computed, not estimated.** Match scores come from the keyword evidence table formula.
3. **Honest scoring.** A 3.2 is real. Below 3.0 means "don't apply here."
4. **PASS/FAIL for regulated industries.** Missing a required license caps score at 2.0.
5. **User confirms before submitting.** Never click Submit without explicit approval.
