#!/usr/bin/env python3
"""Compute a deterministic, tier-weighted match score from a keyword evidence table.

This script replaces v4's `score_keyword_coverage.py` simple presence check.
It reads either:

  (a) session_context.yaml — preferred; reads the `keyword_evidence` block.
  (b) a CSV file with columns: keyword, tier, strength

and writes:

  - match_score block in session_context.yaml (if YAML mode), or
  - a printed report (CSV mode).

Strength → numeric contribution:

    strong  = 1.00
    partial = 0.50
    weak    = 0.25
    missing = 0.00

Tier weights in the final score:

    tier_1 = 0.60
    tier_2 = 0.30
    tier_3 = 0.10

Bands:

    >= 85  : strong
    70-84  : competitive
    55-69  : possible
    < 55   : stretch

Usage:
    python scripts/compute_match_score.py applications/Acme_RS/session_context.yaml
    python scripts/compute_match_score.py keyword_evidence.csv
"""
from __future__ import annotations

import csv
import datetime as _dt
import json
import sys
from pathlib import Path
from typing import Any

STRENGTH_WEIGHTS = {"strong": 1.0, "partial": 0.5, "weak": 0.25, "missing": 0.0}
TIER_WEIGHTS = {1: 0.60, 2: 0.30, 3: 0.10}


def band_for(score: float) -> str:
    if score >= 85:
        return "strong"
    if score >= 70:
        return "competitive"
    if score >= 55:
        return "possible"
    return "stretch"


def compute(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Compute tier coverage and weighted score from evidence rows.

    Each row needs keys: tier (1/2/3), strength (strong/partial/weak/missing).
    """
    by_tier: dict[int, list[float]] = {1: [], 2: [], 3: []}
    for r in rows:
        try:
            tier = int(r.get("tier", 0))
        except (TypeError, ValueError):
            continue
        if tier not in by_tier:
            continue
        strength = str(r.get("strength", "missing")).lower().strip()
        by_tier[tier].append(STRENGTH_WEIGHTS.get(strength, 0.0))

    coverage = {}
    for t, vals in by_tier.items():
        coverage[t] = (sum(vals) / len(vals)) if vals else 0.0

    weighted = 100.0 * sum(TIER_WEIGHTS[t] * coverage[t] for t in (1, 2, 3))

    return {
        "tier_1_coverage": round(coverage[1], 4),
        "tier_2_coverage": round(coverage[2], 4),
        "tier_3_coverage": round(coverage[3], 4),
        "weighted_score": round(weighted, 2),
        "band": band_for(weighted),
        "computed_at": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "tier_counts": {t: len(by_tier[t]) for t in (1, 2, 3)},
    }


def _try_yaml_mode(path: Path) -> bool:
    try:
        import yaml  # type: ignore
    except ImportError:
        print(
            "PyYAML not installed. Install with: pip install pyyaml --break-system-packages",
            file=sys.stderr,
        )
        return False

    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    rows = data.get("keyword_evidence") or []
    if not rows:
        print(f"No keyword_evidence rows found in {path}.", file=sys.stderr)
        return False

    result = compute(rows)
    data["match_score"] = {
        "tier_1_coverage": result["tier_1_coverage"],
        "tier_2_coverage": result["tier_2_coverage"],
        "tier_3_coverage": result["tier_3_coverage"],
        "weighted_score": result["weighted_score"],
        "band": result["band"],
        "computed_at": result["computed_at"],
    }
    path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")

    print(f"Updated {path}")
    print(json.dumps(result, indent=2))
    return True


def _csv_mode(path: Path) -> None:
    rows: list[dict[str, Any]] = []
    with path.open(newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            rows.append(r)
    if not rows:
        print(f"No rows in {path}.", file=sys.stderr)
        sys.exit(2)
    print(json.dumps(compute(rows), indent=2))


def main(argv: list[str]) -> None:
    if len(argv) != 2:
        print(__doc__)
        sys.exit(2)
    path = Path(argv[1])
    if not path.exists():
        print(f"File not found: {path}", file=sys.stderr)
        sys.exit(2)
    if path.suffix.lower() in {".yaml", ".yml"}:
        ok = _try_yaml_mode(path)
        if not ok:
            sys.exit(1)
    elif path.suffix.lower() == ".csv":
        _csv_mode(path)
    else:
        print("Unsupported file type. Use .yaml/.yml or .csv.", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main(sys.argv)
