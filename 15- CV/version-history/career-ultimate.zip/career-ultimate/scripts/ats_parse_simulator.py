#!/usr/bin/env python3
"""ATS parse simulator.

Simulates what a generic ATS parser would extract from a Markdown resume.
This is a deterministic, rule-based check — not a real parser. Its purpose
is to flag formatting that is likely to break parsing across the major ATS
platforms (Workday, Greenhouse, Taleo, iCIMS).

Checks performed:

1. Section detection: are required canonical sections present?
2. Date format consistency: are all date ranges in `Mon YYYY – Mon YYYY` form?
3. Forbidden formatting: tables in experience, columns, header/footer contact,
   non-standard bullet symbols.
4. Acronym hygiene: are acronyms (IRB, HIPAA, GCP, etc.) expanded at first use?
5. Contact line: presence of email and phone in the body (not header/footer).
6. Skill list extraction: can a Skills section be cleanly tokenized?
7. Hyperlinks: do hyperlinked items also have visible plain-text URLs?

Output:
  Prints a parse report to stdout. Exits 0 on success, 1 if any
  blocking issue is found.

Usage:
    python scripts/ats_parse_simulator.py applications/Acme_RS/05_TAILORED_RESUME.md
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

CANONICAL_SECTIONS = {
    "summary",
    "education",
    "experience",
    "research experience",
    "projects",
    "skills",
    "technical skills",
    "publications",
    "certifications",
    "awards",
    "leadership",
}
REQUIRED_FOR_MOST = {"education", "experience"}  # at minimum
REQUIRED_FOR_ACADEMIC = {"education", "publications"}  # academic CV

DATE_RANGE_GOOD = re.compile(
    r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4}\s*[–-]\s*"
    r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|Present|Current|Expected\s+\w+)\s*\d{0,4}\b",
    re.IGNORECASE,
)
DATE_RANGE_AMBIGUOUS = re.compile(r"\b\d{1,2}/\d{1,2}/\d{2,4}\b|\b\d{4}\s*-\s*\d{4}\b")

BAD_BULLETS = ["▪", "◆", "→", "✓", "✔", "✗", "★", "►"]
COMPLIANCE_ACRONYMS = ["IRB", "HIPAA", "PHI", "GCP", "PHI", "GDPR", "DUA", "BAA", "DPIA", "AE", "SAE", "CRF"]

EMAIL_RE = re.compile(r"\b[\w._%+-]+@[\w.-]+\.[A-Za-z]{2,}\b")
PHONE_RE = re.compile(r"(?:\+?\d{1,3}[\s.-]?)?\(?\d{2,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,4}")
URL_RE = re.compile(r"https?://\S+")
MD_LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")


def find_sections(text: str) -> set[str]:
    found: set[str] = set()
    for line in text.splitlines():
        s = line.strip().lower().lstrip("#").strip()
        s = s.rstrip(":")
        if s in CANONICAL_SECTIONS:
            found.add(s)
    return found


def check_dates(text: str) -> tuple[int, int]:
    good = len(DATE_RANGE_GOOD.findall(text))
    ambig = len(DATE_RANGE_AMBIGUOUS.findall(text))
    return good, ambig


def check_tables(text: str) -> int:
    """Count Markdown-style pipe tables. Tables in experience are an ATS risk."""
    return sum(1 for line in text.splitlines() if line.strip().startswith("|") and line.count("|") >= 2)


def check_bullets(text: str) -> list[str]:
    found = []
    for sym in BAD_BULLETS:
        if sym in text:
            found.append(sym)
    return found


def check_acronyms(text: str) -> list[str]:
    """Flag compliance acronyms that appear without expansion on first occurrence."""
    issues = []
    lower = text.lower()
    for ac in COMPLIANCE_ACRONYMS:
        idx = text.find(ac)
        if idx == -1:
            continue
        # check the 80 chars before first occurrence for an expansion pattern like "Word Word (AC)"
        window = text[max(0, idx - 80) : idx + len(ac) + 1]
        # Look for "(AC)" pattern indicating expansion just happened
        if f"({ac})" not in window:
            issues.append(ac)
    return issues


def check_contact(text: str) -> dict[str, bool]:
    # Treat the first 25 lines as the "header zone" body
    head = "\n".join(text.splitlines()[:25])
    return {
        "email_in_body": bool(EMAIL_RE.search(head)),
        "phone_in_body": bool(PHONE_RE.search(head)),
    }


def check_skills_section(text: str) -> dict[str, object]:
    # Find a Skills or Technical Skills section and assess parsability
    lines = text.splitlines()
    in_section = False
    section_lines: list[str] = []
    for line in lines:
        s = line.strip().lower().lstrip("#").strip().rstrip(":")
        if s in {"skills", "technical skills"}:
            in_section = True
            continue
        if in_section:
            if line.startswith("#") or (s in CANONICAL_SECTIONS):
                break
            section_lines.append(line)
    raw = "\n".join(section_lines).strip()
    has_categories = any(":" in ln for ln in section_lines if ln.strip())
    token_count = len(re.split(r"[,;\n]", raw)) if raw else 0
    return {
        "present": bool(raw),
        "has_categories": has_categories,
        "approx_token_count": token_count,
    }


def check_hyperlinks(text: str) -> list[str]:
    """Flag Markdown links where the visible label is just 'here' or 'link' — ATS may not store URL."""
    issues = []
    for m in MD_LINK_RE.finditer(text):
        label = m.group(1).strip().lower()
        url = m.group(2)
        if label in {"here", "link", "click", "click here", "see"}:
            issues.append(f"Opaque link label `{label}` → {url}")
    return issues


def detect_role_family(sections: set[str]) -> str:
    """Heuristic: presence of 'publications' or 'research experience' implies academic CV."""
    if "publications" in sections or "research experience" in sections:
        return "academic"
    return "industry"


def report(path: Path) -> int:
    text = path.read_text(encoding="utf-8")
    sections = find_sections(text)
    role = detect_role_family(sections)
    required = REQUIRED_FOR_ACADEMIC if role == "academic" else REQUIRED_FOR_MOST
    missing_sections = required - sections

    good_dates, ambig_dates = check_dates(text)
    bad_bullet_syms = check_bullets(text)
    acronym_issues = check_acronyms(text)
    contact = check_contact(text)
    skills = check_skills_section(text)
    link_issues = check_hyperlinks(text)
    table_lines = check_tables(text)

    issues: list[str] = []
    if missing_sections:
        issues.append(f"BLOCKER: missing required sections: {sorted(missing_sections)}")
    if ambig_dates:
        issues.append(f"WARNING: {ambig_dates} ambiguous date format(s) found (use 'Mon YYYY – Mon YYYY').")
    if bad_bullet_syms:
        issues.append(f"WARNING: non-standard bullet symbols: {bad_bullet_syms}")
    if acronym_issues:
        issues.append(f"WARNING: compliance acronyms used without expansion at first use: {acronym_issues}")
    if not contact["email_in_body"]:
        issues.append("BLOCKER: no email address found in the body / top of resume.")
    if not contact["phone_in_body"]:
        issues.append("WARNING: no phone number found in the body / top of resume.")
    if table_lines >= 4:
        issues.append(f"WARNING: {table_lines} table lines detected — verify they are not in Experience.")
    if not skills["present"]:
        issues.append("WARNING: no Skills or Technical Skills section detected.")
    if link_issues:
        for li in link_issues:
            issues.append(f"WARNING: {li}")

    print("=" * 60)
    print(f"ATS Parse Report — {path.name}")
    print("=" * 60)
    print(f"Detected role family : {role}")
    print(f"Sections found       : {sorted(sections)}")
    print(f"Date ranges (good)   : {good_dates}")
    print(f"Date ranges (ambig)  : {ambig_dates}")
    print(f"Skills section       : {skills}")
    print(f"Contact in body      : {contact}")
    print(f"Table lines (any)    : {table_lines}")
    print()
    if not issues:
        print("PASS: no blocking issues detected.")
        return 0
    print("Issues:")
    blocker = False
    for i in issues:
        print(f"  - {i}")
        if i.startswith("BLOCKER"):
            blocker = True
    return 1 if blocker else 0


def main(argv: list[str]) -> None:
    if len(argv) != 2:
        print(__doc__)
        sys.exit(2)
    p = Path(argv[1])
    if not p.exists():
        print(f"File not found: {p}", file=sys.stderr)
        sys.exit(2)
    sys.exit(report(p))


if __name__ == "__main__":
    main(sys.argv)
