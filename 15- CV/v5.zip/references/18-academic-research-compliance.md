# Academic and Research Compliance Vocabulary

This reference encodes the compliance, ethics, and methodology vocabulary expected on academic, research scientist, postdoc, medical AI, and clinical-adjacent CVs. Use it when the detected role family is `research`, `phd`, `postdoc`, `medical_ai`, `clinical_ai`, or `regulated_data`.

## IRB and human-subjects research

Surface evidence of one or more of:

- **IRB protocol** authorship, contribution, or named role on an approved protocol.
- **IRB submission** or **continuing review** participation.
- **Informed consent** instrument design or administration.
- **Protocol amendment** experience.
- **Vulnerable population** considerations (pediatric, prisoners, pregnant individuals) when applicable.
- **Exempt vs Expedited vs Full Board** review category, when known.

If the JD names IRB, surface this section above general "Skills". If the candidate has IRB-adjacent experience but no formal protocol authorship, label it carefully:

- **Confirmed**: "Co-author on IRB protocol #XYZ at Institution."
- **Derived**: "Worked on de-identified clinical data under an approved IRB protocol led by PI."
- **Excluded**: do not write "IRB experience" when only the dataset was IRB-approved by someone else.

## HIPAA and PHI (US health data)

Vocabulary that recruiters search for:

- **HIPAA Privacy Rule**, **HIPAA Security Rule**, **HITECH Act**.
- **PHI** (Protected Health Information) handling.
- **De-identification** under Safe Harbor (45 CFR 164.514(b)(2)) or Expert Determination.
- **Limited Data Set** and **Data Use Agreement (DUA)**.
- **Business Associate Agreement (BAA)**.
- **PHI minimum necessary** standard.

## GDPR and international data governance

- **GDPR Article 6** lawful basis, **Article 9** special category data.
- **Data Processing Agreement (DPA)**, **Data Protection Impact Assessment (DPIA)**.
- **Pseudonymization** vs **anonymization**.
- **Cross-border transfer** under SCCs or adequacy decisions.

## Clinical research vocabulary

- **GCP (Good Clinical Practice)** training (ICH E6).
- **CITI Program** training certificates.
- **HSP (Human Subjects Protection)** training.
- **Clinical Data Management** (CDM).
- **Case Report Form (CRF)** design.
- **Adverse Event (AE) / Serious Adverse Event (SAE)** reporting.
- **Phase I / II / III / IV** trial experience.

## Research integrity and reproducibility

- **Pre-registration** (OSF, AsPredicted, ClinicalTrials.gov).
- **Registered Report** publication.
- **Data and code availability statement** authorship.
- **FAIR data principles** (Findable, Accessible, Interoperable, Reusable).
- **Reproducibility checklist** (NeurIPS / ML reproducibility / PRISMA).
- **STROBE / CONSORT / TRIPOD** reporting guidelines (epidemiology / RCT / prediction models).

## Authorship and contribution credit

Distinguish clearly:

- **First-author** publication — primary intellectual contribution.
- **Co-first-author** (with `*` notation) — equal contribution.
- **Senior / last-author** — supervisory role, often the PI.
- **Corresponding author** — handles peer review correspondence.
- **CRediT taxonomy** roles (Conceptualization, Methodology, Software, Validation, Investigation, Writing — Original Draft, etc.).

Never inflate co-authorship to first-authorship. Never list a preprint as "published" unless asked to use the loose definition.

## Venue tier vocabulary (do not fabricate, but surface when present)

- **Top-tier AI/ML conferences**: NeurIPS, ICML, ICLR, CVPR, ECCV, ICCV, ACL, EMNLP, AAAI.
- **Medical imaging**: MICCAI, IPMI, ISBI.
- **Clinical informatics**: AMIA, JAMIA, JBI.
- **Top medical journals**: NEJM, JAMA, Lancet, BMJ, Nature Medicine.
- **Top general-science journals**: Nature, Science, PNAS, Cell.

For each publication recorded, mark whether it is **peer-reviewed**, **conference proceedings**, **journal**, **workshop paper**, **preprint** (arXiv, bioRxiv, medRxiv), **technical report**, or **thesis**.

## Funding and grants

- **PI / Co-PI / Co-Investigator / Senior Personnel** designation.
- **Grant mechanism** (NIH R01, R21, F31, F32, K-award; NSF GRFP, CAREER; DOE, DARPA; ERC, Wellcome Trust, MRC).
- **Award amount** and **duration**, only when known.
- Distinguish between **awarded** and **submitted** grants.

## Open-source and dataset contributions

- **PyPI / CRAN package** authorship.
- **GitHub repository** with stars/forks as conservative impact signal — only cite numbers you can verify.
- **Dataset release** with DOI, license, and curation methodology.
- **Benchmark contribution** (named benchmark + leaderboard position).
- **Model card** authorship for released models.

## What to do when the JD mentions IRB or HIPAA but the CV does not

1. Do **not** insert IRB language into bullets without confirmed evidence.
2. Surface IRB-adjacent evidence ("worked with de-identified clinical data under existing IRB protocol") if present.
3. Flag in `MISSING_EVIDENCE_AND_TODOS.md`: "JD requires IRB protocol authorship; candidate evidence shows data-use only. Cover letter must address this honestly."
4. In the cover letter, address the gap directly: "While I have not personally authored an IRB protocol, I have worked extensively with de-identified clinical data under [PI]'s approved protocol and have completed CITI Human Subjects Research training." Only write this if true.
