# One-Shot Elite CV Agent — v5

An evidence-based, chained-pipeline application-package generator for Claude Skills, Claude Code, and compatible agent stacks.

## What's new in v5

| Capability | v4 | v5 |
|---|---|---|
| Keyword gap identification | Tier system | **Evidence table with strength labels** |
| ATS parse simulation | Formatting rules only | **`scripts/ats_parse_simulator.py`** |
| Match scoring | LLM estimate | **`scripts/compute_match_score.py` (computed)** |
| Multi-ATS platform awareness | None | **`references/17-multi-ats-platform-awareness.md`** |
| IRB / HIPAA / GCP / authorship | Ad hoc | **`references/18-academic-research-compliance.md`** |
| Stage coordination | Implicit | **`session_context.yaml` shared memory** |
| Auto role/domain detection | Manual | **`.claude/agents/auto-profile-detector.md`** |

## Quick start

1. Install as a Claude Skill (drop the folder into `.claude/skills/`).
2. Provide a CV/resume and a job description.
3. The agent runs the 12-stage pipeline and writes a full package to `applications/{Company}_{Role}/`.

## Pipeline

```text
1  auto_profile_detector       → role_profile          → 00_INPUT_SUMMARY.md
2  jd_deconstructor            → jd_keywords           → 01_JOB_ANALYSIS.md
3  cv_evidence_extractor       → cv_evidence           → 02_EVIDENCE_MATRIX.md
4  keyword_evidence_mapper     → keyword_evidence      → 03_KEYWORD_EVIDENCE_TABLE.md
5  match_scorer (script)       → match_score           → (into 11_SCORECARD.md)
6  positioning_strategist      → gaps, role thesis     → 04_POSITIONING_STRATEGY.md
7  resume_writer               → tailored resume       → 05_TAILORED_RESUME.md
8  ats_parse_simulator (script)→ parse report          → 05a_ATS_PARSE_REPORT.md
9  cover_letter_writer         → cover letter          → 06_COVER_LETTER.md
10 supporting_assets           → email/linkedin/prep   → 07–09 files
11 self_auditor                → issue list            → 10_AUDIT_REPORT.md
12 final_review_board          → scorecard             → 11_SCORECARD.md
```

## Honest scoring

The match score is computed from a verifiable keyword evidence table, never estimated:

```text
weighted_score = 100 * (0.60·tier1 + 0.30·tier2 + 0.10·tier3)
```

Where each tier's coverage is the average of strength labels:
- strong = 1.00, partial = 0.50, weak = 0.25, missing = 0.00

## Truth rule

Never fabricate. If evidence does not support a claim, omit it or mark `[TODO: verify ...]`.

## License

For personal use. Adapt freely.
