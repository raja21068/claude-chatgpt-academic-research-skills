# Claude Code project notes — One-Shot Elite CV Agent v5

This repository is a Claude Skill that generates evidence-based application packages.

## Architecture

- `SKILL.md` — entry point and pipeline summary
- `references/` — 19 reference files (00–19), progressive disclosure
- `templates/` — output skeletons including `session_context.yaml`
- `scripts/` — deterministic tools (match scoring, ATS parsing, linters)
- `.claude/agents/` — subagent definitions for the 12-stage pipeline
- `workflows/one_shot_workflow.yaml` — declarative pipeline spec

## When in doubt

1. Read `SKILL.md`.
2. Read `references/19-chained-workflow-and-context.md`.
3. Run the orchestrator agent.

## Truth rule

Never fabricate candidate facts. Always mark unverified claims with `[TODO: ...]`.
