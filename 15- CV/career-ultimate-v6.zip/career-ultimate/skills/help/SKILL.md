---
name: help
description: "Show all available commands and what they do. Use when someone says 'help', 'what can you do', or 'commands'."
argument-hint: ""
user-invocable: true
allowed-tools:
  - Read
---

# Help

Show the user what's available.

## Output

```
## career-ultimate — Your AI Career Agent

### Getting Started
| Command | What It Does |
|---------|-------------|
| **setup** | One-time profile setup: resume, preferences, work history interview |

### Evaluate & Research
| Command | What It Does |
|---------|-------------|
| **evaluate** | Score a job posting (A-F analysis, 1-5 score, 15 industry archetypes) |
| **research {company}** | Company intelligence brief (culture, news, team, contacts) |
| **compare** | Side-by-side comparison of your top opportunities |

### Generate Documents
| Command | What It Does |
|---------|-------------|
| **tailor-resume** | Full 12-stage elite pipeline → ATS-optimized resume + evidence audit |
| **cover-letter** | Evidence-based cover letter matched to the evaluation |

### Find & Apply
| Command | What It Does |
|---------|-------------|
| **scan {company}** | Search career portals for matching openings |
| **network-scan** | Scan your LinkedIn contacts' companies for jobs |
| **pipeline** | Auto-process: fetch → evaluate → filter → tailor → ready queue |
| **pipeline add {URL}** | Queue a job URL for processing |
| **pipeline status** | See pipeline counts by status |
| **apply** | Auto-fill application forms (Greenhouse, Lever, Workday) |

### Track & Network
| Command | What It Does |
|---------|-------------|
| **track** | View/update your application tracker + stats dashboard |
| **outreach** | Draft personalized LinkedIn/email messages |

### Automation
| Command | What It Does |
|---------|-------------|
| **jobsearch-telegram** | Manage your search via Telegram bot |

### Typical Workflow (manual)
1. **setup** → paste your resume, configure preferences
2. **scan Stripe** → find matching openings
3. **evaluate** → paste a job posting, get honest A-F analysis
4. **tailor-resume for Stripe** → 12-stage pipeline produces full package
5. **apply** → auto-fill the application form
6. **track** → monitor your pipeline
7. **outreach for Stripe** → draft a message to the hiring manager

### Automated Workflow (pipeline)
1. **setup** → one-time profile setup
2. **scan Stripe** → finds jobs, adds to pipeline.md
3. **pipeline run** → auto-evaluates all, filters by score, tailors resumes for winners
4. **apply** → you review and confirm each submission
```
