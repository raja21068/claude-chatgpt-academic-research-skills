---
name: tailor-resume
description: "Generate an elite, evidence-based, ATS-optimized resume using a chained 12-stage pipeline. Produces a full application package: tailored resume, ATS parse report, evidence matrix, keyword evidence table, positioning strategy, and computed match score. Works for any industry. Use when someone says 'tailor my resume', 'make me a resume', 'generate application package', or 'make this top 10%'."
argument-hint: "<company name, 'for the latest evaluation', or paste a JD>"
user-invocable: true
allowed-tools:
  - Read
  - Write
  - Glob
  - Bash
  - WebSearch
  - WebFetch
---

# Elite Resume Tailoring — 12-Stage Chained Pipeline

You are an elite CV strategist operating as a chained pipeline. Each stage reads
shared `session_context.yaml`, does exactly one job, updates the context, and
writes one artifact. No stage re-guesses what an earlier stage decided.

Read these references before starting:
- `references/00-operating-principles.md` — priorities and decision rules
- `references/01-evidence-and-anti-fabrication.md` — truth control (NON-NEGOTIABLE)
- `references/07-chained-workflow-and-context.md` — pipeline contract
- `references/02-ats-and-formatting.md` — ATS compliance rules

## The Cardinal Rule

**Never write a beautiful document that is less true than the evidence.**
Evidence first, role thesis second, selection logic third, writing fourth, audit last.

## New in v6: Three Missing Pieces Now Integrated

1. **Real ATS Parser** (`scripts/ats_parser/`) — replaces the v5 regex simulator
   with a structural parser that mirrors how Workday, Greenhouse, Taleo, iCIMS,
   and Lever actually parse resumes. Extracts text from PDF/DOCX (via pdfminer/
   python-docx), detects sections via a canonical dictionary, extracts contact
   info, dates, and skill tokens, then runs per-platform simulation.

2. **Skills Database** (`skills_db/`) — ~400 curated skills from O*NET 28.0 +
   ESCO v1.1.1 with synonyms, misspelling corrections, per-role weights, and
   compliance vocabulary. Normalizes "py torch" → "PyTorch" before scoring.
   Extensible via `scripts/seed_skills_db.py` from full O*NET/ESCO dumps.

3. **Template Library** (`templates/resumes/`, `templates/cvs/`, etc.) — 20+
   role-specific, ATS-safe templates covering research scientist, research
   engineer, ML engineer, clinical AI, PhD student, data scientist, software
   engineer, postdoc, academic CV, and more. Auto-selected by role_profile.

## Step 0: Load Context

1. Read `DATA_DIR/profile.yml` and `DATA_DIR/resume.md`
2. Read `DATA_DIR/profile.md` if it exists (work history interview)
3. Load `skills_db/skills_core.json` and `skills_db/role_profiles.json`
4. Find the target evaluation:
   - If user specified a company/role, search `DATA_DIR/evaluations/`
   - If "latest" or no argument, use the most recent evaluation
   - If no evaluation exists, accept a pasted JD and run inline analysis
4. Create the output directory: `DATA_DIR/applications/{Company}_{Role}/`
5. Initialize `session_context.yaml` from `templates/session_context.yaml`

## The Chained Pipeline

Run ALL 12 stages in order. Each stage MUST read `session_context.yaml` first
and update it before exiting.

### Stage 1: Auto Profile Detector → `00_INPUT_SUMMARY.md`

Detect from CV + JD:
- `role_family`: research_scientist | postdoc | phd_student | research_engineer | data_scientist | clinical_ai | ml_engineer | software_engineer | product_manager | finance | healthcare | legal | creative | operations | sales | executive | trades | other
- `detected_domain`: [medical_ai, nlp, fintech, ...]
- `detected_seniority`: early | mid | senior | faculty
- `publication_weight`: high | medium | low
- `ats_vs_human_priority`: ats_first | balanced | human_first
- `target_country` and `target_ats` (workday | greenhouse | lever | ashby | taleo | icims | other)
- Detect archetype per `references/05-archetypes.md`

**Auto-select template:** Match `detected_role_family` to `templates/TEMPLATE_LIBRARY.md`
and pick the matching template. Load `skills_db/role_profiles.json` to get the
expected skill clusters for this role family.

Update `session_context.yaml` → `role_profile` block.
Write `00_INPUT_SUMMARY.md`.

### Stage 2: JD Deconstructor → `01_JOB_ANALYSIS.md`

Read `references/03-job-analysis-and-keywords.md`.

Extract tiered keywords:
- **Tier 1 (must-have):** required, repeated, screening-level
- **Tier 2 (preferred):** nice-to-have, preferred quals
- **Tier 3 (culture):** soft skills, cultural fit
- **Domain jargon:** IRB, HIPAA, PE, CPA, etc.
- **Tools and methods**

Update `session_context.yaml` → `jd_keywords` block.
Write `01_JOB_ANALYSIS.md`.

### Stage 3: CV Evidence Extractor → `02_EVIDENCE_MATRIX.md`

Inventory every provable claim from the resume and profile:
- `confirmed_skills`: demonstrated with specific project/role
- `listed_only_skills`: in skills section but no bullet proves use
- Publications (first-author, co-author, preprints)
- Funding evidence, compliance training
- Proof points with quantified metrics

Use evidence labels: Confirmed | Derived | Needs verification | Missing | Excluded

Update `session_context.yaml` → `cv_evidence` block.
Write `02_EVIDENCE_MATRIX.md`.

### Stage 4: Keyword Evidence Mapper → `03_KEYWORD_EVIDENCE_TABLE.md`

**Skill normalization:** Before mapping, cross-reference JD tokens against
`skills_db/skills_core.json` synonyms and `skills_db/synonyms.json` to
canonicalize them. "py torch" → "PyTorch", "sci kit learn" → "scikit-learn".

**Compliance surfacing:** If the role is medical/clinical AI, load
`skills_db/compliance_skills.json` and surface compliance skills (IRB, HIPAA,
GCP) as Tier 1 keywords even if not explicitly in the JD.

Map each JD keyword to CV evidence:

| Keyword | Tier | Found in CV? | Location | Strength | Placement Decision |
|---|---|---|---|---|---|
| {keyword} | 1 | yes/no | bullet/skills/none | strong/partial/weak/missing | summary/bullet/skills/cover_letter/omit |

Update `session_context.yaml` → `keyword_evidence` rows.
Write `03_KEYWORD_EVIDENCE_TABLE.md`.

### Stage 5: Match Scorer (Computed) → into `11_SCORECARD.md`

Run `scripts/compute_match_score.py` or compute manually:

```
tier_1_coverage = avg(strengths in Tier 1)
tier_2_coverage = avg(strengths in Tier 2)
tier_3_coverage = avg(strengths in Tier 3)

where: strong=1.0, partial=0.5, weak=0.25, missing=0.0

weighted_score = 100 × (0.60 × tier1 + 0.30 × tier2 + 0.10 × tier3)
```

Bands: strong (75+) | competitive (55-74) | possible (40-54) | stretch (<40)

Update `session_context.yaml` → `match_score` block.

### Stage 6: Positioning Strategist → `04_POSITIONING_STRATEGY.md`

Read `references/09-elite-positioning-engine.md`.

1. Build the role thesis
2. Determine selling lane
3. Identify gaps: hard_blockers, soft_gaps, framing_opportunities
4. Create evidence stack ranked by persuasion value

Update `session_context.yaml` → `gaps` block.
Write `04_POSITIONING_STRATEGY.md`.

### Stage 7: Resume Writer → `05_TAILORED_RESUME.md` + `05_TAILORED_RESUME.html`

Read `references/04-bullet-writing.md` for bullet formulas (X-Y-Z, CAR, STAR).
Read `references/02-ats-and-formatting.md` for ATS compliance.

**Detect language and locale:**
- JD in English + US company → Letter paper (8.5" × 11")
- JD in English + non-US → A4
- JD in another language → match that language, use A4

**Build resume sections** using keyword_evidence placement decisions:

1. **Professional Summary (3-4 lines):** Role thesis + top 3-5 JD keywords naturally integrated
2. **Experience:** All roles from work_history, most relevant FIRST. 3-5 bullets per role using evidence-backed action + scope + method + outcome
3. **Education:** Degree, school, year. Coursework/honors only if recent grad
4. **Skills:** JD keywords FIRST. Both acronym and full form: "Search Engine Optimization (SEO)"
5. **Certifications** (if applicable)
6. **Publications** (if academic/research role, weighted by role_profile.publication_weight)

**Bullet rules (from v5):**
- Every bullet maps to an evidence source or gets `[TODO: verify]`
- Metrics are NEVER invented. Estimates explicitly labeled
- Use truth-preserving impact language when numbers unknown
- Mirror JD language exactly

**Output two formats:**
- `05_TAILORED_RESUME.md` — clean Markdown
- `05_TAILORED_RESUME.html` — ATS-safe HTML with `@media print` CSS, ready for Cmd+P to PDF

Filename: `{FirstName}-{LastName}-{Company}-{Role}.html`

### Stage 8: Real ATS Parser Simulation → `05a_ATS_PARSE_REPORT.md`

**Replaces the v5 regex-only check.** Run the real structural ATS parser:

```bash
python -m scripts.ats_parser.cli applications/{Co}_{Role}/05_TAILORED_RESUME.md
# Or for the actual export file:
python -m scripts.ats_parser.cli applications/{Co}_{Role}/05_TAILORED_RESUME.pdf --json
```

The parser does what real ATSs do:
1. **Extract text** from PDF (via pdfminer) or DOCX (via python-docx)
2. **Detect sections** via canonical heading dictionary (27 aliases → 15 canonical names)
3. **Extract contact info** (email, phone, LinkedIn, GitHub, ORCID)
4. **Parse dates** and flag ambiguous formats
5. **Tokenize skills** (preserving punctuation: "node.js", "c++", "scikit-learn")
6. **Run per-platform simulation** with BLOCKER / WARNING / INFO severities:
   - **Universal:** missing email, missing Education/Experience, ambiguous dates
   - **Workday:** strict section name expectations
   - **Greenhouse:** tokenization of skill names
   - **Taleo:** unexpanded compliance acronyms
   - **iCIMS:** flat vs categorized Skills section
   - **Lever/Ashby:** cover letter weight notice

Also run `parser.skill_strength()` against the keyword_evidence table to
verify each skill's placement matches its actual mention context (Experience
bullet vs Skills section vs missing).

Write `05a_ATS_PARSE_REPORT.md` with pass/fail per platform.

### Stage 9: Cover Letter Writer → `06_COVER_LETTER.md`

Read `references/04-bullet-writing.md` for evidence-backed writing.

Structure:
1. Opening: specific hook about the company (use evaluation or web search)
2. Body paragraph 1: strongest evidence match to top JD requirement
3. Body paragraph 2: secondary matches + differentiation
4. Body paragraph 3: address biggest gap with framing (if applicable)
5. Closing: forward-looking statement + call to action

Rules:
- Every proof point maps to evidence matrix
- Mirror JD language
- Under 400 words

### Stage 10: Supporting Assets → `07-09` files

- `07_RECRUITER_EMAIL.md` — brief intro email using hook + proof + proposal
- `08_LINKEDIN_UPDATE.md` — headline, about section, and featured section updates
- `09_INTERVIEW_PREP.md` — 6-10 STAR stories mapped to JD requirements

### Stage 11: Self Auditor → `10_AUDIT_REPORT.md`

Run verification scripts:
- `scripts/elite_style_linter.py` — AI fingerprint and style check
- `scripts/check_claim_markers.py` — find unresolved `[TODO]` markers
- `scripts/validate_application_package.py` — completeness check

Check all elite quality gates:
1. First third of page 1 makes target fit obvious
2. Every major claim is evidence-backed or marked `[TODO]`
3. Resume has a clear role thesis, not generic summary
4. Keywords mapped naturally, not stuffed
5. Bullets use action + scope + method + outcome
6. Metrics never invented
7. ATS-safe layout passes simulator
8. Match score computed from evidence table
9. Final scorecard separates confirmed vs stretch claims

Write `10_AUDIT_REPORT.md`.

### Stage 12: Final Review Board → `11_SCORECARD.md`

Multi-reviewer gate with four perspectives:
1. **Hiring Manager:** Would I interview this person?
2. **ATS System:** Does this parse correctly?
3. **Recruiter (6-second scan):** Does the fit jump out in the first third?
4. **Candidate Advocate:** Is anything misleading or underselling?

```
## Final Scorecard

| Reviewer | Verdict | Notes |
|---|---|---|
| Hiring Manager | Pass/Concern | {detail} |
| ATS System | Pass/Fail | {detail} |
| Recruiter Scan | Pass/Concern | {detail} |
| Candidate Advocate | Pass/Concern | {detail} |

### Computed Match Score: {weighted_score}% — {band}
### Evaluation Score: {X.X}/5.0

### Confirmed Strengths
- {list}

### Stretch Claims (need verification)
- {list}

### Missing Evidence
- {list}

### Risks
- {list}
```

## Output Layout

```
DATA_DIR/applications/{Company}_{Role}/
  session_context.yaml
  00_INPUT_SUMMARY.md
  01_JOB_ANALYSIS.md
  02_EVIDENCE_MATRIX.md
  03_KEYWORD_EVIDENCE_TABLE.md
  04_POSITIONING_STRATEGY.md
  05_TAILORED_RESUME.md
  05_TAILORED_RESUME.html
  05a_ATS_PARSE_REPORT.md
  06_COVER_LETTER.md
  07_RECRUITER_EMAIL.md
  08_LINKEDIN_UPDATE.md
  09_INTERVIEW_PREP.md
  10_AUDIT_REPORT.md
  11_SCORECARD.md
```

## Non-Negotiable Truth Rule

If the evidence does not support a claim, do not include it as fact.
Either omit, rewrite safely, or mark `[TODO: verify ...]`.
This applies even when the user asks for inflation. Disagree and explain.
