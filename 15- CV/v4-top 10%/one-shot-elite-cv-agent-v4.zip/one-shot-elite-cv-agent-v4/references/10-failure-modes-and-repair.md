# Failure Modes and Repair

## Generic resume

Symptoms:

- Summary could apply to anyone.
- Bullets start with “responsible for.”
- No target keywords.

Repair:

- Re-read Tier 1 keywords.
- Move strongest target evidence to the top third.
- Rewrite bullets using action + object + method + result/context.

## Fabricated or inflated resume

Symptoms:

- Metrics appear without source.
- Verbs imply leadership not evidenced.
- Tools appear only in JD, not candidate evidence.

Repair:

- Replace unsupported claims with TODOs.
- Downgrade verbs.
- Move missing items to gap plan.

## Too long

Symptoms:

- Every role has equal detail.
- Old or irrelevant bullets crowd out target evidence.

Repair:

- Cut by relevance.
- Merge repeated tools.
- Reduce older roles to 1 to 2 bullets.
- Move extra detail to LinkedIn or portfolio.

## ATS unsafe

Symptoms:

- Tables, icons, two columns, image text, inconsistent dates.

Repair:

- Use standard headings and plain text.
- Keep contact details in body text.
- Remove decorative elements from ATS version.

## Weak cover letter

Symptoms:

- Opens generically.
- Repeats resume.
- Praises company without specifics.

Repair:

- Start with role-specific proof.
- Add one company-specific sentence only if supported by job post/company evidence.
- Use two focused evidence paragraphs.
