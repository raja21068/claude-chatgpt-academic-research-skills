# Recruiter Psychology and Selection Logic

Recruiters and hiring managers do not read linearly at first. They scan for risk and fit.

## The 6 to 10 second scan

The first scan answers:

1. What role is this person targeting?
2. Do they have relevant experience, education, or projects?
3. Are the core tools/methods visible?
4. Is the document easy to read?
5. Is there a reason to keep reading?

Therefore page 1 must quickly show:

- Targeted title or summary.
- 3 to 6 high-signal skills/tool groups.
- Most relevant role or project first.
- Clear dates, employers, locations, and job titles.
- Impact bullets with numbers where supported.

## Hiring manager decision logic

Hiring managers prefer evidence that predicts job performance:

- Similar problems solved.
- Similar datasets, tools, clients, students, stakeholders, products, or regulations.
- Clear outputs: reports, dashboards, models, experiments, memos, products, presentations.
- Evidence of ownership: built, led, analyzed, improved, reduced, automated, evaluated, presented.

## Risk signals to remove

- Generic summary that could fit anyone.
- Dense paragraphs.
- Too many tools without context.
- Unsupported adjectives such as excellent, dynamic, visionary, results-driven.
- Over-claiming seniority.
- Inconsistent dates or role titles.
- Bullets that describe duties but not outputs.
- Large blocks of coursework when experience or projects are stronger.

## Human tone standard

The CV should sound like a high-performing professional wrote it, not like a chatbot. Use plain, specific, confident language.
