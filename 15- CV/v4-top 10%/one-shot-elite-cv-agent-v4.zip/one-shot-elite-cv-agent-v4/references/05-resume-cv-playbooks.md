# Resume and CV Playbooks

## Universal resume order

For most jobs:

1. Contact.
2. Targeted summary.
3. Skills or technical skills.
4. Experience.
5. Projects or research.
6. Education.
7. Certifications, awards, leadership if relevant.

For students and early-career candidates, education may come before experience if the degree is a major signal.

## Academic CV order

1. Contact.
2. Research interests or profile.
3. Education.
4. Publications.
5. Research experience.
6. Teaching experience.
7. Presentations.
8. Grants, awards, fellowships.
9. Technical methods.
10. Service.
11. References only if requested.

## Technical resume

Lead with technical skills if tools are important screening criteria. Projects should include tools, data scale, model/method, and outcome.

## Research/economics resume

Prioritize methods, data, identification strategy, reproducibility, policy relevance, and written outputs.

## Finance resume

Prioritize forecasting, variance analysis, reporting, budgeting, SQL/Excel/Power BI/Tableau, stakeholder decisions, accuracy, and process improvement.

## Education/EdTech resume

Prioritize curriculum, assessment, student outcomes, LMS, teacher coordination, content quality, operations, and communications.

## Career-change resume

Lead with transferable evidence. Do not hide the prior domain. Build a bridge:

```text
Former [domain] professional with evidence in [target skill], now targeting [role] where [transferable asset] directly supports [job need].
```

## Executive resume

Lead with scope, strategy, transformation, P&L, teams, stakeholders, governance, and measurable business outcomes only when evidenced.
