# Country and Seniority Conventions

## United States and Canada

- Usually use “resume” for industry roles.
- Avoid photo, date of birth, marital status, religion, full street address, national ID, and references unless explicitly requested.
- One page for early-career; two pages acceptable for experienced candidates.

## United Kingdom

- “CV” often means industry resume.
- Two pages is common.
- Avoid photo and sensitive personal details unless required.

## Europe

- CV norms vary by country.
- Europass may be requested but is often not the strongest format unless specifically required.
- Photo may be more common in some countries but do not include unless user requests or role/country requires.

## Pakistan, India, Middle East

- “CV” is commonly used for industry applications.
- Photo and personal details appear in some local formats, but default to a modern ATS-safe professional CV unless user asks otherwise.

## Seniority

- Internship/student: education, projects, technical skills, transferable experience.
- Analyst/associate: methods, tools, data, reporting, execution quality.
- Mid-level: ownership, cross-functional work, measurable outcomes.
- Senior/executive: scope, strategy, team leadership, business impact, stakeholder influence.
