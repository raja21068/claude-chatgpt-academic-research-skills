# Bullet Writing Rules

## Strong bullet formulas

### X-Y-Z

```text
Accomplished X as measured by Y by doing Z.
```

### CAR

```text
Challenge/context + action + result.
```

### STAR compressed

```text
Situation/task + action + result.
```

### Research bullet

```text
Research question/method + data/model + output/relevance.
```

### Technical bullet

```text
Built/analyzed/implemented + system/model/pipeline + tools + scale + effect.
```

## Good verbs by evidence strength

High ownership:

- Built, led, designed, developed, implemented, launched, authored, modeled, automated.

Medium ownership:

- Co-developed, contributed to, improved, supported, analyzed, coordinated.

Low/unclear ownership:

- Assisted, helped, prepared, maintained, documented.

## Avoid weak or generic bullets

Avoid:

- Responsible for...
- Worked on...
- Helped with various tasks...
- Used Excel for reports...
- Participated in meetings...

Replace with:

- Action + object + method/tool + purpose/result.

## Bullet upgrade matrix

```markdown
| Original bullet | Evidence status | Target keyword | Improved bullet | Risk/TODO |
|---|---|---|---|---|
```

## Anti-AI wording filter

Avoid generic AI prose such as:

- Delve, tapestry, realm, landscape, pivotal, multifaceted, robust when empty, seamless, cutting-edge without proof, leverage when overused, synergy, dynamic, passionate, proven track record.

Prefer concrete words:

- Analyzed, built, evaluated, tested, forecasted, documented, standardized, mapped, classified, deployed, validated.
