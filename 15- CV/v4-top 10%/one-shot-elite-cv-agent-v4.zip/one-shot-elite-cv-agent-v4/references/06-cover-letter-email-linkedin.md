# Cover Letter, Email, LinkedIn, and Supporting Assets

## Cover letter purpose

A cover letter should not repeat the resume. It should explain fit, motivation, and context that the resume cannot fully show.

## Cover letter structure

1. Specific opening tied to the role and company.
2. Evidence paragraph 1: strongest role match.
3. Evidence paragraph 2: second strength or transferable bridge.
4. Optional gap bridge if needed.
5. Concise close.

Avoid “I am excited to apply” as the first sentence unless it is followed by a specific reason.

## Cover letter truth rules

- Do not claim company admiration without specific evidence.
- Do not invent personal connection to the company.
- Do not overstate availability, relocation, visa, salary, or references.

## Recruiter email

Keep it short:

```text
Subject: Application for {Role} — {Name}

Dear {Name or Hiring Team},

Please find attached my application for {Role}. My background in {two strongest evidence areas} aligns with {company/team need}. I would welcome the opportunity to discuss how my experience in {specific proof} can support your team.

Best regards,
{Name}
```

## LinkedIn package

Create:

- Headline: role identity + 2 to 3 proof areas.
- About: 3 short paragraphs.
- Featured/project suggestions.
- Skills to pin.

Do not add unverifiable claims.

## Interview prep

Include:

- Role-specific pitch.
- 8 to 12 likely questions.
- STAR answer outlines using confirmed evidence.
- Weakness/gap answers.
- Questions to ask employer.
- Compensation or availability notes only if provided.
