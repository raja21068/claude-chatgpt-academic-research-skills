# Review Rubrics

Run these reviews before finalizing.

## Evidence reviewer

Questions:

- Which claims lack direct evidence?
- Which metrics need verification?
- Which verbs overstate ownership?
- Are dates and titles preserved?
- Are any sensitive details included unnecessarily?

## ATS reviewer

Questions:

- Are Tier 1 keywords naturally present where supported?
- Are headings standard?
- Is core content in text form?
- Are skills grouped logically?
- Is there keyword stuffing?

## Recruiter reviewer

Questions:

- Can fit be understood in 6 to 10 seconds?
- Does the top third show the target role clearly?
- Are the first three bullets strong and relevant?
- Are irrelevant experiences compressed?
- Is the summary specific rather than generic?

## Hiring manager reviewer

Questions:

- Does the resume prove capability to do the job?
- Are outcomes and methods clear?
- Are gaps acknowledged or bridged?
- Would the candidate be easy to interview from this document?

## Final scorecard categories

Use transparent estimates, not guarantees:

```markdown
| Category | Score / 10 | Evidence | Fix |
|---|---:|---|---|
| Role relevance | | | |
| Evidence strength | | | |
| ATS readability | | | |
| Recruiter scanability | | | |
| Bullet impact | | | |
| Cover letter specificity | | | |
| Risk control | | | |
```
