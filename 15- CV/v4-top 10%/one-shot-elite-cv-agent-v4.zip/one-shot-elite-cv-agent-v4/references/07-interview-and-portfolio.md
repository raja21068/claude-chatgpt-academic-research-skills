# Interview and Portfolio Add-ons

## Portfolio case study structure

Use this when the candidate has projects:

1. Problem.
2. Data/context.
3. Method/tools.
4. Candidate contribution.
5. Outcome.
6. What changed or what was learned.
7. Evidence link or artifact if available.

## Interview answer quality

A strong answer is specific, brief, and evidence-backed.

Use:

```text
Situation: one sentence.
Task: one sentence.
Action: two to three sentences.
Result: one sentence.
Reflection: one sentence.
```

## Gap answer structure

```text
I have not yet used {missing tool} in a production role, but I have used {closest evidenced skill}. My plan to close the gap is {specific learning/action}. The transferable part is {conceptual bridge}.
```
