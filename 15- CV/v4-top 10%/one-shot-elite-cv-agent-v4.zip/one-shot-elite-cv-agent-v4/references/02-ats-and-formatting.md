# ATS and Formatting Rules

## ATS-safe resume structure

Use standard section names:

- Contact
- Summary
- Education
- Experience
- Projects
- Research Experience
- Technical Skills
- Skills
- Publications
- Certifications
- Leadership
- Awards

## Avoid in ATS version

- Text boxes.
- Tables for core experience.
- Icons in contact section.
- Progress bars.
- Skill rating stars.
- Columns for core content.
- Headers/footers containing important contact details.
- Scanned PDFs or image-only content.
- Decorative charts.
- Overly condensed fonts.

## Date format

Use one consistent format:

- `Jun 2024 – Jul 2025`
- `2024 – 2025`
- `Expected May 2026`

Do not mix formats.

## Bullet count guidance

- Recent target-relevant role: 3 to 5 bullets.
- Older relevant role: 2 to 3 bullets.
- Less relevant role: 1 to 2 bullets.
- Projects: 2 to 3 bullets each.
- Early-career one-page: usually 10 to 16 total bullets.

## Summary guidance

Use 2 to 4 lines. Avoid self-praise. Show role identity, domain, methods/tools, and strongest evidence.

Bad:

```text
Motivated and hardworking professional with a passion for excellence.
```

Better:

```text
Economics graduate student with experience in applied policy research, Python/SQL data workflows, and geospatial analysis. Built reproducible pipelines for large-scale datasets and translated findings into stakeholder-facing documentation.
```

## Skills section

Group skills by category only when it improves scanability:

```text
Technical: Python, SQL, R, Stata, ArcGIS, LaTeX
Methods: Difference-in-differences, RDD, panel data, causal inference
Data: CPS/ASEC, geospatial data, administrative datasets
```

Only include skills supported by evidence.
