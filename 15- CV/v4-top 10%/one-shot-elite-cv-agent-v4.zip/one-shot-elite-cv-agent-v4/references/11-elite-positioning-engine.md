# Elite Positioning Engine

A top 10% CV is not mainly a prettier document. It is a clearer hiring argument.

## 1. Build the role thesis

Before writing, create this sentence:

> For [target role], this candidate is credible because they have [domain], [method/tool], and [measurable proof/outcome] that match [employer need].

Examples:

- For a policy research role, credibility may come from applied econometrics, public finance or education policy context, large microdata, and memo/report writing.
- For a finance role, credibility may come from budgeting, forecasting, SAP/Excel/Power BI, dashboarding, variance analysis, and decision-support outputs.
- For AI/data roles, credibility may come from production data pipelines, ML/RAG/vector search, APIs, testing, and measurable workflow improvements.

## 2. Decide the candidate's selling lane

Pick one primary lane. Do not mix too many identities.

- Research and Policy Analyst
- Financial Analyst / FP&A
- Data Analyst / Business Intelligence
- AI / Machine Learning Developer
- Academic Researcher
- EdTech / Education Program Builder
- Early-Career High-Potential Candidate
- Executive / Senior Specialist

Then make all sections serve that lane.

## 3. Create the evidence stack

Rank evidence by persuasion value:

1. Direct role experience in the same function.
2. Measurable outcomes with scope, tools, or stakeholders.
3. Closely related projects using relevant methods.
4. Education, coursework, publications, certificates.
5. Soft skills only when proven through outcomes.

## 4. Cut content ruthlessly

Remove or compress anything that does not help the target role. A top CV is not a full biography.

Keep only content that proves one of these:

- Can do the work.
- Has done similar work.
- Can learn the remaining gap quickly.
- Communicates clearly.
- Reduces hiring risk.

## 5. Convert weak evidence into credible framing

Weak: “Responsible for data analysis.”
Strong: “Cleaned and analyzed CPS/ACS/OEWS datasets to support labor-market and education-policy research outputs.”

Weak: “Worked on dashboards.”
Strong: “Built Excel/Power BI reporting workflows to monitor budget, KPI, and variance trends for management review.”

Weak: “Passionate about education.”
Strong: “Led EdTech operations supporting large student communities, translating student pain points into learning-support workflows.”
