# Role-Specific Writing Packs

Use the correct vocabulary only where supported by evidence.

## Policy / Research Analyst

Emphasize:

- Applied econometrics, program evaluation, public finance, education policy, labor markets.
- ACS, CPS, ASEC, OEWS, PSID, administrative data, survey data.
- Regression, DiD, RDD, robustness checks, data cleaning, literature review, technical memos.
- Stakeholder-ready outputs: briefs, reports, presentations, dashboards.

Strong verbs: analyzed, estimated, evaluated, cleaned, merged, modeled, synthesized, authored, presented.

## Finance / FP&A / Financial Analyst

Emphasize:

- Budgeting, forecasting, variance analysis, KPI reporting, reconciliations.
- Excel, SAP S/4HANA, Power BI, Tableau, SQL, financial modeling.
- Decision support, cross-functional reporting, month-end analysis, process improvements.

Strong verbs: forecasted, reconciled, modeled, automated, analyzed, tracked, consolidated, reported, reduced.

## Data Analyst / BI

Emphasize:

- SQL/Python/R, ETL, dashboarding, data quality, stakeholder questions, reporting cadence.
- Clean data → analysis → visualization → decision.

Strong verbs: built, queried, transformed, validated, visualized, automated, monitored, documented.

## AI / ML / Data Engineering

Emphasize:

- Python, ML models, APIs, vector search, RAG, testing, deployment, monitoring.
- Data pipelines, performance metrics, reproducibility, documentation.

Strong verbs: developed, implemented, benchmarked, optimized, deployed, validated, integrated, tested.

## EdTech / Education Operations

Emphasize:

- Student reach, learning outcomes, content operations, teacher coordination, community growth, curriculum alignment.
- YouTube, WhatsApp, LMS, analytics, student support, exam-prep programs.

Strong verbs: launched, coordinated, scaled, supported, designed, analyzed, trained, improved.

## Academic / Research CV

Emphasize:

- Research questions, datasets, methods, publications, working papers, presentations, teaching, grants, collaborations.
- Separate peer-reviewed publications from manuscripts, presentations, posters, and works in progress.

## Early-career / Student CV

Emphasize:

- Projects, internships, leadership, measurable community or academic work, relevant coursework, tools, volunteer work.
- Replace weak experience with high-quality project descriptions.

## Executive / Senior Specialist

Emphasize:

- Scope, strategy, team leadership, budget, institutional impact, partnerships, transformation, risk management.
- Do not overload technical details unless the role requires them.
