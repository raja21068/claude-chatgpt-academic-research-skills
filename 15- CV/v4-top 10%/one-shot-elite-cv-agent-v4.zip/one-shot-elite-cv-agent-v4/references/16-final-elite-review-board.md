# Final Elite Review Board

Before finalizing, run five reviewers mentally.

## Reviewer 1: Truth Controller

Questions:

- Is every claim supported by evidence?
- Are metrics, dates, tools, employers, and titles unchanged unless supported?
- Are uncertain items marked TODO?
- Does the document avoid fake seniority or inflated ownership?

## Reviewer 2: ATS Parser

Questions:

- Is the layout one-column and text-based?
- Are headings standard?
- Are job keywords present where supported?
- Are tables, icons, images, text boxes, and decorative graphics avoided in the ATS version?

## Reviewer 3: Recruiter

Questions:

- Can the target role fit be understood in 6 to 10 seconds?
- Is the top third of page 1 strong?
- Are the strongest facts easy to find?
- Is there any obvious reason to reject?

## Reviewer 4: Hiring Manager

Questions:

- Does the CV prove the candidate can do the work?
- Are outputs and methods clear?
- Are the most relevant achievements prioritized?
- Are gaps addressed honestly?

## Reviewer 5: Style Editor

Questions:

- Is the writing concise and human?
- Are weak verbs, filler, repetition, and buzzwords removed?
- Are bullets mostly 18 to 30 words?
- Is the document polished without sounding fake?

## Readiness score

Give a transparent readiness estimate, not a guaranteed ATS score.

- 90 to 100: Very strong, targeted, evidence-rich, minimal risk.
- 80 to 89: Strong, likely competitive, with a few gaps or TODOs.
- 70 to 79: Usable but needs sharper evidence, keywords, or positioning.
- Below 70: Significant missing evidence, weak targeting, or formatting issues.

Always list the 3 changes most likely to improve interview probability.
