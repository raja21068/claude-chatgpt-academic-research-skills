# AI Fingerprint and Style Polish

The final document must sound human, grounded, and specific.

## Remove these patterns

- “Results-driven professional”
- “Passionate and dedicated”
- “Proven track record” unless followed by concrete proof
- “Leveraged” repeated many times
- “Utilized” when “used” is cleaner
- Excessive adjectives: exceptional, outstanding, dynamic, innovative, visionary
- Repeating the same bullet rhythm throughout
- Long summaries that repeat the skills section
- Empty soft skills: hardworking, punctual, team player, motivated

## Replace with specific proof

Instead of “strong analytical skills,” show the method and output:

- “Analyzed 951,000+ ACS observations using regression and hypothesis testing to examine education-income gradients.”
- “Built Power BI dashboards to summarize budget, KPI, and variance trends for finance review.”

## Sentence rhythm

Vary bullet openings. Do not start every bullet with “Developed.”

Good action verbs:

- Analysis: analyzed, estimated, evaluated, modeled, tested, synthesized
- Data: cleaned, merged, queried, transformed, validated, automated
- Finance: forecasted, reconciled, consolidated, monitored, reported
- Research: reviewed, coded, authored, presented, designed
- Engineering: implemented, deployed, benchmarked, integrated, documented
- Leadership: coordinated, trained, mentored, led, organized

## Precision rules

- Use exact numbers only when supplied.
- Use ranges only when evidence provides a range.
- Use “supported,” “contributed to,” or “helped” when ownership is partial.
- Do not turn coursework into professional experience.
- Do not imply employment when it was volunteer, internship, coursework, or project work.
