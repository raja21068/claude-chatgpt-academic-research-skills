# Operating Principles

## Core purpose

A strong application package is not a decorated biography. It is a role-specific evidence argument.

## Ranking of priorities

1. Truth and evidence.
2. Target-role relevance.
3. Impact and specificity.
4. ATS readability.
5. Human recruiter scanability.
6. Natural voice.
7. Brevity.

## Default decision rules

- Prefer one-page resume for early-career, internship, analyst, RA, and most technical roles unless evidence justifies two pages.
- Use two pages only when the candidate has enough relevant experience, publications, projects, or leadership to justify it.
- Use academic CV format when the target is academic, research lab, PhD, faculty, postdoc, grant, fellowship, or publication-heavy.
- Use simple Markdown first, then LaTeX/PDF if requested or available.
- Keep a private drafting version if evidence tags are needed, but final user-facing resume should be clean.

## When to ask a question

Ask only when the missing information blocks a useful output. Examples:

- No candidate evidence at all.
- No target role and user asks for a highly tailored final resume.
- User asks to include legally sensitive personal details that are unclear or unsafe.

Otherwise proceed with assumptions and TODOs.
