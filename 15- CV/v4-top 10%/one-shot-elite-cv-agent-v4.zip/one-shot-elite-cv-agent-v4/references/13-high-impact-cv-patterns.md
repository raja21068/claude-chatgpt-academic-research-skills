# High-Impact CV and Resume Patterns

## Default ATS-safe structure

Use this order for most industry roles:

1. Name and contact line
2. Targeted professional headline
3. 3-line summary or 3 selected highlights
4. Technical/Core skills grouped by relevance
5. Experience
6. Selected projects, research, or publications if relevant
7. Education
8. Certifications or additional information if useful

## Top summary formula

Use 2 to 4 lines. Avoid generic adjectives.

Formula:

> [Role identity] with experience in [domain/function], using [tools/methods] to produce [outputs/outcomes]. Background includes [strongest differentiator]. Seeking/positioned for [target role type].

For students and early-career candidates, use:

> Economics / data / finance / education candidate with hands-on experience in [projects/internship], [tools], and [outputs]. Built evidence through [research, dashboards, teaching, operations, analytics].

## Skills section rules

Group skills, do not dump a long list.

Examples:

- Research and Econometrics: Stata, R, Python, regression, DiD, RDD, survey data, robustness checks
- Data and BI: SQL, Excel, Power BI, Tableau, data cleaning, dashboards, reporting automation
- Finance: forecasting, budget-to-actual analysis, variance analysis, financial modeling, SAP S/4HANA
- AI and Engineering: Python, FastAPI, LangChain, FAISS, embeddings, vector search, testing, Docker

## Experience bullet hierarchy

Each role should contain 3 to 5 bullets. Order bullets by relevance to the target job, not chronology of tasks.

Bullet priority:

1. Most target-relevant measurable result.
2. Strongest technical/method bullet.
3. Stakeholder/reporting/communication bullet.
4. Process improvement/automation bullet.
5. Leadership or collaboration bullet if evidenced.

## One-page vs two-page rule

Use one page when:

- Early career, student, internship, analyst, or entry-level roles.
- Fewer than 7 years of experience.
- The job values concise screening.

Use two pages when:

- Research, academic, technical, PhD, senior, publications, grants, patents, or extensive project evidence matters.
- The second page adds decision-relevant evidence, not filler.

## Academic CV vs industry resume

Academic CV: publications, presentations, teaching, grants, research agenda, methodology depth.

Industry resume: role fit, impact, tools, outputs, business/research value, stakeholder usefulness.
