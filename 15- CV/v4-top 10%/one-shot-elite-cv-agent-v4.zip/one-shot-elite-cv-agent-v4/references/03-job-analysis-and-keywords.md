# Job Analysis and Keyword Mapping

## Deconstruct the job description

Extract:

- Company.
- Role title.
- Role family.
- Seniority.
- Location and remote status.
- Required qualifications.
- Preferred qualifications.
- Core responsibilities.
- Tools, methods, software, domains, and datasets.
- Repeated terms.
- Application instructions.
- Possible red flags.

## Keyword tiers

- **Tier 1**: Required, repeated, title-level, screening-level, or core responsibility keywords.
- **Tier 2**: Preferred qualifications and important secondary skills.
- **Tier 3**: Culture language, nice-to-have tools, general traits.

## Keyword use rule

Use exact job wording only when supported by evidence. Do not keyword-stuff.

## Match estimate

Call it a **match estimate**, not a guaranteed ATS score.

Suggested bands:

- 85 to 100: strong match.
- 70 to 84: competitive with focused tailoring.
- 55 to 69: possible, requires bridge and gap handling.
- Below 55: stretch role.

## Job keyword map template

```markdown
| JD keyword | Tier | JD evidence | Candidate evidence | Safe to use? | Placement |
|---|---:|---|---|---|---|
```
