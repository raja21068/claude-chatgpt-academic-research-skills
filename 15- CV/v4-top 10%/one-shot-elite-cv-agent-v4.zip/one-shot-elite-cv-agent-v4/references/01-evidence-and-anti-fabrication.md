# Evidence and Anti-Fabrication Rules

## Non-negotiable rules

Never invent or alter:

- Employer names.
- Job titles.
- Degree names.
- Institutions.
- Dates.
- Locations.
- Salary.
- Visa or work authorization status.
- Publications, awards, certifications, licenses, GPA, honors.
- Tools, programming languages, methods, datasets, or models.
- Team size, budget size, revenue, users, students, subscribers, performance metrics, or percentages.
- References or contact details.

## Evidence labels

Use these labels in the evidence matrix:

- **Confirmed**: directly present in source evidence.
- **Derived**: safely inferred without adding new facts.
- **Needs verification**: plausible but not confirmed.
- **Missing**: requested by the role but not present.
- **Excluded**: true or possible, but irrelevant, risky, or unsupported.

## Claim discipline

Every major resume bullet, summary phrase, and cover-letter proof point should map to one evidence source.

Use this internal logic:

```text
Claim = action + object + method/tool/domain + result/context
```

If any piece is unsupported, either remove it or mark it:

```text
[TODO: verify metric]
[TODO: confirm tool]
[TODO: confirm date]
[TODO: add evidence]
```

## Quantification rules

Acceptable:

- Exact numbers given by the user.
- Ranges explicitly given by the user.
- Conservative non-numeric impact when numbers are unknown.
- Contextual scale that is directly evidenced, such as “across 103 datasets” if that number appears in evidence.

Not acceptable:

- Guessing percentages.
- Turning “helped improve” into “increased by 40%.”
- Adding user counts, budget sizes, team sizes, or rankings without evidence.
- Claiming “first,” “largest,” “best,” “top,” or “award-winning” without proof.

## Truth-preserving impact language

When impact is known but not quantified:

- “improved workflow consistency”
- “reduced manual review effort”
- “supported faster decision-making”
- “strengthened reporting accuracy”
- “expanded visibility into...”
- “standardized...”
- “streamlined...”

When contribution level is uncertain:

- “supported”
- “contributed to”
- “helped build”
- “assisted with”
- “co-developed” only when collaboration is confirmed

## Sensitive and country-specific information

Do not include photo, full street address, date of birth, marital status, religion, national ID, political affiliation, health status, or references unless the user explicitly asks or local norms require it.
