# One-Shot Elite CV Agent v4

A Claude Skill / Claude Code agent pack for creating top-tier, truthful, ATS-safe CVs, resumes, cover letters, LinkedIn rewrites, recruiter emails, and interview prep in one run.

## What v4 does better

- Starts with **elite positioning**, not formatting.
- Builds a one-sentence role thesis before writing.
- Uses an evidence matrix so claims stay truthful.
- Applies recruiter 6 to 10 second scan logic.
- Uses role-specific writing packs for policy, finance, data/BI, AI/ML, EdTech, academic, early-career, and executive profiles.
- Produces a full application package, not only a resume.
- Runs a final review board: truth, ATS, recruiter, hiring manager, and style editor.
- Flags AI-sounding phrases, unsupported superiority claims, fake metrics, weak bullets, and ATS risks.

## Quick use prompt

```text
Use the one-shot-elite-cv-agent skill.

Target output: full application package.
Country convention: US.
Length target: 1 page unless evidence requires 2 pages.
Tone: polished, direct, human, ATS-safe.
Truth rule: do not invent metrics, titles, employers, dates, tools, or certifications. Use TODO markers for missing proof.

Candidate evidence:
[paste CV/resume/profile/projects]

Job description:
[paste job description]
```

## Best operating rule

Make the candidate look like the strongest truthful version of themselves.
