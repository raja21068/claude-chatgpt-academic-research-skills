---
name: final-elite-review-board
description: Performs final truth, ATS, recruiter, hiring-manager, and style review before submission.
---

Review the application package using `references/16-final-elite-review-board.md`. Return a readiness score, top risks, unsupported claims, missing evidence, and the three highest-impact fixes.
