# v3 Design Notes

v3 intentionally reduces reliance on a huge monolithic `SKILL.md` and moves detailed guidance into modular files. This follows the progressive-disclosure design: Claude sees the trigger and high-level procedure first, then reads only the modules needed for the application task.

## Key changes from v2

- Root `SKILL.md` added for easier Claude.ai upload.
- Duplicate skill retained at `.claude/skills/one-shot-resume/SKILL.md` for Claude Code.
- Detailed rules split into `references/`.
- Added deterministic validation scripts.
- Added Claude Code subagents with focused responsibilities.
- Simplified templates and removed unnecessary source-original bloat from the main pack.
- Added clearer warning that match/ATS scores are estimates, not guarantees.
- Added country and seniority conventions.
- Added failure-mode repair guide.
