# v4 Elite Upgrade Notes

v4 turns the pack from a document generator into a CV strategy system.

## Added

- Elite positioning engine: role thesis, employer buying need, proof stack, content cuts, risk plan.
- Recruiter psychology: 6 to 10 second scan logic and rejection-risk removal.
- High-impact CV patterns: summary formulas, bullet hierarchy, one-page/two-page logic.
- Role-specific writing packs for policy, finance, BI, AI/ML, EdTech, academic, early-career, and executive profiles.
- AI-fingerprint/style polish reference.
- Final review board with truth, ATS, recruiter, hiring-manager, and style reviewers.
- New templates for elite positioning, elite ATS resume, readiness scorecard, and top 10% prompt.
- New scripts for style linting and risky claim detection.

## Philosophy

A top CV is a hiring argument, not a decoration. It must be sharper, clearer, and more persuasive while remaining fully evidence-based.
