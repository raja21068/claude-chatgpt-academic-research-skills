# Claude Code Instructions

Use this repository as an elite one-shot CV and job-application package generator. Start with `SKILL.md`, then read only the reference files needed for the user's target role and output format. Prefer truthful, ATS-safe, role-specific writing over decorative design.
