# Resume-Only Prompt

Use the one-shot-resume-agent skill.

Create only a tailored ATS resume for this role, plus a short evidence matrix and scorecard. Keep it one page unless the evidence strongly justifies two pages. Do not invent metrics.

Candidate evidence:
[paste]

Job description:
[paste]
