# Academic CV Prompt

Use the one-shot-resume-agent skill.

Create an academic CV and cover letter for this research role. Prioritize education, publications, research experience, methods, teaching, presentations, and grants. Preserve publication metadata exactly as provided.

Candidate evidence:
[paste]

Role/fellowship/PhD/postdoc description:
[paste]
