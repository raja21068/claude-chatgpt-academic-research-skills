# One-Shot Full Package Prompt

Use the one-shot-resume-agent skill.

Target output: full application package.
Keep it ATS-safe, evidence-based, and concise.
Do not invent metrics. Use TODO placeholders for missing facts.
Create resume, cover letter, recruiter email, LinkedIn update, interview prep, evidence matrix, ATS/recruiter scorecard, editing report, and final checklist.

Candidate evidence:
[paste resume/CV/profile]

Job description:
[paste job description]
