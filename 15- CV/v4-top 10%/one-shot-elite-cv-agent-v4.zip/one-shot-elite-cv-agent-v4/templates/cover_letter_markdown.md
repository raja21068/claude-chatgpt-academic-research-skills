{Candidate Name}  
{Email} | {Phone optional} | {Location}  
{Date}

Dear {Hiring Manager or Hiring Team},

{Specific opening: role + strongest relevant evidence + why this organization/role fits, without generic excitement.}

{Evidence paragraph 1: strongest job requirement matched to confirmed candidate evidence. Include tools/methods/context.}

{Evidence paragraph 2: second evidence pillar or transferable bridge. Address important gap honestly if needed.}

{Closing: concise availability/interest, no invented claims.}

Sincerely,  
{Candidate Name}
