# Elite Positioning Strategy

## Target role
- Company:
- Role:
- Seniority:
- Location / country convention:

## Role thesis
One sentence explaining why the candidate is credible for this role:

> 

## Employer buying need
The employer appears to need someone who can:

1. 
2. 
3. 

## Candidate proof stack
| Rank | Evidence | Why it matters for this role | Strength |
|---|---|---|---|
| 1 |  |  | Confirmed / Partial / Missing |
| 2 |  |  | Confirmed / Partial / Missing |
| 3 |  |  | Confirmed / Partial / Missing |

## Positioning lane
Primary lane:
Secondary support lane:
Content to minimize:
Content to remove:

## Risk plan
| Risk or gap | How to handle honestly |
|---|---|
|  |  |
