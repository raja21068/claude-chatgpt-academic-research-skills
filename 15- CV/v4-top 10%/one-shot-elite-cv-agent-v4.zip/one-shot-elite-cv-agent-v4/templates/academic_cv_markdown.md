# {Candidate Name}

{Email} | {Location} | {Website/Google Scholar/ORCID optional}

## Research Interests

{Specific fields, methods, and research agenda.}

## Education

### {Degree}, {Field} | {Institution}  
*{Dates}*

## Publications

1. {Citation exactly as provided. Do not invent status.}

## Research Experience

### {Role} | {Lab/Center/Institution}  
*{Dates}*

- {Question + method + data/model + output.}

## Teaching Experience

-

## Presentations

-

## Grants, Honors, and Awards

-

## Technical and Methodological Skills

-

## Service

-

## References

Available upon request, unless specific references are provided and requested.
