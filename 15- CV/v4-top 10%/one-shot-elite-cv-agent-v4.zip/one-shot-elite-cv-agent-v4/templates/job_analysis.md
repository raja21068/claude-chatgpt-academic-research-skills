# Job Analysis

## Role Snapshot

- Company:
- Role:
- Role family:
- Seniority:
- Location/work mode:
- Application instructions:

## Required Qualifications

-

## Preferred Qualifications

-

## Core Responsibilities

-

## Keyword Map

| Keyword or phrase | Tier | Type | Exact JD wording | Candidate evidence | Use in resume? | Placement |
|---|---:|---|---|---|---|---|

## Match Estimate

- Estimated range:
- Strongest matches:
- Stretch areas:
- Missing evidence:
