# Strategy and Gap Plan

- Core positioning sentence:
- Top evidence pillar 1:
- Top evidence pillar 2:
- Top evidence pillar 3:
- Strongest transferable bridge:
- Keywords safe to use:
- Keywords not safe to use:
- What to lead with:
- What to minimize:

## Gaps and Handling Plan

| Gap or risk | Why it matters | Honest handling strategy | Resume action | Interview action |
|---|---|---|---|---|
