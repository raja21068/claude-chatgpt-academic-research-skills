# Final Submission Checklist

- [ ] Contact details are correct.
- [ ] Company and role name are correct.
- [ ] Dates, titles, degrees, and institutions are correct.
- [ ] No unsupported metrics remain.
- [ ] No TODO placeholders remain in final documents, unless user intentionally keeps them.
- [ ] Resume is ATS-safe.
- [ ] Cover letter is company/role-specific.
- [ ] Filename is professional: `{Name}_{Company}_{Role}_Resume.pdf`.
- [ ] PDF opens correctly.
- [ ] Application instructions were followed.
