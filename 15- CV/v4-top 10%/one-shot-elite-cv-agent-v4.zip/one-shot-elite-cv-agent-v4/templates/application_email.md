# Application Email

**Subject:** Application for {Role} — {Candidate Name}

Dear {Hiring Team / Name},

Please find attached my application for the {Role} position at {Company}. My background in {evidence pillar 1} and {evidence pillar 2} aligns with your need for {role need from JD}.

I would welcome the opportunity to discuss how my experience with {specific confirmed evidence} can support your team.

Best regards,  
{Candidate Name}
