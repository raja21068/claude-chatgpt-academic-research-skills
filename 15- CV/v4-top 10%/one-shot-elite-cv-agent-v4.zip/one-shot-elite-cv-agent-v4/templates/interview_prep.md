# Interview Prep

## 60-Second Pitch

{Role-specific pitch using confirmed evidence.}

## Likely Questions and Answer Outlines

| Question | What they are testing | Evidence to use | STAR outline |
|---|---|---|---|

## Gap Questions

| Gap | Honest answer strategy | Bridge evidence |
|---|---|---|

## Questions to Ask Employer

-
