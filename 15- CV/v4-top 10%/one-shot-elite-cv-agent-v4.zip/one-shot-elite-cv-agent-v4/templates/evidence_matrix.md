# Evidence Matrix

| Evidence ID | Source | Candidate fact or achievement | Status | Safe wording | Risk/TODO |
|---|---|---|---|---|---|
| E1 |  |  | Confirmed / Derived / Needs verification / Missing / Excluded |  |  |

## Job Requirement Mapping

| Job requirement | Priority | Candidate evidence ID | Evidence status | Resume placement | Cover letter angle | Risk/TODO |
|---|---:|---|---|---|---|---|
