# ATS and Recruiter Scorecard

These are transparent readiness estimates, not guaranteed ATS scores.

| Category | Score / 10 | Evidence | Fix |
|---|---:|---|---|
| Role relevance |  |  |  |
| Evidence strength |  |  |  |
| ATS readability |  |  |  |
| Recruiter scanability |  |  |  |
| Bullet impact |  |  |  |
| Cover letter specificity |  |  |  |
| Risk control |  |  |  |

## Top Fixes Before Submission

1.
2.
3.
