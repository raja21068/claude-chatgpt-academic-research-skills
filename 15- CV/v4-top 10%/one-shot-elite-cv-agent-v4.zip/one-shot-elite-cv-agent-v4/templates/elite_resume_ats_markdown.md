# NAME SURNAME
City, Region/Country | Email | Phone | LinkedIn/Portfolio

## TARGETED HEADLINE
[Target Role / Function] | [Domain] | [Top Tools or Methods]

## SUMMARY
[2 to 4 lines. State role identity, domain, tools/methods, outputs, and strongest differentiator. No generic adjectives.]

## CORE SKILLS
**Category 1:** Skill, Skill, Skill  
**Category 2:** Skill, Skill, Skill  
**Category 3:** Skill, Skill, Skill

## EXPERIENCE

### Job Title | Organization | Location | Month Year - Month Year
- [Action + scope + method/tool + outcome. 18 to 30 words.]
- [Second strongest target-relevant bullet.]
- [Stakeholder, reporting, automation, or technical depth bullet.]

### Job Title | Organization | Location | Month Year - Month Year
- 
- 

## SELECTED PROJECTS / RESEARCH

### Project Title | Tools/Methods | Year
- [Problem + dataset/context + method + result/output.]
- [Relevance to target role.]

## EDUCATION

**Degree**, University/Institution, Location | Graduation Month Year  
Relevant coursework: [Only if useful]

## ADDITIONAL INFORMATION
Certifications / Publications / Awards / Languages / Work authorization only where relevant and appropriate.
