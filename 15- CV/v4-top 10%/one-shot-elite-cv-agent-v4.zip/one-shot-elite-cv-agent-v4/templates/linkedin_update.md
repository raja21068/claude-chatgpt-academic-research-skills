# LinkedIn Update Package

## Headline

{Target role identity} | {Skill/domain 1} | {Skill/domain 2} | {Evidence-backed differentiator}

## About

Paragraph 1: professional identity and strongest domain.  
Paragraph 2: evidence-backed achievements, tools, and methods.  
Paragraph 3: target roles, interests, and collaboration/contact note.

## Featured Items to Add

-

## Skills to Pin

-
