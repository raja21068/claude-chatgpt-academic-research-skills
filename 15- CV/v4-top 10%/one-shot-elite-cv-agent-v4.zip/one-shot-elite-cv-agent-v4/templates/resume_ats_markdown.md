# {Candidate Name}

{City, Country} | {Email} | {Phone optional} | {LinkedIn optional} | {Portfolio optional}

## Summary

{2 to 4 lines targeted to the role. No unsupported adjectives.}

## Skills

**Technical:** {confirmed tools only}  
**Methods:** {confirmed methods only}  
**Domains:** {confirmed domains only}

## Experience

### {Title} | {Organization} | {Location}  
*{Date range}*

- {Action + object + method/tool + result/context.}
- {Action + object + method/tool + result/context.}

## Projects or Research Experience

### {Project Name}  
*{Tools/methods if confirmed}*

- {Problem + method + output/result.}

## Education

### {Degree} | {Institution} | {Location}  
*{Date or expected date}*

- {Relevant coursework/honors only if useful and evidenced.}

## Certifications / Awards / Leadership

- {Only if confirmed and relevant.}
