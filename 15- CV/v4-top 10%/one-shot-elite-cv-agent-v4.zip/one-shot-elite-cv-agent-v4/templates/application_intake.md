# Input Summary

- Candidate evidence received:
- Job description received:
- Target company:
- Target role:
- Location / work mode:
- Seniority:
- Output package requested:
- Format requested:
- Country convention:
- Page target:
- Constraints:
- Missing or ambiguous items:
- Assumptions used:
