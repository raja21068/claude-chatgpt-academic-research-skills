#!/usr/bin/env python3
"""Simple keyword coverage checker.

Usage:
    python scripts/score_keyword_coverage.py keywords.txt resume.md

keywords.txt should contain one keyword or phrase per line.
"""
from pathlib import Path
import sys

if len(sys.argv) != 3:
    print("Usage: score_keyword_coverage.py <keywords.txt> <resume.md>")
    raise SystemExit(2)

keywords = [k.strip() for k in Path(sys.argv[1]).read_text(encoding='utf-8').splitlines() if k.strip()]
text = Path(sys.argv[2]).read_text(encoding='utf-8', errors='ignore').lower()

hits = []
misses = []
for kw in keywords:
    if kw.lower() in text:
        hits.append(kw)
    else:
        misses.append(kw)

print(f"Coverage: {len(hits)}/{len(keywords)} ({(len(hits)/max(len(keywords),1))*100:.1f}%)")
print("\nPresent:")
for k in hits:
    print(f"- {k}")
print("\nMissing:")
for k in misses:
    print(f"- {k}")
