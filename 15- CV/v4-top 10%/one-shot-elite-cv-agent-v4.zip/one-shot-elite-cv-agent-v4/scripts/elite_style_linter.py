#!/usr/bin/env python3
"""Simple resume style linter for AI-sounding phrases and weak CV patterns."""
from pathlib import Path
import sys, re

BAD_PHRASES = [
    "results-driven", "passionate", "dedicated professional", "proven track record",
    "dynamic", "visionary", "excellent communication skills", "hardworking",
    "team player", "go-getter", "detail-oriented"  # allowed only with proof, so flag for review
]
WEAK_VERBS = ["responsible for", "helped with", "worked on", "assisted in", "participated in"]

def scan(text: str):
    issues = []
    low = text.lower()
    for p in BAD_PHRASES:
        if p in low:
            issues.append(f"AI/generic phrase: {p}")
    for p in WEAK_VERBS:
        if p in low:
            issues.append(f"Weak phrasing to rewrite: {p}")
    for i, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if s.startswith('-') and not s.startswith('- `'):
            words = re.findall(r"\b\w+[\w/%+.-]*\b", s)
            if len(words) > 34:
                issues.append(f"Line {i}: bullet may be too long ({len(words)} words)")
            if len(words) < 8 and not any(token in s.lower() for token in ['for ', 'when ', 'optional', 'required']):
                issues.append(f"Line {i}: bullet may be too thin ({len(words)} words)")
    return issues

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: elite_style_linter.py FILE.md')
        sys.exit(2)
    path = Path(sys.argv[1])
    text = path.read_text(errors='ignore')
    issues = scan(text)
    if issues:
        print('STYLE ISSUES FOUND:')
        for x in issues:
            print('-', x)
        sys.exit(1)
    print('Style linter passed.')
