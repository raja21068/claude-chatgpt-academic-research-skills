#!/usr/bin/env python3
"""Self-check the skill pack structure.

Accepts both the full Claude Code project layout and the Claude.ai upload layout.
"""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
required_common = [
    "SKILL.md",
    "README.md",
    "references/01-evidence-and-anti-fabrication.md",
    "templates/resume_ats_markdown.md",
    "scripts/validate_application_package.py",
]
missing = [p for p in required_common if not (root / p).exists()]
print("One-Shot Elite CV Agent v4 self-check")
print("=" * 42)
if missing:
    print("Missing common files:")
    for p in missing:
        print("-", p)
    raise SystemExit(1)

skill = (root / "SKILL.md").read_text(encoding="utf-8")
if not skill.startswith("---") or "name:" not in skill or "description:" not in skill:
    print("SKILL.md frontmatter problem")
    raise SystemExit(1)

if (root / ".claude/skills/one-shot-resume/SKILL.md").exists():
    print("Full Claude Code layout detected.")
else:
    print("Uploadable Claude.ai skill layout detected.")
print("Structure OK")
