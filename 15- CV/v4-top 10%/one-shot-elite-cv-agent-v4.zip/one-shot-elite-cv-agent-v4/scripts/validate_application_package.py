#!/usr/bin/env python3
"""Validate a one-shot resume application package.

Usage:
    python scripts/validate_application_package.py applications/Company_Role
"""
from pathlib import Path
import re
import sys

REQUIRED = [
    "00_INPUT_SUMMARY.md",
    "01_JOB_ANALYSIS.md",
    "02_EVIDENCE_MATRIX.md",
    "03_STRATEGY_AND_GAPS.md",
    "04_TAILORED_RESUME.md",
    "05_COVER_LETTER.md",
    "09_ATS_RECRUITER_SCORECARD.md",
    "10_EDITING_REPORT.md",
    "11_FINAL_SUBMISSION_CHECKLIST.md",
]

RISKY_PHRASES = [
    "proven track record", "results-driven", "dynamic", "passionate",
    "hardworking", "detail-oriented", "synergy", "delve", "tapestry",
    "realm", "pivotal", "multifaceted", "cutting-edge", "game-changing",
]

ATS_RISK_PATTERNS = [
    (r"<table|</table>", "HTML table detected"),
    (r"\|\s*-{3,}\s*\|", "Markdown table detected; avoid tables in final resume core content"),
    (r"[★●■◆✅📌☎✉]", "Icon or symbol detected; avoid icons in ATS resume"),
]

LATEX_SPECIALS = ["&", "%", "$", "#", "_"]


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore") if path.exists() else ""


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: validate_application_package.py <application_folder>")
        return 2
    folder = Path(sys.argv[1])
    problems = []
    warnings = []

    if not folder.exists():
        print(f"ERROR: folder not found: {folder}")
        return 2

    for name in REQUIRED:
        if not (folder / name).exists():
            problems.append(f"Missing required file: {name}")

    resume = read(folder / "04_TAILORED_RESUME.md")
    cover = read(folder / "05_COVER_LETTER.md")
    evidence = read(folder / "02_EVIDENCE_MATRIX.md")
    combined = "\n".join([resume, cover, evidence]).lower()

    if "confirmed" not in evidence.lower() and "needs verification" not in evidence.lower():
        problems.append("Evidence matrix does not appear to contain evidence statuses.")

    for phrase in RISKY_PHRASES:
        if phrase in combined:
            warnings.append(f"Risky generic/AI-sounding phrase: '{phrase}'")

    for pattern, message in ATS_RISK_PATTERNS:
        if re.search(pattern, resume, flags=re.IGNORECASE):
            warnings.append(message)

    if "[todo" in combined or "TODO" in resume or "TODO" in cover:
        warnings.append("TODO placeholders remain. Keep them only in review drafts, not final submissions.")

    # Very simple unsupported-metric heuristic: metrics in resume but no digit in evidence matrix.
    if re.search(r"\b\d+(?:\.\d+)?\s*(?:%|percent|x|k|m|million|billion|users|students|datasets|hours)\b", resume, re.I):
        if not re.search(r"\b\d", evidence):
            warnings.append("Resume contains numeric claims but evidence matrix has no numeric evidence.")

    print("One-Shot Resume Package Validation")
    print("=" * 40)
    if problems:
        print("PROBLEMS:")
        for p in problems:
            print(f"- {p}")
    else:
        print("No blocking file/evidence problems found.")

    if warnings:
        print("\nWARNINGS:")
        for w in warnings:
            print(f"- {w}")
    else:
        print("No warnings found.")

    return 1 if problems else 0

if __name__ == "__main__":
    raise SystemExit(main())
