#!/usr/bin/env python3
"""Flags risky superiority claims in generated application files.

This script is intended for final application packages, not for instructional
reference files. It skips lines that are clearly warnings such as "not guaranteed"
or "without proof".
"""
from pathlib import Path
import sys, re

RISK_PATTERNS = [
    r"\btop\s+\d+%\b", r"\bbest-in-class\b", r"\bindustry-leading\b",
    r"\bexpert\b", r"\bmastery\b", r"\bguaranteed\b", r"\bperfect\b",
    r"\bworld-class\b", r"\baward-winning\b"
]
SAFE_CONTEXTS = ["not guaranteed", "not a guaranteed", "without proof", "do not", "avoid", "risky", "flag", "warning"]
SKIP_PARTS = {"references", "scripts", "docs", ".claude"}

def should_skip_file(path: Path) -> bool:
    return any(part in SKIP_PARTS for part in path.parts)

def main(root):
    root = Path(root)
    files = list(root.rglob('*.md')) + list(root.rglob('*.tex'))
    flagged = []
    for f in files:
        if should_skip_file(f.relative_to(root)):
            continue
        for line_no, line in enumerate(f.read_text(errors='ignore').splitlines(), 1):
            low = line.lower()
            if any(ctx in low for ctx in SAFE_CONTEXTS):
                continue
            for pat in RISK_PATTERNS:
                for m in re.finditer(pat, line, flags=re.I):
                    flagged.append((f, line_no, m.group(0)))
    if flagged:
        print('RISKY CLAIMS TO VERIFY:')
        for f, line_no, found in flagged:
            print(f'- {f}:{line_no}: "{found}"')
        sys.exit(1)
    print('No risky superiority claims detected in output-facing templates.')

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else '.')
