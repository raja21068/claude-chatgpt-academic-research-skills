#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${1:-.}"
cd "$APP_DIR"

compile_tex() {
  local texfile="$1"
  if [[ ! -f "$texfile" ]]; then
    return 0
  fi
  if command -v latexmk >/dev/null 2>&1; then
    latexmk -pdf -interaction=nonstopmode "$texfile"
  elif command -v pdflatex >/dev/null 2>&1; then
    pdflatex -interaction=nonstopmode "$texfile"
    pdflatex -interaction=nonstopmode "$texfile"
  elif command -v xelatex >/dev/null 2>&1; then
    xelatex -interaction=nonstopmode "$texfile"
    xelatex -interaction=nonstopmode "$texfile"
  else
    echo "No TeX engine found. Leave .tex files ready for Overleaf or local compilation."
    return 1
  fi
}

compile_tex "04_TAILORED_RESUME.tex" || true
compile_tex "05_COVER_LETTER.tex" || true
