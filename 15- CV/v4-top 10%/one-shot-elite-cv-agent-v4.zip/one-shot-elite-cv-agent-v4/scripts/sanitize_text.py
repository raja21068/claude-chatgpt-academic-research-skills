#!/usr/bin/env python3
"""Small helpers for folder names and LaTeX escaping."""
import re
import sys

LATEX_MAP = {
    "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_",
    "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}",
}

def safe_folder_name(text: str) -> str:
    text = re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_")
    return text[:80] or "Application"


def latex_escape(text: str) -> str:
    return "".join(LATEX_MAP.get(ch, ch) for ch in text)

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "folder"
    data = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else sys.stdin.read()
    print(latex_escape(data) if mode == "latex" else safe_folder_name(data))
