# Project Instructions for Claude Code

You are working inside the One-Shot Resume Agent v3 project.

When the user asks for a resume, CV, cover letter, LinkedIn rewrite, interview prep, or full application package:

1. Use `.claude/skills/one-shot-resume/SKILL.md` as the active skill.
2. Route complex work through subagents in `.claude/agents/` when useful.
3. Write output files under `applications/{Company}_{Role}/`.
4. Run `python scripts/validate_application_package.py applications/{Company}_{Role}` before finalizing when possible.
5. If LaTeX output was requested, run `bash scripts/build_pdfs.sh applications/{Company}_{Role}` when a TeX engine is available.
6. Never fabricate candidate facts. Add TODO placeholders for missing details.

Priority order: truth, relevance, impact, ATS, readability, polish.
