#!/usr/bin/env python3
"""Self-check the skill pack structure."""
from pathlib import Path
import sys
import re

root = Path(__file__).resolve().parents[1]
required = [
    "SKILL.md",
    "README.md",
    "CLAUDE.md",
    ".claude/skills/one-shot-resume/SKILL.md",
    "references/01-evidence-and-anti-fabrication.md",
    "templates/resume_ats_markdown.md",
    "scripts/validate_application_package.py",
]
missing = [p for p in required if not (root / p).exists()]
print("One-Shot Resume Agent v3 self-check")
print("=" * 42)
if missing:
    print("Missing files:")
    for p in missing:
        print("-", p)
    raise SystemExit(1)

skill = (root / "SKILL.md").read_text(encoding="utf-8")
if not skill.startswith("---") or "name:" not in skill or "description:" not in skill:
    print("SKILL.md frontmatter problem")
    raise SystemExit(1)
print("Structure OK")
