# One-Shot Resume Agent v3

A production-ready Claude Skill / Claude Code agent pack for generating a complete job application package in one run.

## What v3 improves

- **Cleaner Claude Skill trigger**: concise root `SKILL.md` with only required frontmatter fields.
- **Progressive disclosure**: detailed rules are split into reference files so Claude reads only what it needs.
- **Accuracy-first workflow**: all claims are controlled through an evidence matrix.
- **Anti-fabrication system**: missing metrics, dates, tools, certifications, publications, and achievements become TODOs instead of invented facts.
- **One-shot package**: resume/CV, cover letter, application email, LinkedIn update, interview prep, ATS/recruiter scorecard, editing report, and checklist.
- **Deterministic scripts**: validators check missing files, risky phrases, placeholders, keyword coverage, and LaTeX escaping concerns.
- **Claude Code compatible**: includes `.claude/agents/` subagents and `.claude/skills/one-shot-resume/SKILL.md`.
- **Claude.ai upload friendly**: this folder has a root `SKILL.md`.

## Quick use prompt

```text
Use the one-shot-resume-agent skill.

Target output: full application package.
Keep it ATS-safe, evidence-based, and concise.
Do not invent metrics. Use TODO placeholders for missing facts.
Create resume, cover letter, recruiter email, LinkedIn update, interview prep, evidence matrix, ATS/recruiter scorecard, editing report, and final checklist.

Candidate evidence:
[paste resume/CV/profile]

Job description:
[paste job description]
```

## Folder structure

```text
SKILL.md
CLAUDE.md
.claude/agents/
.claude/skills/one-shot-resume/SKILL.md
references/
templates/
scripts/
workflows/
examples/
```

## Best operating rule

This agent should make the candidate look as strong as possible **without making them less true**.
