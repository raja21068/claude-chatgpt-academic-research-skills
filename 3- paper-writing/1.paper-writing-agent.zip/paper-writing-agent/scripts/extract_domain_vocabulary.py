#!/usr/bin/env python3
"""
Extract domain-specific vocabulary and phrasing from recent reference papers.

This learns the CURRENT terminology of the field you're writing in,
separate from your personal writing style. Drop 2-3 top recent papers
from the target domain into reference_papers/ and run this.

Usage:
    python extract_domain_vocabulary.py --pdf-folder ../reference_papers --output ../references/domain_vocabulary.md

Requirements:
    pip install pdfplumber nltk --break-system-packages
"""

import argparse
import re
import string
from pathlib import Path
from collections import Counter

try:
    import pdfplumber
    PDF_BACKEND = "pdfplumber"
except ImportError:
    try:
        from PyPDF2 import PdfReader
        PDF_BACKEND = "pypdf2"
    except ImportError:
        print("ERROR: Install pdfplumber or PyPDF2:")
        print("  pip install pdfplumber --break-system-packages")
        exit(1)

import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.util import ngrams

nltk.download('punkt', quiet=True)
nltk.download('punkt_tab', quiet=True)
nltk.download('averaged_perceptron_tagger_eng', quiet=True)
nltk.download('stopwords', quiet=True)

from nltk.corpus import stopwords

STOP_WORDS = set(stopwords.words('english'))

# Common academic words to filter out (not domain-specific)
GENERIC_ACADEMIC = {
    'paper', 'method', 'approach', 'results', 'show', 'propose', 'proposed',
    'based', 'using', 'used', 'model', 'models', 'data', 'performance',
    'table', 'figure', 'section', 'following', 'work', 'previous', 'recent',
    'also', 'however', 'therefore', 'experiment', 'experiments', 'training',
    'test', 'testing', 'evaluation', 'compared', 'comparison', 'existing',
    'number', 'set', 'given', 'different', 'two', 'three', 'first', 'second',
    'one', 'new', 'use', 'can', 'may', 'well', 'e.g', 'i.e', 'et', 'al',
    'fig', 'eq', 'ref', 'respectively', 'corresponding', 'according',
}

SECTION_PATTERNS = [
    (r'(?i)\babstract\b', 'abstract'),
    (r'(?i)\b(?:1\.?\s*)?introduction\b', 'introduction'),
    (r'(?i)\b(?:2\.?\s*)?(?:related\s+work|background|literature)\b', 'related_work'),
    (r'(?i)\b(?:3\.?\s*)?(?:method|approach|proposed)\b', 'methods'),
    (r'(?i)\b(?:4\.?\s*)?(?:experiment|results)\b', 'results'),
    (r'(?i)\b(?:5\.?\s*)?(?:discussion|analysis)\b', 'discussion'),
    (r'(?i)\b(?:6\.?\s*)?(?:conclusion|summary)\b', 'conclusion'),
]


def extract_text_from_pdf(pdf_path):
    """Extract full text from a PDF file."""
    if PDF_BACKEND == "pdfplumber":
        text = ""
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
        return text
    else:
        reader = PdfReader(pdf_path)
        text = ""
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
        return text


def is_technical_term(word):
    """Check if a word looks like a domain-specific technical term."""
    w = word.lower().strip(string.punctuation)
    if len(w) < 3:
        return False
    if w in STOP_WORDS or w in GENERIC_ACADEMIC:
        return False
    if w.isdigit():
        return False
    return True


def extract_technical_unigrams(texts, top_n=40):
    """Extract most frequent domain-specific single words."""
    counter = Counter()
    for text in texts:
        words = word_tokenize(text.lower())
        for w in words:
            w = w.strip(string.punctuation)
            if is_technical_term(w):
                counter[w] += 1
    return counter.most_common(top_n)


def extract_technical_bigrams(texts, top_n=30):
    """Extract frequent two-word technical phrases."""
    counter = Counter()
    for text in texts:
        words = word_tokenize(text.lower())
        for bg in ngrams(words, 2):
            phrase = ' '.join(bg)
            # Filter: at least one word should be technical
            if any(is_technical_term(w) for w in bg) and not all(w in STOP_WORDS for w in bg):
                # Filter out phrases with punctuation
                if not any(c in string.punctuation for c in phrase.replace('-', '').replace(' ', '')):
                    counter[phrase] += 1
    # Only keep phrases appearing 3+ times
    return [(p, c) for p, c in counter.most_common(top_n * 2) if c >= 3][:top_n]


def extract_technical_trigrams(texts, top_n=20):
    """Extract frequent three-word technical phrases."""
    counter = Counter()
    for text in texts:
        words = word_tokenize(text.lower())
        for tg in ngrams(words, 3):
            phrase = ' '.join(tg)
            if any(is_technical_term(w) for w in tg) and not all(w in STOP_WORDS for w in tg):
                if not any(c in string.punctuation for c in phrase.replace('-', '').replace(' ', '')):
                    counter[phrase] += 1
    return [(p, c) for p, c in counter.most_common(top_n * 2) if c >= 3][:top_n]


def extract_key_sentences(texts, top_terms, max_sentences=15):
    """Extract sentences that contain multiple domain terms — these show how terms are used in context."""
    top_term_set = set(t for t, _ in top_terms)
    scored_sents = []
    seen = set()

    for text in texts:
        sents = sent_tokenize(text)
        for sent in sents:
            sent_clean = ' '.join(sent.split())
            if len(sent_clean) < 50 or len(sent_clean) > 300:
                continue
            # Count how many domain terms appear
            sent_lower = sent_clean.lower()
            score = sum(1 for t in top_term_set if t in sent_lower)
            if score >= 2 and sent_clean not in seen:
                scored_sents.append((sent_clean, score))
                seen.add(sent_clean)

    scored_sents.sort(key=lambda x: -x[1])
    return [s for s, _ in scored_sents[:max_sentences]]


def extract_section_openings(texts):
    """Get how each section typically opens in reference papers."""
    openings = {}
    for text in texts:
        current_section = None
        lines = text.split('\n')
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            for pattern, sec_name in SECTION_PATTERNS:
                if len(stripped) < 80 and re.match(pattern, stripped):
                    current_section = sec_name
                    break
            else:
                if current_section and len(stripped) > 40 and stripped[0].isupper():
                    if current_section not in openings:
                        openings[current_section] = []
                    if len(openings[current_section]) < 2:
                        openings[current_section].append(stripped[:150])
    return openings


def generate_domain_vocabulary(pdf_folder, output_file):
    pdf_folder = Path(pdf_folder)
    output_file = Path(output_file)

    pdf_files = list(pdf_folder.glob("*.pdf"))
    if not pdf_files:
        print(f"No PDF files found in {pdf_folder}")
        return

    print(f"Found {len(pdf_files)} reference papers")

    # Extract text from all PDFs
    all_texts = []
    paper_titles = []
    for i, pdf_path in enumerate(pdf_files, 1):
        print(f"[{i}/{len(pdf_files)}] Reading: {pdf_path.name}")
        try:
            text = extract_text_from_pdf(pdf_path)
            if len(text) > 500:
                all_texts.append(text)
                paper_titles.append(pdf_path.stem)
        except Exception as e:
            print(f"  Error: {e}")

    if not all_texts:
        print("No text extracted from PDFs.")
        return

    print("\nExtracting domain vocabulary...")

    unigrams = extract_technical_unigrams(all_texts)
    bigrams = extract_technical_bigrams(all_texts)
    trigrams = extract_technical_trigrams(all_texts)

    # Combine all top terms for sentence extraction
    all_top_terms = unigrams[:20] + bigrams[:15] + trigrams[:10]
    key_sentences = extract_key_sentences(all_texts, all_top_terms)
    section_openings = extract_section_openings(all_texts)

    # Build the vocabulary file
    content = f"""# Domain Vocabulary Profile

*Auto-generated from {len(all_texts)} reference papers.*
*Source papers: {', '.join(paper_titles[:5])}{'...' if len(paper_titles) > 5 else ''}*

Use this vocabulary when writing in this domain. These are the terms,
phrases, and patterns that current papers in this field actually use.

---

## 1. Key Technical Terms (single words)

{chr(10).join(f'- **{term}** ({count}x)' for term, count in unigrams[:25])}

---

## 2. Key Technical Phrases (2-word)

{chr(10).join(f'- **{phrase}** ({count}x)' for phrase, count in bigrams[:20])}

---

## 3. Key Technical Phrases (3-word)

{chr(10).join(f'- **{phrase}** ({count}x)' for phrase, count in trigrams[:15])}

---

## 4. Example Sentences Showing Terminology in Context

These show how domain terms are naturally used in current papers:

"""
    for i, sent in enumerate(key_sentences, 1):
        content += f"**{i}.** {sent}\n\n"

    content += "---\n\n## 5. Section Opening Patterns in This Domain\n\n"
    content += "How current papers in this field typically open each section:\n\n"
    for sec, openings in section_openings.items():
        content += f"### {sec.capitalize()}\n"
        for j, opening in enumerate(openings, 1):
            content += f'{j}. "{opening}..."\n'
        content += "\n"

    content += """---

## 6. Usage Instructions for Claude

When drafting paper sections in this domain:

1. Use the technical terms and phrases listed above naturally
2. Follow the section opening patterns from current papers
3. Imitate the phrasing shown in the example sentences
4. Combine this domain vocabulary with the author's personal writing style
5. If a term appears 10+ times above, it is standard terminology — use it confidently
6. If a term appears 3-5 times, it is common but not universal — use when appropriate
7. Never invent new terminology when standard terms exist
"""

    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(content, encoding='utf-8')
    print(f"\nDomain vocabulary saved to: {output_file}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Extract domain vocabulary from reference papers")
    parser.add_argument("--pdf-folder", required=True, help="Folder with reference paper PDFs")
    parser.add_argument("--output", default="../references/domain_vocabulary.md",
                        help="Output vocabulary file")
    args = parser.parse_args()
    generate_domain_vocabulary(args.pdf_folder, args.output)
