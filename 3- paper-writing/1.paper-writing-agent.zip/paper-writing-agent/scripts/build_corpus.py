#!/usr/bin/env python3
"""
Build a personal writing corpus from your published papers (PDFs).

Usage:
    python build_corpus.py --pdf-folder /path/to/your/pdfs --output corpus/

This script:
1. Reads all PDF files from the specified folder
2. Extracts text from each paper
3. Splits text into sections (abstract, introduction, methods, etc.)
4. Saves each section as a separate .txt file

Requirements:
    pip install PyPDF2 pdfplumber --break-system-packages
"""

import argparse
import re
from pathlib import Path

try:
    import pdfplumber
    PDF_BACKEND = "pdfplumber"
except ImportError:
    try:
        from PyPDF2 import PdfReader
        PDF_BACKEND = "pypdf2"
    except ImportError:
        print("ERROR: Install pdfplumber or PyPDF2:")
        print("  pip install pdfplumber --break-system-packages")
        exit(1)


SECTION_PATTERNS = [
    (r'(?i)\babstract\b', 'abstract'),
    (r'(?i)\b(?:1\.?\s*)?introduction\b', 'introduction'),
    (r'(?i)\b(?:2\.?\s*)?(?:related\s+work|background|literature\s+review)\b', 'related_work'),
    (r'(?i)\b(?:3\.?\s*)?(?:method(?:s|ology)?|approach|proposed\s+method|our\s+approach)\b', 'methods'),
    (r'(?i)\b(?:4\.?\s*)?(?:experiment(?:s|al)?(?:\s+(?:setup|results))?)\b', 'experiments'),
    (r'(?i)\b(?:5\.?\s*)?results?\b', 'results'),
    (r'(?i)\b(?:6\.?\s*)?(?:discussion|analysis)\b', 'discussion'),
    (r'(?i)\b(?:7\.?\s*)?(?:conclusion(?:s)?|summary)\b', 'conclusion'),
    (r'(?i)\b(?:8\.?\s*)?(?:limitation(?:s)?)\b', 'limitations'),
]


def extract_text_from_pdf(pdf_path):
    """Extract full text from a PDF file."""
    if PDF_BACKEND == "pdfplumber":
        text = ""
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
        return text
    else:
        reader = PdfReader(pdf_path)
        text = ""
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
        return text


def split_into_sections(text):
    """Split paper text into named sections using heading patterns."""
    sections = {}
    lines = text.split('\n')
    current_section = 'preamble'
    current_content = []

    for line in lines:
        stripped = line.strip()
        if not stripped:
            current_content.append('')
            continue

        matched = False
        for pattern, section_name in SECTION_PATTERNS:
            # Match lines that look like section headings (short, starts with pattern)
            if len(stripped) < 80 and re.match(pattern, stripped):
                # Save previous section
                if current_content and current_section != 'preamble':
                    content = '\n'.join(current_content).strip()
                    if len(content) > 100:  # ignore tiny fragments
                        sections[current_section] = content
                current_section = section_name
                current_content = []
                matched = True
                break

        if not matched:
            current_content.append(stripped)

    # Save last section
    if current_content and current_section != 'preamble':
        content = '\n'.join(current_content).strip()
        if len(content) > 100:
            sections[current_section] = content

    return sections


def process_pdfs(pdf_folder, output_folder):
    """Process all PDFs in a folder and save section texts."""
    pdf_folder = Path(pdf_folder)
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)

    pdf_files = list(pdf_folder.glob("*.pdf"))
    if not pdf_files:
        print(f"No PDF files found in {pdf_folder}")
        return

    print(f"Found {len(pdf_files)} PDF files")

    for i, pdf_path in enumerate(pdf_files, 1):
        print(f"[{i}/{len(pdf_files)}] Processing: {pdf_path.name}")
        try:
            text = extract_text_from_pdf(pdf_path)
            if len(text) < 500:
                print(f"  Skipping (too short): {len(text)} chars")
                continue

            sections = split_into_sections(text)
            if not sections:
                print(f"  Warning: No sections detected")
                continue

            # Save sections
            paper_dir = output_folder / pdf_path.stem
            paper_dir.mkdir(exist_ok=True)

            for sec_name, sec_text in sections.items():
                out_file = paper_dir / f"{sec_name}.txt"
                out_file.write_text(sec_text, encoding='utf-8')

            print(f"  Extracted {len(sections)} sections: {list(sections.keys())}")

        except Exception as e:
            print(f"  Error: {e}")

    print(f"\nDone! Corpus saved to: {output_folder}")
    print(f"Next step: run extract_writing_style.py --corpus {output_folder}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Build writing corpus from PDFs")
    parser.add_argument("--pdf-folder", required=True, help="Folder containing your paper PDFs")
    parser.add_argument("--output", default="corpus", help="Output corpus folder (default: corpus/)")
    args = parser.parse_args()
    process_pdfs(args.pdf_folder, args.output)
