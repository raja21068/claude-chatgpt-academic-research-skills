@echo off
echo ============================================
echo   Paper Writing Agent - Full Setup
echo ============================================
echo.

:: Get the directory where this script lives
set SCRIPT_DIR=%~dp0

:: All data folders live inside scripts/ to keep main dir clean
set PDF_FOLDER=%SCRIPT_DIR%pdfs
set CORPUS_FOLDER=%SCRIPT_DIR%corpus
set REF_FOLDER=%SCRIPT_DIR%reference_papers
set STYLE_OUTPUT=%SCRIPT_DIR%..\references\my_writing_style.md
set VOCAB_OUTPUT=%SCRIPT_DIR%..\references\domain_vocabulary.md

:: ── Step 0: Install dependencies ──────────────────────────
echo [Step 1/4] Installing Python dependencies...
pip install pdfplumber nltk --break-system-packages -q 2>nul || pip install pdfplumber nltk -q
echo Done.
echo.

:: ── Step 1-2: Personal writing style ─────────────────────
:: Check if pdfs folder exists and has files
if not exist "%PDF_FOLDER%" (
    echo WARNING: scripts\pdfs\ folder not found.
    echo Skipping personal writing style extraction.
    echo To use this feature, create scripts\pdfs\ and add your published paper PDFs.
    echo.
    goto :check_reference
)

dir /b "%PDF_FOLDER%\*.pdf" >nul 2>&1
if errorlevel 1 (
    echo WARNING: No PDF files found in scripts\pdfs\
    echo Skipping personal writing style extraction.
    echo To use this feature, add your published paper PDFs to scripts\pdfs\
    echo.
    goto :check_reference
)

:: Count PDFs
set /a count=0
for %%f in ("%PDF_FOLDER%\*.pdf") do set /a count+=1
echo Found %count% of your published papers in scripts\pdfs\
echo.

echo [Step 2/4] Extracting sections from your papers...
python "%SCRIPT_DIR%build_corpus.py" --pdf-folder "%PDF_FOLDER%" --output "%CORPUS_FOLDER%"
if errorlevel 1 (
    echo.
    echo ERROR: Corpus building failed. Check the output above.
    pause
    exit /b 1
)
echo.

echo [Step 3/4] Analyzing your personal writing style...
python "%SCRIPT_DIR%extract_writing_style.py" --corpus "%CORPUS_FOLDER%" --output "%STYLE_OUTPUT%"
if errorlevel 1 (
    echo.
    echo ERROR: Style extraction failed. Check the output above.
    pause
    exit /b 1
)
echo.
echo Personal writing style saved to: references\my_writing_style.md
echo.

:: ── Step 3: Domain vocabulary from reference papers ──────
:check_reference
if not exist "%REF_FOLDER%" (
    echo NOTE: scripts\reference_papers\ folder not found.
    echo Skipping domain vocabulary extraction.
    echo To use this feature, create scripts\reference_papers\ and add 2-3
    echo recent top papers from your TARGET field.
    echo.
    goto :done
)

dir /b "%REF_FOLDER%\*.pdf" >nul 2>&1
if errorlevel 1 (
    echo NOTE: No PDF files found in scripts\reference_papers\
    echo Skipping domain vocabulary extraction.
    echo To use this feature, add 2-3 recent papers from your target field.
    echo.
    goto :done
)

set /a refcount=0
for %%f in ("%REF_FOLDER%\*.pdf") do set /a refcount+=1
echo Found %refcount% reference papers in scripts\reference_papers\
echo.

echo [Step 4/4] Extracting domain vocabulary from reference papers...
python "%SCRIPT_DIR%extract_domain_vocabulary.py" --pdf-folder "%REF_FOLDER%" --output "%VOCAB_OUTPUT%"
if errorlevel 1 (
    echo.
    echo ERROR: Domain vocabulary extraction failed. Check the output above.
    pause
    exit /b 1
)
echo.
echo Domain vocabulary saved to: references\domain_vocabulary.md
echo.

:done
echo ============================================
echo   SETUP COMPLETE
echo ============================================
echo.
if exist "%STYLE_OUTPUT%" (
    echo [OK] Personal writing style:  references\my_writing_style.md
) else (
    echo [--] Personal writing style:  not generated (add PDFs to scripts\pdfs\)
)
if exist "%VOCAB_OUTPUT%" (
    echo [OK] Domain vocabulary:       references\domain_vocabulary.md
) else (
    echo [--] Domain vocabulary:       not generated (add PDFs to scripts\reference_papers\)
)
echo.
echo The paper-writing skill will now use these profiles when drafting.
echo.
pause
