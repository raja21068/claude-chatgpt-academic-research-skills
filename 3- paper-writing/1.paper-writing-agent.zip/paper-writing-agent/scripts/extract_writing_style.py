#!/usr/bin/env python3
"""
Generate a writing style profile from your personal corpus.
Reads the corpus folder created by build_corpus.py and outputs a
Markdown file describing your unique writing style with examples.

Usage:
    python extract_writing_style.py --corpus corpus/ --output ../references/my_writing_style.md

Requirements:
    pip install nltk --break-system-packages
"""

import argparse
import json
import re
from pathlib import Path
from collections import Counter

import nltk
from nltk.tokenize import sent_tokenize, word_tokenize

nltk.download('punkt', quiet=True)
nltk.download('punkt_tab', quiet=True)
nltk.download('averaged_perceptron_tagger_eng', quiet=True)

SECTIONS_OF_INTEREST = ["abstract", "introduction", "methods", "results", "discussion", "conclusion"]
MIN_SENTENCE_LEN = 40
MAX_EXAMPLES_PER_SECTION = 5


def load_corpus_texts(corpus_folder):
    """Load all .txt files from subfolders, grouped by section name."""
    texts_by_section = {sec: [] for sec in SECTIONS_OF_INTEREST}
    all_texts = []

    corpus_folder = Path(corpus_folder)
    for subdir in corpus_folder.iterdir():
        if not subdir.is_dir():
            continue
        for sec in SECTIONS_OF_INTEREST:
            txt_file = subdir / f"{sec}.txt"
            if txt_file.exists():
                content = txt_file.read_text(encoding="utf-8")
                if len(content) > 200:
                    texts_by_section[sec].append(content)
                    all_texts.append(content)
    return texts_by_section, all_texts


def get_common_sentence_starters(texts, top_n=10):
    """Find most common ways to start a sentence (first 3 words)."""
    starters = []
    for text in texts:
        sents = sent_tokenize(text)
        for sent in sents:
            cleaned = re.sub(r'^[\W\d]+', '', sent)
            words = word_tokenize(cleaned)
            if len(words) >= 3:
                starter = ' '.join(words[:3]).lower()
                starters.append(starter)
    counter = Counter(starters)
    common = counter.most_common(top_n)
    return [f'"{w}" ({c}x)' for w, c in common if c >= 3]


def get_common_transitions(texts, top_n=10):
    """Extract frequent transition words/phrases."""
    trans_list = [
        "however", "therefore", "moreover", "furthermore", "nevertheless",
        "consequently", "in contrast", "on the other hand", "for example",
        "for instance", "in addition", "accordingly", "thus", "hence",
        "nonetheless", "instead", "meanwhile", "overall", "specifically"
    ]
    all_words = ' '.join(texts).lower()
    counts = {t: all_words.count(t) for t in trans_list}
    sorted_trans = sorted([(t, c) for t, c in counts.items() if c > 0],
                          key=lambda x: -x[1])
    return [f'"{t}" ({c}x)' for t, c in sorted_trans[:top_n]]


def get_representative_sentences(texts_by_section, max_per_section=5):
    """Pick diverse, medium-length sentences that are characteristic."""
    examples = {}
    for sec, texts in texts_by_section.items():
        candidates = []
        for text in texts:
            sents = sent_tokenize(text)
            for sent in sents:
                if MIN_SENTENCE_LEN < len(sent) < 300:
                    sent = ' '.join(sent.split())
                    candidates.append(sent)
        unique = list(dict.fromkeys(candidates))
        if len(unique) > max_per_section:
            indices = [0, len(unique)//4, len(unique)//2, 3*len(unique)//4, -1]
            indices = [i for i in indices if 0 <= i < len(unique)]
            selected = [unique[i] for i in indices[:max_per_section]]
        else:
            selected = unique[:max_per_section]
        examples[sec] = selected
    return examples


def get_section_structure_pattern(texts_by_section):
    """Analyze first sentences of each section to see opening patterns."""
    patterns = {}
    for sec, texts in texts_by_section.items():
        openings = []
        for text in texts[:20]:
            lines = text.split('\n')
            for line in lines:
                line = line.strip()
                if len(line) > 30 and line[0].isupper():
                    openings.append(line[:120])
                    break
        if openings:
            patterns[sec] = openings[:3]
    return patterns


def generate_style_profile(corpus_folder, output_file):
    print("Loading corpus...")
    texts_by_section, all_texts = load_corpus_texts(corpus_folder)
    if not all_texts:
        print("Error: No text files found. Run build_corpus.py first.")
        return

    print(f"Found {len(all_texts)} section files.")

    # Global stats
    all_sentences = []
    for t in all_texts:
        all_sentences.extend(sent_tokenize(t))
    avg_sent_len = sum(len(word_tokenize(s)) for s in all_sentences) / len(all_sentences) if all_sentences else 0

    print("Extracting style features...")
    starters = get_common_sentence_starters(all_texts)
    transitions = get_common_transitions(all_texts)
    examples = get_representative_sentences(texts_by_section, MAX_EXAMPLES_PER_SECTION)
    structures = get_section_structure_pattern(texts_by_section)

    # Build the style profile
    content = f"""# My Academic Writing Style

*Auto-generated from personal corpus of {len(all_texts)} section files.*
*Average sentence length: {avg_sent_len:.1f} words.*

---

## 1. Global Style Traits

### Common sentence starters (first 3 words)
{chr(10).join('- ' + s for s in starters[:8])}

### Preferred transition words / phrases
{chr(10).join('- ' + t for t in transitions[:10])}

### Sentence rhythm
- Typical sentence length: {avg_sent_len:.0f} words per sentence.
- Write medium-length, declarative sentences with occasional complex clauses.

---

## 2. Section-Specific Openings

How to typically begin each section:

"""
    for sec, opening_examples in structures.items():
        content += f"### {sec.capitalize()}\n"
        for i, ex in enumerate(opening_examples, 1):
            content += f'{i}. "{ex}..."\n'
        content += "\n"

    content += "---\n\n## 3. Example Sentences (from your own papers)\n\n"
    content += "*Real sentences from your papers - use as reference for tone, vocabulary, and structure.*\n\n"

    for sec, sent_list in examples.items():
        if sent_list:
            content += f"### {sec.capitalize()}\n"
            for i, sent in enumerate(sent_list, 1):
                content += f"**Example {i}:** {sent}\n\n"

    content += """---

## 4. Style Rules for Claude

When drafting paper sections, follow these rules to match the author's voice:

1. Match the sentence length and rhythm shown above
2. Use the author's preferred transition words
3. Open sections in the same style as the examples
4. Maintain the author's level of formality and hedging
5. Never invent citations or data
6. Preserve the author's terminology choices
7. When in doubt, imitate the example sentences above
"""

    output_file = Path(output_file)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(content, encoding='utf-8')
    print(f"\nStyle profile saved to: {output_file}")
    print("The paper-writing skill will automatically use this when drafting.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Extract writing style from corpus")
    parser.add_argument("--corpus", default="corpus", help="Corpus folder (from build_corpus.py)")
    parser.add_argument("--output", default="../references/my_writing_style.md",
                        help="Output style profile path")
    args = parser.parse_args()
    generate_style_profile(args.corpus, args.output)
