@echo off
echo ============================================
echo   Step 1: Install Python Dependencies
echo ============================================
echo.
echo Installing pdfplumber and nltk...
echo.
pip install pdfplumber nltk --break-system-packages -q 2>nul || pip install pdfplumber nltk -q
echo.
echo ============================================
echo   DONE - Dependencies installed.
echo ============================================
echo.
echo Next: Put your published PDFs in scripts\pdfs\
echo       Then run: 2_build_corpus.bat
echo.
pause
