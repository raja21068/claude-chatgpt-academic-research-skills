@echo off
echo ============================================
echo   Step 2: Build Corpus from Your Papers
echo ============================================
echo.

set SCRIPT_DIR=%~dp0
set PDF_FOLDER=%SCRIPT_DIR%pdfs
set CORPUS_FOLDER=%SCRIPT_DIR%corpus

if not exist "%PDF_FOLDER%" (
    echo ERROR: scripts\pdfs\ folder not found!
    echo Please create it and add your published paper PDFs.
    echo.
    pause
    exit /b 1
)

dir /b "%PDF_FOLDER%\*.pdf" >nul 2>&1
if errorlevel 1 (
    echo ERROR: No PDF files found in scripts\pdfs\
    echo Please add your published paper PDFs to that folder.
    echo.
    pause
    exit /b 1
)

set /a count=0
for %%f in ("%PDF_FOLDER%\*.pdf") do set /a count+=1
echo Found %count% PDFs in scripts\pdfs\
echo.

echo Extracting sections from your papers...
echo.
python "%SCRIPT_DIR%build_corpus.py" --pdf-folder "%PDF_FOLDER%" --output "%CORPUS_FOLDER%"
if errorlevel 1 (
    echo.
    echo ERROR: Corpus building failed. Check the output above.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   DONE - Corpus built in scripts\corpus\
echo ============================================
echo.
echo Next run: 3_extract_writing_style.bat
echo.
pause
