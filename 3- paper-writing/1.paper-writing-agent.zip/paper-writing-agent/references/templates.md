# Paper Writing Templates

Use these templates when producing structured outputs during paper writing.

## Claim-Evidence Matrix

| Claim | Evidence source | Strength | Citation needed | Safe wording | Status |
|---|---|---|---|---|---|
| [claim] | [source] | strong/moderate/weak/unsupported | [yes/no/TODO] | [safer phrasing] | [done/needs work/TODO] |

**Strength guide:**
- Strong: directly supported by provided experiments or verified literature
- Moderate: broadly supported but needs clearer reporting or comparison
- Weak: plausible but evidence is incomplete
- Unsupported: remove, soften, or mark TODO

---

## Literature Matrix

| Cluster | Key papers | What they do | Limitation/gap | How our work differs | Citation priority |
|---|---|---|---|---|---|
| [theme] | [papers] | [summary] | [gap] | [our difference] | P0/P1 |

---

## Citation Priority Table

| Citation | Priority | Role | Section | Claim supported | Verification status |
|---|---|---|---|---|---|
| [ref] | P0/P1 | baseline/dataset/metric/method/background | [section] | [claim] | verified/needs-check/TODO |

---

## Venue Compliance Table

| Requirement | Status | Evidence / Location | Fix needed |
|---|---|---|---|
| Page limit | pass/risk/fail/unknown | [details] | [fix] |
| Anonymity | ... | ... | ... |
| Citation style | ... | ... | ... |
| Required sections | ... | ... | ... |
| Supplementary rules | ... | ... | ... |

---

## Experimental Log Template

```markdown
## Experiment: [name]

### Setup
- Dataset: 
- Baselines: 
- Metrics: 
- Hardware: 
- Seeds/runs: 

### Results
| Method | Metric 1 | Metric 2 | Notes |
|---|---|---|---|

### Ablations
| Variant | Change | Result | Insight |
|---|---|---|---|

### Observations
- ...

### Limitations
- ...
```

---

## Figure/Table Plan

| ID | Type | Purpose | Data source | Claim supported | Placement | Caption draft | Risk |
|---|---|---|---|---|---|---|---|

---

## Novelty Positioning Map

```markdown
## Core contribution
[one sentence]

## What is reused from prior work
- ...

## What is new in this paper
- ...

## Closest prior work
| Prior work | Similarity | Difference | Evidence for difference | Citation status |
|---|---|---|---|---|

## Safe novelty statement
[conservative, verifiable claim]
```

---

## Writing Preferences (defaults)

- Output format: Markdown (alternative: LaTeX)
- Tone: rigorous, clear, concise, academic
- Claim style: conservative and evidence-grounded
- Citation style: venue default
- TODO markers: always used for missing information
- English: American
- Avoid: exaggerated novelty, fabricated citations/results, vague methods, promotional language
- Include when relevant: limitations, reproducibility details, ethical considerations, dataset/baseline descriptions, figure/table captions
