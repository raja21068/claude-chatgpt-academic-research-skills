"""
rewrite_runner.py
=================
Library used by _runner.py to apply inline rewrites.
Can also be used from the command line:
    python rewrite_runner.py input/my_paper.txt
"""

import re
import sys
from pathlib import Path

HERE = Path(__file__).parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from slop_lib import analyse, load_banned_phrases, load_exceptions
from slop_lib.constants import ZOMBIE_NOUNS, HEDGE_WORDS
from slop_lib.config import get_threshold


# ─────────────────────────────────────────────────────────────────────────────
# TEXT HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def normalise(text: str) -> str:
    """Join hard line breaks that split sentences mid-way (common in PDFs)."""
    lines = text.splitlines()
    joined = []
    for line in lines:
        line = line.strip()
        if not line:
            joined.append("")
            continue
        if joined and joined[-1] and not re.search(r'[.!?:]\s*$', joined[-1]):
            joined[-1] = joined[-1] + " " + line
        else:
            joined.append(line)
    return "\n".join(joined)


def split_sentences(text: str) -> list:
    return [s.strip() for s in re.split(r'(?<=[.!?])\s+', text) if len(s.strip()) > 20]


# ─────────────────────────────────────────────────────────────────────────────
# REWRITE RULES  (each returns best rewrite string, or "" if not applicable)
# ─────────────────────────────────────────────────────────────────────────────

_ZOMBIE_PHRASE = re.compile(
    r'\b(?:the|a|an|our|their)\s+(' +
    '|'.join(re.escape(z) for z in sorted(ZOMBIE_NOUNS, key=len, reverse=True)) +
    r')\s+of\s+([^,.;]+)',
    re.IGNORECASE,
)
_ZOMBIE_BARE = re.compile(
    r'\b(?:the|a|an)\s+(' +
    '|'.join(re.escape(z) for z in sorted(ZOMBIE_NOUNS, key=len, reverse=True)) +
    r')\b',
    re.IGNORECASE,
)

def rewrite_zombie_noun(sentence: str) -> str:
    m = _ZOMBIE_PHRASE.search(sentence)
    if m:
        verb = ZOMBIE_NOUNS.get(m.group(1).lower(), m.group(1))
        obj  = m.group(2).strip().rstrip(".,; ")
        r = _ZOMBIE_PHRASE.sub(f"we {verb} {obj}", sentence, count=1)
        r = re.sub(r'\s+', ' ', r).strip()
        return r[0].upper() + r[1:]
    m2 = _ZOMBIE_BARE.search(sentence)
    if m2:
        verb = ZOMBIE_NOUNS.get(m2.group(1).lower(), m2.group(1))
        r = _ZOMBIE_BARE.sub(verb + "ing", sentence, count=1)
        r = re.sub(r'\s+', ' ', r).strip()
        return r[0].upper() + r[1:]
    return ""


_HEDGE_RE = re.compile(
    r'\b(' + '|'.join(re.escape(h) for h in sorted(HEDGE_WORDS, key=len, reverse=True)) + r')\b',
    re.IGNORECASE,
)

def rewrite_hedge_stack(sentence: str) -> str:
    matches = list(_HEDGE_RE.finditer(sentence))
    if len(matches) < 2:
        return ""
    result = sentence
    for m in reversed(matches[1:]):
        result = result[:m.start()] + result[m.end():]
    result = re.sub(r'\s{2,}', ' ', result).strip()
    return result[0].upper() + result[1:]


_PASSIVE_BY = re.compile(
    r'^(.+?)\s+(?:was|were)\s+(\w+(?:ed|en|wn|lt|ght|nt))\s+by\s+(.+?)([,;.].*)?$',
    re.IGNORECASE,
)
_PASSIVE_SIMPLE = re.compile(
    r'^(.+?)\s+(?:was|were)\s+(\w+(?:ed|en|wn|lt|ght|nt))(.*)',
    re.IGNORECASE,
)

def rewrite_passive(sentence: str) -> str:
    m = _PASSIVE_BY.match(sentence.strip())
    if m:
        subj  = m.group(1).strip()
        pp    = m.group(2)
        agent = m.group(3).strip().rstrip(".,; ")
        tail  = (m.group(4) or "").strip()
        r = f"{agent.capitalize()} {pp} {subj.lower()}{' ' + tail if tail else ''}."
        return re.sub(r'\s+', ' ', r)
    m2 = _PASSIVE_SIMPLE.match(sentence.strip())
    if m2:
        subj = m2.group(1).strip()
        pp   = m2.group(2)
        tail = m2.group(3).strip()
        r = f"We {pp} {subj.lower()}{' ' + tail if tail else ''}."
        return re.sub(r'\s+', ' ', r)
    return ""


_COMPARISON_RE = re.compile(
    r'\b(outperforms?|surpasses?|exceeds?|beats?|better than|superior to|'
    r'improves? (?:over|upon)|achieves? (?:better|higher|lower))\b',
    re.IGNORECASE,
)

def rewrite_context_free(sentence: str) -> str:
    m = _COMPARISON_RE.search(sentence)
    if not m:
        return ""
    return sentence[:m.end()] + " [BASELINE] by [N] on [DATASET]" + sentence[m.end():]


_FILLERS = [
    (r'\bIt is worth noting that\b',            ""),
    (r'\bIt is important to note that\b',       ""),
    (r'\bWe note that\b',                       ""),
    (r'\bNotably,?\s+',                         ""),
    (r'\bInterestingly,?\s+',                   ""),
    (r'\bImportantly,?\s+',                     ""),
    (r'\bIt can be observed that\b',            ""),
    (r'\bFrom the results,?\s+it is clear that\b', ""),
    (r'\bThe results clearly show that\b',      "Results show that"),
    (r'\bWe can see that\b',                    ""),
    (r'\bOne can observe that\b',               ""),
    (r'\bIn this (?:paper|work),\s*we (?:propose|present|introduce|describe)\b', "We"),
    (r'\bThis (?:paper|work) (?:presents?|proposes?|introduces?|investigates?)\b', ""),
    (r'\bTo the best of our knowledge,?\s*',    ""),
    (r'\bAs far as we are aware,?\s*',          ""),
    (r'\bWe believe that\b',                    ""),
    (r'\bstate-of-the-art (?:results?|performance)\b', "best reported [METRIC] on [DATASET]"),
    (r'\bsignificant improvement\b',            "[N]-point improvement on [BENCHMARK]"),
    (r'\bextensive experiments?\b',             "experiments on [N] benchmarks"),
    (r'\bstrong performance\b',                 "[METRIC]: [SCORE]"),
    (r'\bsuperior performance\b',               "[MARGIN]-point improvement over [BASELINE]"),
    (r'\bIn this section,\s*we (?:describe|present|introduce)\b', ""),
    (r'\bWe now present our method\b',          ""),
]

def rewrite_academic_phrase(sentence: str) -> str:
    for pattern, replacement in _FILLERS:
        if re.search(pattern, sentence, re.IGNORECASE):
            r = re.sub(pattern, replacement, sentence, flags=re.IGNORECASE)
            r = re.sub(r'\s{2,}', ' ', r).strip().lstrip(",; ")
            if r and r[0].islower():
                r = r[0].upper() + r[1:]
            if r and r != sentence:
                return r
    return ""


def rewrite_synonym_drift(sentence: str, drift_terms: list) -> str:
    if not drift_terms:
        return ""
    canonical = drift_terms[0]
    pattern = re.compile(
        r'\bour\s+(' + '|'.join(re.escape(t) for t in drift_terms) + r')\b',
        re.IGNORECASE,
    )
    r = pattern.sub(f"our {canonical}", sentence)
    return r if r != sentence else ""


# ─────────────────────────────────────────────────────────────────────────────
# ISSUE EXTRACTOR
# ─────────────────────────────────────────────────────────────────────────────

_SPECIFIC_REF = re.compile(r'\b\d+\.?\d*\s*(%|points?|pp|BLEU|F1|mAP|accuracy)\b', re.IGNORECASE)

def extract_issues(report, text: str) -> list:
    sentences = split_sentences(text)
    issues, seen = [], set()

    def add(flag, sent, extra=None):
        key = sent[:80]
        if key not in seen and sent:
            seen.add(key)
            issues.append({"flag": flag, "sentence": sent, "extra": extra})

    r = report.rhythm

    for zombie in r.zombie_nouns[:6]:
        for s in sentences:
            if zombie in s.lower():
                add("zombie_noun", s, zombie); break

    for h in r.hedge_sentences[:5]:
        add("hedge_stack", h["sentence"].strip(), h["hedge_count"])

    if report.linguistic and hasattr(report.linguistic, "passive_hits"):
        for hit in report.linguistic.passive_hits[:6]:
            sent = hit.sentence.strip() if hasattr(hit, "sentence") else str(hit)
            add("passive", sent)

    for s in sentences:
        if _COMPARISON_RE.search(s) and not _SPECIFIC_REF.search(s):
            add("context_free", s)
        if sum(1 for i in issues if i["flag"] == "context_free") >= 3:
            break

    for label, hits in report.phrase_hits.items():
        if label == "academic":
            for phrase in hits[:5]:
                for s in sentences:
                    if phrase.lower() in s.lower():
                        add("academic_phrase", s, phrase); break

    if len(r.synonym_drift) >= 3:
        drift_re = re.compile(
            r'\bour\s+(' + '|'.join(re.escape(d) for d in r.synonym_drift) + r')\b',
            re.IGNORECASE,
        )
        for s in sentences:
            if drift_re.search(s):
                add("synonym_drift", s, r.synonym_drift)
            if sum(1 for i in issues if i["flag"] == "synonym_drift") >= 2:
                break

    return issues


def best_rewrite(issue: dict) -> str:
    flag, sent, extra = issue["flag"], issue["sentence"], issue.get("extra")
    if flag == "zombie_noun":      return rewrite_zombie_noun(sent)
    if flag == "hedge_stack":      return rewrite_hedge_stack(sent)
    if flag == "passive":          return rewrite_passive(sent)
    if flag == "context_free":     return rewrite_context_free(sent)
    if flag == "academic_phrase":  return rewrite_academic_phrase(sent)
    if flag == "synonym_drift":    return rewrite_synonym_drift(sent, extra or [])
    return ""


# ─────────────────────────────────────────────────────────────────────────────
# MAIN FUNCTION  —  used by _runner.py
# ─────────────────────────────────────────────────────────────────────────────

def rewrite_paper(raw_text: str) -> tuple:
    """
    Takes raw paper text.
    Returns (rewritten_text, n_changed, n_total_issues).
    Applies the best automatic rewrite for each flagged sentence.
    Sentences with no safe automatic rewrite are left unchanged.
    """
    text      = normalise(raw_text)
    threshold = get_threshold()
    report    = analyse(text,
                        banned=load_banned_phrases(),
                        exceptions=load_exceptions(),
                        threshold=threshold)

    issues    = extract_issues(report, text)
    rewritten = text
    changed   = 0

    for issue in issues:
        rw = best_rewrite(issue)
        if rw and rw != issue["sentence"]:
            rewritten = rewritten.replace(issue["sentence"], rw, 1)
            changed  += 1

    return rewritten, changed, len(issues), report.score


# ─────────────────────────────────────────────────────────────────────────────
# COMMAND-LINE USE
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python rewrite_runner.py input/my_paper.txt")
        sys.exit(1)

    p = Path(sys.argv[1])
    if not p.exists():
        p = HERE / "input" / sys.argv[1]
    if not p.exists():
        sys.exit(f"File not found: {sys.argv[1]}")

    raw = p.read_text(encoding="utf-8", errors="replace")
    if p.suffix.lower() == ".tex":
        from slop_lib.text import strip_latex
        raw = strip_latex(raw)

    rewritten, changed, total, score = rewrite_paper(raw)

    out_dir = HERE / "output"
    out_dir.mkdir(exist_ok=True)
    out = out_dir / f"{p.stem}_rewritten.txt"
    out.write_text(rewritten, encoding="utf-8")

    print(f"\n  Score  : {score}/100")
    print(f"  Fixed  : {changed}/{total} sentences rewritten automatically")
    print(f"  Saved  : output/{out.name}\n")
