@echo off
REM ONE-CLICK SETUP for paper-writing-agent-v2
REM Run from the scripts/ folder
REM Requires Python 3.8+ and: pip install pdfminer.six nltk

echo ============================================
echo  Paper Writing Agent v2 - Style Setup
echo ============================================
echo.

cd /d "%~dp0"

echo [1/3] Checking Python...
python --version
IF ERRORLEVEL 1 (
    echo ERROR: Python not found. Install from https://python.org
    pause & exit /b 1
)

echo.
echo [2/3] Installing dependencies...
pip install pdfminer.six nltk --quiet
IF ERRORLEVEL 1 echo Warning: some packages may not have installed cleanly.

echo.
echo [3/3] Building corpus and generating style profiles...
python build_corpus.py
IF ERRORLEVEL 1 (
    echo ERROR in build_corpus.py. Make sure PDFs are in scripts/pdfs/
    pause & exit /b 1
)
python extract_writing_style.py
IF ERRORLEVEL 1 (
    echo ERROR in extract_writing_style.py.
    pause & exit /b 1
)
python extract_domain_vocabulary.py

echo.
echo ============================================
echo  Done! Files written:
echo    references/my_writing_style.md
echo    references/domain_vocabulary.md  (if reference PDFs were provided)
echo ============================================
pause
