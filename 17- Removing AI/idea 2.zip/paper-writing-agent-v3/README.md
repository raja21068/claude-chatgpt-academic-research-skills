# Paper Writing Agent v3

Evidence-grounded academic writing assistant with four-layer anti-AI enforcement.

## What's new vs v2

| Feature | v2 | v3 |
|---------|----|----|
| Generic stop-slop (phrases, structures) | ✓ | ✓ |
| Academic-specific phrase list | ✗ | ✓ `references/academic_phrases.md` |
| Quantitative rhythm analysis | ✗ | ✓ `scripts/rhythm_check.py` |
| Hedge density detection | ✗ | ✓ (per-sentence count ≥3) |
| Paragraph shape + echo detection | ✗ | ✓ |
| Combined auto-scorer | ✗ | ✓ `scripts/slop_score.py` — exits 1 on fail |
| Auto-rewrite agent | ✗ | ✓ `agents/rewrite.md` — 3 alternatives + recommended |
| Style checker — academic slop dimension | ✗ | ✓ 6th scoring dimension |
| `academic_style` reviewer axis capped by slop | v2: ≤55 if generic slop fails | v3: also caps on slop_score < 70 |
| Slop gate threshold | 35/50 (generic) | 70/100 (combined 4-layer) |

## Four enforcement layers

```
Layer 1  Generic stop-slop          references/phrases.md + structures.md
Layer 2  Academic-specific slop     references/academic_phrases.md
Layer 3  Quantitative rhythm        scripts/rhythm_check.py
Layer 4  Surgical rewrite           agents/rewrite.md
```

Each layer catches patterns the others miss. Run them in order.

## Quick start

### Setup personal style (one time)
```bash
# Drop your PDFs into scripts/pdfs/
# Drop 2-3 field papers into scripts/reference_papers/
scripts\setup_writing_style.bat          # Windows
# or:
python scripts/build_corpus.py
python scripts/extract_writing_style.py
python scripts/extract_domain_vocabulary.py
```

### Check a section
```bash
python scripts/slop_score.py results_section.txt
python scripts/slop_score.py results_section.txt --report   # full detail
python scripts/rhythm_check.py results_section.txt --fix-hints
```

### Install script dependencies
```bash
pip install pdfminer.six nltk colorama
```

### Use with Claude

**Claude Projects:** Upload `SKILL.md` and all `references/*.md` as project knowledge.

**Claude Code:** Add this folder as a skill directory.

**API:** Include `SKILL.md` in system prompt. Load reference files on demand.

## What the academic_phrases.md catches

The most common AI tells in academic writing that stop-slop (blog-focused) misses:

- "In this paper, we propose/present/introduce…"
- "To the best of our knowledge…"
- "It is worth noting / We note / Notably / Interestingly…"
- "Extensive experiments demonstrate…" (without numbers)
- "Significant / substantial / considerable improvement" (without numbers)
- "As can be seen from Table X…"
- Contribution bullets with identical grammatical shape
- Method sections that open with "In this section, we describe…"
- Related work that summarises without contrasting
- Conclusions that open with "In this paper, we have shown…"

## What rhythm_check.py measures

- **Sentence-length StdDev per paragraph** — human prose StdDev ≈ 8–14 words; AI ≈ 5–7
- **Hedge density** — flags sentences with ≥3 hedge words (`may`, `might`, `could`, `potentially`…)
- **Paragraph shape uniformity** — coefficient of variation of sentence counts across paragraphs
- **Echo detection** — Jaccard overlap between first and last sentence of each paragraph

## License

Scripts and SKILL.md: MIT.
Stop-slop reference files (phrases.md, structures.md, examples.md): MIT (Hardik Pandya).
