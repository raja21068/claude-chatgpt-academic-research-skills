# Paper Writing Agent v4

Evidence-grounded academic writing assistant with four-layer anti-AI enforcement.

## What's new in v4 vs v3

| Area | v3 | v4 |
|------|----|----|
| Section-level structural patterns | ✗ | ✓ `references/academic_structures.md` |
| Positive writing patterns | ✗ | ✓ `references/positive_patterns.md` |
| Context-aware rule application | ✗ | ✓ `references/section_norms.md` |
| User exception whitelist | ✗ | ✓ `references/exceptions.md` |
| **Works on .tex files** | ✗ | ✓ `scripts/latex_slop.py` with line numbers |
| Revision tracking | ✗ | ✓ `scripts/slop_diff.py` |
| Corpus-relative feedback | ✗ | ✓ `scripts/corpus_compare.py` |
| Contribution bullet analysis | ✗ | ✓ `scripts/contribution_checker.py` |
| Abstract component check | ✗ | ✓ `scripts/abstract_scorer.py` |
| Zombie noun detection | ✗ | ✓ all checkers |
| Context-free comparison detection | ✗ | ✓ all checkers |
| Synonym drift detection | ✗ | ✓ all checkers |
| Sentence-initial entropy | ✗ | ✓ `rhythm_check.py` |
| Rewrite agent iterative (3 rounds) | ✗ | ✓ `agents/rewrite.md` |
| Contribution + abstract quality gates | ✗ | ✓ Gates 10 + 11 |

## Complete script reference

```bash
# One-time setup
scripts/setup_writing_style.bat

# Primary check (LaTeX — use this for actual papers)
python scripts/latex_slop.py paper.tex --report
python scripts/latex_slop.py paper.tex --section results

# Section-level checks (plain text)
python scripts/slop_score.py section.txt --report
python scripts/rhythm_check.py section.txt --fix-hints
python scripts/corpus_compare.py section.txt

# Specific section checks
python scripts/abstract_scorer.py abstract.txt --limit 150
python scripts/contribution_checker.py intro.txt --abstract abstract.txt

# Revision tracking
python scripts/slop_diff.py draft_v1.txt draft_v2.txt --sentences

# All scripts support --json for machine-readable output
# All scripts exit code 1 on fail — use in pre-commit hooks or Makefiles
```

## Install dependencies

```bash
pip install pdfminer.six nltk colorama
python -c "import nltk; nltk.download('punkt'); nltk.download('punkt_tab')"
```

## The four enforcement layers

```
Layer 1  Generic stop-slop          references/phrases.md + structures.md
Layer 2  Academic-specific slop     references/academic_phrases.md + academic_structures.md
Layer 3  Quantitative rhythm        scripts/rhythm_check.py
Layer 4  Deep pattern detection     scripts/latex_slop.py + slop_score.py
```

## Quality gates (blocking for submission-ready)

| Gate | Script | Threshold |
|------|--------|-----------|
| Slop gate | `latex_slop.py` | score ≥ 70 |
| Contribution gate | `contribution_checker.py` | score ≥ 70 |
| Abstract gate | `abstract_scorer.py` | pass |
| Claim-audit gate | `/paper-claim-audit` | PASS or WARN-with-fixes |

## Use with Claude

**Claude Projects:** Upload `SKILL.md` + all `references/*.md` as project knowledge.

**Claude Code:** Add this folder as a skill directory.

**API:** Include `SKILL.md` in system prompt.

## License

Scripts and SKILL.md: MIT.
Stop-slop reference files (phrases.md, structures.md, examples.md): MIT (Hardik Pandya).
