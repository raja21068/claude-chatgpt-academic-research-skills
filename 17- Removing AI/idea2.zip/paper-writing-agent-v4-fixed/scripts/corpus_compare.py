#!/usr/bin/env python3
"""
corpus_compare.py
=================
Compare your draft's style statistics to your personal corpus baseline.
Gives feedback framed as "different from YOUR writing" not "different from generic norms".

Usage:
    python corpus_compare.py <draft.txt>
    python corpus_compare.py <draft.txt> --section results
    python corpus_compare.py <draft.txt> --json

Requirements:
    The corpus/ folder must exist (run build_corpus.py first).
"""

import re
import sys
import json
import math
import argparse
from pathlib import Path
from collections import Counter

try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    RED = Fore.RED + Style.BRIGHT; YELLOW = Fore.YELLOW + Style.BRIGHT
    GREEN = Fore.GREEN + Style.BRIGHT; RESET = Style.RESET_ALL; BOLD = Style.BRIGHT
except ImportError:
    RED = YELLOW = GREEN = RESET = BOLD = ""

try:
    import nltk
    nltk.download("punkt", quiet=True); nltk.download("punkt_tab", quiet=True)
    nltk.download("averaged_perceptron_tagger_eng", quiet=True)
    from nltk.tokenize import sent_tokenize, word_tokenize
    from nltk import pos_tag
    HAS_NLTK = True
except ImportError:
    HAS_NLTK = False
    def sent_tokenize(t): return [s.strip() for s in re.split(r'(?<=[.!?])\s+', t) if s.strip()]
    def word_tokenize(t): return re.findall(r'\b\w+\b', t)
    def pos_tag(tokens): return [(t, 'NN') for t in tokens]

# Always resolve corpus/ relative to this script's directory, regardless of cwd
CORPUS_DIR  = Path(__file__).parent / "corpus"
SECTIONS    = ["abstract","introduction","methods","results","discussion","conclusion"]
HEDGE_WORDS = {
    "may","might","could","potentially","possibly","perhaps","appears","appear",
    "seems","seem","arguably","presumably","likely","suggest","suggests",
    "indicate","indicates","imply","implies","somewhat","relatively",
    "generally","typically","usually","often","tend","tends",
}


def stdev(vals):
    if len(vals) < 2: return 0.0
    m = sum(vals) / len(vals)
    return math.sqrt(sum((v - m)**2 for v in vals) / len(vals))


def mean(vals): return sum(vals) / len(vals) if vals else 0.0


def compute_stats(text: str) -> dict:
    """Compute style statistics for a block of text."""
    sentences = sent_tokenize(text)
    words_per_sent = [len(word_tokenize(s)) for s in sentences if len(s) > 10]

    all_words = word_tokenize(text.lower())
    content_words = [w for w in all_words if w.isalpha() and len(w) > 2]

    # type-token ratio (on content words)
    ttr = len(set(content_words)) / len(content_words) if content_words else 0

    # passive voice proxy: "was/were/been/being + past participle"
    passive_count = len(re.findall(
        r'\b(was|were|been|being|is|are)\s+\w+ed\b', text, re.IGNORECASE))

    # hedge density: average hedges per sentence
    hedge_counts = []
    for s in sentences:
        w = re.findall(r'\b\w+\b', s.lower())
        hedge_counts.append(sum(1 for x in w if x in HEDGE_WORDS))
    avg_hedge = mean(hedge_counts)

    # sentence initial distribution entropy
    starters = []
    for s in sentences:
        w = re.findall(r'\b\w+\b', s)
        if w: starters.append(w[0].lower())
    counts = Counter(starters)
    total  = sum(counts.values()) + 1e-9
    entropy = -sum((c/total) * math.log2(c/total) for c in counts.values())

    # transition word density
    transition_list = ["however","therefore","moreover","furthermore","consequently",
                       "in contrast","thus","hence","nonetheless","specifically",
                       "in addition","accordingly","meanwhile","overall"]
    trans_hits = sum(text.lower().count(t) for t in transition_list)
    trans_density = trans_hits / (len(sentences) + 1e-9)

    return {
        "avg_sentence_length": round(mean(words_per_sent), 1),
        "stdev_sentence_length": round(stdev(words_per_sent), 2),
        "type_token_ratio": round(ttr, 3),
        "passive_per_100": round(passive_count / (len(sentences) + 1e-9) * 100, 1),
        "avg_hedge_per_sentence": round(avg_hedge, 2),
        "starter_entropy": round(entropy, 2),
        "transition_density": round(trans_density, 2),
        "sentence_count": len(sentences),
    }


def load_corpus_stats(section_filter=None):
    """Load and compute baseline stats from corpus/ folder."""
    if not CORPUS_DIR.exists():
        return None

    all_texts = []
    for subdir in sorted(CORPUS_DIR.iterdir()):
        if not subdir.is_dir(): continue
        for sec in SECTIONS:
            if section_filter and sec != section_filter: continue
            f = subdir / f"{sec}.txt"
            if f.exists():
                txt = f.read_text(encoding="utf-8", errors="replace").strip()
                if len(txt) > 100:
                    all_texts.append(txt)

    if not all_texts:
        return None

    combined = '\n\n'.join(all_texts)
    return compute_stats(combined)


def divergence_label(draft_val, corpus_val, key):
    """Return a human-readable divergence label for a given metric."""
    if corpus_val == 0:
        return "no baseline"

    ratio = draft_val / (corpus_val + 1e-9)

    labels = {
        "avg_sentence_length": {
            (0.0, 0.8): f"shorter than your usual ({corpus_val} → {draft_val} words)",
            (0.8, 1.2): "matches your baseline",
            (1.2, 9.9): f"longer than your usual ({corpus_val} → {draft_val} words)",
        },
        "stdev_sentence_length": {
            (0.0, 0.7): f"more uniform than your usual (StdDev {corpus_val} → {draft_val})",
            (0.7, 1.4): "similar variety to your baseline",
            (1.4, 9.9): f"more varied than your usual (StdDev {corpus_val} → {draft_val})",
        },
        "passive_per_100": {
            (0.0, 0.7): "less passive voice than your usual",
            (0.7, 1.5): "similar passive voice to your baseline",
            (1.5, 9.9): f"MORE passive voice than your usual ({ratio:.1f}×)",
        },
        "avg_hedge_per_sentence": {
            (0.0, 0.8): "fewer hedges than your usual",
            (0.8, 1.5): "similar hedging to your baseline",
            (1.5, 9.9): f"MORE hedging than your usual ({ratio:.1f}×)",
        },
        "transition_density": {
            (0.0, 0.7): "fewer transitions than your usual",
            (0.7, 1.4): "similar transition density",
            (1.4, 9.9): f"more transitions than your usual ({ratio:.1f}×)",
        },
        "type_token_ratio": {
            (0.0, 0.8): "less lexical variety than your usual (repeating key terms — good for precision)",
            (0.8, 1.2): "similar vocabulary variety",
            (1.2, 9.9): f"MORE vocabulary variety than your usual (may signal AI synonymizing)",
        },
        "starter_entropy": {
            (0.0, 0.8): f"less starter variety than your usual (entropy {corpus_val} → {draft_val})",
            (0.8, 1.3): "similar sentence-starter variety",
            (1.3, 9.9): "more starter variety than your usual",
        },
    }

    ranges = labels.get(key, {})
    for (lo, hi), label in ranges.items():
        if lo <= ratio < hi:
            return label
    return f"ratio {ratio:.1f}×"


def flag_severity(key, ratio):
    if key in ("passive_per_100", "avg_hedge_per_sentence", "type_token_ratio"):
        if ratio > 2.0: return RED
        if ratio > 1.5: return YELLOW
    if key == "stdev_sentence_length":
        if ratio < 0.6: return RED
        if ratio < 0.8: return YELLOW
    return GREEN


def print_comparison(draft_stats, corpus_stats):
    print(f"\n{BOLD}══ Corpus Comparison Report ══{RESET}")
    print(f"  Comparing draft to your personal writing baseline.\n")

    metrics = [
        ("avg_sentence_length",    "Avg sentence length"),
        ("stdev_sentence_length",  "Sentence length StdDev"),
        ("type_token_ratio",       "Type-token ratio"),
        ("passive_per_100",        "Passive voice per 100 sents"),
        ("avg_hedge_per_sentence", "Avg hedges per sentence"),
        ("starter_entropy",        "Sentence-starter entropy"),
        ("transition_density",     "Transition word density"),
    ]

    recommendations = []

    for key, label in metrics:
        d_val = draft_stats.get(key, 0)
        c_val = corpus_stats.get(key, 0)
        div   = divergence_label(d_val, c_val, key)
        ratio = d_val / (c_val + 1e-9)
        colour = flag_severity(key, ratio)

        print(f"  {label:<34} Draft: {str(d_val):<7} Corpus: {str(c_val):<7} "
              f"{colour}{div}{RESET}")

        if colour == RED:
            recommendations.append((key, d_val, c_val, div))

    if recommendations:
        print(f"\n{BOLD}Priority fixes:{RESET}")
        for key, d, c, div in recommendations:
            if key == "passive_per_100":
                print(f"  • Passive voice: {div}. Find the actor in passive sentences.")
            elif key == "avg_hedge_per_sentence":
                print(f"  • Hedging: {div}. Replace hedge clusters with scope statements.")
            elif key == "type_token_ratio":
                print(f"  • Vocabulary variety: {div}. Pick one name for each technical entity and reuse it.")
            elif key == "stdev_sentence_length":
                print(f"  • Rhythm: {div}. Break long uniform paragraphs — add short punchy sentences or split long ones.")
    else:
        print(f"\n  {GREEN}Draft statistics are within your normal writing range.{RESET}")
    print()


def main():
    parser = argparse.ArgumentParser(description="Compare draft stats to personal corpus baseline")
    parser.add_argument("draft",     help="Draft text file (.txt)")
    parser.add_argument("--section", default=None, help="Load only this section from corpus")
    parser.add_argument("--json",    action="store_true")
    args = parser.parse_args()

    path = Path(args.draft)
    if not path.exists():
        print(f"ERROR: {path} not found"); sys.exit(1)

    text = path.read_text(encoding="utf-8", errors="replace").strip()
    if len(text) < 50:
        print("ERROR: file too short"); sys.exit(1)

    corpus_stats = load_corpus_stats(args.section)
    if not corpus_stats:
        print("ERROR: corpus/ not found or empty. Run build_corpus.py first.")
        sys.exit(1)

    draft_stats = compute_stats(text)

    if args.json:
        print(json.dumps({"draft": draft_stats, "corpus": corpus_stats}, indent=2))
        return

    print_comparison(draft_stats, corpus_stats)


if __name__ == "__main__":
    main()
