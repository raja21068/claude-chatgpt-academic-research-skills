#!/usr/bin/env python3
"""
slop_score.py
=============
Combined anti-AI slop scorer for academic prose.
Runs all checks in one pass and produces a single structured report.

Checks:
  A. Generic stop-slop phrases         (references/phrases.md)
  B. Generic stop-slop structures      (references/structures.md)
  C. Academic-specific AI phrases      (references/academic_phrases.md)
  D. Rhythm analysis                   (rhythm_check.py logic, embedded)
  E. Hedge density                     (rhythm_check.py logic, embedded)
  F. Paragraph shape + echo            (rhythm_check.py logic, embedded)

Usage:
    python slop_score.py <section.txt>
    python slop_score.py <section.txt> --json
    python slop_score.py <section.txt> --report      # full detail
    python slop_score.py <section.txt> --threshold 75  # custom pass score

Output:
    Overall score 0–100. Exit code 0 = pass, 1 = fail.

Requirements:
    colorama (optional), nltk (optional)
    All reference .md files must be in ../references/ relative to this script.
"""

import re
import sys
import json
import math
import argparse
from pathlib import Path

# ── optional deps ─────────────────────────────────────────────────────────────
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    RED = Fore.RED + Style.BRIGHT; YELLOW = Fore.YELLOW + Style.BRIGHT
    GREEN = Fore.GREEN + Style.BRIGHT; RESET = Style.RESET_ALL; BOLD = Style.BRIGHT
except ImportError:
    RED = YELLOW = GREEN = RESET = BOLD = ""

try:
    import nltk
    nltk.download("punkt", quiet=True); nltk.download("punkt_tab", quiet=True)
    from nltk.tokenize import sent_tokenize
except ImportError:
    def sent_tokenize(t):
        return [s.strip() for s in re.split(r'(?<=[.!?])\s+', t) if s.strip()]

# ── paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR  = Path(__file__).parent
REF_DIR     = SCRIPT_DIR.parent / "references"

# ── constants ─────────────────────────────────────────────────────────────────
STDEV_THRESHOLD   = 7.0
HEDGE_THRESHOLD   = 3
MIN_PARA_SENTS    = 3
SHAPE_CV_THRESH   = 0.25
ECHO_OVERLAP_THRESH = 0.5

HEDGE_WORDS = {
    "may", "might", "could", "potentially", "possibly", "perhaps",
    "appears", "appear", "seems", "seem", "seemingly", "arguably",
    "presumably", "likely", "suggest", "suggests", "suggested",
    "indicate", "indicates", "implied", "imply", "implies",
    "somewhat", "relatively", "generally", "typically", "usually",
    "often", "tend", "tends",
}

# ── phrase extraction from .md files ─────────────────────────────────────────

def extract_banned_phrases(md_path: Path):
    """Pull quoted phrases from markdown files. Handles both '...' and "..." delimiters."""
    if not md_path.exists():
        return []
    text = md_path.read_text(encoding="utf-8", errors="replace")
    # match "phrase" or 'phrase' — grab content inside quotes
    found = re.findall(r'["""]([^"""]{5,80})["""]', text)
    found += re.findall(r"'([^']{5,80})'", text)
    # also grab | table cells | that look like phrases (left column)
    table_phrases = re.findall(r'\|\s*"?([A-Z][^|"]{5,80})"?\s*\|', text)
    found += table_phrases
    # deduplicate and clean
    cleaned = []
    for p in found:
        p = p.strip().rstrip("…").strip()
        if 5 <= len(p) <= 80 and not p.startswith("#"):
            cleaned.append(p.lower())
    return list(dict.fromkeys(cleaned))  # preserve order, remove dupes


def load_all_banned_phrases():
    # structures.md is excluded: it describes patterns, extracting its quotes produces noise.
    files = {
        "generic":   REF_DIR / "phrases.md",
        "academic":  REF_DIR / "academic_phrases.md",
    }
    banned = {}
    for label, path in files.items():
        banned[label] = extract_banned_phrases(path)
    return banned

# ── text helpers ──────────────────────────────────────────────────────────────

def split_paragraphs(text):
    return [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]

def word_count(s):
    return len(re.findall(r'\b\w+\b', s))

def stdev(vals):
    if len(vals) < 2: return 0.0
    m = sum(vals) / len(vals)
    return math.sqrt(sum((v - m) ** 2 for v in vals) / len(vals))

def echo_overlap(a, b):
    stop = {"the","a","an","of","in","to","and","is","are","was","were","that",
            "this","it","with","for","on","at","by","we","our","its","be","have"}
    wa = {w for w in re.findall(r'\b\w+\b', a.lower()) if w not in stop}
    wb = {w for w in re.findall(r'\b\w+\b', b.lower()) if w not in stop}
    if not wa or not wb: return 0.0
    return len(wa & wb) / len(wa | wb)

# ── checkers ─────────────────────────────────────────────────────────────────

def check_phrases(text, banned, exceptions=None):
    hits = {}
    lower = text.lower()
    exceptions = exceptions or set()
    for label, phrases in banned.items():
        found = [p for p in phrases if p in lower and p not in exceptions]
        if found:
            hits[label] = found
    return hits


def check_rhythm(text):
    paragraphs = split_paragraphs(text)
    all_stdevs, para_lengths, hedge_sents, echo_paras = [], [], [], []

    for para in paragraphs:
        sents = sent_tokenize(para)
        lengths = [word_count(s) for s in sents if word_count(s) > 3]
        if not lengths:
            continue
        para_stdev = stdev(lengths)
        all_stdevs.append(para_stdev)
        para_lengths.append(len(sents))

        for sent in sents:
            h = sum(1 for w in re.findall(r'\b\w+\b', sent.lower()) if w in HEDGE_WORDS)
            if h >= HEDGE_THRESHOLD:
                hedge_sents.append({"sentence": sent, "hedge_count": h})

        if len(sents) >= MIN_PARA_SENTS:
            if echo_overlap(sents[0], sents[-1]) >= ECHO_OVERLAP_THRESH:
                echo_paras.append(para[:120])

    mean_stdev   = sum(all_stdevs) / len(all_stdevs) if all_stdevs else 0
    shape_cv     = (stdev(para_lengths) / (sum(para_lengths)/len(para_lengths) + 1e-9)
                    if len(para_lengths) >= 3 else 1.0)

    return {
        "mean_stdev":        round(mean_stdev, 2),
        "stdev_flag":        mean_stdev < STDEV_THRESHOLD and len(all_stdevs) >= 3,
        "hedge_sentences":   hedge_sents,
        "echo_paragraphs":   echo_paras,
        "shape_uniform":     shape_cv < SHAPE_CV_THRESH and len(para_lengths) >= 4,
        "shape_cv":          round(shape_cv, 3),
    }

# ── scoring ───────────────────────────────────────────────────────────────────

def compute_score(phrase_hits, rhythm):
    """
    Score 0-100 across five dimensions (20 pts each).

    Directness  — penalised by generic + academic phrase hits
    Rhythm      — penalised by StdDev flag + shape uniformity
    Trust       — penalised by hedge stacking
    Authenticity — penalised by structural AI patterns
    Density     — penalised by all combined
    """
    total_generic    = sum(len(v) for v in phrase_hits.values() if True)
    academic_hits    = len(phrase_hits.get("academic", []))
    generic_hits     = len(phrase_hits.get("generic", [])) + len(phrase_hits.get("structures", []))
    hedge_count      = len(rhythm["hedge_sentences"])
    echo_count       = len(rhythm["echo_paragraphs"])

    directness   = max(0, 20 - academic_hits * 3  - generic_hits * 1)
    rhythm_score = max(0, 20 - (10 if rhythm["stdev_flag"] else 0)
                              - (5  if rhythm["shape_uniform"] else 0)
                              - echo_count * 3)
    trust        = max(0, 20 - hedge_count * 4)
    authenticity = max(0, 20 - academic_hits * 2 - generic_hits * 2)
    density      = max(0, 20 - total_generic * 1 - hedge_count * 2)

    dims = {
        "directness":   min(20, directness),
        "rhythm":       min(20, rhythm_score),
        "trust":        min(20, trust),
        "authenticity": min(20, authenticity),
        "density":      min(20, density),
    }
    total = sum(dims.values())
    return total, dims

# ── report ────────────────────────────────────────────────────────────────────

def print_report(score, dims, phrase_hits, rhythm, detailed=False):
    colour = GREEN if score >= 75 else (YELLOW if score >= 50 else RED)
    print(f"\n{BOLD}══ Slop Score Report ══{RESET}")
    print(f"  {colour}Overall: {score}/100{RESET}  "
          f"({'clean' if score >= 75 else 'borderline' if score >= 50 else 'AI-like'})\n")

    print(f"{BOLD}Dimension scores (20 = perfect):{RESET}")
    for dim, val in dims.items():
        bar = "█" * val + "░" * (20 - val)
        c = GREEN if val >= 15 else (YELLOW if val >= 10 else RED)
        print(f"  {dim:<14} {c}{val:>2}/20  {bar}{RESET}")

    print(f"\n{BOLD}Issues found:{RESET}")
    any_issue = False

    for label, hits in phrase_hits.items():
        if hits:
            any_issue = True
            print(f"  {RED}[{label.upper()} PHRASES]{RESET} {len(hits)} hit(s):")
            for h in hits[:5]:
                print(f"    • \"{h}\"")
            if len(hits) > 5:
                print(f"    … and {len(hits)-5} more")

    if rhythm["stdev_flag"]:
        any_issue = True
        print(f"  {RED}[RHYTHM]{RESET} Mean sentence StdDev = {rhythm['mean_stdev']} "
              f"(threshold {STDEV_THRESHOLD}). Prose is metronomically uniform.")

    if rhythm["hedge_sentences"]:
        any_issue = True
        print(f"  {RED}[HEDGING]{RESET} {len(rhythm['hedge_sentences'])} sentence(s) with "
              f"≥{HEDGE_THRESHOLD} hedge words:")
        for h in rhythm["hedge_sentences"][:3]:
            preview = h["sentence"][:100] + "…" if len(h["sentence"]) > 100 else h["sentence"]
            print(f"    [{h['hedge_count']} hedges] \"{preview}\"")

    if rhythm["echo_paragraphs"]:
        any_issue = True
        print(f"  {YELLOW}[ECHO]{RESET} {len(rhythm['echo_paragraphs'])} paragraph(s) where "
              f"last sentence mirrors first.")

    if rhythm["shape_uniform"]:
        any_issue = True
        print(f"  {YELLOW}[SHAPE]{RESET} Paragraph sentence counts are uniform "
              f"(CV={rhythm['shape_cv']}). Vary paragraph lengths.")

    if not any_issue:
        print(f"  {GREEN}No issues detected.{RESET}")

    if detailed and rhythm["hedge_sentences"]:
        print(f"\n{BOLD}Hedge rewrite hints:{RESET}")
        for i, h in enumerate(rhythm["hedge_sentences"][:4], 1):
            print(f"\n  [{i}] {h['sentence'][:120]}")
            print(f"      → State what the evidence shows + one scope qualifier if needed.")
            print(f"         Pattern: '[Subject] [verb] [specific result] in [specific setting].'")
    print()

# ── main ──────────────────────────────────────────────────────────────────────

def load_exceptions():
    exc_file = REF_DIR / "exceptions.md"
    if not exc_file.exists():
        return set()
    text = exc_file.read_text(encoding="utf-8", errors="replace")
    import re as _re
    patterns = _re.findall(r'PATTERN:\s*(.+)', text, _re.IGNORECASE)
    return {p.strip().lower() for p in patterns}


def main():
    parser = argparse.ArgumentParser(description="Combined anti-AI slop scorer")
    parser.add_argument("file",        help="Text file to score")
    parser.add_argument("--json",      action="store_true", help="JSON output")
    parser.add_argument("--report",    action="store_true", help="Full detailed report")
    parser.add_argument("--threshold", type=int, default=70,
                        help="Minimum passing score (default 70)")
    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        print(f"ERROR: {path} not found"); sys.exit(1)

    text = path.read_text(encoding="utf-8", errors="replace").strip()
    if len(text) < 50:
        print("ERROR: file too short"); sys.exit(1)

    banned       = load_all_banned_phrases()
    exceptions   = load_exceptions()
    phrase_hits  = check_phrases(text, banned, exceptions)
    rhythm       = check_rhythm(text)
    score, dims  = compute_score(phrase_hits, rhythm)

    if args.json:
        print(json.dumps({
            "score": score, "pass": score >= args.threshold,
            "dimensions": dims, "phrase_hits": phrase_hits, "rhythm": rhythm,
        }, indent=2))
    else:
        print_report(score, dims, phrase_hits, rhythm, detailed=args.report)
        verdict = f"{GREEN}PASS{RESET}" if score >= args.threshold else f"{RED}FAIL{RESET}"
        print(f"  Verdict: {verdict} (threshold {args.threshold})")
        print()

    sys.exit(0 if score >= args.threshold else 1)


if __name__ == "__main__":
    main()


# ── v4 additions ──────────────────────────────────────────────────────────────

ZOMBIE_NOUNS = {
    "utilization","utilisation","implementation","investigation","optimization",
    "optimisation","examination","consideration","determination","establishment",
    "evaluation","demonstration","presentation","exploration","formulation",
    "computation","approximation",
}

COMPARISON_VERBS = r'\b(outperforms?|surpasses?|exceeds?|beats?|better than|superior to)\b'
SPECIFIC_REF     = r'\b(Table|Figure|\d+\.\d+|\d+\s*(points?|percent|%)|BLEU|ROUGE|F1)\b'

_original_check_rhythm = check_rhythm

def check_rhythm(text):
    r = _original_check_rhythm(text)
    # zombie nouns
    lower = text.lower()
    zombie_hits = [z for z in ZOMBIE_NOUNS
                   if re.search(r'\b(the|a|an|of|our|their)\s+\w*' + z, lower)]
    r["zombie_nouns"] = zombie_hits

    # context-free comparisons
    sents = sent_tokenize(text)
    cf = [s for s in sents
          if re.search(COMPARISON_VERBS, s, re.IGNORECASE)
          and not re.search(SPECIFIC_REF, s, re.IGNORECASE)]
    r["context_free_comparisons"] = len(cf)

    # synonym drift: multiple "our X" for same referent
    core = {"model","framework","system","approach","method","architecture",
            "network","algorithm","pipeline","technique"}
    our_nouns = re.findall(r'\bour\s+(\w+)', lower)
    found_synonyms = {n for n in our_nouns if n in core}
    r["synonym_drift"] = sorted(found_synonyms) if len(found_synonyms) >= 3 else []

    return r


_original_compute_score = compute_score

def compute_score(phrase_hits, rhythm):
    score, dims = _original_compute_score(phrase_hits, rhythm)
    # additional penalties from v4
    extra = 0
    extra += min(15, len(rhythm.get("zombie_nouns", [])) * 3)
    extra += min(10, rhythm.get("context_free_comparisons", 0) * 5)
    extra += min(10, len(rhythm.get("synonym_drift", [])) * 4)
    score = max(0, score - extra)
    return score, dims


_original_print_report = print_report

def print_report(score, dims, phrase_hits, rhythm, detailed=False):
    _original_print_report(score, dims, phrase_hits, rhythm, detailed)
    extras = []
    if rhythm.get("zombie_nouns"):
        extras.append(f"  {RED}[ZOMBIE NOUNS]{RESET}: "
                      + ", ".join(f'"{z}"' for z in rhythm["zombie_nouns"][:5]))
    if rhythm.get("context_free_comparisons"):
        extras.append(f"  {YELLOW}[CONTEXT-FREE COMPARE]{RESET}: "
                      f"{rhythm['context_free_comparisons']} comparison(s) without named metric/baseline")
    if rhythm.get("synonym_drift"):
        extras.append(f"  {YELLOW}[SYNONYM DRIFT]{RESET}: "
                      + ", ".join(f'"our {w}"' for w in rhythm["synonym_drift"])
                      + " — pick one name for your system")
    if extras:
        print(f"\n{BOLD}v4 additional checks:{RESET}")
        for e in extras:
            print(e)
        print()
