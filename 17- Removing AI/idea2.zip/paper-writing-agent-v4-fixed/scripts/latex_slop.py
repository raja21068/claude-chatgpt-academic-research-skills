#!/usr/bin/env python3
"""
latex_slop.py
=============
LaTeX-aware anti-AI slop checker. The highest-priority script gap in v3.

Strips LaTeX commands from .tex files, runs all slop checks on clean text,
then maps every finding back to the original .tex line numbers so you can
fix issues directly in your editor.

Usage:
    python latex_slop.py paper.tex
    python latex_slop.py paper.tex --section results
    python latex_slop.py paper.tex --json
    python latex_slop.py paper.tex --report
    python latex_slop.py paper.tex --threshold 75

Supported section filters (--section):
    abstract, introduction, related_work, method, results, analysis, conclusion, all

Requirements:
    pip install colorama nltk
"""

import re
import sys
import json
import math
import argparse
from pathlib import Path
from collections import Counter, defaultdict

try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    RED = Fore.RED + Style.BRIGHT; YELLOW = Fore.YELLOW + Style.BRIGHT
    GREEN = Fore.GREEN + Style.BRIGHT; RESET = Style.RESET_ALL; BOLD = Style.BRIGHT
    CYAN = Fore.CYAN
except ImportError:
    RED = YELLOW = GREEN = RESET = BOLD = CYAN = ""

try:
    import nltk
    nltk.download("punkt", quiet=True); nltk.download("punkt_tab", quiet=True)
    from nltk.tokenize import sent_tokenize
except ImportError:
    def sent_tokenize(t):
        return [s.strip() for s in re.split(r'(?<=[.!?])\s+', t) if s.strip()]

# ── paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).parent
REF_DIR    = SCRIPT_DIR.parent / "references"

# ── section heading patterns ─────────────────────────────────────────────────
SECTION_PATTERNS = {
    "abstract":     [r"\\begin\{abstract\}", r"\\section\*?\{abstract\}"],
    "introduction": [r"\\section\*?\{introduction"],
    "related_work": [r"\\section\*?\{(related.work|background|prior.work|"
                     r"literature.review|related.studies|related.approaches)"],
    "method":       [r"\\section\*?\{(method|approach|model|framework|"
                     r"proposed.method|system|architecture|our.method|technique|"
                     r"methodology|overview|formulation)"],
    "results":      [r"\\section\*?\{(results?|experiments?|experimental|"
                     r"evaluation|empirical|quantitative|performance)"],
    "analysis":     [r"\\section\*?\{(analysis|ablation|discussion|"
                     r"qualitative|error.analysis|further.analysis|insight)"],
    "conclusion":   [r"\\section\*?\{(conclusion|summary|closing)"],
}

HEDGE_WORDS = {
    "may", "might", "could", "potentially", "possibly", "perhaps",
    "appears", "appear", "seems", "seem", "seemingly", "arguably",
    "presumably", "likely", "suggest", "suggests", "indicate", "indicates",
    "imply", "implies", "somewhat", "relatively", "generally", "typically",
    "usually", "often", "tend", "tends",
}

ZOMBIE_NOUNS = {
    "utilization": "use", "utilisation": "use",
    "implementation": "implement",
    "investigation": "investigate",
    "optimization": "optimize", "optimisation": "optimise",
    "examination": "examine",
    "consideration": "consider",
    "determination": "determine",
    "establishment": "establish",
    "evaluation": "evaluate",
    "demonstration": "demonstrate",
    "presentation": "present",
    "exploration": "explore",
    "formulation": "formulate",
    "computation": "compute",
    "approximation": "approximate",
}

# context-free comparison verbs
COMPARISON_VERBS = r'\b(outperforms?|surpasses?|exceeds?|beats?|better than|superior to|improves? over)\b'
SPECIFIC_REF     = r'\b(Table|Figure|Appendix|Section|\d+\.\d+|\d+\s*(points?|percent|%)|BLEU|ROUGE|F1|accuracy)\b'

# ── LaTeX stripping ───────────────────────────────────────────────────────────

def strip_latex(text: str) -> str:
    """Remove LaTeX markup, preserving readable text and sentence boundaries."""
    # Remove comments
    text = re.sub(r'%.*$', '', text, flags=re.MULTILINE)
    # Remove display math environments
    text = re.sub(r'\\begin\{(equation|align|gather|multline|eqnarray)\*?\}.*?\\end\{\1\*?\}',
                  ' [EQUATION] ', text, flags=re.DOTALL)
    # Replace inline math with placeholder
    text = re.sub(r'\$\$.*?\$\$', ' [EQUATION] ', text, flags=re.DOTALL)
    text = re.sub(r'\$[^$\n]{1,200}\$', ' [MATH] ', text)
    # Replace \cite{...} with [CITE]
    text = re.sub(r'\\cite[pt]?\*?\{[^}]*\}', '[CITE]', text)
    # Replace \ref{...} and \label{...}
    text = re.sub(r'\\(ref|label|eqref)\{[^}]*\}', '', text)
    # Replace figure/table environments with placeholder
    text = re.sub(r'\\begin\{(figure\*?|table\*?)\}.*?\\end\{\1\}',
                  '\n[FIGURE/TABLE PLACEHOLDER]\n', text, flags=re.DOTALL)
    # Remove \begin{...} \end{...} for other envs, keep content
    text = re.sub(r'\\(begin|end)\{[^}]*\}', '', text)
    # Handle common text commands — extract their argument
    text = re.sub(r'\\(textbf|textit|emph|text|textrm|textsc|underline)\{([^}]*)\}', r'\2', text)
    # Remove other commands with arguments
    text = re.sub(r'\\[a-zA-Z]+\*?\{[^}]*\}', '', text)
    # Remove remaining commands
    text = re.sub(r'\\[a-zA-Z]+\*?', '', text)
    # Clean up braces
    text = re.sub(r'[{}]', '', text)
    # Normalize whitespace
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r'[ \t]+', ' ', text)
    return text.strip()


def extract_sections(raw_tex: str):
    """
    Split .tex into named sections.
    Returns dict: section_name -> [(line_number, text_line), ...]
    """
    lines = raw_tex.split('\n')
    sections = defaultdict(list)
    current_section = "preamble"
    abstract_mode = False

    for lineno, line in enumerate(lines, 1):
        stripped_lower = line.strip().lower()

        # detect abstract environment
        if re.search(r'\\begin\{abstract\}', line, re.IGNORECASE):
            current_section = "abstract"
            abstract_mode = True
        elif re.search(r'\\end\{abstract\}', line, re.IGNORECASE):
            abstract_mode = False

        # detect section headings
        for sec_name, patterns in SECTION_PATTERNS.items():
            if any(re.search(p, stripped_lower) for p in patterns):
                current_section = sec_name
                break

        sections[current_section].append((lineno, line))

    return sections


def section_to_clean_text(section_lines):
    """Convert [(lineno, tex_line)] to [(lineno, clean_sentence)].
    Uses paragraph-aware mapping so line numbers are approximate but useful.
    """
    if not section_lines:
        return []

    # Split into paragraph chunks by blank lines, tracking start line numbers
    result = []
    current_para_lines = []
    current_start_lineno = section_lines[0][0]

    def flush_para(para_lines, start_lineno):
        if not para_lines:
            return []
        raw = ' '.join(line for _, line in para_lines)
        clean = strip_latex(raw)
        sents = sent_tokenize(clean)
        return [(start_lineno, s.strip()) for s in sents if len(s.strip()) > 10]

    for lineno, line in section_lines:
        if line.strip() == '':
            result.extend(flush_para(current_para_lines, current_start_lineno))
            current_para_lines = []
        else:
            if not current_para_lines:
                current_start_lineno = lineno
            current_para_lines.append((lineno, line))

    result.extend(flush_para(current_para_lines, current_start_lineno))
    return result

# ── checkers ─────────────────────────────────────────────────────────────────

def check_zombie_nouns(sentences):
    findings = []
    for lineno, sent in sentences:
        for zombie, fix in ZOMBIE_NOUNS.items():
            if re.search(r'\b' + zombie + r'\b', sent, re.IGNORECASE):
                # check it's used as a noun phrase (preceded by article/adj)
                pattern = r'\b(the|a|an|their|our|its|this|that|of)\s+\w*' + zombie
                if re.search(pattern, sent, re.IGNORECASE):
                    findings.append({
                        "line": lineno, "zombie": zombie, "fix": fix,
                        "sentence": sent[:120],
                    })
    return findings


def check_context_free_comparisons(sentences):
    """Flag comparison claims not followed by a number or named reference within 30 words."""
    findings = []
    for lineno, sent in sentences:
        if re.search(COMPARISON_VERBS, sent, re.IGNORECASE):
            if not re.search(SPECIFIC_REF, sent, re.IGNORECASE):
                findings.append({"line": lineno, "sentence": sent[:120]})
    return findings


def check_sentence_initial_distribution(sentences):
    """Flag if any word starts >30% of sentences."""
    if len(sentences) < 5:
        return [], {}
    starters = []
    for _, sent in sentences:
        words = re.findall(r'\b\w+\b', sent)
        if words:
            starters.append(words[0].lower())
    counts = Counter(starters)
    total = len(starters)
    flags = []
    for word, count in counts.most_common(5):
        if count / total > 0.30 and word not in {'[figure', '[equation', '[math'}:
            flags.append({
                "word": word,
                "count": count,
                "pct": round(count / total * 100, 1),
            })
    return flags, dict(counts.most_common(10))


def check_tense_consistency(sentences, section_name):
    """Basic tense check: flag tense violations for the section's expected tense."""
    expected = {
        "abstract": "mixed",
        "introduction": "present",
        "related_work": "past",
        "method": "present",
        "results": "past",
        "analysis": "past",
        "conclusion": "mixed",
    }.get(section_name, "mixed")

    if expected == "mixed":
        return []

    past_markers   = r'\b(showed|demonstrated|achieved|proposed|introduced|found|observed|reported|used|obtained)\b'
    present_markers = r'\b(shows?|demonstrates?|achieves?|proposes?|introduces?|finds?|observes?|reports?|uses?|obtains?)\b'

    findings = []
    for lineno, sent in sentences:
        if len(sent) < 20:
            continue
        has_past    = bool(re.search(past_markers, sent, re.IGNORECASE))
        has_present = bool(re.search(present_markers, sent, re.IGNORECASE))
        if expected == "past" and has_present and not has_past:
            findings.append({"line": lineno, "issue": "present tense in past-tense section",
                             "sentence": sent[:100]})
        elif expected == "present" and has_past and not has_present:
            findings.append({"line": lineno, "issue": "past tense in present-tense section",
                             "sentence": sent[:100]})
    return findings


def check_related_work_contrast(section_text):
    """Flag related work paragraphs with no contrast sentence."""
    if not section_text:
        return 0
    paragraphs = re.split(r'\n\s*\n', section_text)
    contrast_words = r'\b(unlike|in contrast|however|whereas|differ|differs|different|instead|'
    contrast_words += r'our (work|method|approach|model)|this work|we (instead|address|differ))\b'
    missing = 0
    for para in paragraphs:
        clean = strip_latex(para)
        if len(clean.split()) > 30:  # ignore very short paragraphs
            if not re.search(contrast_words, clean, re.IGNORECASE):
                missing += 1
    return missing


def check_punctuation_variety(clean_text):
    """Check that sentence-ending punctuation and internal punctuation are varied."""
    puncts = Counter(c for c in clean_text if c in '.,;:()!')
    total = sum(puncts.values()) + 1
    comma_ratio = puncts.get(',', 0) / total
    semi_count  = puncts.get(';', 0)
    findings = []
    if comma_ratio > 0.75:
        findings.append(f"Comma-heavy: {comma_ratio:.0%} of punctuation marks are commas. "
                        f"Vary with semicolons, colons, or sentence breaks.")
    if semi_count == 0 and len(clean_text) > 500:
        findings.append("No semicolons found. Academic prose uses semicolons to join "
                        "closely related independent clauses.")
    return findings


def check_synonym_drift(sentences):
    """
    Detect synonymizing: multiple 'our [noun]' variants for the same referent.
    E.g. 'our model', 'our framework', 'our system', 'our approach', 'our method' all in one section.
    """
    our_nouns = []
    for _, sent in sentences:
        matches = re.findall(r'\bour\s+(\w+)', sent, re.IGNORECASE)
        our_nouns.extend(m.lower() for m in matches)

    core_synonyms = {"model", "framework", "system", "approach", "method",
                     "architecture", "network", "algorithm", "pipeline", "technique"}
    found = {n for n in our_nouns if n in core_synonyms}
    if len(found) >= 3:
        return sorted(found)
    return []

# ── scoring ───────────────────────────────────────────────────────────────────

def score_findings(zombie, context_free, starter_flags, tense, rw_missing, punct, synonym_drift,
                   generic_phrases, hedge_sents):
    penalties = 0
    penalties += min(20, len(zombie) * 3)
    penalties += min(15, len(context_free) * 5)
    penalties += min(10, len(starter_flags) * 5)
    penalties += min(10, len(tense) * 3)
    penalties += min(10, rw_missing * 4)
    penalties += min(5,  len(punct) * 3)
    penalties += min(10, len(synonym_drift) * 4)
    penalties += min(15, len(generic_phrases) * 2)
    penalties += min(15, len(hedge_sents) * 4)
    return max(0, 100 - penalties)

# ── phrase loading ────────────────────────────────────────────────────────────

def load_banned_phrases():
    # structures.md is intentionally excluded: it describes patterns, not banned phrases.
    # Extracting quoted text from it produces noisy false positives.
    files = [REF_DIR / "phrases.md", REF_DIR / "academic_phrases.md"]
    phrases = []
    for f in files:
        if not f.exists():
            continue
        text = f.read_text(encoding="utf-8", errors="replace")
        found = re.findall(r'["""]([^"""]{5,80})["""]', text)
        phrases.extend(p.lower().strip() for p in found if 5 <= len(p) <= 80)
    return list(dict.fromkeys(phrases))


def load_exceptions():
    exc_file = REF_DIR / "exceptions.md"
    if not exc_file.exists():
        return set()
    text = exc_file.read_text(encoding="utf-8", errors="replace")
    patterns = re.findall(r'PATTERN:\s*(.+)', text, re.IGNORECASE)
    return {p.strip().lower() for p in patterns}

# ── main analysis ─────────────────────────────────────────────────────────────

def analyse_section(section_name, section_lines, banned_phrases, exceptions):
    if not section_lines:
        return None

    raw_text  = '\n'.join(line for _, line in section_lines)
    clean     = strip_latex(raw_text)
    sentences = section_to_clean_text(section_lines)

    # phrase hits (minus exceptions)
    lower_clean = clean.lower()
    phrase_hits = [p for p in banned_phrases if p in lower_clean and p not in exceptions]

    # hedge sentences
    hedge_sents = []
    for lineno, sent in sentences:
        words  = re.findall(r'\b\w+\b', sent.lower())
        hcount = sum(1 for w in words if w in HEDGE_WORDS)
        if hcount >= 3:
            hedge_sents.append({"line": lineno, "count": hcount,
                                 "sentence": sent[:120]})

    # all checks
    zombie         = check_zombie_nouns(sentences)
    context_free   = check_context_free_comparisons(sentences)
    starter_flags, starter_dist = check_sentence_initial_distribution(sentences)
    tense          = check_tense_consistency(sentences, section_name)
    punct          = check_punctuation_variety(clean)
    synonym_drift  = check_synonym_drift(sentences)
    rw_missing     = check_related_work_contrast(raw_text) if section_name == "related_work" else 0

    score = score_findings(zombie, context_free, starter_flags, tense, rw_missing,
                           punct, synonym_drift, phrase_hits, hedge_sents)

    return {
        "section":          section_name,
        "score":            score,
        "phrase_hits":      phrase_hits[:10],
        "hedge_sentences":  hedge_sents,
        "zombie_nouns":     zombie,
        "context_free":     context_free,
        "starter_flags":    starter_flags,
        "starter_dist":     starter_dist,
        "tense_issues":     tense[:5],
        "punct_issues":     punct,
        "synonym_drift":    synonym_drift,
        "rw_missing_contrast": rw_missing,
    }

# ── output ────────────────────────────────────────────────────────────────────

def print_section_report(r, detailed=False):
    score  = r["score"]
    colour = GREEN if score >= 75 else (YELLOW if score >= 50 else RED)
    print(f"\n{BOLD}── {r['section'].upper()} ──{RESET}  {colour}{score}/100{RESET}")

    if r["phrase_hits"]:
        print(f"  {RED}Phrases ({len(r['phrase_hits'])}){RESET}: "
              + ", ".join(f'"{p}"' for p in r["phrase_hits"][:5]))

    if r["zombie_nouns"]:
        print(f"  {RED}Zombie nouns{RESET}:")
        for z in r["zombie_nouns"][:3]:
            print(f"    L{z['line']}: \"{z['zombie']}\" → use \"{z['fix']}\"  "
                  f"| {z['sentence'][:80]}")

    if r["context_free"]:
        print(f"  {RED}Context-free comparisons ({len(r['context_free'])}){RESET}:")
        for c in r["context_free"][:2]:
            print(f"    L{c['line']}: {c['sentence'][:90]}")

    if r["hedge_sentences"]:
        print(f"  {RED}Hedge stacking ({len(r['hedge_sentences'])} sentence(s)){RESET}:")
        for h in r["hedge_sentences"][:2]:
            print(f"    L{h['line']} [{h['count']} hedges]: {h['sentence'][:90]}")

    if r["starter_flags"]:
        for sf in r["starter_flags"]:
            print(f"  {YELLOW}Starter overuse{RESET}: \"{sf['word']}\" opens "
                  f"{sf['pct']}% of sentences")

    if r["tense_issues"]:
        print(f"  {YELLOW}Tense ({len(r['tense_issues'])} issue(s)){RESET}:")
        for t in r["tense_issues"][:2]:
            print(f"    L{t['line']}: {t['issue']}")

    if r["synonym_drift"]:
        print(f"  {YELLOW}Synonym drift{RESET}: "
              + ", ".join(f'"our {w}"' for w in r["synonym_drift"])
              + " — pick one name")

    if r["rw_missing_contrast"]:
        print(f"  {YELLOW}Related work{RESET}: "
              f"{r['rw_missing_contrast']} paragraph(s) with no contrast sentence")

    if r["punct_issues"]:
        for p in r["punct_issues"]:
            print(f"  {YELLOW}Punctuation{RESET}: {p}")

    if score >= 75 and not any([
        r["phrase_hits"], r["zombie_nouns"], r["context_free"],
        r["hedge_sentences"], r["starter_flags"]
    ]):
        print(f"  {GREEN}No major issues.{RESET}")


def print_report(all_results, threshold, detailed=False):
    scores = [r["score"] for r in all_results if r]
    overall = round(sum(scores) / len(scores)) if scores else 0

    colour = GREEN if overall >= threshold else (YELLOW if overall >= 50 else RED)
    print(f"\n{BOLD}══ LaTeX Slop Report ══{RESET}")
    print(f"  {colour}Overall: {overall}/100{RESET}  "
          f"(threshold {threshold})  "
          f"{'PASS' if overall >= threshold else 'FAIL'}")
    print(f"  Sections analysed: {len(all_results)}")

    for r in all_results:
        if r:
            print_section_report(r, detailed)

    print()
    verdict = f"{GREEN}PASS{RESET}" if overall >= threshold else f"{RED}FAIL{RESET}"
    print(f"  Verdict: {verdict}\n")
    return overall

# ── entry point ───────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="LaTeX-aware anti-AI slop checker")
    parser.add_argument("file",         help=".tex file to analyse")
    parser.add_argument("--section",    default="all",
                        help="Section to analyse: abstract|introduction|related_work|method|results|analysis|conclusion|all")
    parser.add_argument("--json",       action="store_true")
    parser.add_argument("--report",     action="store_true", help="Full detail")
    parser.add_argument("--threshold",  type=int, default=70)
    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        print(f"ERROR: {path} not found"); sys.exit(1)

    raw_tex       = path.read_text(encoding="utf-8", errors="replace")
    sections      = extract_sections(raw_tex)
    banned        = load_banned_phrases()
    exceptions    = load_exceptions()

    target = args.section.lower().replace(" ", "_")
    to_analyse = (list(sections.items()) if target == "all"
                  else [(target, sections.get(target, []))])

    all_results = []
    for sec_name, sec_lines in to_analyse:
        if sec_name in ("preamble",) and target == "all":
            continue
        r = analyse_section(sec_name, sec_lines, banned, exceptions)
        if r:
            all_results.append(r)

    if not all_results:
        print("No content found for the requested section(s)."); sys.exit(0)

    if args.json:
        print(json.dumps(all_results, indent=2))
        sys.exit(0)

    overall = print_report(all_results, args.threshold, args.report)
    sys.exit(0 if overall >= args.threshold else 1)


if __name__ == "__main__":
    main()
