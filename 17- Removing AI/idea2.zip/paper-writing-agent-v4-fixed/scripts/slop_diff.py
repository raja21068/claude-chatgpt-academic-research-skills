#!/usr/bin/env python3
"""
slop_diff.py
============
Compare two versions of a section and show exactly what improved/regressed.

Usage:
    python slop_diff.py draft_v1.txt draft_v2.txt
    python slop_diff.py draft_v1.txt draft_v2.txt --json
    python slop_diff.py draft_v1.txt draft_v2.txt --sentences   # sentence-level diff

Output:
    Score delta per dimension, list of fixed issues, list of new issues introduced.
"""

import re
import sys
import json
import math
import argparse
import difflib
from pathlib import Path
from collections import Counter

try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    RED = Fore.RED + Style.BRIGHT; YELLOW = Fore.YELLOW + Style.BRIGHT
    GREEN = Fore.GREEN + Style.BRIGHT; RESET = Style.RESET_ALL; BOLD = Style.BRIGHT
except ImportError:
    RED = YELLOW = GREEN = RESET = BOLD = ""

try:
    import nltk
    nltk.download("punkt", quiet=True); nltk.download("punkt_tab", quiet=True)
    from nltk.tokenize import sent_tokenize
except ImportError:
    def sent_tokenize(t):
        return [s.strip() for s in re.split(r'(?<=[.!?])\s+', t) if s.strip()]

SCRIPT_DIR = Path(__file__).parent
REF_DIR    = SCRIPT_DIR.parent / "references"

HEDGE_WORDS = {
    "may", "might", "could", "potentially", "possibly", "perhaps",
    "appears", "appear", "seems", "seem", "arguably", "presumably",
    "likely", "suggest", "suggests", "indicate", "indicates", "imply",
    "implies", "somewhat", "relatively", "generally", "typically", "usually",
    "often", "tend", "tends",
}

ZOMBIE_NOUNS = {
    "utilization","utilisation","implementation","investigation","optimization",
    "optimisation","examination","consideration","determination","establishment",
    "evaluation","demonstration","presentation","exploration","formulation",
}

COMPARISON_VERBS = r'\b(outperforms?|surpasses?|exceeds?|beats?|better than|superior to)\b'
SPECIFIC_REF = r'\b(Table|Figure|\d+\.\d+|\d+\s*(points?|percent|%)|BLEU|ROUGE|F1)\b'


def load_banned_phrases():
    files = [REF_DIR / "phrases.md", REF_DIR / "academic_phrases.md",
             REF_DIR / "structures.md"]
    phrases = []
    for f in files:
        if not f.exists(): continue
        text = f.read_text(encoding="utf-8", errors="replace")
        found = re.findall(r'["""]([^"""]{5,80})["""]', text)
        phrases.extend(p.lower().strip() for p in found if 5 <= len(p) <= 80)
    return list(dict.fromkeys(phrases))


def stdev(vals):
    if len(vals) < 2: return 0.0
    m = sum(vals) / len(vals)
    return math.sqrt(sum((v - m)**2 for v in vals) / len(vals))


def analyse_text(text, banned_phrases):
    sentences = sent_tokenize(text)
    lengths   = [len(re.findall(r'\b\w+\b', s)) for s in sentences if len(s) > 10]
    lower     = text.lower()

    # phrase hits
    phrase_hits = [p for p in banned_phrases if p in lower]

    # hedge sentences
    hedge_sents = []
    for s in sentences:
        words  = re.findall(r'\b\w+\b', s.lower())
        hcount = sum(1 for w in words if w in HEDGE_WORDS)
        if hcount >= 3:
            hedge_sents.append(s[:100])

    # zombie nouns
    zombie_hits = [z for z in ZOMBIE_NOUNS if re.search(r'\b'+z+r'\b', lower)]

    # context-free comparisons
    cf_hits = [s for s in sentences
               if re.search(COMPARISON_VERBS, s, re.IGNORECASE)
               and not re.search(SPECIFIC_REF, s, re.IGNORECASE)]

    # sentence starters
    starters = []
    for s in sentences:
        words = re.findall(r'\b\w+\b', s)
        if words: starters.append(words[0].lower())
    starter_counts = Counter(starters)
    dominated = [w for w, c in starter_counts.items()
                 if c / (len(starters) + 1e-9) > 0.30 and len(starters) >= 5]

    # rhythm stdev
    rhythm_stdev = stdev(lengths) if lengths else 0

    # score (simple version matching slop_score.py logic)
    penalties = 0
    penalties += min(25, len(phrase_hits) * 2)
    penalties += min(20, len(hedge_sents) * 5)
    penalties += min(15, len(zombie_hits) * 3)
    penalties += min(15, len(cf_hits) * 5)
    penalties += min(10, len(dominated) * 5)
    penalties += 15 if rhythm_stdev < 7.0 and len(lengths) >= 4 else 0

    score = max(0, 100 - penalties)

    return {
        "score":         score,
        "phrase_hits":   phrase_hits,
        "hedge_sents":   hedge_sents,
        "zombie_hits":   zombie_hits,
        "cf_hits":       cf_hits,
        "dominated_starters": dominated,
        "rhythm_stdev":  round(rhythm_stdev, 2),
    }


def diff_findings(a, b):
    """Return what was fixed and what was introduced."""
    fixed    = {}
    regressed = {}

    for key in ["phrase_hits", "hedge_sents", "zombie_hits", "cf_hits", "dominated_starters"]:
        set_a = set(a.get(key, []))
        set_b = set(b.get(key, []))
        gone  = set_a - set_b
        new   = set_b - set_a
        if gone:    fixed[key]     = sorted(gone)
        if new:     regressed[key] = sorted(new)

    # rhythm
    if a["rhythm_stdev"] < 7.0 and b["rhythm_stdev"] >= 7.0:
        fixed["rhythm"] = f"StdDev improved {a['rhythm_stdev']} → {b['rhythm_stdev']}"
    elif a["rhythm_stdev"] >= 7.0 and b["rhythm_stdev"] < 7.0:
        regressed["rhythm"] = f"StdDev worsened {a['rhythm_stdev']} → {b['rhythm_stdev']}"

    return fixed, regressed


def sentence_diff(text_a, text_b):
    """Show sentence-level additions and removals."""
    sents_a = sent_tokenize(text_a)
    sents_b = sent_tokenize(text_b)
    sm = difflib.SequenceMatcher(None, sents_a, sents_b)
    added, removed, changed = [], [], []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'insert':
            added.extend(sents_b[j1:j2])
        elif tag == 'delete':
            removed.extend(sents_a[i1:i2])
        elif tag == 'replace':
            for old, new in zip(sents_a[i1:i2], sents_b[j1:j2]):
                changed.append({"old": old[:100], "new": new[:100]})
    return added, removed, changed


def print_report(a, b, fixed, regressed, show_sents=False,
                 text_a=None, text_b=None):
    delta = b["score"] - a["score"]
    dcolour = GREEN if delta >= 0 else RED
    print(f"\n{BOLD}══ Slop Diff Report ══{RESET}")
    print(f"  v1 score: {a['score']}/100")
    print(f"  v2 score: {b['score']}/100")
    print(f"  Delta:    {dcolour}{'+' if delta >= 0 else ''}{delta}{RESET}\n")

    if fixed:
        print(f"{GREEN}{BOLD}Fixed issues:{RESET}")
        for key, items in fixed.items():
            label = key.replace("_", " ")
            if isinstance(items, list):
                print(f"  ✓ {label}: {len(items)} removed")
                for it in items[:3]:
                    print(f"      \"{it[:80]}\"")
            else:
                print(f"  ✓ {label}: {items}")

    if regressed:
        print(f"\n{RED}{BOLD}New issues introduced:{RESET}")
        for key, items in regressed.items():
            label = key.replace("_", " ")
            if isinstance(items, list):
                print(f"  ✗ {label}: {len(items)} new")
                for it in items[:3]:
                    print(f"      \"{it[:80]}\"")
            else:
                print(f"  ✗ {label}: {items}")

    if not fixed and not regressed:
        print(f"  {YELLOW}No detectable changes in flagged patterns.{RESET}")

    if show_sents and text_a and text_b:
        added, removed, changed = sentence_diff(text_a, text_b)
        if changed:
            print(f"\n{BOLD}Changed sentences ({len(changed)}):{RESET}")
            for i, c in enumerate(changed[:5], 1):
                print(f"\n  [{i}] {RED}− {c['old']}{RESET}")
                print(f"      {GREEN}+ {c['new']}{RESET}")
    print()


def main():
    parser = argparse.ArgumentParser(description="Compare slop scores between two draft versions")
    parser.add_argument("v1",         help="Original version (.txt)")
    parser.add_argument("v2",         help="Revised version (.txt)")
    parser.add_argument("--json",     action="store_true")
    parser.add_argument("--sentences",action="store_true", help="Show sentence-level diff")
    args = parser.parse_args()

    for f in [args.v1, args.v2]:
        if not Path(f).exists():
            print(f"ERROR: {f} not found"); sys.exit(1)

    text_a = Path(args.v1).read_text(encoding="utf-8", errors="replace")
    text_b = Path(args.v2).read_text(encoding="utf-8", errors="replace")
    banned = load_banned_phrases()
    a = analyse_text(text_a, banned)
    b = analyse_text(text_b, banned)
    fixed, regressed = diff_findings(a, b)

    if args.json:
        print(json.dumps({"v1": a, "v2": b, "fixed": fixed, "regressed": regressed}, indent=2))
        return

    print_report(a, b, fixed, regressed,
                 args.sentences, text_a if args.sentences else None,
                 text_b if args.sentences else None)
    sys.exit(0 if b["score"] >= a["score"] else 1)


if __name__ == "__main__":
    main()
