@echo off
REM ONE-CLICK SETUP for paper-writing-agent-v4
REM Run from the scripts/ folder
REM Requires Python 3.8+ and: pip install pdfminer.six nltk colorama

cd /d "%~dp0"

echo ============================================
echo  Paper Writing Agent v4 - Style Setup
echo ============================================
echo.

python --version 2>nul || (echo ERROR: Python not found. & pause & exit /b 1)

echo [1/4] Installing dependencies...
pip install pdfminer.six nltk colorama --quiet

echo.
echo [2/4] Building corpus from PDFs...
python build_corpus.py
IF ERRORLEVEL 1 (echo ERROR: Check that PDFs are in scripts/pdfs/ & pause & exit /b 1)

echo.
echo [3/4] Generating writing style profile...
python extract_writing_style.py
IF ERRORLEVEL 1 (echo ERROR in extract_writing_style.py & pause & exit /b 1)

echo.
echo [4/4] Generating domain vocabulary...
python extract_domain_vocabulary.py

echo.
echo ============================================
echo  Done! Files written:
echo    references/my_writing_style.md
echo    references/domain_vocabulary.md
echo.
echo  To check a section:
echo    python slop_score.py section.txt
echo    python latex_slop.py paper.tex
echo    python corpus_compare.py section.txt
echo ============================================
pause
