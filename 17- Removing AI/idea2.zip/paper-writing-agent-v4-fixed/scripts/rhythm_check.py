#!/usr/bin/env python3
"""
rhythm_check.py
===============
Quantitative anti-AI rhythm analyser for academic prose.

Checks four things the manual stop-slop checklist cannot easily catch:
  1. Sentence-length standard deviation per paragraph (low StdDev = AI)
  2. Hedge word density per sentence (≥3 hedges = stacking)
  3. Paragraph shape uniformity (same sentence count every para = AI)
  4. Paragraph echo detection (last sentence mirrors first = AI summary habit)

Usage:
    python rhythm_check.py <text_file_or_section.txt>
    python rhythm_check.py <text_file> --json          # machine-readable output
    python rhythm_check.py <text_file> --fix-hints      # suggest rewrites for worst sentences

Output:
    Coloured terminal report (default) or JSON (--json)

Requirements:
    pip install colorama   (optional — for colour; falls back to plain text)
"""

import re
import sys
import json
import math
import argparse
from pathlib import Path
from collections import Counter

# ── optional colour ──────────────────────────────────────────────────────────
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    RED    = Fore.RED    + Style.BRIGHT
    YELLOW = Fore.YELLOW + Style.BRIGHT
    GREEN  = Fore.GREEN  + Style.BRIGHT
    RESET  = Style.RESET_ALL
    BOLD   = Style.BRIGHT
except ImportError:
    RED = YELLOW = GREEN = RESET = BOLD = ""

# ── optional NLTK sentence tokeniser ─────────────────────────────────────────
try:
    import nltk
    nltk.download("punkt", quiet=True)
    nltk.download("punkt_tab", quiet=True)
    from nltk.tokenize import sent_tokenize
except ImportError:
    def sent_tokenize(text):
        return [s.strip() for s in re.split(r'(?<=[.!?])\s+', text) if s.strip()]

# ── configuration ─────────────────────────────────────────────────────────────
STDEV_THRESHOLD     = 7.0    # paragraphs below this StdDev are flagged
HEDGE_THRESHOLD     = 3      # sentences with ≥ this many hedges are flagged
MIN_PARA_SENTENCES  = 3      # ignore single/double sentence paragraphs for shape check
SHAPE_THRESHOLD     = 0.25   # flag if StdDev of paragraph lengths ÷ mean < this
ECHO_OVERLAP        = 0.5    # flag if word-overlap between first/last sentence > this

HEDGE_WORDS = {
    "may", "might", "could", "potentially", "possibly", "perhaps",
    "appears", "appear", "seems", "seem", "seemingly",
    "arguably", "presumably", "likely", "suggest", "suggests",
    "suggested", "indicate", "indicates", "indicated", "imply", "implies",
    "somewhat", "relatively", "generally", "typically", "usually",
    "often", "tend", "tends", "tended",
}

# ── helpers ───────────────────────────────────────────────────────────────────

def split_paragraphs(text):
    """Split on one or more blank lines."""
    return [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]


def word_count(sentence):
    return len(re.findall(r'\b\w+\b', sentence))


def sentence_lengths(paragraph):
    sents = sent_tokenize(paragraph)
    return [word_count(s) for s in sents if word_count(s) > 3], sents


def stdev(values):
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    return math.sqrt(sum((v - mean) ** 2 for v in values) / len(values))


def hedge_density(sentence):
    words = re.findall(r'\b\w+\b', sentence.lower())
    return sum(1 for w in words if w in HEDGE_WORDS)


def echo_overlap(sent_a, sent_b):
    """Jaccard overlap of content words between two sentences."""
    stop = {"the", "a", "an", "of", "in", "to", "and", "is", "are", "was",
            "were", "that", "this", "it", "with", "for", "on", "at", "by",
            "we", "our", "its"}
    words_a = {w for w in re.findall(r'\b\w+\b', sent_a.lower()) if w not in stop}
    words_b = {w for w in re.findall(r'\b\w+\b', sent_b.lower()) if w not in stop}
    if not words_a or not words_b:
        return 0.0
    return len(words_a & words_b) / len(words_a | words_b)

# ── analysis ──────────────────────────────────────────────────────────────────

def analyse(text):
    paragraphs = split_paragraphs(text)
    results = {
        "paragraphs": [],
        "global": {},
        "flags": [],
        "score": 0,
    }

    all_stdevs      = []
    hedge_flags     = []
    para_lengths    = []   # sentence counts per paragraph
    echo_flags      = []

    for i, para in enumerate(paragraphs, 1):
        lengths, sents = sentence_lengths(para)
        if not lengths:
            continue

        para_stdev = stdev(lengths)
        all_stdevs.append(para_stdev)
        para_lengths.append(len(sents))

        para_result = {
            "paragraph": i,
            "sentence_count": len(sents),
            "avg_length": round(sum(lengths) / len(lengths), 1),
            "stdev": round(para_stdev, 2),
            "stdev_flag": para_stdev < STDEV_THRESHOLD and len(sents) >= MIN_PARA_SENTENCES,
            "hedge_sentences": [],
            "echo_flag": False,
            "preview": para[:80] + "…" if len(para) > 80 else para,
        }

        # hedge density per sentence
        for sent in sents:
            h = hedge_density(sent)
            if h >= HEDGE_THRESHOLD:
                hedge_flags.append(sent)
                para_result["hedge_sentences"].append({
                    "sentence": sent[:120] + "…" if len(sent) > 120 else sent,
                    "hedge_count": h,
                })

        # echo detection
        if len(sents) >= MIN_PARA_SENTENCES:
            overlap = echo_overlap(sents[0], sents[-1])
            if overlap >= ECHO_OVERLAP:
                echo_flags.append(para)
                para_result["echo_flag"] = True

        results["paragraphs"].append(para_result)

    # global paragraph shape uniformity
    if len(para_lengths) >= 3:
        shape_cv = stdev(para_lengths) / (sum(para_lengths) / len(para_lengths) + 1e-9)
        shape_uniform = shape_cv < SHAPE_THRESHOLD
    else:
        shape_cv = 0.0
        shape_uniform = False

    global_stdev = stdev(all_stdevs) if len(all_stdevs) >= 2 else (all_stdevs[0] if all_stdevs else 0)
    mean_stdev   = sum(all_stdevs) / len(all_stdevs) if all_stdevs else 0

    results["global"] = {
        "paragraph_count":       len(paragraphs),
        "mean_sentence_stdev":   round(mean_stdev, 2),
        "stdev_flag":            mean_stdev < STDEV_THRESHOLD,
        "hedge_sentence_count":  len(hedge_flags),
        "echo_paragraph_count":  len(echo_flags),
        "shape_uniform":         shape_uniform,
        "shape_cv":              round(shape_cv, 3),
    }

    # build human-readable flags
    flags = []
    if results["global"]["stdev_flag"]:
        flags.append(f"RHYTHM: Mean sentence-length StdDev is {mean_stdev:.1f} words "
                     f"(threshold {STDEV_THRESHOLD}). Prose is metronomically uniform.")
    for p in results["paragraphs"]:
        if p["stdev_flag"]:
            flags.append(f"RHYTHM Para {p['paragraph']}: StdDev {p['stdev']} — "
                         f"all {p['sentence_count']} sentences near {p['avg_length']} words. "
                         f"Vary length.")
    if hedge_flags:
        flags.append(f"HEDGING: {len(hedge_flags)} sentence(s) contain ≥{HEDGE_THRESHOLD} hedge words.")
        for sent in hedge_flags[:3]:
            flags.append(f"  → \"{sent[:100]}…\"" if len(sent) > 100 else f"  → \"{sent}\"")
    if echo_flags:
        flags.append(f"ECHO: {len(echo_flags)} paragraph(s) — last sentence mirrors first "
                     "(AI summary habit). Vary paragraph endings.")
    if shape_uniform:
        flags.append(f"SHAPE: Paragraphs have near-uniform sentence counts (CV={shape_cv:.2f}). "
                     f"Humans vary paragraph length more.")

    results["flags"] = flags

    # 0–100 score: 100 = fully human-rhythm, 0 = pure AI
    penalties = 0
    penalties += 30 if results["global"]["stdev_flag"] else 0
    penalties += min(25, len(hedge_flags) * 5)
    penalties += 15 if shape_uniform else 0
    penalties += min(15, len(echo_flags) * 8)
    results["score"] = max(0, 100 - penalties)

    return results


def fix_hints(results):
    """Generate simple fix suggestions for the worst items."""
    hints = []
    for p in results["paragraphs"]:
        for hs in p.get("hedge_sentences", []):
            hints.append({
                "type": "hedge_rewrite",
                "original": hs["sentence"],
                "hint": (
                    f"Remove {hs['hedge_count']} hedges. State what the evidence shows, "
                    "then add a single scope qualifier if genuinely needed. "
                    "Example pattern: '[Subject] [verb] [specific result] in [specific setting].'"
                ),
            })
        if p.get("echo_flag"):
            hints.append({
                "type": "echo_paragraph",
                "preview": p["preview"],
                "hint": "Last sentence echoes the first. End on a forward-looking detail, "
                        "a number, or a consequence — not a restatement.",
            })
    return hints


# ── output formatting ─────────────────────────────────────────────────────────

def print_report(results, show_hints=False):
    g = results["global"]
    score = results["score"]

    colour = GREEN if score >= 75 else (YELLOW if score >= 50 else RED)
    print(f"\n{BOLD}══ Rhythm Check Report ══{RESET}")
    print(f"  Paragraphs analysed : {g['paragraph_count']}")
    print(f"  Mean sentence StdDev: {g['mean_sentence_stdev']} words  "
          f"{'✓' if not g['stdev_flag'] else f'{RED}⚠ below {STDEV_THRESHOLD}{RESET}'}")
    print(f"  Hedge sentences     : {g['hedge_sentence_count']}  "
          f"{'✓' if g['hedge_sentence_count'] == 0 else f'{RED}⚠{RESET}'}")
    print(f"  Echo paragraphs     : {g['echo_paragraph_count']}  "
          f"{'✓' if g['echo_paragraph_count'] == 0 else f'{YELLOW}⚠{RESET}'}")
    print(f"  Shape uniformity    : {'uniform ⚠' if g['shape_uniform'] else 'varied ✓'}  "
          f"(CV={g['shape_cv']})")
    print(f"\n  {colour}Rhythm score: {score}/100{RESET}  "
          f"({'human-sounding' if score >= 75 else 'borderline' if score >= 50 else 'AI-like'})\n")

    if results["flags"]:
        print(f"{BOLD}Issues:{RESET}")
        for f in results["flags"]:
            prefix = "  " if f.startswith("  →") else "• "
            colour_f = RED if "RHYTHM" in f or "HEDGING" in f else YELLOW
            print(f"{colour_f}{prefix}{f}{RESET}")
    else:
        print(f"{GREEN}No issues found.{RESET}")

    if show_hints:
        hints = fix_hints(results)
        if hints:
            print(f"\n{BOLD}Fix hints:{RESET}")
            for i, h in enumerate(hints[:5], 1):
                print(f"\n  [{i}] {h['type'].upper()}")
                if "original" in h:
                    print(f"      Original : {h['original'][:120]}")
                print(f"      Hint     : {h['hint']}")
    print()


# ── entry point ───────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Quantitative anti-AI rhythm analyser")
    parser.add_argument("file",        help="Text file to analyse (.txt or plain text)")
    parser.add_argument("--json",      action="store_true", help="Output JSON instead of coloured report")
    parser.add_argument("--fix-hints", action="store_true", help="Show rewrite hints for worst sentences")
    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        print(f"ERROR: file not found: {path}")
        sys.exit(1)

    text = path.read_text(encoding="utf-8", errors="replace")
    if len(text.strip()) < 50:
        print("ERROR: file is empty or too short.")
        sys.exit(1)

    results = analyse(text)

    if args.json:
        print(json.dumps(results, indent=2))
    else:
        print_report(results, show_hints=args.fix_hints)

    # exit code: 0 = pass, 1 = issues found
    sys.exit(0 if not results["flags"] else 1)


if __name__ == "__main__":
    main()


# ── v4 additions: sentence-initial entropy + punctuation variety ──────────────

def sentence_initial_entropy(sentences):
    """Shannon entropy of sentence-initial words. Low = AI-uniform."""
    starters = []
    for _, sent in sentences:
        words = re.findall(r'\b\w+\b', sent)
        if words:
            starters.append(words[0].lower())
    if len(starters) < 5:
        return None, {}
    counts = Counter(starters)
    total  = sum(counts.values()) + 1e-9
    entropy = -sum((c/total) * math.log2(c/total) for c in counts.values())
    dominated = [(w, c, round(c/total*100,1)) for w, c in counts.most_common(3)
                 if c/total > 0.25]
    return round(entropy, 2), {"dominated": dominated, "top_counts": dict(counts.most_common(5))}


def punctuation_variety(text):
    """Check comma dominance and absence of semicolons."""
    puncts = Counter(c for c in text if c in '.,;:()!')
    total  = sum(puncts.values()) + 1
    findings = []
    if total > 20:
        comma_ratio = puncts.get(',', 0) / total
        if comma_ratio > 0.75:
            findings.append(f"Comma-heavy ({comma_ratio:.0%} of punctuation). Vary with semicolons or sentence breaks.")
    if puncts.get(';', 0) == 0 and len(text) > 500:
        findings.append("No semicolons. Academic prose uses them to join related independent clauses.")
    return findings


# Monkey-patch analyse() to include v4 additions
_original_analyse = analyse

def analyse(text):
    results = _original_analyse(text)
    # get all sentences for entropy check
    all_sents = []
    for p in results.get("paragraphs", []):
        pass  # already computed inside _original_analyse; re-extract here
    paragraphs = split_paragraphs(text)
    all_sents_flat = []
    for para in paragraphs:
        _, sents = sentence_lengths(para)
        all_sents_flat.extend([(0, s) for s in sents])

    entropy, entropy_data = sentence_initial_entropy(all_sents_flat)
    punct_issues = punctuation_variety(text)

    results["global"]["starter_entropy"] = entropy
    results["global"]["starter_entropy_data"] = entropy_data
    results["global"]["punctuation_issues"] = punct_issues

    if entropy is not None and entropy < 2.0 and len(all_sents_flat) >= 8:
        results["flags"].append(
            f"STARTERS: Low sentence-initial entropy ({entropy:.2f} bits). "
            f"Sentences start with similar words. "
            + (f"Dominant: {entropy_data['dominated']}" if entropy_data.get('dominated') else "")
        )
        results["score"] = max(0, results["score"] - 10)

    for issue in punct_issues:
        results["flags"].append(f"PUNCTUATION: {issue}")

    return results
