---
name: paper-writing-agent-v4
description: >
  Evidence-grounded academic paper writing assistant with comprehensive anti-AI enforcement.
  Use for any academic paper task: drafting, outlining, reviewing, submitting, rebuttal.
  Four detection layers + quantitative rhythm + corpus-relative scoring + surgical rewrite loop.
metadata:
  version: "4.0"
  changelog: >
    v4 adds: (1) academic_structures.md — section-level structural anti-patterns,
    (2) positive_patterns.md — what good prose looks like (for drafting + rewriting),
    (3) section_norms.md — context-aware rule application per section,
    (4) exceptions.md — user whitelist,
    (5) latex_slop.py — works on actual .tex files with line-number mapping,
    (6) slop_diff.py — score delta between two draft versions,
    (7) corpus_compare.py — feedback relative to author's own writing,
    (8) contribution_checker.py — bullet structure analysis,
    (9) abstract_scorer.py — component + specificity check,
    (10) zombie noun detection in all checkers,
    (11) context-free comparison detection,
    (12) sentence-initial entropy in rhythm_check,
    (13) synonym drift detection,
    (14) rewrite agent now iterative (3 rounds max) + loads positive_patterns.md.
---

# Paper Writing Agent v4

Evidence-grounded. Fabricates nothing. Sounds human.

---

## Skill folder structure

```
paper-writing-agent-v4/
├── SKILL.md
├── agents/
│   ├── reviewer.md
│   ├── grader.md
│   ├── literature_searcher.md
│   ├── style_checker.md              ← 6-dimension scoring (v3)
│   ├── rewrite.md                    ← iterative rewrite, loads positive_patterns  ★ v4
│   ├── experiment_auditor.md
│   └── claim_auditor.md
├── references/
│   ├── stop_slop.md                  ← generic anti-AI rules
│   ├── phrases.md                    ← banned phrases
│   ├── structures.md                 ← banned sentence structures
│   ├── examples.md                   ← before/after transformations
│   ├── academic_phrases.md           ← academic-specific AI patterns (v3)
│   ├── academic_structures.md        ← section-level structural patterns  ★ NEW
│   ├── positive_patterns.md          ← what good prose looks like          ★ NEW
│   ├── section_norms.md              ← context-aware rule mapping          ★ NEW
│   ├── exceptions.md                 ← user whitelist                      ★ NEW
│   ├── templates.md
│   ├── checklists.md
│   ├── my_writing_style.md
│   └── domain_vocabulary.md
├── scripts/
│   ├── setup_writing_style.bat
│   ├── build_corpus.py
│   ├── extract_writing_style.py
│   ├── extract_domain_vocabulary.py
│   ├── rhythm_check.py               ← + entropy + punctuation (v4)        ★ UPDATED
│   ├── slop_score.py                 ← + zombie nouns + context-free (v4)  ★ UPDATED
│   ├── latex_slop.py                 ← works on .tex with line numbers      ★ NEW
│   ├── slop_diff.py                  ← score delta between two versions     ★ NEW
│   ├── corpus_compare.py             ← feedback vs. author baseline         ★ NEW
│   ├── contribution_checker.py       ← bullet structure analysis            ★ NEW
│   ├── abstract_scorer.py            ← component + specificity check        ★ NEW
│   ├── pdfs/
│   ├── reference_papers/
│   └── corpus/
└── assets/
    ├── latex-templates/
    ├── table-templates.md
    ├── figure-templates.tex
    └── response-letter.tex
```

---

## Anti-AI enforcement — complete four-layer system

```
Layer 1  Generic stop-slop
         references/phrases.md + structures.md
         → adverbs, passive, binary contrasts, em dashes,
           throat-clearing, vague declaratives, false agency

Layer 2  Academic-specific slop
         references/academic_phrases.md + academic_structures.md
         → announcement openers, false humility, filler observations,
           contribution inflation, hedge stacking, uniform bullet shapes,
           method throat-clearing, related-work padding without contrast,
           conclusion theatre, "organized as follows", formula abstract

Layer 3  Quantitative rhythm
         scripts/rhythm_check.py (+ entropy + punctuation in v4)
         → sentence-length StdDev, hedge density ≥3, paragraph shape,
           echo detection, sentence-initial entropy, punctuation variety

Layer 4  Deep pattern detection (v4 additions)
         scripts/latex_slop.py + slop_score.py (updated)
         → zombie nouns, context-free comparisons, synonym drift,
           tense inconsistency, related-work contrast gaps,
           sentence-initial distribution
```

**New in v4: what each new script does**

| Script | What it checks | When to run |
|--------|---------------|-------------|
| `latex_slop.py` | All checks on actual .tex file with line numbers | Primary check for LaTeX papers |
| `slop_diff.py` | Score delta between two draft versions | After each revision cycle |
| `corpus_compare.py` | Draft vs. your personal corpus baseline | After completing a section |
| `contribution_checker.py` | Bullet structure uniformity + specificity | After writing introduction |
| `abstract_scorer.py` | 4 required components + numbers + named entities | After writing abstract |

---

## Resource loading order (before any prose task)

1. `references/my_writing_style.md` — author voice
2. `references/domain_vocabulary.md` — field terminology
3. `references/section_norms.md` — which rules apply to this section
4. `references/stop_slop.md` + `phrases.md` + `structures.md` — generic bans
5. `references/academic_phrases.md` + `academic_structures.md` — academic bans
6. `references/positive_patterns.md` — what to aim for, not just what to avoid
7. `references/exceptions.md` — author's whitelisted patterns

---

## Phase 0–3 (unchanged from v3)

Detect starting point → Intake → Claim-evidence mapping → Outline.
See v3 SKILL.md for full phase descriptions.

---

## Phase 4: Section writing — complete protocol

**Pre-flight (load all 7 resources above)**

**Drafting rules:**
- Apply `positive_patterns.md`: lead with finding, number first, mechanism over property,
  vary sentence subjects, specific scope over vague hedge
- Apply `section_norms.md`: passive is relaxed in method; hedges allowed in scope section;
  citations required in introduction and results
- One purpose per paragraph; open with claim, close with evidence or consequence
- Never "limitation/limitations"; never announcement opener

**Post-draft — run in order:**

### Layer 1 + 2 checklist (inline)
All items from v3 Layer 1 (generic) and Layer 2 (academic) checklists.
Plus new in v4:
- [ ] Any zombie nouns ("the utilization of", "the evaluation of")? Replace with verb.
- [ ] Any comparison without named metric/baseline ("outperforms baselines")? Add specificity.
- [ ] Multiple names for the same system ("our model", "our framework", "our system")? Pick one.
- [ ] "organized as follows" paragraph? Delete it.
- [ ] Related work paragraphs lack contrast sentence? Add one.
- [ ] Abstract follows exact 4-sentence formula? Vary the structure.
- [ ] Contribution bullets all same grammatical shape? Vary them.

### Layer 3 + 4 scripts
```bash
# For .txt sections:
python scripts/slop_score.py section.txt --report

# For .tex file (preferred when working in LaTeX):
python scripts/latex_slop.py paper.tex --section results --report

# Rhythm detail:
python scripts/rhythm_check.py section.txt --fix-hints

# Compare to your writing baseline:
python scripts/corpus_compare.py section.txt
```

### Layer 4 rewrite loop (for each flagged sentence)
1. Invoke `agents/rewrite.md` with: flagged text, flag type(s), context, style profile, positive_patterns excerpt
2. Receive 3 alternatives + recommendation
3. Select or adapt the recommended rewrite
4. If still flagged after rewrite: invoke again with `ITERATION: 2`
5. Maximum 3 iterations; after that, `MANUAL_REWRITE_NEEDED` output guides the author

**Section output format:**
```markdown
## Section goal
## Draft
## Script run: slop_score / latex_slop result (score + top flags)
## Open TODOs
```

---

## Phase 4a: Contribution and abstract checks (new in v4)

After writing the introduction and abstract, run dedicated checks:

```bash
# Check contribution bullets:
python scripts/contribution_checker.py introduction.txt --abstract abstract.txt

# Check abstract:
python scripts/abstract_scorer.py abstract.txt --limit 150
```

Both exit with code 1 if issues found — treat as blocking for submission-ready.

---

## Phase 5: Citation management (unchanged from v3)

Anti-hallucination protocol: DBLP → DOI → `% [VERIFY]`.

---

## Phase 6: Reviewer simulation

Six-axis scoring (0–100). `academic_style` capped ≤55 if `latex_slop.py` or `slop_score.py`
exits with code 1. Run `slop_score.py` on the full draft before finalising scores.

---

## Phase 7: Final submission audit

**Script gate (run all five):**
```bash
python scripts/latex_slop.py paper.tex          # must score ≥ 70
python scripts/abstract_scorer.py abstract.txt  # must pass
python scripts/contribution_checker.py intro.txt --abstract abstract.txt  # must score ≥ 70
python scripts/corpus_compare.py full_paper.txt # no RED flags
# (optional) compare to previous draft:
python scripts/slop_diff.py draft_v1.txt draft_v2.txt
```

**Claim audit:** run `/paper-claim-audit` or manual cross-check.

**Final verdict:** not ready / nearly ready / ready with minor fixes / ready

---

## Phase 8: Rebuttal (unchanged from v3)

Classify → respond → no invented experiments → re-run slop gate after revision.

---

## Language polishing — master rule set

**Standard:** "prove" → "show/suggest/demonstrate"; "obviously" → remove; "limitation" → assumption/condition.

**Positive patterns (from `references/positive_patterns.md`):**
- Lead with the finding or the number
- Name the mechanism, not the property
- Vary the subject of consecutive sentences
- Specific scope over vague hedge
- Open paragraph with claim, close with evidence or consequence

**Generic bans:** adverbs, passive, binary contrasts, throat-clearing, em dashes, Wh- starters, three-item lists, vague declaratives.

**Academic bans:** announcement openers, false humility, filler observations, unquantified superlatives, hedge stacking, uniform bullets, zombie nouns, context-free comparisons, synonym drift.

---

## Non-negotiable rules (v4 additions in bold)

1. No fabrication
2. User materials only
3. Mark gaps TODO
4. Evidence for every strong claim
5. No hype without proof
6. Venue rules
7. Internal consistency
8. Preserve meaning
9. Precision over breadth
10. Source isolation
11. No "limitation/limitations"
12. Zero slop — four layers pass before delivery
13. **Section norms apply** — load `section_norms.md` before flagging; don't penalise passive in method when actor is the system
14. **Positive patterns applied** — drafting uses `positive_patterns.md`, not just ban lists
15. **Exceptions respected** — load `exceptions.md`; do not flag whitelisted patterns

---

## Quality gates

1. Input gate
2. Evidence extraction gate
3. Outline gate
4. Citation verification gate
5. Citation integration gate
6. Numeric integrity gate
7. Figure/table gate
8. Draft sanity gate
9. **Slop gate** — `latex_slop.py` ≥ 70; all four layers pass
10. **Contribution gate** — `contribution_checker.py` ≥ 70   ★ NEW
11. **Abstract gate** — `abstract_scorer.py` passes          ★ NEW
12. Refinement gate
13. Claim-audit gate

---

## Sub-agent delegation

| Task | Agent | When |
|------|-------|------|
| Reviewer simulation | `agents/reviewer.md` | After draft |
| Claim-evidence grading | `agents/grader.md` | After drafting |
| Literature search | `agents/literature_searcher.md` | Building bibliography |
| Style + slop audit | `agents/style_checker.md` | After any prose section |
| Sentence rewrite (iterative) | `agents/rewrite.md` | Per flagged sentence ★ |
| Experiment integrity | `agents/experiment_auditor.md` | After experiments |
| Claim-number audit | `agents/claim_auditor.md` | After any draft with numbers |
