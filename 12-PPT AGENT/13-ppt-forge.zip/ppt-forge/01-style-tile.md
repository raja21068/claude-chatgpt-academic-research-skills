---
name: ppt-style-tile
description: PPT 风格定调流程 — 先做 1-2 张核心页定义 CSS 基调，审过再批量生产，避免 20 页全做完才发现方向不对。B 场景详细流程。
---

# 01 · 风格定调（B 场景）

> 来源原则：2026-04-04 决策 — "不能 20 页全做完再审，先定调再批量"

## 原则

**先做 1-2 张核心页定调 CSS 基调，审过再批量生产。**

核心页 = 封面 + 最复杂的内容页。这两页定义了整套 PPT 的视觉基因。

## 触发条件

- A 场景（内容规划）的大纲已确认
- 开局参数（品牌 / 受众 / 场景 / 观看方式 / archetype）已声明

## 流程

### 1. Author 制作 2 张核心页

- **封面**：标题 + 副标题 + 品牌色 + 日期/署名
- **最复杂内容页**：双列 / 多元素混合布局，能体现密度上限

### 2. 提取 CSS 变量

从核心页中提炼出可复用的设计 token：

```css
:root {
  --brand-primary: #c7020e;    /* 华为红 */
  --brand-secondary: #1a1a1a;  /* 黑 */
  --bg-slide: #ffffff;
  --bg-card: #fafafa;
  --text-title: 18px;
  --text-body: 10px;
  --text-caption: 8px;
  --gap-tight: 2px;
  --gap-normal: 4px;
  --padding-card: 4px 6px;
  --radius-card: 0px;          /* 华为=直角 */
}
```

### 3. D2 reviewer 审定风格

D2 reviewer 审查核心页，确认：

- [ ] 品牌色正确
- [ ] 字体层级合理（标题 / 正文 / 标注）
- [ ] 卡片 / 模块风格统一
- [ ] 整体氛围匹配目标品牌
- [ ] 观看方式适配（大屏字够大 / PDF 密度够高）

### 4. 输出：Style Tile

确认后产出一个 Style Tile 文档（或直接在核心页 HTML 中注释），包含：

- 品牌色板
- 字体层级表
- 间距 / 圆角规范
- 图标风格约定（线框 or 面性）
- 参考截图

### 5. 进入 C 场景

Style Tile 确认后，author 按确定的 CSS 变量批量制作剩余 slide（见 [02-slide-authoring.md](02-slide-authoring.md)）。

## 常见风格差异速查

| 维度 | 华为 | Apple | 阿里 |
|------|------|-------|------|
| 主色 | 红/黑/灰 | 黑/白/渐变 | 橙/科技蓝 |
| 圆角 | 直角（0px） | 大圆角（12-16px） | 中圆角（8px） |
| 密度 | 高（模块化 Boxy） | 极低（每页一件事） | 中高（Dashboard） |
| 字重 | 粗体标语 + 细体数据 | 超大超粗标题 | 中等偏细 |
| 图标 | 面性 / 实心 | 线框 / SF Symbols | Ant Design 线框 |
| 留白 | 最小化 | 最大化 | 适度 |
